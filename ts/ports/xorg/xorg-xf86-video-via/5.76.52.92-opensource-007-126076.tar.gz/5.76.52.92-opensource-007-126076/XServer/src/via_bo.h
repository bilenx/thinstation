/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef VIA_BO_H
#define VIA_BO_H
#include <xf86drm.h>
#include "via_chrome9_drm.h"

struct generic_bo_bufmgr;


/* The generic bo definition */
struct generic_bo {
   /** Size in bytes of the buffer object. */
    unsigned long size;
   /**
    * Card virtual address (offset from the beginning of the aperture) for the
    * object.  Only valid while validated.
    */
    unsigned long offset;
   /**
    * Virtual address for accessing the buffer data.  Only valid while mapped.
    */
    void *virtual;
   /** Buffer manager context associated with this buffer object */
   struct generic_bo_bufmgr *bufmgr;
};

/* The generic bo buffer management context */
struct generic_bo_bufmgr {
   /**
    * Allocate a buffer object.
    *
    * Buffer objects are not necessarily initially mapped into CPU virtual
    * address space or graphics device aperture.  They must be mapped using
    * bo_map() to be used by the CPU, and validated for use using bo_validate()
    * to be used from the graphics device.
    */
   struct generic_bo *(*bo_alloc)(struct generic_bo_bufmgr *bufmgr_ctx,
        const char *name, unsigned long size, unsigned int alignment,
        uint32_t location_mask);

   /** Takes a reference on a buffer object */
    void (*bo_reference)(struct generic_bo *bo);

   /**
    * Releases a reference on a buffer object, freeing the data if
    * rerefences remain.
    */
    void (*bo_unreference)(struct generic_bo *bo);

   /**
    * Maps the buffer into userspace.
    */
    int (*bo_map)(struct generic_bo *buf, int write_enable);

   /** Reduces the refcount on the userspace mapping of the buffer object. */
    int (*bo_unmap)(struct generic_bo *buf);

    /** build the reloc list for buffer object valid. */
    int (*bo_reloc)(unsigned int *buffer_ptr, unsigned long offset,
                                struct generic_bo *target_bo, uint32_t delta,
                                uint32_t location_mask,
                                enum drm_via_chrome9_reloc_type type);
    /** for branch buffer reloc */
    int (*bo_branch_buffer_reloc)(struct via_cmd_buffer_obj *cmd_bo,
                                unsigned long offset,
                                struct generic_bo *target_bo, uint32_t delta,
                                uint32_t location_mask,
                                enum drm_via_chrome9_reloc_type type);
    /** set command type in one flush when necessary */
    void (*bo_set_cmd_type)(struct generic_bo *buf, unsigned int cmd_type);
    /** flush the command */
    int (*bo_flush)(struct generic_bo *buf, unsigned int *buffer_ptr,
                                int length,
                                drm_clip_rect_t * cliprects,
                                int num_cliprects);
    /** Creat a global name for this bo */
    int (*bo_flink)(struct generic_bo *bo, unsigned int *name);

    /** Get the global bo with the global name */
   struct generic_bo *(*bo_open)(struct generic_bo_bufmgr *bufmgr_ctx,
                                 unsigned int global_name,
                                 unsigned int location_mask);
    /*wait bo idle*/
    int (*bo_wait)(struct generic_bo *bo);

    /* bo is idle */
    int (*bo_is_idle)(struct generic_bo *bo);

    /* set bo to cpu domain*/
    int (*bo_set_cpu_domain)(struct generic_bo *bo, int write_enable);

    /* cpu grab/release bo */
    int (*bo_cpu_grab)(struct generic_bo *bo);
    int (*bo_cpu_release)(struct generic_bo *bo);

    /* branch buffer ops*/
    int (*bo_branch_buffer_init)(struct generic_bo_bufmgr *bufmgr,
                                 int buf_num, int buf_size);
    int (*bo_branch_buffer_get)(struct generic_bo_bufmgr *bufmgr,
                                uint32_t cmd_type,
                                struct via_cmd_buffer_obj *);
    int (*bo_branch_buffer_flush)(struct via_cmd_buffer_obj *cmd_bo,
                                  int length, drm_clip_rect_t *cliprects,
                                  int num_cliprects);
    void (*bo_branch_buffer_finish)(struct generic_bo_bufmgr *bufmgr);
    /* disable bo reuse */
    void (*bo_disable_reuse)(struct via_bo *vbo);

    /* end */

    /* drm file description*/
    int drmfd;
};

struct generic_bo *dri_bo_alloc(struct generic_bo_bufmgr *bufmgr,
                                const char *name,
                                unsigned long size,
                                unsigned int alignment,
                                uint64_t location_mask);
void dri_bo_reference(struct generic_bo *bo);
void dri_bo_unreference(struct generic_bo *bo);
int dri_bo_map(struct generic_bo *buf, int write_enable);
int dri_bo_unmap(struct generic_bo *buf);
int dri_bo_reloc(unsigned int *buffer_ptr, unsigned long offset,
                 struct generic_bo *target_bo, uint32_t delta,
                 uint32_t location_mask,
                 enum drm_via_chrome9_reloc_type type);
int dri_bo_branch_buffer_reloc(struct via_cmd_buffer_obj *cmd_bo,
                 unsigned long offset,
                 struct generic_bo *target_bo, uint32_t delta,
                 uint32_t location_mask,
                 enum drm_via_chrome9_reloc_type type);
void dri_bo_set_cmd_type(struct generic_bo *buf, uint32_t cmd_type);
int dri_bo_flush(struct generic_bo *buf,
                 unsigned int *buffer_ptr, int length,
                 drm_clip_rect_t * cliprects,
                 int num_cliprects);
int dri_bo_flink(struct generic_bo *buf, unsigned int *name);
int dri_bo_set_cpu_domain(struct generic_bo *buf);
int dri_bo_cpu_grab(struct generic_bo *buf);
int dri_bo_cpu_release(struct generic_bo *buf);
struct generic_bo *dri_bo_open(struct generic_bo_bufmgr *bufmgr,
                               unsigned int global_name,
                               unsigned int location_mask);
int dri_bo_wait(struct generic_bo *buf);
int dri_bo_is_idle(struct generic_bo *buf);
int dri_bo_branch_buffer_init(struct generic_bo_bufmgr *bufmgr,
                              int buf_num, int buf_size);
int dri_bo_branch_buffer_get(struct generic_bo_bufmgr *bufmgr,
                         uint32_t cmd_type,
                         struct via_cmd_buffer_obj *buf_bo);
int dri_bo_branch_buffer_flush(struct via_cmd_buffer_obj *cmd_bo, int length,
                               drm_clip_rect_t * cliprects,
                               int num_cliprects);
void dri_bo_branch_buffer_finish(struct generic_bo_bufmgr *bufmgr);

#endif
