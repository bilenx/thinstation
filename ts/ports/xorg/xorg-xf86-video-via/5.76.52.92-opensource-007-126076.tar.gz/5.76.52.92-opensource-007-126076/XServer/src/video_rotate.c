/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * INCLUDES
 */
#include "debug.h"               /* for DBG_DD */
#include "via_eng_regs.h"
#include "via_driver.h"
#include "via_rotate.h"               /* for rotate feature. */
#include "h1hwreg.h"
#include "via_drm.h"
#include "agpctl.h"
#include "via_video.h"
#include "via_eng_reg_fops.h"

extern unsigned long vfCMHQVR(unsigned long dwIndex, ScrnInfoPtr pScrn,
    viaPortPrivPtr pPriv);
extern void vfHM(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv,
    unsigned long dwFunSel);

/*use 3D engines to rotate an  area to the direction as specified by rotDirect */
/*When with TTM, the src and dst bo information be passed to 3D engine,
 *so change the function viaHWRotation*/
static void
viaHWRotation(VIAPtr pVia, unsigned long dst, unsigned long src,
    unsigned long dstPitch, unsigned long srcPitch, unsigned long srcHeight,
    unsigned long srcWidth, unsigned long dstHeight, unsigned long dstWidth,
    int rotDirect, struct generic_bo *srcBo, struct generic_bo *dstBo)
{
    ScrnInfoPtr pScrn = xf86Screens[pVia->pBIOSInfo->scrnIndex];

    viaTexture3DBltSrcRec texBltSrc;
    viaTexture3DBltDstRec texBltDst;
    viaTexture3DBltRotationRec texBltRotation;
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    memset(&texBltSrc, 0x00, sizeof(texBltSrc));
    memset(&texBltDst, 0x00, sizeof(texBltDst));
    memset(&texBltRotation, 0x00, sizeof(texBltRotation));

    if (pVia->ChipId == VIA_DEVICE_VT3314)
        texBltSrc.format = PIXMAN_yuy2;
    else
        texBltSrc.format = PICT_r5g6b5;

    texBltDst.format = PICT_r5g6b5;

    /* The dstWidth and dstHeight is swapped before in 90/270 case,
       so we must recorve it here. */
    if (rotDirect & (VIA_ROTATE_DEGREE_90 | VIA_ROTATE_DEGREE_270)) {
        EXCHANGE(dstWidth, dstHeight);
    }
#ifdef VIA_HAVE_UXA
    texBltDst.dstBo = dstBo;           /*3D engine dstBo */
    texBltDst.Bo_delta = dst - dstBo->offset;
#else
    texBltDst.offset = dst;
#endif
    texBltDst.pitch = dstPitch;
    texBltDst.x = 0;
    texBltDst.y = 0;
    texBltDst.w = dstWidth;
    texBltDst.h = dstHeight;

#ifdef VIA_HAVE_UXA
    texBltSrc.srcBo = srcBo; /*3D engine srcBo, i.e. HQV surface related BO */
    texBltSrc.Bo_delta = src - srcBo->offset;
    texBltSrc.srcBo_udelta = 0;
    texBltSrc.srcBo_vdelta = 0;
#else
    texBltSrc.offset = src;
#endif
    texBltSrc.pitch = srcPitch;
    texBltSrc.x = 0;
    texBltSrc.y = 0;
    texBltSrc.w = srcWidth;
    texBltSrc.h = srcHeight;
    texBltSrc.surfwidth = srcWidth;
    texBltSrc.surfheight = srcHeight;
    texBltSrc.filter = ((texBltSrc.w == texBltDst.w)
        && (texBltSrc.h ==
        texBltDst.h)) ? via_FilterNearest : via_FilterBilinear;
    texBltSrc.memLoc = LOC_SL;
    texBltRotation.rotate = VIA_TO_RR(rotDirect);
    texBltRotation.width = dstWidth;
    texBltRotation.height = dstHeight;

    viaAccelTexture3DBlt(pScrn, &texBltSrc, &texBltDst, &texBltRotation,
        NULL);
}

/* rotate a video to the direction as specified */
void
viaHWVideoRotation(ScrnInfoPtr pScrn, viaPortPrivPtr pPriv)
{
    VIAPtr pVia = VIAPTR(pScrn);
    PVIDDATA pVidData = pVia->pVIAEnt->pVidData;
    LPOVERLAYRECORD lpOverlayRecord = &pPriv->ovlInfo[pPriv->curIGA - 1];
    viaGfxInfoPtr viaGfxInfo = pVidData->viaGfxInfo;

    unsigned long *pVideoFlag = &pPriv->videoFlag;
    ViaXvRectRec rSrc = lpOverlayRecord->dwOverlaySrcRect;
    ViaXvRectRec rDest = lpOverlayRecord->dwOverlayDestRect;
    int rot = 0;
    int reflect = 0;
    int rrDegree = 0;               /*Rotate and Reflect information */
    unsigned long hqvBufIndex = 0, rotBufIndex = 0;
    unsigned long srcWidth = 0, srcHeight = 0, srcPitch = 0;
    unsigned long dstWidth = 0, dstHeight = 0, dstPitch = 0;
    unsigned long srcAddr = 0, dstAddr = 0;

    DBG_DD(("Enter Function : %s\n", __FUNCTION__));

    if (((*pVideoFlag & VIDEO_1_SHOW) == 0)
        && ((*pVideoFlag & VIDEO_3_SHOW) == 0)) {
        return;
    }

    rot =
        viaGfxInfo->igaInfo[pPriv->curIGA -
        1].igaRRStatus.unit & VIA_ROTATE_DEGREE_ALL;
    reflect =
        viaGfxInfo->igaInfo[pPriv->curIGA -
        1].igaRRStatus.unit & VIA_ROTATE_REFLECT_ALL;

    srcWidth = pPriv->pHqvSurface[pPriv->curIGA - 1]->width;
    srcHeight = pPriv->pHqvSurface[pPriv->curIGA - 1]->height;
    srcPitch = pPriv->pHqvSurface[pPriv->curIGA - 1]->pitch;

    dstWidth = pPriv->pRotSurface[pPriv->curIGA - 1]->width;
    dstHeight = pPriv->pRotSurface[pPriv->curIGA - 1]->height;
    dstPitch = pPriv->pRotSurface[pPriv->curIGA - 1]->pitch;

    DBG_DD(("  dstHeight:%ld,  dstWidth:%ld,  srcHeight:%ld,  srcWidth:%ld\n",
        dstHeight, dstWidth, srcHeight, srcWidth));
    DBG_DD(("  dstpitch= %ld,  srcPitch =%ld\n", dstPitch, srcPitch));

    switch (rot) {
    case VIA_ROTATE_DEGREE_90:
    case VIA_ROTATE_DEGREE_270:
        if (reflect == VIA_ROTATE_REFLECT_X) {
            reflect = VIA_ROTATE_REFLECT_Y;
        } else if (reflect == VIA_ROTATE_REFLECT_Y) {
            reflect = VIA_ROTATE_REFLECT_X;
        }
        break;
    default:
        break;
    }

    rrDegree = rot | reflect;

    hqvBufIndex = vfCMHQVR(HQV_CONTROL, pScrn, pPriv);
    rotBufIndex = pPriv->pRotSurface[pPriv->curIGA - 1]->cur_idx;

    dstAddr = pPriv->pRotSurface[pPriv->curIGA - 1]->offset[rotBufIndex];

    switch (hqvBufIndex & 0x6) {
    case 0:                   /*working on buf 0 */
        DBG_DD(("  Rotate Src on HQV Buf 2\n"));
        srcAddr = pPriv->pHqvSurface[pPriv->curIGA - 1]->offset[2];
        break;
    case 2:                   /*working on buf 1 */
        DBG_DD(("  Rotate Src on HQV Buf 0\n"));
        srcAddr = pPriv->pHqvSurface[pPriv->curIGA - 1]->offset[0];
        break;
    case 4:                   /*working on buf 2 */
        DBG_DD(("  Rotate Src on HQV Buf 1\n"));
        srcAddr = pPriv->pHqvSurface[pPriv->curIGA - 1]->offset[1];
        break;
    default:
        break;
    }

    viaHWRotation(pVia, dstAddr, srcAddr, dstPitch, srcPitch,
        srcHeight, srcWidth, dstHeight, dstWidth, rrDegree,
        pPriv->hqvMem[pPriv->curIGA - 1].bo,
        pPriv->rotMem[pPriv->curIGA - 1].bo);

    /* wait 3D engine idle because image jitter is quite noticeable when playing HD video */
    Command_CRSync_Video(&pVia->cb, (unsigned int)pVia->ChipId,
        FLAG_WAIT_2D_IDLE | FLAG_WAIT_3D_IDLE);
}
