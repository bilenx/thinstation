/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
#ifndef VIA_EXA_COMMON_H
#define VIA_EXA_COMMON_H

#include "via_driver.h"
#include "via_regs.h"
#include "via_eng_regs.h"
#include "via_rotate.h"		       /* add by STChen, for rotate feature. */
#include "agpctl.h"
#include "exa.h"
#include "via_3d.h"
#include "Xarch.h"
#include "macros.h"
#include "xaarop.h"

static int VIACopyROP[16] = {
    ROP_0,			       /* GXclear */
    ROP_DSa,			       /* GXand */
    ROP_SDna,			       /* GXandReverse */
    ROP_S,			       /* GXcopy */
    ROP_DSna,			       /* GXandInverted */
    ROP_D,			       /* GXnoop */
    ROP_DSx,			       /* GXxor */
    ROP_DSo,			       /* GXor */
    ROP_DSon,			       /* GXnor */
    ROP_DSxn,			       /* GXequiv */
    ROP_Dn,			       /* GXinvert */
    ROP_SDno,			       /* GXorReverse */
    ROP_Sn,			       /* GXcopyInverted */
    ROP_DSno,			       /* GXorInverted */
    ROP_DSan,			       /* GXnand */
    ROP_1			       /* GXset */
};

static int VIACopyROP_PM[16] = {
    ROP_0,			       /* not used */
    ROP_DSPnoa,
    ROP_DPSnaon,
    ROP_DPSDxax,
    ROP_DPSana,
    ROP_D,			       /* not used */
    ROP_DPSax,
    ROP_DPSao,
    ROP_DPSaon,
    ROP_DPSaxn,
    ROP_Dn,			       /* not used */
    ROP_DPSanan,
    ROP_PSDPxox,		       /* is that correct ? */
    ROP_DPSnao,
    ROP_DSPnoan,
    ROP_1			       /* not used */
};

static int VIAPatternROP[16] = {
    ROP_0,
    ROP_DPa,
    ROP_PDna,
    ROP_P,
    ROP_DPna,
    ROP_D,
    ROP_DPx,
    ROP_DPo,
    ROP_DPon,
    ROP_PDxn,
    ROP_Dn,
    ROP_PDno,
    ROP_Pn,
    ROP_DPno,
    ROP_DPan,
    ROP_1
};

static int VIAPatternROP_PM[16] = {
    ROP_DPna,
    ROP_DPSnoa,
    ROP_DSPnaon,
    ROP_DSPDxax,
    ROP_DPSana,
    ROP_D,
    ROP_DPSax,
    ROP_DPSao,
    ROP_DPSaon,
    ROP_DPSaxn,
    ROP_DPx,
    ROP_DPSanan,
    ROP_SPDSxox,		       /* is that correct ? */
    ROP_DSPnao,
    ROP_DPSnoan,
    ROP_DPo
};

#define VIAACCELPATTERNROP(vRop) (VIAPatternROP[vRop] << 24)
#define VIAACCELCOPYROP(vRop) (VIACopyROP[vRop] << 24)

/* define driver pixmap private */
struct via_pixmap
{
    struct generic_bo *pbo;
    unsigned int location;
    unsigned int current_domain;
    unsigned int accel_blocked;
};

#define UXA_RANGE_PITCH (1 << 0)
#define UXA_RANGE_WIDTH (1 << 1)
#define UXA_RANGE_HEIGHT (1 << 2)

#define VIA_ALIGN(x,bytes) (((x) + ((bytes) - 1)) & ~((bytes) - 1))

extern ExaDriverPtr viaInitExa(ScreenPtr pScreen);
extern void viaExa3DInit(ScreenPtr pScreen);
extern void viaExa2DInit(ScreenPtr pScreen);
extern void viaAccelSync(ScrnInfoPtr pScrn);
Bool viaCheckUpload(ScrnInfoPtr pScrn, Via3DState * v3d);
struct via_pixmap *via_get_uxa_pixmap(PixmapPtr pixmap);
#endif
