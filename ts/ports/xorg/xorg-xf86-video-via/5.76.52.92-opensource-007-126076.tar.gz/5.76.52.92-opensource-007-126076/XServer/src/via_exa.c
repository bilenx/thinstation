/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*************************************************************************
 *
 *  File:       via_exa.c
 *  Content:    2D acceleration function for VIA/S3G UniChrome
 *
 ************************************************************************/
#include "via_exa_common.h"
#include "via_dri.h"
#include "via_dmabuffer.h"
#include "via_bo_gem.h"

#include <os.h>
#define RESERVED_FIX_SIZE (1024*1024)

#if HAS_DEVPRIVATEKEYREC
DevPrivateKeyRec uxa_pixmap_index;
#else
int uxa_pixmap_index;
#endif

extern Bool via_module_loaded;	       /*Flag for vva submodule for DDMpeg */

/* declare useful interfaces for Exa Initialization */
static CARD32 viaBitExpandHelper(CARD32 pixel, CARD32 bits);
static Bool viaAccelSetMode(int bpp, unsigned format, unsigned rotate,
    unsigned alphaCnst, unsigned alphaVaule, ViaTwodContext * tdc);
static Bool viaAccelPlaneMaskHelper(ViaTwodContext * tdc, CARD32 planeMask);
static void viaAccelTransparentHelper(ViaTwodContext * tdc,
    ViaCommandBuffer * cb, CARD32 keyControl, CARD32 transColor,
    Bool usePlaneMask);
static void viaAccelCopyHelper(ViaCommandBuffer * cb, int xs, int ys, int xd,
    int yd, int w, int h, CARD32 cmd);
static void viaAccelSolidHelper(ViaCommandBuffer * cb, int x, int y, int w,
    int h, CARD32 cmd);
static Bool viaAccelScalingHelper_410(Bool ENscale, unsigned Vfactor,
    unsigned Hfactor, Bool Shrink, unsigned scaleMode, unsigned h, unsigned w,
    ViaTwodContext * tdc);
static Bool viaAccelCFCHelper_410(Bool enCFC, Bool Extend0,
    Bool DirthModeRouding, unsigned dstCFMode, unsigned srcCFMode,
    unsigned srcDep, ViaTwodContext * tdc);
static Bool viaAccelSet410Helper(ViaCommandBuffer * cb, ViaTwodContext * tdc);

/*static void viaAccelSync(ScrnInfoPtr pScrn);*/
static void viaAccelWaitMarker(ScreenPtr pScreen, int marker);
static int viaAccelMarkSync(ScreenPtr pScreen);

static Bool viaExaPrepareCopy(PixmapPtr pSrcPixmap, PixmapPtr pDstPixmap,
    int xdir, int ydir, int alu, Pixel planeMask);
static void viaExaCopy(PixmapPtr pDstPixmap, int srcX, int srcY, int dstX,
    int dstY, int width, int height);
static void viaExaDoneCopy(PixmapPtr pPixmap);

static Bool viaExaPrepareSolid(PixmapPtr pPixmap, int alu, Pixel planeMask,
    Pixel fg);
static void viaExaSolid(PixmapPtr pPixmap, int x1, int y1, int x2, int y2);
static void viaExaDoneSolid(PixmapPtr pPixmap);
static Bool viaExaCheckComposite(int op, PicturePtr pSrcPicture,
    PicturePtr pMaskPicture, PicturePtr pDstPicture, int width, int height);
static Bool viaExaPrepareComposite(int op, PicturePtr pSrcPicture,
    PicturePtr pMaskPicture, PicturePtr pDstPicture, PixmapPtr pSrc,
    PixmapPtr pMask, PixmapPtr pDst);
static void viaExaComposite(PixmapPtr pDst, int srcX, int srcY, int maskX,
    int maskY, int dstX, int dstY, int width, int height);
static void viaExaDoneComposite(PixmapPtr pDst);

#ifdef VIA_HAVE_UXA
static void *viaUxaCreatePixmap2(ScreenPtr pScreen, int width, int height,
    int depth, int usage_hint, int bitsPerPixel, int *new_fb_pitch);
static void *viaUxaCreatePixmap(ScreenPtr pScreen, int size, int align);
static Bool viaUxaModifyPixmapHeader(PixmapPtr pPixmap, int width, int height,
    int depth, int bitsPerPixel, int devKind, pointer pPixData);
static void viaUxaDestroyPixmap(ScreenPtr pScreen, void *driverPriv);

static Bool viaUxaPixmapIsOffscreen(PixmapPtr pPix);
static Bool viaUxaPrepareAccess(PixmapPtr pPix, int index);
static void viaUxaFinishAccess(PixmapPtr pPix);
static Bool via_uxa_check_2d_pitch(PixmapPtr pixmap);
static Bool via_uxa_check_3d_pitch(PixmapPtr pixmap);

static Bool
viaUxaPutImage(PixmapPtr pDst,
    int x, int y, int w, int h, char *src, int src_pitch);
static Bool
viaUxaGetImage(PixmapPtr pSrc,
    int x, int y, int w, int h, char *dst, int dst_pitch);

#endif

static void viaExaSetupFuncTable(ExaDriverPtr pExa, ScreenPtr pScreen);
static void viaInit2DState(ViaTwodContext * td, int Chipid);
static void via_exa_set_pixmap_bo(PixmapPtr pPix, struct generic_bo *bo);

/* ------------------------------------------------- */

ExaDriverPtr
viaInitExa(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    int dimension, mem4ddmpeg = 0, tmpFreeEnd;
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    /*3*mode size + 1*Onscreen size for RandR rotate and 3D Desktop */
    int reserve4drm =
        ((pScrn->virtualY * pVia->Bpl) +
        3 * pBIOSInfo->HDisplay * pBIOSInfo->VDisplay * 4);
#ifndef VIA_HAVE_UXA
    double exaOffscreenSize;
#endif

    ExaDriverPtr pExa = exaDriverAlloc();

    if (!pExa)
        return NULL;

    memset(pExa, 0, sizeof(*pExa));
    pExa->exa_major = EXA_VERSION_MAJOR;
    pExa->exa_minor = EXA_VERSION_MINOR;
    pExa->memoryBase = (unsigned char *)pVia->front_bo->virtual;
    pExa->memorySize = pVia->front_bo->size;
#ifndef VIA_HAVE_UXA
    pExa->offScreenBase =
        (pScrn->displayWidth * pScrn->bitsPerPixel >> 3) * pScrn->virtualY;
#endif

    pVia->nPOT[0] = 0;
    pVia->nPOT[1] = 0;
    pExa->flags = EXA_OFFSCREEN_PIXMAPS;
#ifndef VIA_HAVE_UXA
    pExa->pixmapOffsetAlign = 256;
#endif
    pExa->pixmapPitchAlign = 32;

#ifdef VIA_HAVE_UXA
    pExa->flags |= EXA_HANDLES_PIXMAPS | EXA_SUPPORTS_PREPARE_AUX;
#endif
    pVia->set_pixmap_bo = via_exa_set_pixmap_bo;
    /* Deliver the pitch limitation to exa up layer, and relax the max dimension
     * limitation for pixmap which will be accelerated by our HW.
     * From doing this, our driver will receive pixmaps who's dimension may be
     * larger than our HW's limitation. But that is what we want, since we want
     * to accelerate pixmaps who's dimension is larger than our hw limitation,
     * while its pitch still falls into our hw range.
     */
    /* Exa version < 2.3.0 hasn't gotten "maxPitchBytes" yet.
     * So it may throw pixmap whose pitch is bigger than 
     * our hw limitation to driver, and our driver need to care about this
     */
#if EXA_VERSION_MAJOR > 2 || (EXA_VERSION_MAJOR == 2 && EXA_VERSION_MINOR >= 3)
    pExa->maxPitchBytes = (TEX_PITCH_LIMIT_INBYTE << 1) - 1;
#endif
    dimension =
        (TEX_PITCH_LIMIT_INBYTE << 1) / (pScrn->bitsPerPixel >> 3) - 1;
    /* Do not let max dimension larger than twice TEX_DIMENSION_LIMIT_INPIXEL
     * Just for helping simplify the case.
     */
    pExa->maxX = pExa->maxY =
        (dimension >
        (TEX_DIMENSION_LIMIT_INPIXEL << 1)) ? (TEX_DIMENSION_LIMIT_INPIXEL <<
        1) : dimension;

    viaExaSetupFuncTable(pExa, pScreen);

    if (!exaDriverInit(pScreen, pExa)) {
        free(pExa);
        return NULL;
    }

    viaExa3DInit(pScreen);
    viaExa2DInit(pScreen);

    xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Enable EXA Now\n");

    return pExa;
}

static void
viaExaSetupFuncTable(ExaDriverPtr pExa, ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    switch (pVia->ChipId) {
    case PCI_CHIP_VT3353:
    case PCI_CHIP_VT3409:
    case PCI_CHIP_VT3410:
        pExa->WaitMarker = viaAccelWaitMarker;
#ifndef VIA_HAVE_UXA
        pExa->MarkSync = viaAccelMarkSync;
#endif
        pExa->PrepareCopy = viaExaPrepareCopy;
        pExa->Copy = viaExaCopy;
        pExa->DoneCopy = viaExaDoneCopy;

        pExa->PrepareSolid = viaExaPrepareSolid;
        pExa->Solid = viaExaSolid;
        pExa->DoneSolid = viaExaDoneSolid;
#if XORG_VERSION_CURRENT < XF86_VERSION_NUMERIC(1,6,99,0,0) || \
    XORG_VERSION_CURRENT >= XF86_VERSION_NUMERIC(7,0,0,0,0)
	/*
	 * pExa->PixmapIsOffscreen = viaExaIsOffscreen;
	 */
#endif
	pExa->CheckComposite = viaExaCheckComposite;
	pExa->PrepareComposite = viaExaPrepareComposite;
	pExa->Composite = viaExaComposite;
	pExa->DoneComposite = viaExaDoneComposite;
#ifdef VIA_HAVE_UXA
	pExa->PixmapIsOffscreen = viaUxaPixmapIsOffscreen;
	pExa->PrepareAccess = viaUxaPrepareAccess;
	pExa->FinishAccess = viaUxaFinishAccess;
	pExa->DestroyPixmap = viaUxaDestroyPixmap;
#if 0
	pExa->UploadToScreen = viaUxaPutImage;
	pExa->DownloadFromScreen = viaUxaGetImage;
#endif
#if EXA_VERSION_MAJOR == 2 && EXA_VERSION_MINOR == 5
	pExa->CreatePixmap2 = viaUxaCreatePixmap2;
#else
	pExa->CreatePixmap = viaUxaCreatePixmap;
	/*XXX if no special alignment required, viaUxaModifyPixmapHeader
	 * is not necessary since the pitch alignment is caculated earlier
	 pExa->ModifyPixmapHeader = viaUxaModifyPixmapHeader;
	 */
#endif
#endif
        break;
    default:
        ErrorF("Unsupported ChipID\n");
        break;
    }

}

void
viaExa2DInit(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    switch (pVia->ChipId) {
    case PCI_CHIP_VT3353:
    case PCI_CHIP_VT3409:
    case PCI_CHIP_VT3410:
        viaInit2DState(&pVia->td, pVia->ChipId);
        break;
    default:
        ErrorF("Unsupported ChipID\n");
        break;
    }
}

void
viaExa3DInit(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    switch (pVia->ChipId) {
    case PCI_CHIP_VT3353:
    case PCI_CHIP_VT3409:
        pVia->v3d.chipset410 = FALSE;
        viaInit3DState(&pVia->v3d);
        break;
    case PCI_CHIP_VT3410:
        pVia->v3d.chipset410 = TRUE;
        viaInit3DState(&pVia->v3d);
        break;
    default:
        ErrorF("Unsupported ChipID\n");
        break;
    }
}

static Bool
viaIsOffscreen(VIAPtr pVia, PixmapPtr pPix)
{
    return ((unsigned long)pPix->devPrivate.ptr -
        (unsigned long)pVia->FBBase) < pVia->videoRambytes;
}

static Bool
viaExaIsOffscreen(PixmapPtr pPix)
{
    ScreenPtr pScreen = pPix->drawable.pScreen;
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    return ((unsigned long)pPix->devPrivate.ptr -
        (unsigned long)pVia->FBBase) <
        pVia->front_bo->size /*pVia->videoRambytes */ ;
}

/*
 * Check if the above function will work.
 */
static Bool
viaExpandablePixel(int format)
{
    int formatType = PICT_FORMAT_TYPE(format);

    return (formatType == PICT_TYPE_A ||
        formatType == PICT_TYPE_ABGR || formatType == PICT_TYPE_ARGB);
}

/*
 * Check if we need to force upload of the whole 3D state (when other
 * clients or subsystems have touched the 3D engine). Also tell DRI
 * clients and subsystems that we have touched the 3D engine.
 */
Bool
viaCheckUpload(ScrnInfoPtr pScrn, Via3DState * v3d)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    Bool forceUpload;

    forceUpload = (pVia->lastToUpload != v3d);
    pVia->lastToUpload = v3d;

#ifdef XF86DRI
    if (pVia->driType == DRI_1) {
        volatile drm_via_sarea_t *saPriv = (drm_via_sarea_t *)
            DRIGetSAREAPrivate(pScrn->pScreen);
        int myContext = DRIGetContext(pScrn->pScreen);

        forceUpload = forceUpload || (saPriv->ctxOwner != myContext);
        saPriv->ctxOwner = myContext;
    }
#endif
    return (forceUpload);
}

/*
 * Extract the components from a pixel of the given format to an argb8888 pixel.
 * This is used to extract data from one-pixel repeat pixmaps.
 * Assumes little endian.
 */
static void
viaPixelARGB8888(unsigned format, void *pixelP, CARD32 *argb8888)
{
    CARD32 bits, shift, pixel, bpp;

    bpp = PICT_FORMAT_BPP(format);

    if (bpp <= 8) {
        pixel = *((CARD8 *) pixelP);
    } else if (bpp <= 16) {
        pixel = *((CARD16 *) pixelP);
    } else {
        pixel = *((CARD32 *) pixelP);
    }

    switch (PICT_FORMAT_TYPE(format)) {
    case PICT_TYPE_A:
        bits = PICT_FORMAT_A(format);
        *argb8888 = viaBitExpandHelper(pixel, bits) << 24;
        return;
    case PICT_TYPE_ARGB:
        shift = 0;
        bits = PICT_FORMAT_B(format);
        *argb8888 = viaBitExpandHelper(pixel, bits);
        shift += bits;
        bits = PICT_FORMAT_G(format);
        *argb8888 |= viaBitExpandHelper(pixel >> shift, bits) << 8;
        shift += bits;
        bits = PICT_FORMAT_R(format);
        *argb8888 |= viaBitExpandHelper(pixel >> shift, bits) << 16;
        shift += bits;
        bits = PICT_FORMAT_A(format);
        *argb8888 |= ((bits) ? viaBitExpandHelper(pixel >> shift,
            bits) : 0xFF) << 24;
        return;
    case PICT_TYPE_ABGR:
        shift = 0;
        bits = PICT_FORMAT_B(format);
        *argb8888 = viaBitExpandHelper(pixel, bits) << 16;
        shift += bits;
        bits = PICT_FORMAT_G(format);
        *argb8888 |= viaBitExpandHelper(pixel >> shift, bits) << 8;
        shift += bits;
        bits = PICT_FORMAT_R(format);
        *argb8888 |= viaBitExpandHelper(pixel >> shift, bits);
        shift += bits;
        bits = PICT_FORMAT_A(format);
        *argb8888 |= ((bits) ? viaBitExpandHelper(pixel >> shift,
            bits) : 0xFF) << 24;
        return;
    default:
        break;
    }
    return;
}

/*
 * Helper for bitdepth expansion.
 */
static CARD32
viaBitExpandHelper(CARD32 pixel, CARD32 bits)
{
    CARD32 component, mask, tmp;

    component = pixel & ((1 << bits) - 1);
    mask = (1 << (8 - bits)) - 1;
    tmp = component << (8 - bits);
    return ((component & 1) ? (tmp | mask) : tmp);
}

static void
via_ExaMoveDwords(CARD32 * dest, CARD32 * src, int dwords)
{
    while (dwords & ~0x03) {
        *dest = *src;
        *(dest + 1) = *(src + 1);
        *(dest + 2) = *(src + 2);
        *(dest + 3) = *(src + 3);
        src += 4;
        dest += 4;
        dwords -= 4;
    }
    if (!dwords)
        return;
    *dest = *src;
    if (dwords == 1)
        return;
    *(dest + 1) = *(src + 1);
    if (dwords == 2)
        return;
    *(dest + 2) = *(src + 2);
}

static void
viaInit2DState(ViaTwodContext * td, int Chipid)
{
    td->setModeHelper = viaAccelSetMode;
    td->planeMaskHelper = viaAccelPlaneMaskHelper;
    td->transparentHelper = viaAccelTransparentHelper;
    td->copyHelper = viaAccelCopyHelper;
    td->solidHelper = viaAccelSolidHelper;
    td->ScalingHelper_H6_410 = NULL;
    td->CFCHelper_H6_410 = NULL;
    td->Set410Helper_H6 = NULL;
    td->Chipid = 0;
    if (Chipid == PCI_CHIP_VT3410) {
        td->Chipid = PCI_CHIP_VT3410;
        td->ScalingHelper_H6_410 = viaAccelScalingHelper_410;
        td->CFCHelper_H6_410 = viaAccelCFCHelper_410;
        td->Set410Helper_H6 = viaAccelSet410Helper;
    }
}

/*
 * Wait for the value to get blitted, or in the PCI case for engine idle.
 */
static void
viaAccelWaitMarker(ScreenPtr pScreen, int marker)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    CARD32 uMarker = marker;

#ifdef VIA_HAVE_UXA
    return;
#endif

    if (!pVia->IsPCI) {
        while ((pVia->lastMarkerRead - uMarker) > (1 << 24))
            pVia->lastMarkerRead = *(volatile CARD32 *)pVia->markerBuf;
    } else {
        viaAccelSync(pScrn);
    }
}

/*
 * Wait for acceleration engines idle. An expensive way to sync.
 */
void
viaAccelSync(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    int loop = 0;

    mem_barrier();

    switch (pVia->ChipId) {
    case PCI_CHIP_VT3353:
    case PCI_CHIP_VT3409:
    case PCI_CHIP_VT3410:
        while ((VIAGETREG(VIA_REG_STATUS) &
            (VIA_CMD_RGTR_BUSY_M1 | VIA_2D_ENG_BUSY_M1 |
            VIA_3D_ENG_BUSY_M1))
            && (loop++ < MAXLOOP)) ;
        break;

    default:
        break;
    }
}

/*
 * Mark Sync using the 2D blitter for AGP. NoOp for PCI.
 * In the future one could even launch a NULL PCI DMA command
 * to have an interrupt generated, provided it is possible to
 * write to the PCI DMA engines from the AGP command stream.
 */

static int
viaAccelMarkSync(ScreenPtr pScreen)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;

    RING_VARS;

    ++pVia->curMarker;

    /* Wrap around without affecting the sign bit. */
    pVia->curMarker &= 0x7FFFFFFF;
    if (!pVia->IsPCI) {
        Command_CRSync_2D3D(&pVia->cb, (unsigned int)pVia->ChipId,
            FLAG_WAIT_2D_IDLE);
        BEGIN_HEADER0_2D_H5(1);
        OUT_RING_QW(VIA_REG_KEYCONTROL_M1, 0x00);
        if (pVia->ChipId == PCI_CHIP_VT3410) {
            viaAccelScalingHelper_410(0, 0, 0, 0, 0, 0, 0, tdc);
            viaAccelCFCHelper_410(0, 0, 0, 0, 0, 0, tdc);
            viaAccelSet410Helper(cb, tdc);
        }

        BEGIN_HEADER0_2D_H5(4);
        OUT_RING_QW(VIA_REG_GEMODE_M1, VIA_GEM_32bpp);
#ifdef VIA_HAVE_UXA
        OUT_RING(VIA_REG_DSTBASE_M1);
        dri_bo_reloc(cb->buf, cb->pos++, pVia->exa_sync_bo, 0, 0,
            VIA_RELOC_2D);
        OUT_RING_QW(VIA_REG_PITCH_M1, ((4 >> 3) << 16));
#else
        OUT_RING_QW(VIA_REG_DSTBASE_M1, pVia->markerOffset >> 3);
        OUT_RING_QW(VIA_REG_PITCH_M1, (4 >> 3) << 16);
#endif
        OUT_RING_QW(VIA_REG_MONOPATFGC_M1, pVia->curMarker);

        viaAccelSolidHelper(cb, 0, 0, 1, 1,
            (0xF0 << 24) | VIA_GEC_BLT | VIA_GEC_FIXCOLOR_PAT);

        Command_CRSync_2D3D(&pVia->cb, (unsigned int)pVia->ChipId,
            FLAG_WAIT_2D_IDLE);
        ADVANCE_RING;
    }
    return pVia->curMarker;
}

static void
viaAccelSolidHelper(ViaCommandBuffer *cb, int x, int y, int w, int h,
    CARD32 cmd)
{
    BEGIN_HEADER0_2D_H5(3);
    OUT_RING_QW(VIA_REG_DSTPOS_M1, (y << 16) | (x & 0xFFFF));
    OUT_RING_QW(VIA_REG_DIMENSION_M1, ((h - 1) << 16) | (w - 1));
    OUT_RING_QW(VIA_REG_GECMD_M1, cmd);
}

static Bool
via_uxa_check_copy(PixmapPtr pSrcPixmap, PixmapPtr pDstPixmap,
    int alu, Pixel planeMask)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->IsSuspending)
        return FALSE;
    if (pSrcPixmap->drawable.bitsPerPixel !=
        pDstPixmap->drawable.bitsPerPixel)
        return FALSE;

    if (!via_uxa_check_2d_pitch(pSrcPixmap))
        return FALSE;

    if (!via_uxa_check_2d_pitch(pDstPixmap))
        return FALSE;

    if (exaGetPixmapPitch(pSrcPixmap) & 3)
        return FALSE;

    if (exaGetPixmapPitch(pDstPixmap) & 7)
        return FALSE;

    switch (pSrcPixmap->drawable.bitsPerPixel) {
    case 8:
    case 16:
    case 32:
        break;
    default:
        return FALSE;
    }
    return TRUE;
}

static Bool
viaExaPrepareCopy(PixmapPtr pSrcPixmap, PixmapPtr pDstPixmap, int xdir,
    int ydir, int alu, Pixel planeMask)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;
    unsigned int srcPitch, dstPitch;

#ifdef VIA_HAVE_UXA
    struct via_pixmap *vSrcPix, *vDstPix;
    unsigned int src_bo_loc, dst_bo_loc;
#else
    unsigned long srcOffset, dstOffset;
#endif

	/* RDP performance issue:
	*  we use CPU to do COPY for pixmaps in TT */
	struct via_pixmap *pix;
	pix = (struct via_pixmap*)via_get_uxa_pixmap(pSrcPixmap);
	if((pix->location & VIA_CHROME9_GEM_DOMAIN_GTT) &&
		(pix->pbo->size < 1000000))
		return FALSE;

    if (pVia->IsSuspending)
        return FALSE;

    RING_VARS;

    if (pSrcPixmap->drawable.bitsPerPixel !=
        pDstPixmap->drawable.bitsPerPixel)
        return FALSE;

    if ((srcPitch = exaGetPixmapPitch(pSrcPixmap)) & 3)
        return FALSE;

    if ((dstPitch = exaGetPixmapPitch(pDstPixmap)) & 7)
        return FALSE;

    if (!viaAccelSetMode(pDstPixmap->drawable.bitsPerPixel, 0, 0, 0, 0, tdc))
        return FALSE;

    if (!viaAccelPlaneMaskHelper(tdc, planeMask))
        return FALSE;

    tdc->cmd = VIA_GEC_BLT | VIAACCELCOPYROP(alu);
    if (xdir < 0)
        tdc->cmd |= VIA_GEC_DECX;
    if (ydir < 0)
        tdc->cmd |= VIA_GEC_DECY;

#ifdef VIA_HAVE_UXA
    if (pVia->useUXA) {
        vSrcPix = (struct via_pixmap *)via_get_uxa_pixmap(pSrcPixmap);
        vDstPix = (struct via_pixmap *)via_get_uxa_pixmap(pDstPixmap);
    } else {
        vSrcPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pSrcPixmap);
        vDstPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pDstPixmap);
    }

    src_bo_loc =
        (vSrcPix->location == VIA_CHROME9_GEM_DOMAIN_VRAM) ? 0x0 : 0x01;
    dst_bo_loc =
        (vDstPix->location == VIA_CHROME9_GEM_DOMAIN_VRAM) ? 0x0 : 0x01;
#else
    srcOffset = exaGetPixmapOffset(pSrcPixmap) + pScrn->fbOffset;
    dstOffset = exaGetPixmapOffset(pDstPixmap) + pScrn->fbOffset;
#endif

    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    viaAccelTransparentHelper(tdc, cb, 0x0, 0x0, TRUE);
    if (pVia->ChipId == PCI_CHIP_VT3410) {
        viaAccelScalingHelper_410(0, 0, 0, 0, 0, 0, 0, tdc);
        viaAccelCFCHelper_410(0, 0, 0, 0, 0, 0, tdc);
        viaAccelSet410Helper(cb, tdc);
    }

    BEGIN_HEADER0_2D_H5(4);
    OUT_RING_QW(VIA_REG_GEMODE_M1, tdc->mode);
#ifdef VIA_HAVE_UXA
    OUT_RING(VIA_REG_SRCBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, vSrcPix->pbo, 0, 0, VIA_RELOC_2D);
    OUT_RING(VIA_REG_DSTBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, vDstPix->pbo, 0, 0, VIA_RELOC_2D);
    OUT_RING_QW(VIA_REG_PITCH_M1, ((dstPitch >> 3) << 16) | (srcPitch >> 3) |
	(dst_bo_loc << 30) | (src_bo_loc << 12));
#else
    OUT_RING_QW(VIA_REG_SRCBASE_M1, srcOffset >> 3);
    OUT_RING_QW(VIA_REG_DSTBASE_M1, dstOffset >> 3);
    OUT_RING_QW(VIA_REG_PITCH_M1, ((dstPitch >> 3) << 16) | (srcPitch >> 3));
#endif

#ifdef VIA_HAVE_UXA
    if (vSrcPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vSrcPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;

    if (vDstPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vDstPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;
#endif
    return TRUE;
}

/*
 * Emit transparency state and color to the command buffer.
 */
static void
viaAccelTransparentHelper(ViaTwodContext * tdc, ViaCommandBuffer * cb,
    CARD32 keyControl, CARD32 transColor, Bool usePlaneMask)
{
    tdc->keyControl &= ((usePlaneMask) ? 0xF0000000 : 0x00000000);
    tdc->keyControl |= (keyControl & 0x0FFFFFFF);
    BEGIN_HEADER0_2D_H5(1);
    OUT_RING_QW(VIA_REG_KEYCONTROL_M1, tdc->keyControl);
    if (keyControl) {
        BEGIN_HEADER0_2D_H5(1);
        OUT_RING_QW(VIA_REG_SRCCOLORKEY_M1, transColor);
    }
}

static void
viaExaCopy(PixmapPtr pDstPixmap, int srcX, int srcY, int dstX, int dstY,
    int width, int height)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;

    RING_VARS;

    viaAccelCopyHelper(cb, srcX, srcY, dstX, dstY, width, height, tdc->cmd);
}

/*
 * Emit a copy blit operation to the command buffer.
 */
static void
viaAccelCopyHelper(ViaCommandBuffer * cb, int xs, int ys,
    int xd, int yd, int w, int h, CARD32 cmd)
{
    if (cmd & VIA_GEC_DECY) {
        ys += h - 1;
        yd += h - 1;
    }

    if (cmd & VIA_GEC_DECX) {
        xs += w - 1;
        xd += w - 1;
    }

    BEGIN_HEADER0_2D_H5(4);
    OUT_RING_QW(VIA_REG_SRCPOS_M1, (ys << 16) | (xs & 0xFFFF));
    OUT_RING_QW(VIA_REG_DSTPOS_M1, (yd << 16) | (xd & 0xFFFF));
    OUT_RING_QW(VIA_REG_DIMENSION_M1, ((h - 1) << 16) | (w - 1));
    OUT_RING_QW(VIA_REG_GECMD_M1, cmd);
}

static void
viaExaDoneCopy(PixmapPtr pPixmap)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    RING_VARS;
    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    ADVANCE_RING;
}

static Bool
via_uxa_check_solid(DrawablePtr drawable, int alu, Pixel planeMask)
{
    switch (drawable->bitsPerPixel) {
    case 8:
    case 16:
    case 32:
        break;
    default:
        return FALSE;
    }
    return TRUE;
}

static Bool
viaExaPrepareSolid(PixmapPtr pPixmap, int alu, Pixel planeMask, Pixel fg)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;
    unsigned int dstPitch;

#ifdef VIA_HAVE_UXA
    struct via_pixmap *vDstPix;
    unsigned int dst_bo_loc;
#else
    unsigned long dstOffset;
#endif

	/* RDP performance issue:
	*  we use CPU to do SOLID for pixmaps in TT */
	struct via_pixmap *pix;
	pix = (struct via_pixmap*)via_get_uxa_pixmap(pPixmap);
	if((pix->location & VIA_CHROME9_GEM_DOMAIN_GTT) &&
		(pix->pbo->size < 1000000))
		return FALSE;

    if (pVia->IsSuspending)
        return FALSE;

    RING_VARS;

    if ((dstPitch = exaGetPixmapPitch(pPixmap)) & 7)
        return FALSE;

    if (!viaAccelSetMode(pPixmap->drawable.bitsPerPixel, 0, 0, 0, 0, tdc))
        return FALSE;

    if (!viaAccelPlaneMaskHelper(tdc, planeMask))
        return FALSE;

    if (!via_uxa_check_2d_pitch(pPixmap))
        return FALSE;

    tdc->cmd = VIA_GEC_BLT | VIA_GEC_FIXCOLOR_PAT | VIAACCELPATTERNROP(alu);
#ifdef VIA_HAVE_UXA
    if (pVia->useUXA)
        vDstPix = (struct via_pixmap *)via_get_uxa_pixmap(pPixmap);
    else
        vDstPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPixmap);
    dst_bo_loc =
        (vDstPix->location == VIA_CHROME9_GEM_DOMAIN_VRAM) ? 0x0 : 0x01;
#else
    dstOffset = exaGetPixmapOffset(pPixmap) + pScrn->fbOffset;
#endif
    Command_CRSync_2D3D(&pVia->cb, (unsigned int)pVia->ChipId,
        FLAG_WAIT_2D_IDLE);
    viaAccelTransparentHelper(tdc, cb, 0x0, 0x0, TRUE);
    if (pVia->ChipId == PCI_CHIP_VT3410) {
        viaAccelScalingHelper_410(0, 0, 0, 0, 0, 0, 0, tdc);
        viaAccelCFCHelper_410(0, 0, 0, 0, 0, 0, tdc);
        viaAccelSet410Helper(cb, tdc);
    }
    BEGIN_HEADER0_2D_H5(4);
    OUT_RING_QW(VIA_REG_GEMODE_M1, tdc->mode);
#ifdef VIA_HAVE_UXA
    OUT_RING(VIA_REG_DSTBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, vDstPix->pbo, 0, 0, VIA_RELOC_2D);
    OUT_RING_QW(VIA_REG_PITCH_M1,
        ((dstPitch >> 3) << 16) | (dst_bo_loc << 30));
#else
    OUT_RING_QW(VIA_REG_DSTBASE_M1, dstOffset >> 3);
    OUT_RING_QW(VIA_REG_PITCH_M1, (dstPitch >> 3) << 16);
#endif
    OUT_RING_QW(VIA_REG_MONOPATFGC_M1, fg);

#ifdef VIA_HAVE_UXA
    if (vDstPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vDstPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;
#endif
    return TRUE;
}

static void
viaExaSolid(PixmapPtr pPixmap, int x1, int y1, int x2, int y2)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;

    RING_VARS;

    int w = x2 - x1, h = y2 - y1;

    viaAccelSolidHelper(cb, x1, y1, w, h, tdc->cmd);
}

static void
viaExaDoneSolid(PixmapPtr pPixmap)
{
    ScrnInfoPtr pScrn = xf86Screens[pPixmap->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    RING_VARS;
    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    ADVANCE_RING;
}

/*
 * Update our 2D state (TwoDContext) with a new mode.
 */
static Bool
viaAccelSetMode(int bpp, unsigned format, unsigned rotate, unsigned alphaCnst,
    unsigned alphaVaule, ViaTwodContext *tdc)
{
    switch (bpp) {
    case 16:
        tdc->mode = VIA_GEM_16bpp;
        tdc->bytesPPShift = 1;
        break;
    case 32:
        tdc->mode = VIA_GEM_32bpp;
        tdc->bytesPPShift = 2;
        break;
    case 8:
        tdc->mode = VIA_GEM_8bpp;
        tdc->bytesPPShift = 0;
        break;
/*old tdc->mode*/
    default:
        /*410 set according to PicFormat */
        if (format == PICT_x1r5g5b5) {
            tdc->mode = VIA_GEM_16bpp;
            tdc->bytesPPShift = 1;
        } else if (format == PICT_r5g6b5) {
            tdc->mode = VIA_GEM_16bpp;
            tdc->bytesPPShift = 1;
        } else if ((format == PICT_x8r8g8b8) || (format == PICT_a8r8g8b8)) {
            tdc->mode = VIA_GEM_32bpp;
            tdc->bytesPPShift = 2;
        } else {
            tdc->bytesPPShift = 0;
            return FALSE;
        }
        break;
/*add fm setting mode*/
    }
    if (tdc->Chipid == PCI_CHIP_VT3410) {
        if (alphaCnst) {
            tdc->mode |= VIA_GEM_ALPHA_CNT_EN;
            tdc->mode |= VIA_GEM_SETALPHA8(alphaVaule);

        }
        switch (rotate) {
        case RR_Rotate_90:
            tdc->mode |= VIA_GEM_degree90;
        case RR_Rotate_180:
            tdc->mode |= VIA_GEM_degree180;
        case RR_Rotate_270:
            tdc->mode |= VIA_GEM_degree270;
        }
    }

    return TRUE;
}

static Bool
viaAccelScalingHelper_410(Bool ENscale, unsigned Vfactor, unsigned Hfactor,
    Bool Shrink, unsigned scaleMode, unsigned h, unsigned w,
    ViaTwodContext * tdc)
{
    if (ENscale) {
        tdc->Scale = VIA_SCALEM_En;
        if (Shrink)
            tdc->Scale |= VIA_SCALEM_Shrink;
        tdc->Scale |= scaleMode;
    /* scale mode should be :VIA_SCALEM_BW,VIA_SCALEM_WB,*/
    /* VIA_SCALEM_CC,VIA_SCALEM_CC*/
        tdc->Scale |= (((h - 1) << 16) | (w - 1) | 0x0fffffff);
        tdc->ScaleFactor = 0;
        if ((Vfactor) || (Hfactor))
            tdc->ScaleFactor = (VIA_SCALEF_VFactor8(Vfactor) |
            VIA_SCALEF_HFactor8(Hfactor) | 0x0ff00ff0);
    } else {
        tdc->Scale = 0;
        tdc->ScaleFactor = 0;
    }
    return TRUE;
}

static Bool
viaAccelCFCHelper_410(Bool enCFC, Bool Extend0, Bool DirthModeRouding,
    unsigned dstCFMode, unsigned srcCFMode, unsigned srcDep,
    ViaTwodContext * tdc)
{
    if (enCFC) {
        tdc->Cfc = VIA_CFC_en;
        if (Extend0)
            tdc->Cfc |= VIA_CFC_EXT_en;	/*extent with 0, else with High Color */
        if (DirthModeRouding)
            tdc->Cfc |= VIA_CFC_DITH_en;	/*Mode with rounding, else with Dit table */
        tdc->Cfc |= dstCFMode;	       /*VIA_CFC_DesCF16/32_555,565,888,000(10,10,10), */
        tdc->Cfc |= srcCFMode;	       /*VIA_CFC_DesCF16/32_555,565,888,000(10,10,10), */
        tdc->Cfc |= srcDep;	       /*VIA_CFC_SrcDep8/16/32, */
    } else {
        tdc->Cfc = 0;
    }
    return TRUE;
}

/*Call before Solid /CopyHelper ,to set CFC Scaling etc.410 issue*/
static Bool
viaAccelSet410Helper(ViaCommandBuffer *cb, ViaTwodContext *tdc)
{
    BEGIN_HEADER0_2D_H5(3);
    OUT_RING_QW(VIA_REG_CFC, tdc->Cfc);
    OUT_RING_QW(VIA_REG_SCALEFACTOR, tdc->ScaleFactor);
    OUT_RING_QW(VIA_REG_SCALINGMODE, tdc->Scale);
}

/*
 * Check if we can use a planeMask and update the 2D context accordingly.
 */
static Bool
viaAccelPlaneMaskHelper(ViaTwodContext *tdc, CARD32 planeMask)
{
    CARD32 modeMask = (1 << ((1 << tdc->bytesPPShift) << 3)) - 1;
    CARD32 curMask = 0x00000000;
    CARD32 curByteMask;
    int i;

    if ((planeMask & modeMask) != modeMask) {

        /* Masking doesn't work in 8bpp. */
        if (modeMask == 0xFF) {
            tdc->keyControl &= 0x0FFFFFFF;
            return FALSE;
        }

        /* Translate the bit planemask to a byte planemask. */
        for (i = 0; i < (1 << tdc->bytesPPShift); ++i) {
            curByteMask = (0xFF << (i << 3));

            if ((planeMask & curByteMask) == 0) {
                curMask |= (1 << i);
            } else if ((planeMask & curByteMask) != curByteMask) {
                tdc->keyControl &= 0x0FFFFFFF;
                return FALSE;
            }
        }
        ErrorF("DEBUG: planeMask 0x%08x, curMask 0%02x\n",
            (unsigned)planeMask, (unsigned)curMask);

        tdc->keyControl = (tdc->keyControl & 0x0FFFFFFF) | (curMask << 28);
    }

    return TRUE;
}

/* ------------------------------------------- */
/* Create H6 Composite interfaces */
/* ------------------------------------------- */
static Bool
viaExaCheckComposite(int op, PicturePtr pSrcPicture,
    PicturePtr pMaskPicture, PicturePtr pDstPicture, int width, int height)
{
    ScrnInfoPtr pScrn = xf86Screens[pDstPicture->pDrawable->pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    Via3DState *v3d = &pVia->v3d;

    if (!pScrn->vtSema || pVia->IsSuspending)
        return FALSE;

    if (width == 0 || height == 0)
        return FALSE;

    /* Reject small composites early. They are done much faster in software. */
    if (pSrcPicture && pSrcPicture->pDrawable) {
        if (!pSrcPicture->repeat &&
            pSrcPicture->pDrawable->width *
            pSrcPicture->pDrawable->height < VIA_MIN_COMPOSITE)
            return FALSE;
    } else {
        return FALSE;
    }

    if (pMaskPicture && pMaskPicture->pDrawable) {
        if (!pMaskPicture->repeat &&
            pMaskPicture->pDrawable->width *
            pMaskPicture->pDrawable->height < VIA_MIN_COMPOSITE)
            return FALSE;
    }

    if (pMaskPicture && pMaskPicture->componentAlpha) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "use componentAlpha \n"));
        if ((op == PictOpAdd) || (op == PictOpOver) || (op == PictOpAtop)
            || (op == PictOpAtopReverse) || (op == PictOpXor))
            return FALSE;
    }

    if (pMaskPicture && pMaskPicture->repeatType > RepeatReflect) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "Unsupported picture repeat %d\n", pMaskPicture->repeatType));
        return FALSE;
    }

    if (pMaskPicture && (pMaskPicture->filter > PictFilterBest)) {
        ErrorF("Unsupported filter 0x%x\n", pMaskPicture->filter);
        return FALSE;
    }

    if (!v3d->opSupported(op)) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "Operator not supported \n"));
        return FALSE;
    }

    if (pSrcPicture && pSrcPicture->pDrawable && pMaskPicture
        && pMaskPicture->pDrawable && pDstPicture && pDstPicture->pDrawable) {
        if (((pSrcPicture->pDrawable->width > TEX_DIMENSION_LIMIT_INPIXEL
            || pSrcPicture->pDrawable->height >
            TEX_DIMENSION_LIMIT_INPIXEL) || (pMaskPicture
            && (pMaskPicture->pDrawable->width >
            TEX_DIMENSION_LIMIT_INPIXEL
            || pMaskPicture->pDrawable->height >
            TEX_DIMENSION_LIMIT_INPIXEL)))
            && (pDstPicture->pDrawable->width > TEX_DIMENSION_LIMIT_INPIXEL
            || pDstPicture->pDrawable->height >
            TEX_DIMENSION_LIMIT_INPIXEL)) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "The Composite is not support the region bigger than 2048 \n");
            return FALSE;
        }
    }

    /*
     * TODO: A8 destination formats are currently not supported and do not
     * seem supported by the hardware, although there are some leftover
     * register settings apparent in the via_3d_reg.h file. We need TODO this
     * (if important), by using component ARGB8888 operations with bitmask.
     */

    if (!v3d->dstSupported(pDstPicture->format)) {
        DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
            "Destination format not supported \n"));
        return FALSE;
    }

    if (v3d->texSupported(pSrcPicture->format)) {
        if (pMaskPicture && (PICT_FORMAT_A(pMaskPicture->format) == 0 ||
            !v3d->texSupported(pMaskPicture->format))) {
            DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                "Mask format not supported \n"));
            return FALSE;
        }
        return TRUE;
    }
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
	    "Src format not supported \n"));
    return FALSE;
}

static void
viaPrepare3DTexture(ViaTextureUnit *vTex, PicturePtr pPicture,
    PixmapPtr pPix, CARD32 textureBlendMode, Bool textureRepeat, int index)
{
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    struct via_pixmap *vPix;

#ifdef VIA_HAVE_UXA
    if (pVia->useUXA)
        vPix = (struct via_pixmap *)via_get_uxa_pixmap(pPix);
    else
        vPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPix);
    vTex->PictureBo = vPix->pbo;
    vTex->PictureLocation = vPix->location;
#else
    vTex->PictureOffset = exaGetPixmapOffset(pPix) + pScrn->fbOffset;
#endif
    vTex->npot = pVia->nPOT[index];
    vTex->textureLevel0Pitch = exaGetPixmapPitch(pPix);
    vTex->pictureFormat = pPicture->format;
    vTex->textureBlendMode = textureBlendMode;
    vTex->transform = pPicture->transform;
    vTex->bytePerPixel = pPicture->pDrawable->bitsPerPixel >> 3;
    vTex->textureDrawable_width = pPix->drawable.width;
    vTex->textureDrawable_height = pPix->drawable.height;
    vTex->pictureFilter = pPicture->filter;
    vTex->textureRepeat = textureRepeat;
    vTex->isaffine = TRUE;
}

static Bool
viaExaPrepareComposite(int op, PicturePtr pSrcPicture,
    PicturePtr pMaskPicture, PicturePtr pDstPicture,
    PixmapPtr pSrc, PixmapPtr pMask, PixmapPtr pDst)
{
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    Via3DState *v3d = &pVia->v3d;
    ViaTextureUnit *vTex = v3d->tex;
    int curTex = 0;
    ViaTexBlendingModes srcMode, maskMode;
    unsigned long offset;

    v3d->componentAlpha = v3d->srcRepeat = v3d->maskRepeat = FALSE;
    CARD32 bpp;
    CARD32 col, i, j, textureDrawable_width, textureDrawable_height;

	/* RDP performance issue:
	*  we use CPU to do COMPOSITE for pixmaps in TT */
	struct via_pixmap *pix1;
	pix1 = (struct via_pixmap*)via_get_uxa_pixmap(pSrc);
	struct via_pixmap *pix2;
	if(pMask)
	{
		pix2 = (struct via_pixmap*)via_get_uxa_pixmap(pMask);
		if(pix1->location & VIA_CHROME9_GEM_DOMAIN_GTT && 
			pix2->location & VIA_CHROME9_GEM_DOMAIN_GTT)
			return FALSE;
	}
	else 
	{
		if((pix1->location & VIA_CHROME9_GEM_DOMAIN_GTT) &&
			(pix1->pbo->size < 1000000))
			return FALSE;
	}

#ifdef VIA_HAVE_UXA
    struct via_pixmap *vMaskPix = NULL;
    struct via_pixmap *vSrcPix;
    struct via_pixmap *vDstPix;

    if (!pVia->useUXA) {
        vSrcPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pSrc);
        vDstPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pDst);
        if (pMask)
            vMaskPix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pMask);
    } else {
        vSrcPix = (struct via_pixmap *)via_get_uxa_pixmap(pSrc);
        vDstPix = (struct via_pixmap *)via_get_uxa_pixmap(pDst);
        if (pMask)
            vMaskPix = (struct via_pixmap *)via_get_uxa_pixmap(pMask);
    }

    if (pSrc && !via_uxa_check_3d_pitch(pSrc))
        return FALSE;

    if (pDst && !via_uxa_check_3d_pitch(pDst))
        return FALSE;

    if (pMask && !via_uxa_check_3d_pitch(pMask))
        return FALSE;

#endif

#ifdef VIA_HAVE_UXA
    v3d->setDestination_uxa(v3d, vDstPix->pbo, exaGetPixmapPitch(pDst),
	pDstPicture->format);
    v3d->destLocation = vDstPix->location;
#else
    offset = exaGetPixmapOffset(pDst) + pScrn->fbOffset;
    v3d->setDestination(v3d, offset /*exaGetPixmapOffset(pDst) */ ,
	exaGetPixmapPitch(pDst), pDstPicture->format);
#endif
    if (pMaskPicture && pMaskPicture->componentAlpha)
        v3d->componentAlpha = TRUE;
    else
        v3d->componentAlpha = FALSE;
    v3d->setCompositeOperator(v3d, op, v3d->componentAlpha);
    v3d->setDrawing(v3d, 0x0c, 0xFFFFFFFF, 0x000000FF, 0xFF);

    /*
     * For one-pixel repeat mask pictures we avoid using multitexturing by
     * modifying the src's texture blending equation and feed the pixel
     * value as a constant alpha for the src's texture. Multitexturing on the
     * Unichromes seems somewhat slow, so this speeds up translucent windows.
     */

    srcMode = via_src;
    pVia->maskP = NULL;
    if (pMaskPicture && pMaskPicture->pDrawable &&
        (pMaskPicture->pDrawable->height == 1) &&
        (pMaskPicture->pDrawable->width == 1) &&
        pMaskPicture->repeat && viaExpandablePixel(pMaskPicture->format)) {
#ifdef VIA_HAVE_UXA
        if (!vMaskPix->pbo->virtual)
            dri_bo_map(vMaskPix->pbo, 0);

        pVia->maskP = vMaskPix->pbo->virtual;
#else
        pVia->maskP = exaGetPixmapOffset(pMask) + pVia->FBBase;
#endif
        pVia->componentAlpha = pMaskPicture->componentAlpha;
        v3d->maskRepeat = TRUE;
        srcMode = ((pMaskPicture->componentAlpha)
            ? via_src_onepix_comp_mask : via_src_onepix_mask);
    }

    if (pMaskPicture) {
        pVia->maskFormat = pMaskPicture->format;
    }

    /*
     * One-Pixel repeat src pictures go as solid color instead of textures.
     * Speeds up window shadows.
     */
    pVia->srcP = NULL;
    if (pSrcPicture && pSrcPicture->repeat && pSrcPicture->pDrawable
        && (pSrcPicture->pDrawable->height == 1)
        && (pSrcPicture->pDrawable->width == 1)
        && viaExpandablePixel(pSrcPicture->format)) {
#ifdef VIA_HAVE_UXA
        if (!vSrcPix->pbo->virtual)
            dri_bo_map(vSrcPix->pbo, 0);

        pVia->srcP = vSrcPix->pbo->virtual;
#else
        pVia->srcP = exaGetPixmapOffset(pSrc) + pVia->FBBase;
#endif
        v3d->srcRepeat = TRUE;
    }

    if (pSrcPicture) {
        pVia->srcFormat = pSrcPicture->format;
    }

    /* Exa should be smart enough to eliminate this IN operation. */
    if (pVia->srcP && pVia->maskP) {
        ErrorF("Bad one-pixel IN composite operation. "
            "EXA needs to be smarter.\n");
        return FALSE;
    }
    maskMode = via_mask;
    if (pMaskPicture && pMaskPicture->componentAlpha) {
        switch (op) {
        case PictOpOutReverse:
        case PictOpInReverse:
            srcMode = src_Aa;
            maskMode = mask_Ca;
            break;
        case PictOpOverReverse:
        case PictOpIn:
        case PictOpOut:
        case PictOpAdd:
        case PictOpSrc:
        case PictOpDisjointSrc:
        case PictOpConjointSrc:
            srcMode = src_Ca;
            maskMode = mask_Ca;
            break;
        case PictOpClear:
        case PictOpDisjointClear:
        case PictOpConjointClear:
        case PictOpDst:
        case PictOpDisjointDst:
        case PictOpConjointDst:
            pVia->srcP = NULL;
            pVia->maskP = NULL;
            curTex = 0;
            goto AlphaBlendOnly;
            break;
        default:
            break;
        }
        pVia->srcP = NULL;
        pVia->maskP = NULL;
    }
#ifdef VIA_HAVE_UXA
    if (pVia->srcP) {
        if (dri_bo_cpu_grab(vSrcPix->pbo))
            ErrorF("source pixmap bo grab failed\n");

        dri_bo_set_cpu_domain(vSrcPix->pbo);

        pVia->srcBo = vSrcPix->pbo;
    }
#endif

    if (!pVia->srcP) {
        vTex = v3d->tex + curTex;
        viaPrepare3DTexture(vTex, pSrcPicture, pSrc, srcMode, v3d->srcRepeat,
            curTex);

        bpp = PICT_FORMAT_BPP(vTex->pictureFormat);

        if (bpp < 8)
            return FALSE;

        textureDrawable_width = vTex->textureLevel0Pitch / (bpp >> 3);
        if (textureDrawable_width >= (TEX_DIMENSION_LIMIT_INPIXEL * 2))
            return FALSE;

        curTex++;
    }
#ifdef VIA_HAVE_UXA
    if (pVia->maskP) {
        if (dri_bo_cpu_grab(vMaskPix->pbo))
            ErrorF("mask pixmap bo grab failed\n");

        dri_bo_set_cpu_domain(vMaskPix->pbo);

        pVia->maskBo = vMaskPix->pbo;
    }
#endif

    if (pMaskPicture && pMaskPicture->pDrawable && !pVia->maskP) {
        vTex = v3d->tex + curTex;
        viaPrepare3DTexture(vTex, pMaskPicture, pMask, maskMode,
            v3d->maskRepeat, curTex);

        bpp = PICT_FORMAT_BPP(vTex->pictureFormat);

        if (bpp < 8)
            return FALSE;

        textureDrawable_width = vTex->textureLevel0Pitch / (bpp >> 3);
        if (textureDrawable_width >= (TEX_DIMENSION_LIMIT_INPIXEL * 2))
            return FALSE;

        curTex++;
    }
  AlphaBlendOnly:
    v3d->setFlags(v3d, curTex, FALSE, TRUE, TRUE);

    RING_VARS;

    for (i = 0; i < v3d->numTextures; i++) {
        vTex = v3d->tex + i;
        textureDrawable_width = vTex->textureDrawable_width;
        textureDrawable_height = vTex->textureDrawable_height;

#ifdef VIA_HAVE_UXA
        if(!(v3d->setTexture_uxa(v3d, i, vTex->PictureBo,
            vTex->textureLevel0Pitch, vTex->npot,
            textureDrawable_width, textureDrawable_height,
            vTex->pictureFormat,
            via_single, via_single,
            vTex->textureBlendMode, FALSE,
            vTex->transform, vTex->pictureFilter))){
            xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                        " The matrix is not support by hardware,go to software \n");
            	return FALSE;
        	}
        vTex->textureLevel0Location = vTex->PictureLocation;
#else
        if(!(v3d->setTexture(v3d, i, vTex->PictureOffset,
            vTex->textureLevel0Pitch, vTex->npot,
            textureDrawable_width, textureDrawable_height,
            vTex->pictureFormat,
            via_single, via_single,
            vTex->textureBlendMode, FALSE,
            vTex->transform, vTex->pictureFilter))){
             xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                        " The matrix is not support by hardware,go to software \n");
             return FALSE;
        	}
#endif
    }

    if (pVia->maskP) {
        viaPixelARGB8888(pVia->maskFormat, pVia->maskP, &col);
        v3d->setTexBlendCol(v3d, 0, pVia->componentAlpha, col);
    }

    if (pVia->srcP) {
        viaPixelARGB8888(pVia->srcFormat, pVia->srcP, &col);
        v3d->setDrawing(v3d, 0x0c, 0xFFFFFFFF, col & 0x00FFFFFF, col >> 24);
    }

    Command_CRSync_2D3D(&pVia->cb, (unsigned int)pVia->ChipId,
	FLAG_WAIT_3D_IDLE);
    v3d->emitState(v3d, &pVia->cb, 1); /*force upload all Setting */

    if (v3d->chipset410) {
        v3d->emitVetexShader(v3d, &pVia->cb);
    }
    v3d->emitPixelShader(v3d, &pVia->cb, pVia->srcFormat, 0, 0);

#ifdef VIA_HAVE_UXA
    if (!pVia->srcP && vSrcPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vSrcPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;

    if (!pVia->maskP && pMask
        && vMaskPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vMaskPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;

    if (vDstPix->current_domain == VIA_CHROME9_OBJ_DOMAIN_CPU)
        vDstPix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;
#endif
    return TRUE;
}

static void
viaExaComposite(PixmapPtr pDst, int srcX, int srcY, int maskX, int maskY,
    int dstX, int dstY, int width, int height)
{
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    Via3DState *v3d = &pVia->v3d;
    ViaTextureUnit *vTex = v3d->tex;
    CARD32 col, i, j, textureDrawable_width, textureDrawable_height;
    int dst_X_wasted = 0, dst_Y_wasted = 0;

    RING_VARS;

    if (pVia->srcP) {
        srcX = maskX;
        srcY = maskY;
    }

    if (((dstX + width) > H5_CLIPPING_WINDOW_LIMIT_INPIXEL) ||
        ((dstY + height) > H5_CLIPPING_WINDOW_LIMIT_INPIXEL)) {
        dst_X_wasted = dstX % 256;
        dst_Y_wasted = dstY % 256;
        dstX = dstX - dst_X_wasted;
        dstY = dstY - dst_Y_wasted;
#ifdef VIA_HAVE_UXA
        v3d->destBo_delta =
            dstY * v3d->destPitch + dstX * (pDst->drawable.bitsPerPixel >> 3);
#else
        v3d->destOffset +=
            dstY * v3d->destPitch + dstX * (pDst->drawable.bitsPerPixel >> 3);
#endif
        dstX = dst_X_wasted;
        dstY = dst_Y_wasted;
        v3d->destDirty = TRUE;
        v3d->emitState(v3d, &pVia->cb, 0);
    }
#ifdef VIA_HAVE_UXA
    else {
        v3d->destBo_delta = 0;
    }
#endif

    v3d->emitClipRect(v3d, &pVia->cb, dstX, dstY, width, height);
    v3d->emitQuad(v3d, &pVia->cb, dstX, dstY, srcX, srcY, maskX, maskY,
	width, height);
}

static void
viaExaDoneComposite(PixmapPtr pDst)
{
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    RING_VARS;
    Command_CRSync_2D3D(&pVia->cb, (unsigned int)pVia->ChipId,
	FLAG_WAIT_3D_IDLE);
    ADVANCE_RING;

#ifdef VIA_HAVE_UXA
    if (pVia->srcBo) {
        dri_bo_cpu_release(pVia->srcBo);
        pVia->srcBo = NULL;
    }

    if (pVia->maskBo) {
        dri_bo_cpu_release(pVia->maskBo);
        pVia->maskBo = NULL;
    }
#endif
}

/* ------------------------------------------- */
#ifdef VIA_HAVE_UXA
static void *
viaUxaCreatePixmap2(ScreenPtr pScreen, int width, int height,
    int depth, int usage_hint, int bitsPerPixel, int *new_fb_pitch)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    struct via_pixmap *vpix;
    unsigned int size;
    uint64_t location_mask;

    vpix = calloc(1, sizeof(*vpix));

    if (!vpix) {
        ErrorF("can not allocate pixmap driver private\n");
        return NULL;
    }

    if (width > pVia->max_x || height > pVia->max_y)
        vpix->accel_blocked = UXA_RANGE_HEIGHT;

    if (!width || !height) {
        return vpix;
    }

    if (bitsPerPixel < 8)
        *new_fb_pitch = (width * bitsPerPixel + 7) / 8;
    else
        *new_fb_pitch = width * (bitsPerPixel >> 3);

    if (pVia->useUXA)
        *new_fb_pitch = VIA_ALIGN(*new_fb_pitch, pVia->pixmapPitchAlign);
    else
        *new_fb_pitch =
            VIA_ALIGN(*new_fb_pitch, pVia->exaDriverPtr->pixmapPitchAlign);

    size = *new_fb_pitch * height;

    /* Honor DRI2 request pixmap located at VRAM:
     * although CreatePixmap2 is used for tiling support
	 * RDP performance issue:
	 * put backbuffers in VRAM to reduce cache flushing */
    if((usage_hint & (VIA_CHROME9_GEM_DOMAIN_VRAM << 8)) ||
                (usage_hint == CREATE_PIXMAP_USAGE_BACKING_PIXMAP))	
        location_mask = VIA_CHROME9_GEM_DOMAIN_VRAM;
    else
        location_mask = VIA_CHROME9_GEM_DOMAIN_GTT;

    vpix->pbo = dri_bo_alloc(pVia->bufmgr, NULL, size, 0, location_mask);

    if (!vpix->pbo) {
        ErrorF("FatalError: Failed to allocate pixmap bo\n");
        free(vpix);
        return NULL;
    }
    /* When V92-CRT(1280x1024)+HDMI/DVI(1920x1080) is enabled,There is a black block area
     * at right and bottom side of DVI/ HDMI login interface.
     * After we create pixmap in TT memory,we should memset the pixmap space to 0 to
     * make sure there is no garbage in the bigger area of HDMI,
     * The reason why create pixmap in TT cause garbage is unknown.
     */
#if XORG_VERSION_CURRENT == XF86_VERSION_NUMERIC(1,10,4,0,0)
    if((location_mask == VIA_CHROME9_GEM_DOMAIN_GTT)&&
        (width == pScrn->virtualX)&&(height == pScrn->virtualY)) {
        dri_bo_map(vpix->pbo, 0);
        if (vpix->pbo->virtual) {
                memset(vpix->pbo->virtual, 0x00, size);
        }    
    }
#endif
    /* Driver update 2D engine register based on this flag, and kernel
       validate the bo into via_bo->locations, so we must keep this flag same
       with via_bo->location

       Hint: kernel doesn't reloc which location the bo is but only offset
       of this bo
     */
    vpix->location = ((struct via_bo *)vpix->pbo)->domains;

    vpix->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;

    return vpix;
}

static void *
viaUxaCreatePixmap(ScreenPtr pScreen, int size, int align)
{
    ScrnInfoPtr pScrn = xf86Screens[pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    struct via_pixmap *vpix = NULL;

    vpix = calloc(1, sizeof(*vpix));
    if (!vpix) {
        ErrorF("can not allocate pixmap driver private\n");
        return NULL;
    }

    if (!size) {
        return vpix;
    }

    vpix->pbo =
        dri_bo_alloc(pVia->bufmgr, NULL, size, 0, VIA_CHROME9_GEM_DOMAIN_GTT);

    if (!vpix->pbo) {
        ErrorF("FatalError: Failed to allocate pixmap bo\n");
        free(vpix);
        return NULL;
    }

    vpix->location = VIA_CHROME9_GEM_DOMAIN_GTT;
    vpix->current_domain = VIA_CHROME9_OBJ_DOMAIN_CPU;

    return vpix;
}

static Bool
viaUxaModifyPixmapHeader(PixmapPtr pPixmap, int width, int height,
    int depth, int bitsPerPixel, int devKind, pointer pPixData)
{
}

static Bool
viaUxaPixmapIsOffscreen(PixmapPtr pPix)
{
    struct via_pixmap *vpix = NULL;
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->useUXA)
        vpix = (struct via_pixmap *)via_get_uxa_pixmap(pPix);
    else
        vpix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPix);

    if (!vpix || !vpix->pbo)
        return FALSE;

    return TRUE;
}

static Bool
viaUxaPrepareAccess(PixmapPtr pPix, int index)
{
    struct via_pixmap *vpix;
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    int writeable = (index & UXA_ACCESS_RW);

    if (pVia->useUXA)
        vpix = (struct via_pixmap *)via_get_uxa_pixmap(pPix);
    else
        vpix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPix);

    if (!vpix || !vpix->pbo) {
        ErrorF("viaUxaPrepareAccess: this is not a driver pixmap\n");
        return FALSE;
    }

    if (!vpix->pbo->virtual) {
        if (dri_bo_map(vpix->pbo, 0)) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "can not map the driver pixmap\n");
            return FALSE;
        }
    }

    pPix->devPrivate.ptr = vpix->pbo->virtual;

    if (dri_bo_cpu_grab(vpix->pbo)) {
        ErrorF("cpu grab bo failed\n");
    }

	/* RDP performance issue:
	*  we only need to handle pixmaps in TT */
	if(vpix->location & VIA_CHROME9_GEM_DOMAIN_GTT)
   		 dri_bo_set_cpu_rw_domain(vpix->pbo, 1);
    /* TODO */
/*    dri_bo_set_cpu_rw_domain(vpix->pbo, writeable);*/

    return TRUE;
}

static void
viaUxaFinishAccess(PixmapPtr pPix)
{
    struct via_pixmap *vpix;
    ScrnInfoPtr pScrn = xf86Screens[pPix->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->useUXA)
        vpix = (struct via_pixmap *)via_get_uxa_pixmap(pPix);
    else
        vpix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPix);

    if (vpix && vpix->pbo) {
        dri_bo_cpu_release(vpix->pbo);
    }

    pPix->devPrivate.ptr = NULL;
}

static void
viaUxaDestroyPixmap(ScreenPtr pScreen, void *driverPriv)
{
    struct via_pixmap *vpix = (struct via_pixmap *)driverPriv;

    if (!vpix)
        return;

    if (vpix->pbo) {
        dri_bo_unreference(vpix->pbo);
        vpix->pbo = NULL;
    }

    free(vpix);
}

static Bool
viaUxaPutImage(PixmapPtr pDst,
    int x, int y, int w, int h, char *src, int src_pitch)
{
    int height = h;
    struct via_pixmap *dst_pix;
    struct generic_bo *scratch_obj = NULL;
    char *scratch_virtual;
    unsigned int scratch_size, scratch_pitch, scratch_bpp;
    unsigned int copy_pitch, dst_pitch;
    ScrnInfoPtr pScrn = xf86Screens[pDst->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;

    if (pVia->useUXA)
        dst_pix = (struct via_pixmap *)via_get_uxa_pixmap(pDst);
    else
        dst_pix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pDst);
    dst_pitch = exaGetPixmapPitch(pDst);

    /* unable or unnecessary to accelerate */
    if (!dst_pix || !dst_pix->pbo)
        goto fallback;

    scratch_bpp = pDst->drawable.bitsPerPixel;
    int cpp = scratch_bpp / 8;

    if (scratch_bpp < 8)
        copy_pitch = scratch_pitch = (w * scratch_bpp + 7) / 8;
    else
        copy_pitch = scratch_pitch = w * (scratch_bpp >> 3);
    if (pVia->useUXA)
        scratch_pitch = VIA_ALIGN(scratch_pitch, pVia->pixmapPitchAlign);
    else
        scratch_pitch =
            VIA_ALIGN(scratch_pitch, pVia->exaDriverPtr->pixmapPitchAlign);

    if (dst_pix->location == VIA_CHROME9_GEM_DOMAIN_GTT)
        goto pcie;
	/* RDP performance issue:
	*  when dst_pix in VRAM, the putimage performance is low, so 
	*  use CPU to handle this case  */
	return FALSE;

    scratch_size = scratch_pitch * h;
    scratch_obj =
        dri_bo_alloc(pVia->bufmgr, NULL, scratch_size, 0,
        VIA_CHROME9_GEM_DOMAIN_GTT);
    /* Disable this scratch BO re-usage  
     * for piplined the put image, wo may call unref this BO before GPU done.
     * TTM will handle this in kernel, release it after GPU done.
     */
    dri_bo_disable_reuse(scratch_obj);

    if (!scratch_obj) {
        ErrorF("Create scratch object failed\n");
        goto fallback;
    }

    /*TODO write_enable means what */
    dri_bo_map(scratch_obj, 0);
    dri_bo_set_cpu_domain(scratch_obj);
    scratch_virtual = scratch_obj->virtual;

    /* use cpu to do copy from source to scratch object */
    while (height--) {
        memcpy(scratch_virtual, src, copy_pitch);
        src += src_pitch;
        scratch_virtual += scratch_pitch;
    }

    /* use 2D to do copy from scratch to vram destination */
    RING_VARS;

    if (src_pitch & 3 || dst_pitch & 7 ||
        !viaAccelSetMode(scratch_bpp, 0, 0, 0, 0, tdc) ||
        !viaAccelPlaneMaskHelper(tdc, 0xffffffff))
        goto fallback;

    tdc->cmd = VIA_GEC_BLT | VIAACCELCOPYROP(3);

    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    viaAccelTransparentHelper(tdc, cb, 0x0, 0x0, TRUE);
    if (pVia->ChipId == PCI_CHIP_VT3410) {
        viaAccelScalingHelper_410(0, 0, 0, 0, 0, 0, 0, tdc);
        viaAccelCFCHelper_410(0, 0, 0, 0, 0, 0, tdc);
        viaAccelSet410Helper(cb, tdc);
    }

    BEGIN_HEADER0_2D_H5(4);
    OUT_RING_QW(VIA_REG_GEMODE_M1, tdc->mode);
    OUT_RING(VIA_REG_SRCBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, scratch_obj, 0, 0, VIA_RELOC_2D);
    OUT_RING(VIA_REG_DSTBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, dst_pix->pbo, 0, 0, VIA_RELOC_2D);
    OUT_RING_QW(VIA_REG_PITCH_M1,
	((dst_pitch >> 3) << 16) | (scratch_pitch >> 3) | (0x0 << 30) | (0x1
	    << 12));

    viaAccelCopyHelper(cb, 0, 0, x, y, w, h, tdc->cmd);
    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    ADVANCE_RING;
    dri_bo_unreference(scratch_obj);
    return TRUE;

  pcie:
    dri_bo_map(dst_pix->pbo, 0);
    dri_bo_cpu_grab(dst_pix->pbo);
    dri_bo_set_cpu_domain(dst_pix->pbo);
    char *dst = dst_pix->pbo->virtual;
    int row_length = w * cpp;
    int num_rows = h;

    if ((row_length == src_pitch) && (src_pitch == dst_pitch))
        num_rows = 1, row_length *= h;
    dst += y * dst_pitch + x * cpp;
    do {
        memcpy(dst, src, row_length);
        src += src_pitch;
        dst += dst_pitch;
    } while (--num_rows);
    dri_bo_cpu_release(dst_pix->pbo);
    return TRUE;

  fallback:
    if (scratch_obj)
        dri_bo_unreference(scratch_obj);

    return FALSE;
}

static Bool
viaUxaGetImage(PixmapPtr pSrc,
    int x, int y, int w, int h, char *dst, int dst_pitch)
{
    struct via_pixmap *src_pix;
    struct generic_bo *scratch_obj = NULL;
    char *scratch_virtual;
    unsigned int scratch_size, scratch_pitch, scratch_bpp;
    unsigned int copy_pitch, src_pitch;
    ScrnInfoPtr pScrn = xf86Screens[pSrc->drawable.pScreen->myNum];
    VIAPtr pVia = VIAPTR(pScrn);
    ViaTwodContext *tdc = &pVia->td;

    if (pVia->useUXA)
        src_pix = (struct via_pixmap *)via_get_uxa_pixmap(pSrc);
    else
        src_pix = (struct via_pixmap *)exaGetPixmapDriverPrivate(pSrc);
    src_pitch = exaGetPixmapPitch(pSrc);

    /* unable or unnecessary to accelerate */
    if (!src_pix || !src_pix->pbo)
        goto fallback;

    scratch_bpp = pSrc->drawable.bitsPerPixel;
    int cpp = scratch_bpp / 8;

    if (scratch_bpp < 8)
        copy_pitch = scratch_pitch = (w * scratch_bpp + 7) / 8;
    else
        copy_pitch = scratch_pitch = w * (scratch_bpp >> 3);
    if (pVia->useUXA)
        scratch_pitch = VIA_ALIGN(scratch_pitch, pVia->pixmapPitchAlign);
    else
        scratch_pitch =
            VIA_ALIGN(scratch_pitch, pVia->exaDriverPtr->pixmapPitchAlign);

    if (src_pix->location == VIA_CHROME9_GEM_DOMAIN_GTT)
        goto pcie;

    scratch_size = scratch_pitch * h;
    scratch_obj =
	dri_bo_alloc(pVia->bufmgr, NULL, scratch_size, 0,
        VIA_CHROME9_GEM_DOMAIN_GTT);

    if (!scratch_obj) {
        ErrorF("Create scratch object failed\n");
        goto fallback;
    }

    /* use 2D to do copy from vram source to scratch object */
    RING_VARS;

    if (src_pitch & 3 || scratch_pitch & 7 ||
        !viaAccelSetMode(scratch_bpp, 0, 0, 0, 0, tdc) ||
        !viaAccelPlaneMaskHelper(tdc, 0xffffffff))
        goto fallback;

    tdc->cmd = VIA_GEC_BLT | VIAACCELCOPYROP(3);

    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    viaAccelTransparentHelper(tdc, cb, 0x0, 0x0, TRUE);
    if (pVia->ChipId == PCI_CHIP_VT3410) {
        viaAccelScalingHelper_410(0, 0, 0, 0, 0, 0, 0, tdc);
        viaAccelCFCHelper_410(0, 0, 0, 0, 0, 0, tdc);
        viaAccelSet410Helper(cb, tdc);
    }

    BEGIN_HEADER0_2D_H5(4);
    OUT_RING_QW(VIA_REG_GEMODE_M1, tdc->mode);
    OUT_RING(VIA_REG_SRCBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, src_pix->pbo, 0, 0, VIA_RELOC_2D);
    OUT_RING(VIA_REG_DSTBASE_M1);
    dri_bo_reloc(cb->buf, cb->pos++, scratch_obj, 0, 0, VIA_RELOC_2D);
    OUT_RING_QW(VIA_REG_PITCH_M1,
	((scratch_pitch >> 3) << 16) | (src_pitch >> 3) | (0x1 << 30) | (0x0
	    << 12));

    viaAccelCopyHelper(cb, x, y, 0, 0, w, h, tdc->cmd);
    Command_CRSync_2D3D(cb, (unsigned int)pVia->ChipId, FLAG_WAIT_2D_IDLE);
    ADVANCE_RING;

    dri_bo_wait(scratch_obj);
    dri_bo_map(scratch_obj, 0);
    dri_bo_set_cpu_domain(scratch_obj);
    scratch_virtual = scratch_obj->virtual;

    /* use cpu to do copy from scratch object to dst */
    while (h--) {
        memcpy(dst, scratch_virtual, copy_pitch);
        dst += dst_pitch;
        scratch_virtual += scratch_pitch;
    }

    dri_bo_unreference(scratch_obj);
    return TRUE;
  pcie:
    dri_bo_wait(src_pix->pbo);
    dri_bo_map(src_pix->pbo, 0);
    dri_bo_cpu_grab(src_pix->pbo);
    dri_bo_set_cpu_domain(src_pix->pbo);
    char *src = src_pix->pbo->virtual + y * src_pitch + x * cpp;

    w *= cpp;
    do {
        memcpy(dst, src, w);
        src += src_pitch;
        dst += dst_pitch;
    } while (--h);
    dri_bo_cpu_release(src_pix->pbo);
    return TRUE;
  fallback:
    if (scratch_obj)
        dri_bo_unreference(scratch_obj);

    return FALSE;
}

#endif

static void
via_exa_set_pixmap_bo(PixmapPtr pPix, struct generic_bo *bo)
{
    struct via_pixmap *driver_priv;
    ScreenPtr pScreen = pPix->drawable.pScreen;
    ScrnInfoPtr scrp = XF86SCRNINFO(pScreen);
    VIAPtr pVia = VIAPTR(scrp);

    driver_priv = (struct via_pixmap *)exaGetPixmapDriverPrivate(pPix);
    if (driver_priv) {
        if (driver_priv->pbo == bo)
            return;
        if (driver_priv->pbo) {
            dri_bo_unreference(driver_priv->pbo);
            driver_priv->pbo = NULL;
        }
        dri_bo_reference(bo);
        driver_priv->pbo = bo;
        if (!pVia->NoAccel) {
#ifdef VIA_HAVE_UXA
            driver_priv->location = VIA_CHROME9_GEM_DOMAIN_VRAM;
            driver_priv->current_domain = VIA_CHROME9_OBJ_DOMAIN_GPU;
#endif
        }
    }
}

/* For UXA */

static void
via_uxa_set_pixmap_bo(PixmapPtr pPix, struct generic_bo *bo)
{
    struct via_pixmap *driver_priv, *vpix;
    ScreenPtr pScreen = pPix->drawable.pScreen;
    ScrnInfoPtr scrp = XF86SCRNINFO(pScreen);
    VIAPtr pVia = VIAPTR(scrp);

    driver_priv = (struct via_pixmap *)via_get_uxa_pixmap(pPix);

    if (!driver_priv) {
        vpix = calloc(1, sizeof(*vpix));
        vpix->pbo = bo;
        vpix->location = VIA_CHROME9_GEM_DOMAIN_VRAM;
        via_uxa_set_pixmap_private(pPix, vpix);
    } else {
        if (driver_priv->pbo == bo)
            return;
        if (driver_priv->pbo) {
            dri_bo_unreference(driver_priv->pbo);
            driver_priv->pbo = NULL;
        }
        dri_bo_reference(bo);
        driver_priv->pbo = bo;
        if (!pVia->NoAccel) {
            driver_priv->location = VIA_CHROME9_GEM_DOMAIN_VRAM;
        }
    }
}

static inline unsigned long
via_pixmap_pitch(PixmapPtr pixmap)
{
    return (unsigned long)pixmap->devKind;
}

static Bool
via_uxa_check_2d_pitch(PixmapPtr pixmap)
{
    ScreenPtr pScreen = pixmap->drawable.pScreen;
    ScrnInfoPtr scrp = XF86SCRNINFO(pScreen);
    VIAPtr pVia = VIAPTR(scrp);
    int pitch = via_pixmap_pitch(pixmap);

    if (pitch > pVia->max_2d_pitch)
        return FALSE;

    return TRUE;
}

static Bool
via_uxa_check_3d_pitch(PixmapPtr pixmap)
{
    ScreenPtr pScreen = pixmap->drawable.pScreen;
    ScrnInfoPtr scrp = XF86SCRNINFO(pScreen);
    VIAPtr pVia = VIAPTR(scrp);
    int pitch = via_pixmap_pitch(pixmap);

    if (pitch > pVia->max_3d_pitch)
        return FALSE;

    return TRUE;
}

void
via_uxa_set_pixmap_private(PixmapPtr pixmap, struct via_pixmap *vpix)
{
    dixSetPrivate(&pixmap->devPrivates, &uxa_pixmap_index, vpix);
}

struct via_pixmap *
via_get_uxa_pixmap(PixmapPtr pixmap)
{
    ScreenPtr screen = pixmap->drawable.pScreen;

#if HAS_DEVPRIVATEKEYREC
    return dixGetPrivate(&pixmap->devPrivates, &uxa_pixmap_index);
#else
    return dixLookupPrivate(&pixmap->devPrivates, &uxa_pixmap_index);
#endif
}

Bool
via_uxa_check_composite_target(PixmapPtr pixmap)
{
    if (!via_uxa_check_3d_pitch(pixmap))
        return FALSE;

    return TRUE;
}

Bool
via_uxa_check_composite_texture(ScreenPtr screen, PicturePtr picture)
{

	ScrnInfoPtr scrn = xf86Screens[screen->myNum];
	
	if (picture->repeatType > RepeatReflect) {
		xf86DrvMsg(scrn->scrnIndex, X_INFO, 
				"Unsupported picture repeat %d\n", picture->repeatType);
		return FALSE;
	}

	if (picture->filter != PictFilterNearest &&
			picture->filter != PictFilterBilinear) {
		xf86DrvMsg(scrn->scrnIndex, X_INFO,
				"Unsupported filter 0x%x\n", picture->filter);
		return FALSE;
	}

	if (picture->pSourcePict) {
		SourcePict *source = picture->pSourcePict;
		if (source->type == SourcePictTypeSolidFill)
			return TRUE;
	}

    if (picture->pDrawable) {
    /* HW has limitation of the texture width and height,
     * so rightnow,our HW texture acceleration limit to 2048x2048.
     * But the more exciting thing is when UXA blit the texture 
     * from virtual on screen into the shadow buffer,it only blit 
     * the damage area which are always smaller than 2048, 
     * so we can take this property and play a trick,to move the 
     * texture start address to implement HW bit desktop support.
     * 1280(CRT)+1920(HDMI)
	 |_ _ _ _ _ _ _ _ _ _ _ _ _ _|
     |						 	 |
     |				   _ _ _ _	 |
     |			      | 	  |	 |
     |				  |damage |  |
     |	 			  |area	  |  |
     |				  |_ _ _ _|	 |
     |_ _ _ _ _ _ _ _ _ _ _ _ _ _|
     * So we comment out the following return FALSE
     */
	/*  
		int w, h;
	    w = picture->pDrawable->width;
		h = picture->pDrawable->height;
		if ((w > 2048) || (h > 2048)) {
		xf86DrvMsg(scrn->scrnIndex, X_INFO,
				"Picture w/h too large (%dx%d)\n", w, h);
			return FALSE;
		}
	*/
		return TRUE;
	}

	return FALSE;
}

PixmapPtr
via_uxa_create_pixmap(ScreenPtr screen, int w, int h, int depth,
    unsigned usage)
{
    ScrnInfoPtr scrn = xf86Screens[screen->myNum];
    VIAPtr pVia = VIAPTR(scrn);
    struct via_pixmap *vpix;
    PixmapPtr pixmap;
    int pitch, bpp;

    if (w > 32767 || h > 32767)
        return NullPixmap;

    if (depth == 1) {
		return fbCreatePixmap(screen, w, h, depth, usage);
    }
    if (usage == CREATE_PIXMAP_USAGE_GLYPH_PICTURE && w <= 32 && h <= 32) {
		return fbCreatePixmap(screen, w, h, depth, usage);
    }

    pixmap = fbCreatePixmap(screen, 0, 0, depth, usage);
    bpp = pixmap->drawable.bitsPerPixel;
    if (w && h) {
        vpix = viaUxaCreatePixmap2(screen, w, h, depth, usage, bpp, &pitch);

        if (!vpix) {
            fbDestroyPixmap(pixmap);
            return NullPixmap;
        }
        screen->ModifyPixmapHeader(pixmap, w, h, 0, 0, pitch, NULL);

        via_uxa_set_pixmap_private(pixmap, vpix);

        /* High version XServer(1.10.0) doesn't take care of the content of the
         ** pixmap when redirecting the window, so here do clear of the pixmap
         ** or some backround of the window will have garbage in composited case
         */
        if (usage == CREATE_PIXMAP_USAGE_BACKING_PIXMAP) {
            GCPtr gc;

            gc = GetScratchGC(pixmap->drawable.depth, screen);
            if (gc) {
                xRectangle rect;

                ValidateGC(&pixmap->drawable, gc);

                rect.x = 0;
                rect.y = 0;
                rect.width = pixmap->drawable.width;
                rect.height = pixmap->drawable.height;
                gc->ops->PolyFillRect(&pixmap->drawable, gc, 1, &rect);

                FreeScratchGC(gc);
            }
        }
    }
    return pixmap;
}

static Bool
via_uxa_destroy_pixmap(PixmapPtr pixmap)
{
    ScreenPtr pScreen = pixmap->drawable.pScreen;
    struct via_pixmap *vpix;

    if (pixmap->refcnt == 1) {
        vpix = via_get_uxa_pixmap(pixmap);
        viaUxaDestroyPixmap(pScreen, vpix);
    }
    fbDestroyPixmap(pixmap);
    return TRUE;
}

Bool
via_uxa_init(ScreenPtr screen)
{
    ScrnInfoPtr scrn = xf86Screens[screen->myNum];
    VIAPtr pVia = VIAPTR(scrn);
    int dimension;

#if HAS_DIXREGISTERPRIVATEKEY
    if (!dixRegisterPrivateKey(&uxa_pixmap_index, PRIVATE_PIXMAP, 0))
#else
    if (!dixRequestPrivate(&uxa_pixmap_index, 0))
#endif
        return FALSE;

    pVia->uxa_driver = uxa_driver_alloc();
    if (pVia->uxa_driver == NULL)
        return FALSE;

    memset(pVia->uxa_driver, 0, sizeof(*pVia->uxa_driver));

    pVia->uxa_driver->uxa_major = 1;
    pVia->uxa_driver->uxa_minor = 0;

    /* pitch & width/heigh limitaion, port from old EXA code  */
    pVia->pixmapPitchAlign = 32;
    pVia->max_3d_pitch = (TEX_PITCH_LIMIT_INBYTE << 1) - 1;
    pVia->max_2d_pitch = 4096 * 4 - 1;

    dimension = (TEX_PITCH_LIMIT_INBYTE << 1) / (scrn->bitsPerPixel >> 3) - 1;
    /* Do not let max dimension larger than twice TEX_DIMENSION_LIMIT_INPIXEL
     * Just for helping simplify the case.
     */
    pVia->max_x = pVia->max_y =
        (dimension >
        (TEX_DIMENSION_LIMIT_INPIXEL << 1)) ? (TEX_DIMENSION_LIMIT_INPIXEL <<
        1) : dimension;

    pVia->set_pixmap_bo = via_uxa_set_pixmap_bo;

    /* Solid fill */
    pVia->uxa_driver->check_solid = via_uxa_check_solid;
    pVia->uxa_driver->prepare_solid = viaExaPrepareSolid;
    pVia->uxa_driver->solid = viaExaSolid;
    pVia->uxa_driver->done_solid = viaExaDoneSolid;

    /* Copy */
    pVia->uxa_driver->check_copy = via_uxa_check_copy;
    pVia->uxa_driver->prepare_copy = viaExaPrepareCopy;
    pVia->uxa_driver->copy = viaExaCopy;
    pVia->uxa_driver->done_copy = viaExaDoneCopy;

    /* Composite */
    pVia->uxa_driver->check_composite = viaExaCheckComposite;
    pVia->uxa_driver->check_composite_target = via_uxa_check_composite_target;
    pVia->uxa_driver->check_composite_texture =
        via_uxa_check_composite_texture;
    pVia->uxa_driver->prepare_composite = viaExaPrepareComposite;
    pVia->uxa_driver->composite = viaExaComposite;
    pVia->uxa_driver->done_composite = viaExaDoneComposite;

    /* PutImage */
    pVia->uxa_driver->put_image = viaUxaPutImage;
    pVia->uxa_driver->get_image = viaUxaGetImage;

    pVia->uxa_driver->prepare_access = viaUxaPrepareAccess;
    pVia->uxa_driver->finish_access = viaUxaFinishAccess;
    pVia->uxa_driver->pixmap_is_offscreen = viaUxaPixmapIsOffscreen;

    screen->CreatePixmap = via_uxa_create_pixmap;
    screen->DestroyPixmap = via_uxa_destroy_pixmap;

    if (!uxa_driver_init(screen, pVia->uxa_driver)) {
        xf86DrvMsg(scrn->scrnIndex, X_ERROR, "UXA initialization failed\n");
        free(pVia->uxa_driver);
        return FALSE;
    }

    pVia->nPOT[0] = 0;
    pVia->nPOT[1] = 0;
    viaExa3DInit(screen);
    viaExa2DInit(screen);

    return TRUE;
}
