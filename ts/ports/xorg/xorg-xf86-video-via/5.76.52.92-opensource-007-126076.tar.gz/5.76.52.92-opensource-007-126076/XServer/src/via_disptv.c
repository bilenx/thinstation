/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_driver.h"
#include "xf86.h"
#include "via_common.h"
#include "via_bios.h"
#include "via_disptv.h"
#include "via_serial.h"
#include "X11/Xatom.h"

extern Bool vt1625_module_loaded;
extern Bool integratedtv_module_loaded;

#ifdef VIA_RANDR12_SUPPORT
Bool
viaGetTvCapsSupported(xf86OutputPtr output, CARD32 hDisplay, CARD32 vDisplay)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);

    /*initially supported none caps */
    tvInfo->tvSupportedCaps = 0;

    /* get supported standard tv system */
    if ((hDisplay == 640 && vDisplay == 480) ||
        (hDisplay == 800 && vDisplay == 600) ||
        (hDisplay == 1024 && vDisplay == 768)) {
        tvInfo->tvSupportedCaps |=
            TV_STANDARD_NTSC | TV_STANDARD_PAL | TV_STANDARD_480P |
            TV_STANDARD_576P | TV_STANDARD_720P | TV_STANDARD_1080I;
    } else if (hDisplay == 720 && vDisplay == 480) {
        tvInfo->tvSupportedCaps |= TV_STANDARD_NTSC | TV_STANDARD_480P
            | TV_STANDARD_720P | TV_STANDARD_1080I;
    } else if (hDisplay == 720 && vDisplay == 576) {
        tvInfo->tvSupportedCaps |= TV_STANDARD_PAL | TV_STANDARD_576P
            | TV_STANDARD_720P | TV_STANDARD_1080I;
    } else if (hDisplay == 1280 && vDisplay == 720) {
        tvInfo->tvSupportedCaps |= TV_STANDARD_720P;
    } else if (hDisplay == 1920 && vDisplay == 1080) {
        tvInfo->tvSupportedCaps |= TV_STANDARD_1080I;
    } else {
        /* support non standard */
        tvInfo->tvSupportedCaps |= 0;
    }

    /* Get supported signal caps */
    tvInfo->tvSupportedCaps |= TV_SIGNAL_YCBCR | TV_SIGNAL_RGB;
    switch (tvInfo->commonInfo.subChipName) {
    case SUBCHIP_INTEGRATED_TV:
        if (tvInfo->standard == TV_STANDARD_NTSC
            || tvInfo->standard == TV_STANDARD_PAL) {
            tvInfo->tvSupportedCaps |= TV_SIGNAL_COMPOSITE | TV_SIGNAL_SVIDEO;
        }
        break;
    case SUBCHIP_VT1625:
        if ((tvInfo->standard == TV_STANDARD_NTSC
            || tvInfo->standard == TV_STANDARD_PAL)) {
            tvInfo->tvSupportedCaps |= TV_SIGNAL_COMPOSITE | TV_SIGNAL_SVIDEO;
        }
        break;
    default:
        break;
    }

    /* Get tuning and setting caps. Include:
       FFilter.Adaptive-FFilter.brightness.contrast.saturation.Hue.DotCrawl. */
    switch (tvInfo->commonInfo.subChipName) {
        case SUBCHIP_VT1625:
        tvInfo->tvSupportedCaps |= TV_TUNING_FFILTER |
            TV_TUNING_ADAPTIVE_FFILTER |
            TV_TUNING_BRIGHTNESS |
            TV_TUNING_CONTRAST | TV_POSITION_TUNING_SUPPORT;

        /* 720P,1080I only have normal Scan,other standard have Fit Normal Over Scan */
        if (tvInfo->standard != TV_STANDARD_1080I
            && tvInfo->standard != TV_STANDARD_720P) {
            tvInfo->tvSupportedCaps |= TV_SETTING_LEVEL;
        }
        /* RGB/YCbCr don't support SATURATION & Hue */
        if ((tvInfo->signal & TV_SIGNAL_COMPOSITE)
            || (tvInfo->signal & TV_SIGNAL_SVIDEO)) {
            tvInfo->tvSupportedCaps |= TV_TUNING_SATURATION | TV_TUNING_HUE;
        }
        if (tvInfo->standard == TV_STANDARD_NTSC
            && tvInfo->signal == TV_SIGNAL_COMPOSITE) {
            tvInfo->tvSupportedCaps |= TV_SETTING_DOT_CRAWL;
        }
        break;
    case SUBCHIP_INTEGRATED_TV:
        tvInfo->tvSupportedCaps |= TV_TUNING_FFILTER |
            TV_TUNING_ADAPTIVE_FFILTER |
            TV_TUNING_BRIGHTNESS |
            TV_SIZE_TUNING_SUPPORT | TV_POSITION_TUNING_SUPPORT;

        /* RGB/YCbCr don't support SATURATION & Hue */
        if ((tvInfo->signal & TV_SIGNAL_COMPOSITE)
            || (tvInfo->signal & TV_SIGNAL_SVIDEO)) {
            tvInfo->tvSupportedCaps |= TV_TUNING_HUE;
        }
        break;
    default:
        break;
    }

    return TRUE;
}

/* fix up the TV information
   e.g. 720P/1080I only support normal scan mode,
   doesn't support over/fit scan mode */
static void
viaFixupTvInfo(int modeIndex, ViaTvPrivateInfoPtr tvInfo)
{
    if (modeIndex == VIA_720X480) {
        /* NTSC, 480P, 720P, 1080I support 720x480 */
        if (tvInfo->standard != TV_STANDARD_480P &&
            tvInfo->standard != TV_STANDARD_720P &&
            tvInfo->standard != TV_STANDARD_1080I) {
            tvInfo->standard = TV_STANDARD_NTSC;
        }
    } else if (modeIndex == VIA_720X576) {
        /* PAL, 576P, 720P, 1080I support 720x576 */
        if (tvInfo->standard != TV_STANDARD_576P &&
            tvInfo->standard != TV_STANDARD_720P &&
            tvInfo->standard != TV_STANDARD_1080I) {
            tvInfo->standard = TV_STANDARD_PAL;
        }
    } else if (modeIndex == VIA_1280X720) {
        /* 720P support 1280x720 */
        tvInfo->standard = TV_STANDARD_720P;
    } else if (modeIndex == VIA_1920X1080) {
        /* 1080I support 1920x1080 */
        tvInfo->standard = TV_STANDARD_1080I;
    }

    /* SDTV/HDTV only suport RGB & YCbCr signal type */
    if (tvInfo->standard == TV_STANDARD_480P ||
        tvInfo->standard == TV_STANDARD_576P ||
        tvInfo->standard == TV_STANDARD_720P ||
        tvInfo->standard == TV_STANDARD_1080I) {
        if (tvInfo->signal != TV_SIGNAL_RGB)
            tvInfo->signal = TV_SIGNAL_YCBCR;
    }

    /* VT1625: 720P, 1080I only have normal scan mode */
    if (tvInfo->commonInfo.subChipName == SUBCHIP_VT1625) {
        if (tvInfo->standard == TV_STANDARD_720P ||
            tvInfo->standard == TV_STANDARD_1080I) {
            tvInfo->scan = TV_SCAN_NORMAL;
        }
    } else if (tvInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TV) {
        /* Integrated TV: only have normal scan mode */
        tvInfo->scan = TV_SCAN_NORMAL;
    }
}

/* Set TV clock source(from iga path or from tv itself) */
static void
viaSetTvClockSource(ViaTvPrivateInfoPtr tvInfo, int chipset, int iga)
{
    if (tvInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TV) {
        /* From TVPLL. */
        if (iga == IGA1) {
            viaWriteVgaIoBits(REG_CR6C, 0x50, 0xF0);
        } else {
            viaWriteVgaIoBits(REG_CR6C, 0x05, 0x0F);
        }
    } else {
        /* External TV: */
        switch (chipset) {
        case VIA_CX700:
        case VIA_VX800:
        case VIA_VX855:
        case VIA_VX900:
            /* From DVP1 TV clock. */
            if (iga == IGA1) {
                if (tvInfo->commonInfo.diPort == DISP_DI_DVP0) {
                    viaWriteVgaIoBits(REG_CR6C, 0x90, 0xF0);
                } else if (tvInfo->commonInfo.diPort == DISP_DI_DVP1) {
                    viaWriteVgaIoBits(REG_CR6C, 0xB0, 0xF0);
                }
            } else {
                if (tvInfo->commonInfo.diPort == DISP_DI_DVP0) {
                    viaWriteVgaIoBits(REG_CR6C, 0x09, 0x0F);
                } else if (tvInfo->commonInfo.diPort == DISP_DI_DVP1) {
                    viaWriteVgaIoBits(REG_CR6C, 0x0B, 0x0F);
                }
            }
            break;
        default:
            if (iga == IGA1) {
                viaWriteVgaIoBits(REG_CR6C, BIT5 + BIT0, BIT7 + BIT5 + BIT0);
            } else {
                viaWriteVgaIoBits(REG_CR6C, BIT7 + BIT5 + BIT0,
                    BIT7 + BIT5 + BIT0);
            }
        }
    }
}

static void
viaTvSwReset(unsigned int MMIOBase, ViaTvPrivateInfoPtr tvInfo)
{
    if ((tvInfo->commonInfo.subChipName == SUBCHIP_VT1625)
        && vt1625_module_loaded) {
        viaSwResetVt1625(tvInfo);
    } else if ((tvInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TV) &&
        integratedtv_module_loaded) {
        viaEmbTvSwReset(MMIOBase);
    }
}

static int
parseDynamicProperty(CARD32 *propertyID, const char *name,
    TVParseStructPtr tvParseStr)
{
    int i = 0;

    if (!(xf86NameCmp(name, ""))) {
        while (tvParseStr[i].propertyID > -1) {
            if (*propertyID == tvParseStr[i].propertyID)
                return i;
            i++;
        }
    } else {
        while (tvParseStr[i].propertyID > -1) {
            if (!(xf86NameCmp(name, tvParseStr[i].name))) {
                *propertyID = tvParseStr[i].propertyID;
                return i;
            }
            i++;
        }
    }

    return -1;
}

static int
getWhichStr(CARD32 propertyID, TVParseCombineStructPtr tvParseStr)
{
    int i = 0;

    while (tvParseStr[i].propertyID > 0) {
        if (propertyID == tvParseStr[i].propertyID)
            return i;
        i++;
    }

    return -1;
}

/* Set TV subchip DPA Setting*/
static void
LoadUserTvEncoderDPASetting(CARD32 subchipName, CARD32 serialPort,
    ViaTvEncoderDPAPtr pVal)
{
    if (subchipName == SUBCHIP_VT1625) {
        if (pVal->isDPAUsed)
            viaSerialWriteByteMask(serialPort, SUBCHIP_VT1625_SLAVE_ADDR,
                0x05, pVal->DPA, 0x0F);
    }
}

static void
createTvPropertyBrightness(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    INT32 brightness_range[2];
    unsigned int temp_brightness_percent;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    tv_brightness_atom = MakeAtom(TV_BRIGHTNESS_NAME,
	sizeof(TV_BRIGHTNESS_NAME) - 1, TRUE);
    /*range is 0~100 */
    brightness_range[0] = 0;
    brightness_range[1] = 100;

    err = RRConfigureOutputProperty(output->randr_output, tv_brightness_atom,
	FALSE, TRUE, FALSE, 2, brightness_range);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);
    }

    if (tvFeatureInfoPtr->brightnessLevel) {
        temp_brightness_percent =
            (tvFeatureInfoPtr->defaultBrightness * 100) /
            (tvFeatureInfoPtr->brightnessLevel);
        if (temp_brightness_percent > 100)
            temp_brightness_percent = 0;
    } else
        temp_brightness_percent = 100;

    err = RRChangeOutputProperty(output->randr_output, tv_brightness_atom,
	XA_INTEGER, 32, PropModeReplace, 1, &(temp_brightness_percent),
	FALSE, TRUE);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);
    }
}

static void
createTvPropertyContrast(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    INT32 contrast_range[2];
    unsigned int temp_contrast_percent;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    /*if  tvSupportedCaps don't support Contrast property at the moment ,we should remove
     * tv_contrast_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_TUNING_CONTRAST)) {
        if (tv_contrast_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_contrast_atom);
            tv_contrast_atom = 0;
        }
        return;
    } else {
        if (tv_contrast_atom != 0)
            return;
        /* tvSupportedCaps support Contrast property and tv_contrast_atom
           isn't be created yet, so create it */
        tv_contrast_atom = MakeAtom(TV_CONTRAST_NAME,
            sizeof(TV_CONTRAST_NAME) - 1, TRUE);
        contrast_range[0] = 0;
        contrast_range[1] = 100;

        err = RRConfigureOutputProperty(output->randr_output,
            tv_contrast_atom, FALSE, TRUE, FALSE, 2, contrast_range);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);

        if (tvFeatureInfoPtr->contrastLevel) {
            temp_contrast_percent =
                (tvFeatureInfoPtr->defaultContrast * 100) /
                (tvFeatureInfoPtr->contrastLevel);
            if (temp_contrast_percent > 100)
                temp_contrast_percent = 0;
        } else
            temp_contrast_percent = 100;
            err = RRChangeOutputProperty(output->randr_output,
                tv_contrast_atom,
                XA_INTEGER, 32, PropModeReplace, 1,
                &(temp_contrast_percent), FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRChangeOutputProperty error, %d\n", err);
    }
}

static void
createTVPropertySaturation(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    INT32 saturation_range[2];
    unsigned int temp_saturation_percent;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    /* if  tvSupportedCaps don't support saturation property at the moment,
       we should remove tv_saturation_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_TUNING_SATURATION)) {
        if (tv_saturation_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_saturation_atom);
            tv_saturation_atom = 0;
        }
        return;
    } else {
        if (tv_saturation_atom != 0)
            return;
        /* tvSupportedCaps support Saturation property and tv_saturation_atom
           isn't be created yet, so create it */
        tv_saturation_atom = MakeAtom(TV_SATURATION_NAME,
            sizeof(TV_SATURATION_NAME) - 1, TRUE);
        saturation_range[0] = 0;
        saturation_range[1] = 100;

        err =
            RRConfigureOutputProperty(output->randr_output,
            tv_saturation_atom, FALSE, TRUE, FALSE, 2, saturation_range);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        if (tvFeatureInfoPtr->saturationLevel) {
            temp_saturation_percent =
                (tvFeatureInfoPtr->defaultSaturation * 100) /
                (tvFeatureInfoPtr->saturationLevel);
            if (temp_saturation_percent > 100)
                temp_saturation_percent = 0;
        } else {
            temp_saturation_percent = 100;
        }
        err = RRChangeOutputProperty(output->randr_output, tv_saturation_atom,
            XA_INTEGER, 32, PropModeReplace, 1,
            &(temp_saturation_percent), FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);

    }
}

static void
createTVPropertyHue(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    INT32 hue_range[2];
    unsigned int temp_hue_percent;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    /* if  tvSupportedCaps don't support Hue property at the moment,
       we should remove tv_hue_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_TUNING_HUE)) {
        if (tv_hue_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_hue_atom);
            tv_hue_atom = 0;
        }
        return;
    } else {
        if (tv_hue_atom != 0)
            return;
        /* tvSupportedCaps support Hue property and tv_hue_atom isn't be
         * created yet, so create it */
        tv_hue_atom = MakeAtom(TV_HUE_NAME, sizeof(TV_HUE_NAME) - 1, TRUE);
        hue_range[0] = 0;
        hue_range[1] = 100;

        err = RRConfigureOutputProperty(output->randr_output, tv_hue_atom,
            FALSE, TRUE, FALSE, 2, hue_range);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        if (tvFeatureInfoPtr->hueLevel) {
            temp_hue_percent = (tvFeatureInfoPtr->defaultHue * 100) /
                (tvFeatureInfoPtr->hueLevel);
        } else {
            temp_hue_percent = 100;
        }
        err = RRChangeOutputProperty(output->randr_output, tv_hue_atom,
            XA_INTEGER, 32, PropModeReplace, 1, &(temp_hue_percent),
            FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRChangeOutputProperty error, %d\n", err);

    }
}

static void
createTvPropertyDotCrawl(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
	(ViaTvPrivateInfoPtr) (output->driver_private);
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;
    int i;

    /* if  tvSupportedCaps don't support dotcrawl property at the moment,
       we should remove tv_dotcrawl_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_SETTING_DOT_CRAWL)) {
        if (tv_dotcrawl_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_dotcrawl_atom);
            tv_dotcrawl_atom = 0;
        }
        return;
    } else {
        if (tv_dotcrawl_atom != 0)
            return;
        /* tvSupportedCaps support dotcrawl property and tv_dotcrawl_atom
           isn't be created yet, so create it */
        tv_dotcrawl_atom = MakeAtom(TV_DOTCRAWL_NAME,
            sizeof(TV_DOTCRAWL_NAME) - 1, TRUE);
        for (i = 0; i < TV_DOTCRAWL_NUM; i++) {
            tv_dotcrawl_name_atoms[i] = MakeAtom(tv_dotcrawl_names[i],
            strlen(tv_dotcrawl_names[i]), TRUE);
        }
        err =
            RRConfigureOutputProperty(output->randr_output, tv_dotcrawl_atom,
            TRUE, FALSE, FALSE, TV_DOTCRAWL_NUM,
            (INT32 *) tv_dotcrawl_name_atoms);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        err = RRChangeOutputProperty(output->randr_output, tv_dotcrawl_atom,
            XA_ATOM, 32, PropModeReplace, 1,
            &tv_dotcrawl_name_atoms[tvInfo->deDotCrawl], FALSE, TRUE);
        if (err != 0) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "failed to set tv dot crawl, %d\n", err);
        }
    }
}

static void
createTvPropertyType(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
	(ViaTvPrivateInfoPtr) (output->driver_private);
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;
    int i, num;
    int currentType = 0;
    static int lastType = 0;

    if ((lastType & TV_STANDARD_ALL) ==
        (tvInfo->tvSupportedCaps & TV_STANDARD_ALL)) {
        return;
    } else {
        /* find out supported Types at this momoent  according to
           tvSupportedCaps */
        lastType = tvInfo->tvSupportedCaps;
        num = getWhichStr((tvInfo->tvSupportedCaps & TV_STANDARD_ALL),
            tv_type_struct);
        currentType = parseDynamicProperty(&(tvInfo->standard), "",
            tv_type_struct[num].pTvParseStruct);
        if (currentType < 0) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "Can not find the related vPropertyType!\n");
            return;
        }

        tv_type_atom = MakeAtom(TV_TYPE_NAME, sizeof(TV_TYPE_NAME) - 1, TRUE);
        /*Create atoms for supported Types */
        for (i = 0; i < tv_type_struct[num].tvSignalNum; i++) {
            tv_type_name_atoms[i] =
                MakeAtom(tv_type_struct[num].pTvSignalNames[i],
                strlen(tv_type_struct[num].pTvSignalNames[i]), TRUE);
        }
        err = RRConfigureOutputProperty(output->randr_output, tv_type_atom,
            TRUE, FALSE, FALSE,
            tv_type_struct[num].tvSignalNum, (INT32 *) tv_type_name_atoms);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        err = RRChangeOutputProperty(output->randr_output, tv_type_atom,
            XA_ATOM, 32, PropModeReplace, 1,
            &tv_type_name_atoms[currentType], FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "failed to set tv type, %d\n", err);

    }
}

static void
createTvPropertySignal(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
	(ViaTvPrivateInfoPtr) (output->driver_private);
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;
    int i, num;
    int currentSignal = 0;
    static int lastType = 0;

    if ((lastType & TV_SIGNAL_ALL) == (tvInfo->tvSupportedCaps
	    & TV_SIGNAL_ALL)) {
        return;
    } else {
        /* find out supported Signals at this momoent according to
           tvSupportedCaps */
        lastType = tvInfo->tvSupportedCaps;
        num = getWhichStr((tvInfo->tvSupportedCaps & TV_SIGNAL_ALL),
            tv_signal_struct);
        currentSignal = parseDynamicProperty(&(tvInfo->signal), "",
            tv_signal_struct[num].pTvParseStruct);
        if (currentSignal < 0) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Can not find the related TvPropertySignal!\n");
            return;
        }

        tv_signal_atom = MakeAtom(TV_SIGNAL_NAME, sizeof(TV_SIGNAL_NAME) - 1,
            TRUE);
        /* Create atoms for Supported Signals */
        for (i = 0; i < tv_signal_struct[num].tvSignalNum; i++) {
            tv_signal_name_atoms[i] =
                MakeAtom(tv_signal_struct[num].pTvSignalNames[i],
                strlen(tv_signal_struct[num].pTvSignalNames[i]), TRUE);
        }

        err = RRConfigureOutputProperty(output->randr_output, tv_signal_atom,
            TRUE, FALSE, FALSE,
            tv_signal_struct[num].tvSignalNum,
            (INT32 *) tv_signal_name_atoms);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        err = RRChangeOutputProperty(output->randr_output, tv_signal_atom,
            XA_ATOM, 32, PropModeReplace, 1,
            &tv_signal_name_atoms[currentSignal], FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "failed to set tv signal, %d\n", err);

    }
}

static void
createTvPropertyScan(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;
    int i;
    int currentScan = 0;

    /* if  tvSupportedCaps don't support Scan property at the moment,
       we should remove tv_scan_typel_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_SETTING_LEVEL)) {
        if (tv_scan_type_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_scan_type_atom);
            tv_scan_type_atom = 0;
        }
        return;
    } else {
        if (tv_scan_type_atom != 0)
            return;

        currentScan =
            parseDynamicProperty(&(tvInfo->scan), "", tv_scan_struct);
        /* tvSupportedCaps support Scan property and tv_scan_type_atom isn't be
         * created yet, so create it */
        tv_scan_type_atom = MakeAtom(TV_SCAN_TYPE_NAME,
            sizeof(TV_SCAN_TYPE_NAME) - 1, TRUE);
        for (i = 0; i < TV_SCAN_TYPE_NUM; i++) {
            tv_scan_type_name_atoms[i] = MakeAtom(tv_scan_type_names[i],
            strlen(tv_scan_type_names[i]), TRUE);
        }
        err =
            RRConfigureOutputProperty(output->randr_output, tv_scan_type_atom,
            TRUE, FALSE, FALSE, TV_SCAN_TYPE_NUM,
            (INT32 *) tv_scan_type_name_atoms);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        err = RRChangeOutputProperty(output->randr_output, tv_scan_type_atom,
            XA_ATOM, 32, PropModeReplace, 1,
            &tv_scan_type_name_atoms[currentScan], FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "failed to set tv scan type, %d\n", err);

    }
}

static void
createTVPropertyAFFliterValue(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    unsigned int affliter_value[2];
    unsigned int temp_affliter;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    tv_affliterValue_atom = MakeAtom(TV_AFFliter_Value,
	sizeof(TV_AFFliter_Value) - 1, TRUE);
    /*range is 0~100 */
    affliter_value[0] = 0;
    affliter_value[1] = 100;

    err =
        RRConfigureOutputProperty(output->randr_output, tv_affliterValue_atom,
        FALSE, TRUE, FALSE, 2, (INT32 *) affliter_value);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);
    }
    if (tvFeatureInfoPtr->AFFilterLevel)
        temp_affliter = (tvFeatureInfoPtr->DefaultAFFilter * 100)
            / (tvFeatureInfoPtr->AFFilterLevel);
    else
        temp_affliter = 100;
    err = RRChangeOutputProperty(output->randr_output, tv_affliterValue_atom,
        XA_INTEGER, 32, PropModeReplace, 1, &(temp_affliter), FALSE, TRUE);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);
    }
}

static void
createTVPropertyHorScaleLevel(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    ScrnInfoPtr pScrn = output->scrn;
    INT32 horScaleRange[2];
    unsigned int temp;
    int err = -1;

    /* if tvSupportedCaps don't support hor scale property at the moment,
       we should remove tv_hor_scale_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_SIZE_TUNING_SUPPORT)) {
        if (tv_hor_scale_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_hor_scale_atom);
            tv_hor_scale_atom = 0;
        }
        return;
    } else {
        if (tv_hor_scale_atom != 0)
            return;
        /* tvSupportedCaps support scale property and tv_hor_scale_atom isn't
           be created yet, so create it */
        tv_hor_scale_atom = MakeAtom(TV_HOR_SCALE_NAME,
            sizeof(TV_HOR_SCALE_NAME) - 1, TRUE);
        horScaleRange[0] = 0;
        horScaleRange[1] = 100;

        err =
            RRConfigureOutputProperty(output->randr_output, tv_hor_scale_atom,
            FALSE, TRUE, FALSE, 2, horScaleRange);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);

        /* Default scale percent is 50% */
        temp = 50;
        err = RRChangeOutputProperty(output->randr_output, tv_hor_scale_atom,
            XA_INTEGER, 32, PropModeReplace, 1, &temp, FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRChangeOutputProperty error, %d\n", err);
    }
}

static void
createTVPropertyVerScaleLevel(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    INT32 verScaleRange[2];
    unsigned int temp;
    ScrnInfoPtr pScrn = output->scrn;
    int err = -1;

    /* if  tvSupportedCaps don't support VerScale property at the moment,
       we should remove tv_ver_scale_atom property */
    if (!(tvInfo->tvSupportedCaps & TV_SIZE_TUNING_SUPPORT)) {
        if (tv_ver_scale_atom != 0) {			
			RRPropertyPtr	prop, *prev;			
			for (prev = &output->randr_output->properties; (prop = *prev); prev = &(prop->next))
			if (prop->propertyName == tv_dotcrawl_atom)
				break;
			if (prop) {				
				if (prop->valid_values) {
					/* this patch is to fix xorg-server-1.7.6 issue.
					 The prop->valid_value was free twice in xorg-server-1.7.6, 
					 which will cause segment fault */
					free (prop->valid_values);
					prop->valid_values = NULL;
				}
			}
            RRDeleteOutputProperty(output->randr_output, tv_ver_scale_atom);
            tv_ver_scale_atom = 0;
        }
        return;
    } else {
        if (tv_ver_scale_atom != 0)
            return;
        /* tvSupportedCaps support VerScale property and tv_ver_scale_atom
           isn't be created yet, so create it */
        tv_ver_scale_atom = MakeAtom(TV_VER_SCALE_NAME,
            sizeof(TV_VER_SCALE_NAME) - 1, TRUE);
        verScaleRange[0] = 0;
        verScaleRange[1] = 100;

        err =
            RRConfigureOutputProperty(output->randr_output, tv_ver_scale_atom,
            FALSE, TRUE, FALSE, 2, verScaleRange);
        if (err != 0) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRConfigureOutputProperty error, %d\n", err);
        }

        /* Default scale percent is 50% */
        temp = 50;
        err = RRChangeOutputProperty(output->randr_output, tv_ver_scale_atom,
            XA_INTEGER, 32, PropModeReplace, 1, &temp, FALSE, TRUE);
        if (err != 0)
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                "RRChangeOutputProperty error, %d\n", err);
    }
}

static void
createTVPropertyFFliter(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    ScrnInfoPtr pScrn = output->scrn;
    CARD32 defaultValue;
    int err, i;

    /*Create TV FFliter Property */
    tv_ffliter_atom = MakeAtom(TV_FFliter_NAME,
	sizeof(TV_FFliter_NAME) - 1, TRUE);

    for (i = 0; i < 3; i++)
        tv_ffliter_name_atoms[i] = MakeAtom(tv_ffliter_names[i],
            strlen(tv_ffliter_names[i]), TRUE);

    err = RRConfigureOutputProperty(output->randr_output, tv_ffliter_atom,
        TRUE, FALSE, FALSE, 3, (INT32 *) tv_ffliter_name_atoms);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);

    if (tvFeatureInfoPtr->AdaptiveFFilterOn)
        defaultValue = 1;
    else if (tvFeatureInfoPtr->FFilterOn)
        defaultValue = 0;
    else
        defaultValue = 2;
    err = RRChangeOutputProperty(output->randr_output, tv_ffliter_atom,
        XA_ATOM, 32, PropModeReplace, 1,
        &tv_ffliter_name_atoms[defaultValue], FALSE, TRUE);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "failed to set FFliter, %d\n", err);

}

static void
createTVPropertyFFliterValue(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    ScrnInfoPtr pScrn = output->scrn;
    unsigned int ffliter_value[2];
    unsigned int temp_ffliter;
    int err = -1;

    tv_ffliterValue_atom = MakeAtom(TV_FFliter_Value,
	sizeof(TV_FFliter_Value) - 1, TRUE);
    ffliter_value[0] = 0;
    ffliter_value[1] = 100;

    err =
        RRConfigureOutputProperty(output->randr_output, tv_ffliterValue_atom,
        FALSE, TRUE, FALSE, 2, (INT32 *) ffliter_value);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);
    if (tvFeatureInfoPtr->FFilterLevel)
        temp_ffliter = (tvFeatureInfoPtr->DefaultFFilter * 100)
            / (tvFeatureInfoPtr->FFilterLevel);
    else
        temp_ffliter = 100;

    err = RRChangeOutputProperty(output->randr_output, tv_ffliterValue_atom,
        XA_INTEGER, 32, PropModeReplace, 1, &(temp_ffliter), FALSE, TRUE);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);

}

static void
createTVPropertyPosH(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    ScrnInfoPtr pScrn = output->scrn;
    unsigned int value[2];
    unsigned int tempValue;
    int err = -1;

    tv_posh_atom = MakeAtom(TV_POSH_NAME, sizeof(TV_POSH_NAME) - 1, TRUE);
    value[0] = 0;
    value[1] = 100;

    err = RRConfigureOutputProperty(output->randr_output, tv_posh_atom,
        FALSE, TRUE, FALSE, 2, (INT32 *) value);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);
    tempValue = tvFeatureInfoPtr->CurrentPositionH;
    err = RRChangeOutputProperty(output->randr_output, tv_posh_atom,
        XA_INTEGER, 32, PropModeReplace, 1, &(tempValue), FALSE, TRUE);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);
}

static void
createTVPropertyPosV(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;
    ScrnInfoPtr pScrn = output->scrn;
    unsigned int value[2];
    unsigned int tempValue;
    int err = -1;

    tv_posv_atom = MakeAtom(TV_POSV_NAME, sizeof(TV_POSV_NAME) - 1, TRUE);
    value[0] = 0;
    value[1] = 100;

    err = RRConfigureOutputProperty(output->randr_output, tv_posv_atom,
        FALSE, TRUE, FALSE, 2, (INT32 *) value);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);

    tempValue = tvFeatureInfoPtr->CurrentPositionV;
        err = RRChangeOutputProperty(output->randr_output, tv_posv_atom,
        XA_INTEGER, 32, PropModeReplace, 1, &(tempValue), FALSE, TRUE);
    if (err != 0)
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRChangeOutputProperty error, %d\n", err);

}

static void
via_tv_create_resources(xf86OutputPtr output)
{
    createTvPropertyScan(output);
    createTvPropertySignal(output);
    createTvPropertyType(output);
    createTvPropertyDotCrawl(output);
    createTvPropertyBrightness(output);
    createTvPropertyContrast(output);
    createTVPropertySaturation(output);
    createTVPropertyHue(output);
    createTVPropertyAFFliterValue(output);
    createTVPropertyFFliter(output);
    createTVPropertyFFliterValue(output);
    createTVPropertyHorScaleLevel(output);
    createTVPropertyVerScaleLevel(output);
    createTVPropertyPosH(output);
    createTVPropertyPosV(output);
}

static Bool
setTvPropertyType(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Type\n"));

    ScrnInfoPtr pScrn = output->scrn;
    Atom atom;
    const char *name;
    int modeIndex = 0;
    int num;
    int ret = 0;
    ViaTvPrivateInfoPtr tvInfo =
	(ViaTvPrivateInfoPtr) (output->driver_private);
    /*Set TV Type Property */
    if (value->type != XA_ATOM || value->format != 32 || value->size != 1)
        return FALSE;

    memcpy(&atom, value->data, 4);
    name = NameForAtom(atom);

    num = getWhichStr((tvInfo->tvSupportedCaps & TV_STANDARD_ALL),
        tv_type_struct);
    ret = parseDynamicProperty((CARD32 *) & (tvInfo->standard), name,
        tv_type_struct[num].pTvParseStruct);
    if (ret < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Can not find the related type property!\n");
        return FALSE;
    }

    if (output->crtc) {
        xf86CrtcPtr crtc = output->crtc;

        if (crtc->enabled) {
            modeIndex = VIA_MAKE_ID(crtc->mode.HDisplay, crtc->mode.VDisplay);
            viaFixupTvInfo(modeIndex, tvInfo);
            /*update the TV Caps and recreate the property */
            viaGetTvCapsSupported(output, crtc->mode.HDisplay,
            crtc->mode.VDisplay);
            createTvPropertyDotCrawl(output);
            createTvPropertySignal(output);
            createTvPropertyScan(output);
        }
    }
    return TRUE;
}

static Bool
setTvPropertySignal(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Signal\n"));

    ScrnInfoPtr pScrn = output->scrn;
    Atom atom;
    const char *name;
    int num;
    int ret = 0;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);

    if (value->type != XA_ATOM || value->format != 32 || value->size != 1)
        return FALSE;

    memcpy(&atom, value->data, 4);
    name = NameForAtom(atom);
    /*find out if tv support user's wanted  TV Signal  */
    num = getWhichStr((tvInfo->tvSupportedCaps & TV_SIGNAL_ALL),
        tv_signal_struct);
    ret = parseDynamicProperty((CARD32 *) & (tvInfo->signal), name,
        tv_signal_struct[num].pTvParseStruct);
    if (ret < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Can not find the related signal property!\n");
        return FALSE;
    }

    if (output->crtc) {
        xf86CrtcPtr crtc = output->crtc;
        int modeIndex = 0;

        if (crtc->enabled) {
            modeIndex = VIA_MAKE_ID(crtc->desiredMode.HDisplay,
            crtc->desiredMode.VDisplay);
            viaFixupTvInfo(modeIndex, tvInfo);
            /*update the TV Caps and recreate the property */
            viaGetTvCapsSupported(output, crtc->desiredMode.HDisplay,
            crtc->desiredMode.VDisplay);
            createTvPropertyDotCrawl(output);
            /*1.if tv signal changed, update tv feature level */
            if (tvInfo->commonInfo.subChipName == SUBCHIP_VT1625 &&
                vt1625_module_loaded)
                viaGetVT1625TVInfo(tvInfo);

            createTVPropertyHue(output);
            createTVPropertySaturation(output);
        }
    }
    return TRUE;
}

static Bool
setTvPropertyScan(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Scan Type\n"));

    ScrnInfoPtr pScrn = output->scrn;
    Atom atom;
    const char *name;
    int ret = 0;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);

    if (value->type != XA_ATOM || value->format != 32 || value->size != 1)
        return FALSE;

    memcpy(&atom, value->data, 4);
    name = NameForAtom(atom);
    /*find out if tv support user's wanted  TV Scan  */
    ret =
	parseDynamicProperty((CARD32 *) & (tvInfo->scan), name,
	tv_scan_struct);
    if (ret < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Can not find the related scan property!\n");
        return FALSE;
    }
    if (output->crtc) {
        xf86CrtcPtr crtc = output->crtc;

        if (crtc->enabled) {
            if ((tvInfo->standard == TV_STANDARD_720P ||
                tvInfo->standard == TV_STANDARD_1080I) &&
                (tvInfo->scan != TV_SCAN_NORMAL)) {
                tvInfo->scan = TV_SCAN_NORMAL;
                return FALSE;
            }
        }
    }
    return TRUE;
}

static Bool
setTvPropertyDotCrawl(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Dot Crawl\n"));

    ScrnInfoPtr pScrn = output->scrn;
    Atom atom;
    const char *name;
    int ret = 0;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);

    if (value->type != XA_ATOM || value->format != 32 || value->size != 1)
        return FALSE;

    memcpy(&atom, value->data, 4);
    name = NameForAtom(atom);
    /*find out if tv support DotCrawl at this moment */
    ret = parseDynamicProperty((CARD32 *) & (tvInfo->deDotCrawl), name,
        tv_dotcrawl_struct);
    if (ret < 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Can not find the related deDotCrawl property!\n");
        return FALSE;
    }

    return TRUE;
}

static Bool
setTvPropertyBrightness(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Brightness\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /*if we can set brightness */
    if (tvFeatureInfoPtr->brightnessLevel) {
        /*convert percent to real value */
        val = (val * tvFeatureInfoPtr->brightnessLevel) / 100;
        if (tvFeatureInfoPtr->currentBrightness != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTvBrightnessVt1625(tvInfo, val);
                    tvFeatureInfoPtr->currentBrightness = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustBrightnessEmbTv(MMIOBase, val);
                    tvFeatureInfoPtr->currentBrightness = val;
                }
                break;
            default:
                break;
            }
        }
    }
    return TRUE;
}

static Bool
setTvPropertyContrast(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Contrast\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /*if we can set contrast */
    if (tvFeatureInfoPtr->contrastLevel) {
        val = (val * tvFeatureInfoPtr->contrastLevel) / 100;
        if (tvFeatureInfoPtr->currentContrast != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTvContrastVt1625(tvInfo, val);
                    tvFeatureInfoPtr->currentContrast = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustContrastEmbTv(MMIOBase, val);
                    tvFeatureInfoPtr->currentContrast = val;
                }
                break;
            default:
                break;
            }
        }
    }
    return TRUE;
}

static Bool
setTvPropertySaturation(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Saturation\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /*if we can set saturation */
    if (tvFeatureInfoPtr->saturationLevel) {
        val = (val * tvFeatureInfoPtr->saturationLevel) / 100;
        if (tvFeatureInfoPtr->currentSaturation != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTvSaturationVt1625(tvInfo, val);
                    tvFeatureInfoPtr->currentSaturation = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustSaturationEmbTv(MMIOBase, val);
                    tvFeatureInfoPtr->currentSaturation = val;
                }
                break;
            default:
                break;
            }
        }
    }

    return TRUE;
}

static Bool
setTvPropertyHue(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV HUE\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /*if we can set hue */
    if (tvFeatureInfoPtr->hueLevel) {
        val = (val * tvFeatureInfoPtr->hueLevel) / 100;
        if (tvFeatureInfoPtr->currentHue != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTvHueVt1625(tvInfo, val);
                    tvFeatureInfoPtr->currentHue = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustHueEmbTv(MMIOBase, val);
                    tvFeatureInfoPtr->currentHue = val;
                }
                break;
            default:
                break;
            }
        }
    }

    return TRUE;
}

static Bool
setTvPropertyAFFliterValue(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV AFFliter Value\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /* if we can set adapative FFilter */
    if (tvFeatureInfoPtr->AFFilterLevel) {
        /* convert percent to real value */
        val = (val * tvFeatureInfoPtr->AFFilterLevel) / 100;
        if (tvFeatureInfoPtr->CurrentAFFilter != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTVAFFilterVt1625(tvInfo, val);
                    tvFeatureInfoPtr->CurrentAFFilter = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustEmbTvAFFilter(MMIOBase, val);
                    tvFeatureInfoPtr->CurrentAFFilter = val;
                }
                break;
            default:
                break;
            }
        }
    }
    return TRUE;
}

static Bool
setTvPropertyFFliter(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV affliter\n"));
    Atom atom;
    const char *name;
    int fliter = -1;
    CARD32 ffstatus, affstatus;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_ATOM || value->format != 32 || value->size != 1)
        return FALSE;

    memcpy(&atom, value->data, 4);
    name = NameForAtom(atom);
    if (!xf86NameCmp(name, tv_ffliter_names[0])) {
        DEBUG(ErrorF("Apply FFliter\n"));
        fliter = 0;
        ffstatus = TRUE;
        affstatus = FALSE;
    }
    if (!xf86NameCmp(name, tv_ffliter_names[1])) {
        DEBUG(ErrorF("Don't Apply FFliter \n"));
        fliter = 1;
        ffstatus = FALSE;
        affstatus = TRUE;
    }
    if (!xf86NameCmp(name, tv_ffliter_names[2])) {
        DEBUG(ErrorF("Don't Apply FFliter \n"));
        fliter = 2;
        ffstatus = FALSE;
        affstatus = FALSE;
    }

    if (fliter < 0)
        return FALSE;
    /*Set Filter status according to user's Setting ,AFFON, FFON or ALLOFF */
    if (tvFeatureInfoPtr->FFilterOn == ffstatus
        && tvFeatureInfoPtr->AdaptiveFFilterOn == affstatus)
        return TRUE;
    else {
        switch (subChipName) {
        case SUBCHIP_VT1625:
            if (vt1625_module_loaded) {
            viaEnableTVFFilterVt1625(tvInfo, ffstatus, affstatus);
            tvFeatureInfoPtr->FFilterOn = ffstatus;
            tvFeatureInfoPtr->AdaptiveFFilterOn = affstatus;
            }
            break;
        case SUBCHIP_INTEGRATED_TV:
            if (integratedtv_module_loaded) {
            viaEnableEmbTvFFilter(MMIOBase, ffstatus, affstatus);
            tvFeatureInfoPtr->FFilterOn = ffstatus;
            tvFeatureInfoPtr->AdaptiveFFilterOn = affstatus;
            }
            break;
        default:
            break;
        }
    }
    return TRUE;
}

static Bool
setTvPropertyFFliterValue(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV AFFliter Value\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
	return FALSE;


    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    /* if we can set FFilter */
    if (tvFeatureInfoPtr->FFilterLevel) {
        /* convert percent to real value */
        val = (val * tvFeatureInfoPtr->FFilterLevel) / 100;
        if (tvFeatureInfoPtr->CurrentFFilter != val) {
            switch (subChipName) {
            case SUBCHIP_VT1625:
                if (vt1625_module_loaded) {
                    viaAdjustTVFFilterVt1625(tvInfo, val);
                    tvFeatureInfoPtr->CurrentFFilter = val;
                }
                break;
            case SUBCHIP_INTEGRATED_TV:
                if (integratedtv_module_loaded) {
                    viaAdjustEmbTvFFilter(MMIOBase, val);
                    tvFeatureInfoPtr->CurrentFFilter = val;
                }
                break;
            default:
                break;
            }
        }
    }
    return TRUE;
}

static Bool
setTvPropertyHorScaleLevel(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Horizontal Scale\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    val = tvFeatureInfoPtr->defaultHorScale +
        (val - 50) * tvFeatureInfoPtr->horScaleInterval;
    if (tvFeatureInfoPtr->currentHorScale != val) {
        if ((subChipName == SUBCHIP_INTEGRATED_TV)
            && integratedtv_module_loaded) {
            viaAdjustHorScaleEmbTv(MMIOBase, tvInfo, val);
            tvFeatureInfoPtr->currentHorScale = val;
        }
    }

    return TRUE;
}

static Bool
setTvPropertyVerScaleLevel(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV Vertical Scale\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    val = tvFeatureInfoPtr->defaultVerScale +
	(val - 50) * tvFeatureInfoPtr->verScaleInterval;
    if (tvFeatureInfoPtr->currentVerScale != val) {
        if ((subChipName == SUBCHIP_INTEGRATED_TV)
            && integratedtv_module_loaded) {
            viaAdjustVerScaleEmbTv(MMIOBase, tvInfo, val);
            tvFeatureInfoPtr->currentVerScale = val;
        }
    }
    return TRUE;
}

static Bool
setTvPropertyPosH(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV position H\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    if (tvFeatureInfoPtr->CurrentPositionH != val) {
        switch (subChipName) {
        case SUBCHIP_VT1625:
            if (vt1625_module_loaded) {
                viaAdjustTvPosHVt1625(tvInfo, val);
                tvFeatureInfoPtr->CurrentPositionH = val;
            }
            break;
        case SUBCHIP_INTEGRATED_TV:
            if (integratedtv_module_loaded) {
                viaAdjustPosHEmbTv(MMIOBase, tvInfo, val);
                tvFeatureInfoPtr->CurrentPositionH = val;
            }
            break;
        default:
            break;
        }
    }
    return TRUE;
}

static Bool
setTvPropertyPosV(RRPropertyValuePtr value, xf86OutputPtr output)
{
    DEBUG(ErrorF("Property: TV position V\n"));
    CARD32 val;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    TVFeaturePtr tvFeatureInfoPtr = tvInfo->tvFeatureInfoPtr;

    if (value->type != XA_INTEGER || value->format != 32 || value->size != 1)
        return FALSE;

    val = *(CARD32 *) value->data;
    if (val < 0 || val > 100)
        return FALSE;

    if (tvFeatureInfoPtr->CurrentPositionV != val) {
        switch (subChipName) {
        case SUBCHIP_VT1625:
            if (vt1625_module_loaded) {
                viaAdjustTvPosVVt1625(tvInfo, val);
                tvFeatureInfoPtr->CurrentPositionV = val;
            }
            break;
        case SUBCHIP_INTEGRATED_TV:
            if (integratedtv_module_loaded) {
                viaAdjustPosVEmbTv(MMIOBase, tvInfo, val);
                tvFeatureInfoPtr->CurrentPositionV = val;
            }
            break;
        default:
            break;
        }
    }
    return TRUE;
}

static Bool
via_tv_set_property(xf86OutputPtr output, Atom property,
    RRPropertyValuePtr value)
{
    int retval = 0;

    /*set tv type */
    if (property == tv_type_atom) {
        retval = setTvPropertyType(value, output);
        return retval;
    }

    /*set tv Signal */
    if (property == tv_signal_atom) {
        retval = setTvPropertySignal(value, output);
        return retval;
    }

    /*set tv scan */
    if (property == tv_scan_type_atom) {
        retval = setTvPropertyScan(value, output);
        return retval;
    }

    /*set tv DotCrawl */
    if (property == tv_dotcrawl_atom) {
        retval = setTvPropertyDotCrawl(value, output);
        return retval;
    }

    /*set tv brightness */
    if (property == tv_brightness_atom) {
        retval = setTvPropertyBrightness(value, output);
        return retval;
    }

    /*set tv contrast */
    if (property == tv_contrast_atom) {
        retval = setTvPropertyContrast(value, output);
        return retval;
    }

    /*set tv saturation */
    if (property == tv_saturation_atom) {
        retval = setTvPropertySaturation(value, output);
        return retval;
    }

    /*set tv hue */
    if (property == tv_hue_atom) {
        retval = setTvPropertyHue(value, output);
        return retval;
    }

    /* Adapative filter value */
    if (property == tv_affliterValue_atom) {
        retval = setTvPropertyAFFliterValue(value, output);
        return retval;
    }

    /* Filter status */
    if (property == tv_ffliter_atom) {
        retval = setTvPropertyFFliter(value, output);
        return retval;
    }

    /*set tv ffliter Value */
    if (property == tv_ffliterValue_atom) {
        retval = setTvPropertyFFliterValue(value, output);
        return retval;
    }

    /*set tv horizontal scale */
    if (property == tv_hor_scale_atom) {
        retval = setTvPropertyHorScaleLevel(value, output);
        return retval;
    }

    /*set tv vertical scale */
    if (property == tv_ver_scale_atom) {
        retval = setTvPropertyVerScaleLevel(value, output);
        return retval;
    }

    /*set tv horiz position */
    if (property == tv_posh_atom) {
        retval = setTvPropertyPosH(value, output);
        return retval;
    }

    /*set tv vertical position */
    if (property == tv_posv_atom) {
        retval = setTvPropertyPosV(value, output);
        return retval;
    }

    return retval;
}

static void
via_tv_dpms(xf86OutputPtr output, int mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    int usedIga;
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 serialPort = tvInfo->commonInfo.serialPort;
    CARD32 subChipName = tvInfo->commonInfo.subChipName;
    CARD32 diPort = tvInfo->commonInfo.diPort;
    CARD32 outputSignal = tvInfo->signal;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;

    if (NONE_SUBCHIP == subChipName)
        return;

    switch (mode) {
    case DPMSModeOn:
        usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;
        /*1. Turn on DI port clock, set Iga source for DI port */
        if (diPort && usedIga)
            viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga,
                pVia->Chipset);
        /*2. Turn on TV encoder if it is exist */
        switch (subChipName) {
        case SUBCHIP_VT1625:
            if (vt1625_module_loaded) {
                viaEnableVt1625(serialPort, outputSignal);
                /* VT1625 power on, auto detect */
                tvInfo->isAutoDetect = TRUE;
            }
            break;

        case SUBCHIP_INTEGRATED_TV:
            if (integratedtv_module_loaded)
                viaEnableEmbTv(MMIOBase, EMBTV_DAC_PRIMARY);
            break;
        default:
            break;
        }
        /*3. Set tv clock source  */
        viaSetTvClockSource(tvInfo, pVia->Chipset, usedIga);
        break;
    case DPMSModeStandby:	       /* 1 */
    case DPMSModeSuspend:	       /* 2 */
    case DPMSModeOff:
        /*Turn off TV encoder if it is exist */
        switch (subChipName) {
        case SUBCHIP_VT1625:
            if (vt1625_module_loaded) {
                viaDisableVt1625(serialPort);
                /* VT1625 power off, normal detect */
                tvInfo->isAutoDetect = FALSE;
            }
            break;

        case SUBCHIP_INTEGRATED_TV:
            if (integratedtv_module_loaded)
                viaDisableEmbTv(MMIOBase, EMBTV_DAC_PRIMARY);

            break;
        default:
            break;
        }
        /*3. Turn off DI port clk */
        viaDIPortPadOff(pScrn->scrnIndex, diPort);
        break;
    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

/*
* Saves the crtc's state for restoration on VT switch.

static void
via_tv_save (xf86OutputPtr output)
{
}
*/
/*
* Restore's the crtc's state at VT switch.

static void
via_tv_restore (xf86OutputPtr output)
{
}
*/
/*
 * Callback for testing a video mode for a given output.
 *
 * This function should only check for cases where a mode can't be supported
 * on the pipe specifically, and not represent generic CRTC limitations.
 *
 * return MODE_OK if the mode is valid, or another MODE_* otherwise.
 */
static int
via_tv_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    int i = 0;

    while (TvSupportMode[i].ModeIndex > -1) {
        if ((mode->HDisplay == TvSupportMode[i].HActive) &&
            (mode->VDisplay == TvSupportMode[i].VActive))
            return MODE_OK;

        i++;
    }
    return MODE_NOMODE;
}

static Bool
via_tv_mode_fixup(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    int modeIndex = 0;
    ViaTvPrivateInfoPtr tvInfo =
	(ViaTvPrivateInfoPtr) (output->driver_private);

    modeIndex = VIA_MAKE_ID(adjusted_mode->HDisplay, adjusted_mode->VDisplay);
    viaFixupTvInfo(modeIndex, tvInfo);
    if ((tvInfo->commonInfo.subChipName == SUBCHIP_VT1625)
        && vt1625_module_loaded) {
        Vt1625FuncTablePtr vt1625_func = NULL;

        vt1625_func = viaParseVt1625FuncTable(modeIndex, tvInfo);
        if (vt1625_func == NULL)
            return FALSE;
        viaLoadVt1625BasicFuncReg(vt1625_func, tvInfo);
        viaLoadVt1625PatchFuncReg(vt1625_func, tvInfo);
        viaFixupVt1625Mode(adjusted_mode, tvInfo, vt1625_func);
        viaLoadVt1625CgmsReg(tvInfo);
    } else if ((tvInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TV) &&
        integratedtv_module_loaded) {
        if (viaEmbModeFixup(pVia, modeIndex, output, adjusted_mode) == FALSE)
            return FALSE;
    }

    return TRUE;
}

static void
via_tv_mode_set(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ViaTvPrivateInfoPtr tvInfo =
        (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subchipName = tvInfo->commonInfo.subChipName;
    CARD32 serialPort = tvInfo->commonInfo.serialPort;
    CARD32 diPort = tvInfo->commonInfo.diPort;
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    unsigned int MMIOBase = (unsigned int)pVia->IntegratedTVMapBase;
    int modeIndex = 0;
    int usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;

    /* Do SW reset */
    viaTvSwReset(MMIOBase, tvInfo);

    /*update the TV Caps and recreate the property */
    if (output->randr_output) {
        viaGetTvCapsSupported(output, adjusted_mode->HDisplay,
            adjusted_mode->VDisplay);
        createTvPropertyType(output);
    }

    /* get VT1625 TV Info */
    if ((subchipName == SUBCHIP_VT1625) && vt1625_module_loaded)
        viaGetVT1625TVInfo(tvInfo);
    else if ((subchipName == SUBCHIP_INTEGRATED_TV)
        && integratedtv_module_loaded)
        viaGetEmbTvInfo(tvInfo, MMIOBase);

    /*Patch for clock skew */
    modeIndex = VIA_MAKE_ID(adjusted_mode->HDisplay, adjusted_mode->VDisplay);
    loadTvDefaultDPASetting(output, pVia->Chipset, modeIndex);
    LoadUserGfxDPASetting(diPort, &tvInfo->userGfxDPA);
    LoadUserTvEncoderDPASetting(subchipName, serialPort,
        &tvInfo->userTvEncoderDPA);
}

static xf86OutputStatus
via_tv_detect(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputStatus status = XF86OutputStatusDisconnected;
    ViaTvPrivateInfoPtr viaTvInfo = (ViaTvPrivateInfoPtr)
        (output->driver_private);
    unsigned char ret = FALSE;
    unsigned int tvSubchipName = viaTvInfo->commonInfo.subChipName;
    unsigned short subchipSlaveAddr = viaTvInfo->commonInfo.slaveAddress;
    unsigned int serialPort = viaTvInfo->commonInfo.serialPort;
    unsigned char *RawEDID;

    switch (tvSubchipName) {
    case SUBCHIP_VT1625:
        if (vt1625_module_loaded)
            ret = viaDetectTvVia1625(pVia, serialPort, subchipSlaveAddr,
            viaTvInfo->isAutoDetect);
        break;
    case SUBCHIP_INTEGRATED_TV:
        /* Determine which DAC we should use according to chipset. */
        if (integratedtv_module_loaded)
            ret = viaDetectTvViaEmbTvEncoder(pVia);
        break;
    default:
        break;
    }

    if (ret) {
        status = XF86OutputStatusConnected;
    }
    return status;
}

static void
via_tv_destroy(xf86OutputPtr output)
{
    ViaTvPrivateInfoPtr viaTvInfo = (ViaTvPrivateInfoPtr)
	(output->driver_private);

    if (viaTvInfo->tvFeatureInfoPtr) {
        free((void *)viaTvInfo->tvFeatureInfoPtr);
        viaTvInfo->tvFeatureInfoPtr = NULL;
    }
    if (viaTvInfo) {
        free(viaTvInfo);
        viaTvInfo = NULL;
    }
}

static void
via_tv_prepare(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOff);
}

static void
via_tv_commit(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOn);
}

static DisplayModePtr
via_tv_get_modes(xf86OutputPtr output)
{
    DisplayModePtr modes = NULL;
    int i = 0;

    /* Add fake timing, which is calculated by CVT equation,
     * and we can't set the timing to the hardware */
    while (TvSupportMode[i].ModeIndex > -1) {
        modes = xf86ModesAdd(modes,
            xf86CVTMode(TvSupportMode[i].HActive,
            TvSupportMode[i].VActive, 60, 0, 0));
        i++;
    }
    return modes;
}

static const xf86OutputFuncsRec via_tv_output_funcs = {
    .create_resources = via_tv_create_resources,
    .set_property = via_tv_set_property,
    .dpms = via_tv_dpms,
    .save = NULL,
    .restore = NULL,
    .mode_valid = via_tv_mode_valid,
    .mode_fixup = via_tv_mode_fixup,
    .prepare = via_tv_prepare,
    .mode_set = via_tv_mode_set,
    .commit = via_tv_commit,
    .detect = via_tv_detect,
    .get_modes = via_tv_get_modes,
    .destroy = via_tv_destroy,
};

/*
Function Name:  checkTvSupport
Description:    Check if TV supported by platform
*/
static Bool
checkTvSupport(VIAPtr pVia, xf86OutputPtr output)
{
    Bool retVal = FALSE;
    ViaTvPrivateInfoPtr viaTvInfo = output->driver_private;

    viaTvInfo->tvFeatureInfoPtr = xnfcalloc(sizeof(TVFeature), 1);
    if (!(viaTvInfo->tvFeatureInfoPtr)) {
        ErrorF("Allocate TV Feature private info Fail.\n");
        return retVal;
    }

    /* default TV type is internal */
    if (viaTvInfo->commonInfo.type == DISP_DEFAULT_SETTING) {
        /* if the chip have the cap of internal TV encoder */
        if (pVia->GfxDispCaps & INTERNAL_TVEncoder)
            viaTvInfo->commonInfo.type = DISP_TYPE_INTERNAL;
        /* if the chip doesn't have, return FALSE directly */
        else
            return retVal;

    }

    /* deault TV DIPort */
    if (viaTvInfo->commonInfo.diPort == DISP_DEFAULT_SETTING) {
        /* for internal TV encoder: DAC */
        if (viaTvInfo->commonInfo.type == DISP_TYPE_INTERNAL)
            viaTvInfo->commonInfo.diPort = DISP_DI_DAC;
        /* for external and hard-wired TV, use DVP1 as default port */
        else
            viaTvInfo->commonInfo.diPort = DISP_DI_DVP1;

    }

    /*if DI port is free */
    if (checkDiPortUsage(pVia, viaTvInfo->commonInfo.diPort)) {
        /* internal TV Encoder */
        if (viaTvInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
            /* if the platform doesn't support internal TV, it fails  */
            if (INTERNAL_TVEncoder & pVia->GfxDispCaps) {
                viaTvInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_TV;
                viaTvInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
                /* default serial port (internal TV), NONE */
                if (viaTvInfo->commonInfo.serialPort == DISP_DEFAULT_SETTING)
                    viaTvInfo->commonInfo.serialPort = DISP_SERIALP_NONE;
                /* DI port is occupied, and internal TV cap is lost */
                pVia->MbDiPortUsedInfo |= viaTvInfo->commonInfo.diPort;
                pVia->GfxDispCaps &= ~INTERNAL_TVEncoder;
                retVal = TRUE;
            }
            /* external TV Encoder */
        } else if (viaTvInfo->commonInfo.type == DISP_TYPE_EXTERNAL) {
            /*Case that graphic chip before 3324 */
            if (DISP_DI_DVP0 == viaTvInfo->commonInfo.diPort &&
                !(DISP_DEV_TV & pVia->MbDvp0Device))
                pVia->MbDiPortUsedInfo &= ~DISP_DI_DVP0;
            else {
                /* Sense VT1625 */
                if (senseSubChip(&viaTvInfo->commonInfo, SUBCHIP_VT1625)) {
                    viaTvInfo->commonInfo.subChipName = SUBCHIP_VT1625;
                    viaTvInfo->commonInfo.slaveAddress =
                    SUBCHIP_VT1625_SLAVE_ADDR;
                    if (viaTvInfo->commonInfo.ddcPort == DISP_DEFAULT_SETTING)
                        viaTvInfo->commonInfo.ddcPort =
                            viaTvInfo->commonInfo.serialPort;
                    /* Mask the DI port which is occupied */
                    pVia->MbDiPortUsedInfo |= viaTvInfo->commonInfo.diPort;
                    retVal = TRUE;
                }
            }
            /* Hard-wired TV, reserved */
        } else {

        }
    }
    return retVal;
}

CARD32
transformTvStandard(char *pStr)
{
    if (!xf86NameCmp(pStr, "1080I"))
        return TV_STANDARD_1080I;
    else if (!xf86NameCmp(pStr, "720P"))
        return TV_STANDARD_720P;
    else if (!xf86NameCmp(pStr, "576P"))
        return TV_STANDARD_576P;
    else if (!xf86NameCmp(pStr, "480P"))
        return TV_STANDARD_480P;
    else if (!xf86NameCmp(pStr, "PAL"))
        return TV_STANDARD_PAL;
    else
        return TV_STANDARD_NTSC;

}

CARD32
transformTvSignal(char *pStr)
{
    if (!xf86NameCmp(pStr, "YCbCr"))
        return TV_SIGNAL_YCBCR;
    else if (!xf86NameCmp(pStr, "RGB"))
        return TV_SIGNAL_RGB;
    else if (!xf86NameCmp(pStr, "Composite"))
        return TV_SIGNAL_COMPOSITE;
    else if (!xf86NameCmp(pStr, "Composite+S-Video"))
        return (TV_SIGNAL_COMPOSITE + TV_SIGNAL_SVIDEO);
    else if (!xf86NameCmp(pStr, "Composite+S-Video+RGB"))
        return (TV_SIGNAL_COMPOSITE + TV_SIGNAL_SVIDEO + TV_SIGNAL_RGB);
    else if (!xf86NameCmp(pStr, "Composite+S-Video+YCbCr"))
        return (TV_SIGNAL_COMPOSITE + TV_SIGNAL_SVIDEO + TV_SIGNAL_YCBCR);
    else
        return TV_SIGNAL_SVIDEO;

}

CARD32
transformTvScan(char *pStr)
{
    if (!xf86NameCmp(pStr, "Over"))
        return TV_SCAN_OVER;
    else if (!xf86NameCmp(pStr, "Fit"))
        return TV_SCAN_FIT;
    else
        return TV_SCAN_NORMAL;

}

static void
parseTvOption(xf86OutputPtr output)
{
    char *s = NULL;
    int value = 0;
    int sPort = DISP_SERIALP_NONE;
    OptionInfoPtr tempRecOptionsPtr;
    ViaTvPrivateInfoPtr viaTvInfo = output->driver_private;

    viaTvInfo->userGfxDPA.isClkPolarityUsed = FALSE;
    viaTvInfo->userGfxDPA.isClkAdjustUsed = FALSE;
    viaTvInfo->userGfxDPA.isClkDrivingSelUsed = FALSE;
    viaTvInfo->userGfxDPA.isDataDrivingSelUsed = FALSE;

    /* Default value */
    viaTvInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
    viaTvInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    viaTvInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
    viaTvInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;
    viaTvInfo->standard = TV_STANDARD_NTSC;
    viaTvInfo->signal = TV_SIGNAL_SVIDEO;
    viaTvInfo->scan = TV_SCAN_NORMAL;
    viaTvInfo->deDotCrawl = FALSE;

    if (!(tempRecOptionsPtr = (OptionInfoPtr) malloc(sizeof(ViaTvOptions)))) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, ViaTvOptions, sizeof(ViaTvOptions));
    /* if no "TV" monitor section, all use default setting */
    if (output->conf_monitor)
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr);


    /* parse option "DIPort" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_TV_DIPORT)))
        viaTvInfo->commonInfo.diPort = transformDiPort(s);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_TV_TYPE)))
        viaTvInfo->commonInfo.type = transformOutputType(s);

    /* parse option "SerialPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_TV_SERIALPORT, &sPort))
        viaTvInfo->commonInfo.serialPort = transformPort(sPort);

    /* parse option "Standard" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_TV_STANDARD)))
        viaTvInfo->standard = transformTvStandard(s);

    /* parse option "Signal" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_TV_SIGNAL)))
        viaTvInfo->signal = transformTvSignal(s);

    /* parse option "Scan" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_TV_SCAN)))
        viaTvInfo->scan = transformTvScan(s);

    /* parse option "DeDotCrawl" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_TV_DEDOTCRAWL, FALSE))
        viaTvInfo->deDotCrawl = TRUE;

    /* parse user clock skew setting */
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_TV_CLOCK_POLARITY,
	    &value)) {
        viaTvInfo->userGfxDPA.clkPolarity = value & BIT0;
        viaTvInfo->userGfxDPA.isClkPolarityUsed = TRUE;
    }

    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_TV_CLOCK_ADJUST,
	    &value)) {
        viaTvInfo->userGfxDPA.clkAdjust = value;
        viaTvInfo->userGfxDPA.isClkAdjustUsed = TRUE;
    }

    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
	    OPTION_TV_CLOCK_DRIVING_SELECTION, &value)) {
        viaTvInfo->userGfxDPA.clkDrivingSel = value;
        viaTvInfo->userGfxDPA.isClkDrivingSelUsed = TRUE;
    }

    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
	    OPTION_TV_DATA_DRIVING_SELECTION, &value)) {
        viaTvInfo->userGfxDPA.dataDrivingSel = value;
        viaTvInfo->userGfxDPA.isDataDrivingSelUsed = TRUE;
    }

    /* 5. parse option "TvEncoderDPA" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_TV_VT162X_DPA, &value)) {
        viaTvInfo->userTvEncoderDPA.DPA = value;
        viaTvInfo->userTvEncoderDPA.isDPAUsed = TRUE;
    }

    free(tempRecOptionsPtr);
}

void
via_tv_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr outputTv;
    ViaTvPrivateInfoPtr viaTvInfo;

    outputTv = xf86OutputCreate(pScrn, &via_tv_output_funcs, name);
    if (!outputTv) {
        DEBUG(ErrorF("xf86OutputCreate %s Fail.\n", name));
        return;
    }
    viaTvInfo = xnfcalloc(sizeof(ViaTvPrivateInfo), 1);
    if (!viaTvInfo) {
        xf86OutputDestroy(outputTv);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }
    outputTv->driver_private = viaTvInfo;
    viaTvInfo->isAutoDetect = FALSE;   /* default use normal detect */

    /* Read TV options in TV monitor section */
    parseTvOption(outputTv);

    if (checkTvSupport(pVia, outputTv)) {
        if (viaTvInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TV)
            pVia->numOfEmbTv++;

        outputTv->possible_crtcs = 0x1 | 0x2;
        outputTv->possible_clones = 0;
        outputTv->interlaceAllowed = TRUE;
        outputTv->doubleScanAllowed = FALSE;

        if (!xf86NameCmp(name, OUTPUT_TV_NAME))
            pVia->tv1Created = TRUE;
    } else
        /* also free TV private date */
        xf86OutputDestroy(outputTv);

}
#endif
