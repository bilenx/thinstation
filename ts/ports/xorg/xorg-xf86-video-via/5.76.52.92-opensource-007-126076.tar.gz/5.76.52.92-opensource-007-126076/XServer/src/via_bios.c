/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*************************************************************************
 *
 *  File:       via_bios.c
 *  Content:    Get the mode table from VGA BIOS and set mode by this table
 *
 ************************************************************************/

#include "via_driver.h"
#include "hw.h"
#include "xf86Priv.h"
#include "via_rotate.h"
#include "via_serial.h"
#include "via_lcd.h"

/* Functions Prototype Declaration */
Bool IsValidMode(CARD16 HDisplay, CARD16 VDisplay);

/* Extern Functions Prototypes Declaration */
extern __inline__ void write_reg(CARD8 index, CARD16 io_port, CARD8 data);
extern void write_reg_mask(CARD8 index, int io_port, CARD8 data, CARD8 mask);
extern __inline__ CARD8 read_reg(int io_port, CARD8 index);
extern int SearchModeSetting(int ModeInfoIndex);
extern void EnableSecondDisplayChannel();
extern void DisableSecondDisplayChannel();

extern Bool vt1625_module_loaded;
extern Bool ad9389_module_loaded;

/* Support Mode, the order must follow the rule "small to big". */
struct _VIASUPPORTMODE VIASupportMode[] = {
/*  Index,         HActive, VActive*/
    {"480x640",     M480x640,     480,     640},
    {"640x480",     M640x480,     640,     480},
    {"720x480",     M720x480,     720,     480},
    {"720x576",     M720x576,     720,     576},
    {"800x480",     M800x480,     800,     480},
    {"800x600",     M800x600,     800,     600},
    {"848x480",     M848x480,     848,     480},
    {"852x480",     M852x480,     856,     480},
    {"960x600",     M960x600,     960,     600},
    {"1000x600",    M1000x600,    1000,    600},
    {"1024x512",    M1024x512,    1024,    512},
    {"1024x600",    M1024x600,    1024,    600},
    {"1024x576",    M1024x576,    1024,    576},
    {"1024x768",    M1024x768,    1024,    768},
    {"1088x612",    M1088x612,    1088,    612},
    {"1152x720",    M1152x720,    1152,    720},
    {"1152x864",    M1152x864,    1152,    864},
    {"1200x720",    M1200x720,    1200,    720},
    {"1280x600",    M1280x600,    1280,    600},
    {"1280x720",    M1280x720,    1280,    720},
    {"1280x768",    M1280x768,    1280,    768},
    {"1280x800",    M1280x800,    1280,    800},
    {"1280x960",    M1280x960,    1280,    960},
    {"1280x1024",   M1280x1024,   1280,    1024},
    {"1360x768",    M1360x768,    1360,    768},
    {"1366x768",    M1366x768,    1366,    768},
    {"1368x768",    M1368x768,    1368,    768},
    {"1400x1050",   M1400x1050,   1400,    1050},
    {"1440x900",    M1440x900,    1440,    900},
    {"1440x1050",   M1440x1050,   1440,    1050},
    {"1600x900",    M1600x900,    1600,    900},
    {"1600x1024",   M1600x1024,   1600,    1024},
    {"1600x1200",   M1600x1200,   1600,    1200},
    {"1680x1050",   M1680x1050,   1680,    1050},
    {"1792x1344",   M1792x1344,   1792,    1344},
    {"1856x1392",   M1856x1392,   1856,    1392},
    {"1920x1080",   M1920x1080,   1920,    1080},
    {"1920x1200",   M1920x1200,   1920,    1200},
    {"1920x1440",   M1920x1440,   1920,    1440},
    {"2048x1536",   M2048x1536,   2048,    1536},
    {"720x400",     M720x400,     720,     400},
    {"832x624",     M832x624,     832,     624},
    {"",            -1,           0,       0}
};



/* Search Valid mode */
Bool
IsValidMode(CARD16 HDisplay, CARD16 VDisplay)
{
    int i = 0;

    while (VIASupportMode[i].ModeIndex > -1) {
        if ((HDisplay == VIASupportMode[i].HActive) &&
            (VDisplay == VIASupportMode[i].VActive)) {
            return 1;
        }
        i++;
    }
    return 0;
}

Bool
VIAFindRefreshRate(VIABIOSInfoPtr pBIOSInfo, int ModeIndex)
{
    struct VideoModeTable   *VideoMode;
    int     i;
    int     needRefresh = pBIOSInfo->Refresh;

    if (pBIOSInfo->IsEnableInterlaceMode) {
        switch (ModeIndex) {
        case M1024x768:
        case M1152x864:
        case M1280x1024:
        case M1600x1200:
        case M1920x1080:
            ModeIndex |= 0x200;
            break;
        }
    }

    VideoMode = &VIARoutineModes[SearchModeSetting(ModeIndex)];

    for (i = 0; i < VideoMode->mode_array; i++) {
        pBIOSInfo->FoundRefresh = VideoMode->crtc[i].refresh_rate;

        if (VideoMode->crtc[i].refresh_rate == needRefresh) {
            return TRUE;
        }
    }

    xf86DrvMsg(pBIOSInfo->scrnIndex, X_WARNING,
        "Can't find refresh rate %d Hz.\n", needRefresh);

    return FALSE;
}

int
VIAGetModeIndex(int HorResolution, int VerResolution)
{
    int ModeIndex = M1024x768;
    int i = 0;

    while (VIASupportMode[i].ModeIndex > -1) {
        if ((HorResolution == VIASupportMode[i].HActive) &&
            (VerResolution == VIASupportMode[i].VActive)) {
            ModeIndex = VIASupportMode[i].ModeIndex;
            break;
        }

        i++;
    }

    return ModeIndex;
}


void
VIAGetModeSizeByName(char *pName, int *pHSize, int *pVSize)
{
    int i = 0;

    if (!pName) {
        return;
    }

    while (VIASupportMode[i].ModeIndex > -1) {
        if (xf86NameCmp(pName, VIASupportMode[i].Name) == 0) {
            *pHSize = VIASupportMode[i].HActive;
            *pVSize = VIASupportMode[i].VActive;
            break;
        }

        i++;
    }
}

void
VIAAdjustActiveSize(VIABIOSInfoPtr pBIOSInfo)
{
    int     HActive = pBIOSInfo->CrtcHDisplay;
    int     VActive = pBIOSInfo->CrtcVDisplay;

    /* pBIOSInfo->frameX1 pBIOSInfo->frameY1 always remain the actual view size
       whenever rotation or not */
    pBIOSInfo->frameX1 = HActive - 1;
    pBIOSInfo->frameY1 = VActive - 1;

    pBIOSInfo->HDisplay = HActive;
    pBIOSInfo->VDisplay = VActive;
}

Bool
VIAFindModeUseBIOSTable(ScrnInfoPtr pScrn)
{
    VIAPtr          pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr  pBIOSInfo = pVia->pBIOSInfo;
    int             needRefresh;
    int             ModeIndex;
    Bool            IsFoundRefresh = FALSE;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIAFindModeUseBIOSTable\n"));

    /* Initial down scaling variable. */
    pBIOSInfo->IsDownScaleEnable = FALSE;

    if (pBIOSInfo->VirtualX > 0) {
        /* If set Virtual Desktop Size in xorg.conf: */
        pBIOSInfo->ActualDesktopSizeX = pBIOSInfo->VirtualX;
        pBIOSInfo->ActualDesktopSizeY = pBIOSInfo->VirtualY;
    } else {
        pBIOSInfo->ActualDesktopSizeX = pBIOSInfo->CrtcHDisplay;
        pBIOSInfo->ActualDesktopSizeY = pBIOSInfo->CrtcVDisplay;
    }

    /* Initial device's setting information: */
    VIAAdjustActiveSize(pBIOSInfo);

    /* Find Resolution index: */
    ModeIndex = VIAGetModeIndex(pBIOSInfo->CrtcHDisplay,
                    pBIOSInfo->CrtcVDisplay);

    /* Find suitable refresh rate: */
    /* Set the refresh rate to 60MHz for DuoView. */
    /* Note: We should support other refresh rate later. */
    if (pBIOSInfo->OptRefresh) {
        pBIOSInfo->Refresh = pBIOSInfo->OptRefresh;
        IsFoundRefresh = VIAFindRefreshRate(pBIOSInfo, ModeIndex);
    } 

    if (!IsFoundRefresh) {
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_WARNING,
            "Refresh rate setting in xorg.conf is not supported!!\n");
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_WARNING,
            "Driver will try to find another refresh rate instead.\n");

        /* use the monitor information */
        /* needRefresh = (pBIOSInfo->Clock * 1000) /
                            (pBIOSInfo->HTotal * pBIOSInfo->VTotal); */
        /* Do rounding */
        needRefresh = ((pBIOSInfo->Clock * 10000) /
                        (pBIOSInfo->HTotal * pBIOSInfo->VTotal) + 5) / 10;
        pBIOSInfo->Refresh = needRefresh;
        IsFoundRefresh = VIAFindRefreshRate(pBIOSInfo, ModeIndex);
    }

    if (!IsFoundRefresh) {
        pBIOSInfo->FoundRefresh = 60;
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_WARNING,
            "Can't find suitable refresh rate, use 60Hz as default.\n");
    } 
	
    /* pBIOSInfo->widthByQWord =
        (pBIOSInfo->displayWidth * (pBIOSInfo->bitsPerPixel >> 3)) >> 3; */
    pBIOSInfo->offsetWidthByQWord =
        (pBIOSInfo->displayWidth * (pBIOSInfo->bitsPerPixel >> 3)) >> 3;
    pBIOSInfo->countWidthByQWord =
        (pBIOSInfo->CrtcHDisplay * (pBIOSInfo->bitsPerPixel >> 3)) >> 3;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "pBIOSInfo->FoundRefresh: %d\n", pBIOSInfo->FoundRefresh));
    return TRUE;
}

/* query NB to get frame buffer size */
int
VIAGetFBSize(ScrnInfoPtr pScrn)
{
    unsigned long   configid, deviceid, FBSize = 0;
    int   VideoMemSize;
    int   DeviceFound = FALSE;
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    for (configid = 0x80000000; configid < 0x80010800; configid += 0x100) {
        outl((unsigned long)0xCF8, configid);
        deviceid = (inl((unsigned long)0xCFC)>>16) & 0xffff;

        /* Add KM800 case*/
        switch (deviceid) {
        case CN700_FUNCTION3:
        case CX700_FUNCTION3:
        case KM890_FUNCTION3:
        case P4M890_FUNCTION3:
        case P4M900_FUNCTION3:
        case VX800_FUNCTION3:
        case VX855_FUNCTION3:
        case VX900_FUNCTION3:
            outl((unsigned long)0xCF8, configid + 0xA0);
            FBSize = inl((unsigned long)0xCFC);
            DeviceFound = TRUE; /* Found device id */
            break;

        /* Can't set default, otherwise FBSize will be modified incorrectly */
        default:
            break;
         }

         if (DeviceFound) {
            break; /* Found device id, so exit for loop */
         }
    }

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "Device ID = %lx\n", deviceid));

    FBSize = FBSize & 0x00007000;
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "FB Size = %lx\n", FBSize));

    if (pBIOSInfo->Chipset < VIA_CX700) {
        switch (FBSize) {
        case 0x00004000:
            VideoMemSize = (16 << 10);  /*16M*/
            break;

        case 0x00005000:
            VideoMemSize = (32 << 10);  /*32M*/
            break;

        case 0x00006000:
            VideoMemSize = (64 << 10);  /*64M*/
            break;

        default:
            VideoMemSize = (32 << 10);  /*32M*/
            break;
        }
    } else {
        switch (FBSize) {
        case 0x00001000:
            VideoMemSize = (8 << 10);   /*8M*/
            break;

        case 0x00002000:
            VideoMemSize = (16 << 10);  /*16M*/
            break;

        case 0x00003000:
            VideoMemSize = (32 << 10);  /*32M*/
            break;

        case 0x00004000:
            VideoMemSize = (64 << 10);  /*64M*/
            break;

        case 0x00005000:
            VideoMemSize = (128 << 10); /*128M*/
            break;

        case 0x00006000:
            VideoMemSize = (256 << 10); /*256M*/
            break;

        case 0x00007000:
            VideoMemSize = (512 << 10); /*512M*/
            break;

        default:
            VideoMemSize = (32 << 10);  /*32M*/
            break;
        }
    }

    pScrn->videoRam = VideoMemSize;

    return VideoMemSize;
}


void
VIADelayIn_usec(VIABIOSInfoPtr pBIOSInfo, int usec)
{
    VIABIOSInfoPtr  pVia = pBIOSInfo;
    volatile long   i;
    unsigned char   tmp;

    if (usec > 0) {
        for (i = usec * 4; i > 0; i--) {
            tmp = VGAIN8(0x3c3);
        }
    }
}

/*
*   Attach a new mode to the modeline.
*   So we don't need to add modeline in the config file.
*/
void
ViaModesAttachHelper(ScrnInfoPtr pScrn,
            MonPtr monitorp, DisplayModePtr Modes)
{
    DisplayModePtr mode;
    DisplayModePtr last = monitorp->Last;
    int i;

    for (i = 0; Modes[i].name; i++) {
        mode = xnfalloc(sizeof(DisplayModeRec));
        memcpy(mode, &Modes[i], sizeof(DisplayModeRec));
        mode->name = xnfstrdup(Modes[i].name);

        if (last) {
            mode->prev = last;
            last->next = mode;
        } else {
            /* this is the first mode */
            monitorp->Modes = mode;
            mode->prev = NULL;
        }
        last = mode;
    }

    monitorp->Last = last;
}

