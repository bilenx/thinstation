 /*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
/* This file does stuffs about user mode GEM interface implementation
 * it will call ioctl to communicate TTM core to deal with boes
 */
#include "config_via.h"
#include "via_bo.h"
#include <malloc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include "via_bo_gem.h"
#include "via_bo_reloc.h"
#include "via_bo.h"
#include <assert.h>
#if ! defined(LINUX_VERSION_CODE)  
#include <linux/version.h>
#endif

#define VIA_PAGE_SHIFT 12
#define VIA_PAGE_SIZE   (1UL << VIA_PAGE_SHIFT)
#define VIA_POOL_BO_MAX 0x10
#define via_roundup(x, y) ((((x) + ((y) - 1)) / (y)) * (y))

static void via_bo_reference(struct generic_bo *bo);
static void via_bo_unreference(struct generic_bo *bo);
static struct via_bo *
via_bo_pool_get_bo(struct via_bo_pool_mgr *bo_pool_mgr,
        unsigned long size, int type);
static int
via_bo_pool_free_bo(struct via_bo_pool_mgr *bo_pool_mgr, struct via_bo *vbo);
/* getting the exact read/write domains */
static unsigned int
via_bo_get_domain(enum drm_via_chrome9_reloc_type type);

static struct generic_bo *
via_bo_alloc(struct generic_bo_bufmgr *bufmgr_ctx,
        const char *name, unsigned long size, unsigned int alignment,
        uint32_t location_mask)
{
    struct via_bo *vbo;
    struct drm_via_chrome9_gem_create args;
    struct via_bo_pool_mgr *via_pool_mgr;
    int ret, type;

    via_pool_mgr = ((struct via_bo_bufmgr *)bufmgr_ctx)->bo_pool_mgr;

    /* Try to alloc from BO Pool first
     * Not cache VRAM Bos
     */
    type = ((location_mask & 0xF) == VIA_CHROME9_GEM_DOMAIN_VRAM) ? 0 : 1;
    if (!(location_mask & VIA_CHROME9_GEM_FLAG_NO_EVICT) && type &&
            (vbo = via_bo_pool_get_bo(via_pool_mgr, size, type)))
        return (struct generic_bo *)vbo;

    vbo = (struct via_bo*)calloc(1, sizeof(struct via_bo));
    if (vbo == NULL) {
        fprintf(stderr,"Failed to allocate the vbo \n");
        return NULL;
    }

    if (pthread_mutex_init(&vbo->lock, NULL) != 0) {
      free(vbo);
      return NULL;
    }

    vbo->bo.bufmgr = bufmgr_ctx;
    vbo->bo.size = size;
    vbo->bo.offset = 0;
    vbo->bo.virtual = NULL;
    DRMINITLISTHEAD(&vbo->list);
    vbo->handle = 0;
    vbo->domains= location_mask;
    vbo->name = name;
    vbo->reusable = 1;

    pthread_mutex_lock(&vbo->lock);
    vbo->reference_count = 1;
    pthread_mutex_unlock(&vbo->lock);

    args.size = size;
    args.alignment = alignment;
    args.initial_domain = location_mask;
    args.flags = 0;
    args.handle = 0;
    ret = drmCommandWriteRead(bufmgr_ctx->drmfd, DRM_VIA_CHROME9_GEM_CREATE,
                                &args, sizeof(args));
    vbo->handle = args.handle;
    vbo->bo.offset = args.offset;
    if (ret) {
        fprintf(stderr,"Failed to allocate the bo handle \n");
        fprintf(stderr,"   size=%lu bytes\n", size);
        free(vbo);
        return NULL;
    }
    return (struct generic_bo*)vbo;
}

/** Takes a reference on a buffer object */
static void
via_bo_reference(struct generic_bo *bo)
{
    struct via_bo *vbo = (struct via_bo *)bo;
    pthread_mutex_lock(&vbo->lock);
    vbo->reference_count++;
    pthread_mutex_unlock(&vbo->lock);
}

/**
* Releases a reference on a buffer object, freeing the data if
* rerefences remain.
*/
static void
via_bo_unreference(struct generic_bo *bo)
{
    struct via_bo *vbo = (struct via_bo *)bo;
    struct drm_gem_close args;
    struct via_bo_pool_mgr *via_pool_mgr;

    assert(vbo->reference_count > 0);
    pthread_mutex_lock(&vbo->lock);
    vbo->reference_count = vbo->reference_count - 1;
    if (vbo->reference_count){
        pthread_mutex_unlock(&vbo->lock);
        return;
    }
    pthread_mutex_unlock(&vbo->lock);
    /* If bo is already be unrefed */
    if (!bo->bufmgr)
        return ;

    /* Try to add to bo pool first
     * Not cache VRAM BOs
     */
    via_pool_mgr = ((struct via_bo_bufmgr *)bo->bufmgr)->bo_pool_mgr;
    if (vbo->reusable && via_pool_mgr->initialized &&
        !(vbo->domains & VIA_CHROME9_GEM_FLAG_NO_EVICT) &&
        !(vbo->domains & VIA_CHROME9_GEM_DOMAIN_VRAM)) {
        if (!via_bo_pool_free_bo(via_pool_mgr, vbo)) {
            via_bo_reference(bo);
            return;
        }
    }
    /*unmap object*/
    if (bo->virtual)
        munmap(bo->virtual, bo->size);

    memset(&args, 0, sizeof(args));

    /*close object*/
    args.handle = vbo->handle;
    ioctl(bo->bufmgr->drmfd, DRM_IOCTL_GEM_CLOSE, &args);
    memset(vbo, 0, sizeof(struct via_bo));
    free(vbo);
    vbo = NULL;
 }

/**
* Maps the buffer into userspace.
*
* This function will block waiting for any existing fence on the buffer to
* clear, first.  The resulting mapping is available at buf->virtual.
*/
static int
via_bo_map(struct generic_bo *bo, int write_enable)
{
    struct via_bo *vbo = (struct via_bo*)bo;
    struct drm_via_chrome9_gem_mmap args;
    int ret;

    if (bo->virtual)
        return 0;

    bo->virtual = NULL;
    memset(&args, 0, sizeof(args));
    args.handle = vbo->handle;
    args.offset = 0;
    args.size = (uint64_t)bo->size;
    ret = drmCommandWriteRead(bo->bufmgr->drmfd,
                            DRM_VIA_CHROME9_GEM_MMAP,
                            &args,
                            sizeof(args));
    if (ret) {
        fprintf(stderr,"error mapping %p 0x%08X \n", bo, vbo->handle);
        return ret;
    }

#if (((LINUX_VERSION_CODE + 768) == KERNEL_VERSION(3,5,35)) || (LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0)))  
	bo->virtual = mmap(0, args.size, PROT_READ | PROT_WRITE, MAP_SHARED,
			bo->bufmgr->drmfd, args.addr_ptr);
#else 
    bo->virtual = args.virtual;
#endif
    return 0;
}

/** Reduces the refcount on the userspace mapping of the buffer object. */
static int
via_bo_unmap(struct generic_bo *bo)
{
    return 0;
}

/** Creat a global name for this bo */
static int
via_bo_flink(struct generic_bo *bo, unsigned int *name)
{
    struct drm_gem_flink flink;
    struct via_bo *vbo = (struct via_bo*)bo;
    int ret;

    flink.handle = vbo->handle;
    ret = ioctl(bo->bufmgr->drmfd, DRM_IOCTL_GEM_FLINK, &flink);
    if (ret) {
        fprintf(stderr,"Failed to flink the bo \n");
        return ret;
    }

    *name = flink.name;
    vbo->global_name = flink.name;

    /* disable BO reuse if this BO may shared */
    vbo->reusable = 0;
    return 0;
}

static int
via_bo_wait(struct generic_bo *bo)
{
    struct drm_via_chrome9_gem_wait bo_wait;
    struct via_bo *vbo = (struct via_bo*)bo;
    int ret;

    bo_wait.handle = vbo->handle;
    bo_wait.no_wait = 0;
    ret = drmCommandWriteRead(bo->bufmgr->drmfd, DRM_VIA_CHROME9_GEM_WAIT,
            &bo_wait, sizeof(bo_wait));
    if (ret) {
        fprintf(stderr,"Failed to wait the bo \n");
        return ret;
    }
    return 0;
}

/* via_bo_is_free
 * return 0, if bo is free
 */
static int
via_bo_is_idle(struct generic_bo *bo)
{
    struct drm_via_chrome9_gem_wait bo_wait;
    struct via_bo *vbo = (struct via_bo*)bo;
    int ret;

    bo_wait.handle = vbo->handle;
    bo_wait.no_wait = 1;
    ret = drmCommandWriteRead(bo->bufmgr->drmfd, DRM_VIA_CHROME9_GEM_WAIT,
            &bo_wait, sizeof(bo_wait));

    return ret;
}

/** Get the global bo with the global name */
static struct generic_bo *
via_bo_open(struct generic_bo_bufmgr *bufmgr_ctx,
        unsigned int global_name, unsigned int location_mask)
{
    struct via_bo *vbo;
    struct drm_gem_open args;
    int ret;

    vbo = (struct via_bo*)calloc(1, sizeof(struct via_bo));
    if (vbo == NULL) {
        fprintf(stderr,"Failed to allocate the vbo \n");
        return NULL;
    }

    if (pthread_mutex_init(&vbo->lock, NULL) != 0) {
      free(vbo);
      return NULL;
    }

    args.name = global_name;
    ret = ioctl(bufmgr_ctx->drmfd, DRM_IOCTL_GEM_OPEN, &args);
    if (ret) {
        fprintf(stderr,"Failed to allocate the bo handle for global bo\n");
        free(vbo);
        return NULL;
    }
    vbo->global_name = global_name;
    vbo->bo.bufmgr = bufmgr_ctx;
    vbo->domains= location_mask;
    vbo->handle = args.handle;
    vbo->bo.size = args.size;

    via_bo_reference((struct generic_bo*)vbo);
    return (struct generic_bo*)vbo;
}

static unsigned int
via_bo_get_domain(enum drm_via_chrome9_reloc_type type)
{
    switch(type) {
    case VIA_RELOC_2D:
    case VIA_RELOC_3D:
    case VIA_RELOC_VERTEX_STREAM_L:
    case VIA_RELOC_VERTEX_STREAM_H:
        return VIA_CHROME9_OBJ_DOMAIN_GFX;
    case VIA_RELOC_HQV0:
        return VIA_CHROME9_OBJ_DOMAIN_HQV0;
    case VIA_RELOC_HQV1:
        return VIA_CHROME9_OBJ_DOMAIN_HQV1;
    case VIA_RELOC_VIDEO:
        return VIA_CHROME9_OBJ_DOMAIN_VIDEO;
    case VIA_RELOC_VD:
        return VIA_CHROME9_OBJ_DOMAIN_VD;
    default:
            fprintf(stderr, "via_bo_get_domain: unkown command type\n");
        break;
    }
}

/** build the reloc list for buffer object valid. */
static int
via_bo_reloc(unsigned int *buffer_ptr, unsigned long offset,
            struct generic_bo *target_bo,
            uint32_t delta,
            uint32_t location_mask,
            enum drm_via_chrome9_reloc_type type)
{
    struct via_bo *target_vbo = (struct via_bo *)target_bo;
    struct generic_bo_bufmgr *bo_bufmgr = target_bo->bufmgr;
    struct via_bo_bufmgr *vbo_mgr = (struct via_bo_bufmgr *)bo_bufmgr;
    struct via_bo_reloc_info *preloc_info = &vbo_mgr->reloc_info;

    if (preloc_info->relocs == NULL &&
        drm_via_chrome9_setup_reloc(preloc_info))
        return -errno;

    /* write the taget bo to command buffer */
    via_gem_write_reloc(buffer_ptr, offset, target_bo, delta, type);

    /* allocate more relocation */
     if (preloc_info->reloc_count >= preloc_info->max_reloc) {
        uint32_t size;

        size = ((preloc_info->max_reloc + 6) *
                    sizeof(struct drm_via_chrome9_gem_relocation_entry));
        preloc_info->relocs = (struct drm_via_chrome9_gem_relocation_entry *)
                    realloc(preloc_info->relocs, size);
        if (preloc_info->relocs == NULL) {
            return -errno;
        }
        size = ((preloc_info->max_reloc + 6) * sizeof(struct via_bo *));
        preloc_info->target_bo_list =
                   (struct via_bo **)realloc(preloc_info->target_bo_list, size);
        if (preloc_info->target_bo_list == NULL) {
            return -errno;
        }
        preloc_info->max_reloc += 6;
    }

    /* record the target bo info to the reloc list */
    preloc_info->relocs[preloc_info->reloc_count].offset = offset;
    preloc_info->relocs[preloc_info->reloc_count].delta = delta;
    preloc_info->relocs[preloc_info->reloc_count].target_handle = target_vbo->handle;
    preloc_info->relocs[preloc_info->reloc_count].location_mask = target_vbo->domains;
    preloc_info->relocs[preloc_info->reloc_count].presumed_offset = target_bo->offset;
    preloc_info->relocs[preloc_info->reloc_count].type = type;
    preloc_info->relocs[preloc_info->reloc_count].read_domains= VIA_CHROME9_OBJ_DOMAIN_GPU;
    preloc_info->relocs[preloc_info->reloc_count].write_domain= VIA_CHROME9_OBJ_DOMAIN_GPU;
    preloc_info->relocs[preloc_info->reloc_count].access_engine_type = via_bo_get_domain(type);
    preloc_info->target_bo_list[preloc_info->reloc_count] = target_vbo;
    preloc_info->reloc_count++;

    via_bo_reference((struct generic_bo*)target_vbo);

    return 0;
}

static int
via_bo_branch_buffer_reloc(struct via_cmd_buffer_obj *cmd_bo,
            unsigned long offset,
            struct generic_bo *target_bo,
            uint32_t delta,
            uint32_t location_mask,
            enum drm_via_chrome9_reloc_type type)
{
    struct via_bo *target_vbo = (struct via_bo *)target_bo;
    struct generic_bo_bufmgr *bo_bufmgr = target_bo->bufmgr;
    struct via_bo_bufmgr *vbo_mgr = (struct via_bo_bufmgr *)bo_bufmgr;
    struct via_bo_reloc_info *preloc_info;
    struct via_branch_buffer_mgr  *via_branchbuf_mgr;
    struct via_branchbuf_bo *vbranch_bo;

    via_branchbuf_mgr = vbo_mgr->branchbuf_mgr;
    vbranch_bo = &via_branchbuf_mgr->buf_bo[cmd_bo->num];
    preloc_info = &vbranch_bo->reloc_info;

    if (preloc_info->relocs == NULL && drm_via_chrome9_setup_reloc(preloc_info))
        return -errno;

    /* write the taget bo to command buffer */
    via_gem_write_reloc(cmd_bo->bo->virtual, offset, target_bo, delta, type);

    /* allocate more relocation */
     if (preloc_info->reloc_count >= preloc_info->max_reloc) {
        uint32_t size;

        size = ((preloc_info->max_reloc + 6) *
                    sizeof(struct drm_via_chrome9_gem_relocation_entry));
        preloc_info->relocs = (struct drm_via_chrome9_gem_relocation_entry *)
                    realloc(preloc_info->relocs, size);
        if (preloc_info->relocs == NULL) {
            return -errno;
        }
        size = ((preloc_info->max_reloc + 6) * sizeof(struct via_bo *));
        preloc_info->target_bo_list = (struct via_bo **)
                realloc(preloc_info->target_bo_list, size);
        if (preloc_info->target_bo_list == NULL) {
            return -errno;
        }
        preloc_info->max_reloc += 6;
    }

    /* record the target bo info to the reloc list */
    preloc_info->relocs[preloc_info->reloc_count].offset = offset;
    preloc_info->relocs[preloc_info->reloc_count].delta = delta;
    preloc_info->relocs[preloc_info->reloc_count].target_handle =
        target_vbo->handle;
    preloc_info->relocs[preloc_info->reloc_count].location_mask =
        target_vbo->domains;
    preloc_info->relocs[preloc_info->reloc_count].presumed_offset =
        target_bo->offset;
    preloc_info->relocs[preloc_info->reloc_count].type = type;
    preloc_info->relocs[preloc_info->reloc_count].read_domains =
        VIA_CHROME9_OBJ_DOMAIN_GPU;
    preloc_info->relocs[preloc_info->reloc_count].write_domain =
        VIA_CHROME9_OBJ_DOMAIN_GPU;
    preloc_info->relocs[preloc_info->reloc_count].access_engine_type =
        via_bo_get_domain(type);
    preloc_info->target_bo_list[preloc_info->reloc_count] = target_vbo;
    preloc_info->reloc_count++;

    via_bo_reference((struct generic_bo*)target_vbo);

    return 0;
}

/* set command type when no relocaton does */
static void
via_bo_set_cmd_type(struct generic_bo *bo, uint32_t cmd_type)
{
    struct via_bo *vbo = (struct via_bo*)bo;
    struct generic_bo_bufmgr *bo_bufmgr = bo->bufmgr;
    struct via_bo_bufmgr *vbo_mgr = (struct via_bo_bufmgr *)bo_bufmgr;

    vbo_mgr->reloc_info.cmd_type = cmd_type;
}

/** flush the command. */
static int
via_bo_flush(struct generic_bo *bo, unsigned int *buffer_ptr, int length,
            drm_clip_rect_t * cliprects, int num_cliprects)
{
    struct via_bo *vbo = (struct via_bo *)bo;
    struct generic_bo_bufmgr *bo_bufmgr = bo->bufmgr;
    struct via_bo_bufmgr *vbo_mgr = (struct via_bo_bufmgr *)bo_bufmgr;
    struct drm_via_chrome9_gem_flush args;
    struct via_bo *target_vbo;
    struct drm_via_chrome9_gem_relocation_entry entry;
    int ret, i;

    if (vbo_mgr->exec_objects == NULL &&
                drm_via_chrome9_setup_exec_objects(&vbo_mgr->exec_objects))
        return -errno;

    vbo_mgr->exec_objects->buffer_ptr = (uint64_t)buffer_ptr;
    vbo_mgr->exec_objects->relocs_ptr = (uint64_t) vbo_mgr->reloc_info.relocs;
    vbo_mgr->exec_objects->buffer_length = length;
    vbo_mgr->exec_objects->relocation_count = vbo_mgr->reloc_info.reloc_count;

    args.buffer_ptr = (uintptr_t)vbo_mgr->exec_objects;
    args.cliprects_ptr = (uintptr_t)cliprects;
    args.num_cliprects = num_cliprects;
    /* XXX temporary solution */
    args.flag = VIA_CHROME9_FLUSH_RING_BUFFER |
                    (vbo_mgr->reloc_info.cmd_type ?
                    vbo_mgr->reloc_info.cmd_type :
                    VIA_CHROME9_CMD_GFX);
    vbo_mgr->reloc_info.cmd_type = 0;

    ret = drmCommandWriteRead(bo->bufmgr->drmfd,
                            DRM_VIA_CHROME9_GEM_FLUSH,
                            &args,
                            sizeof(args));
    if (ret) {
        fprintf(stderr, "error flush the command %p 0x%08X \n",
            bo, vbo->handle);
        return ret;
    }

    /* update the target bo offset */
    for (i = 0; i < vbo_mgr->reloc_info.reloc_count; i++) {
        target_vbo = vbo_mgr->reloc_info.target_bo_list[i];
        entry = vbo_mgr->reloc_info.relocs[i];

        if (target_vbo->bo.offset != entry.presumed_offset)
            target_vbo->bo.offset = entry.presumed_offset;
        via_bo_unreference((struct generic_bo*)target_vbo);
    }
    vbo_mgr->reloc_info.reloc_count = 0;

    return 0;
}

/* set bo to cpu domain */
static int
via_bo_set_cpu_domain(struct generic_bo *bo, int  write_enable)
{
    int ret;
    struct drm_via_chrome9_gem_set_domain args;
    struct via_bo *vbo = (struct via_bo *)bo;
    int write_domain;

    write_domain = write_enable ? VIA_CHROME9_OBJ_DOMAIN_CPU : 0;
    args.handle = vbo->handle;
    switch (vbo->domains) {
        case VIA_CHROME9_GEM_DOMAIN_GTT:
            args.write_domain = VIA_CHROME9_GEM_DOMAIN_GTT | write_domain;
            args.read_domains = VIA_CHROME9_GEM_DOMAIN_GTT | VIA_CHROME9_OBJ_DOMAIN_CPU;
            break;
        case VIA_CHROME9_GEM_DOMAIN_VRAM:
            args.write_domain = VIA_CHROME9_GEM_DOMAIN_CPU | write_domain;
            args.read_domains = VIA_CHROME9_GEM_DOMAIN_CPU | VIA_CHROME9_OBJ_DOMAIN_CPU;
            break;
        default:
            return -EINVAL;
    }

    ret = drmCommandWriteRead(bo->bufmgr->drmfd,
        DRM_VIA_CHROME9_GEM_SET_DOMAIN,
        &args,
        sizeof(args));

    if (ret) {
        fprintf(stderr,"set bo domain to cpu failed\n");
        return ret;
    }

    return 0;
}

/* cpu grab/ungrab bo */
static int
via_bo_cpu_grab(struct generic_bo *bo)
{
    int ret;
    struct drm_via_chrome9_cpu_grab args;
    struct via_bo *vbo = (struct via_bo *)bo;

    args.handle = vbo->handle;

    ret = drmCommandWriteRead(bo->bufmgr->drmfd,
        DRM_VIA_CHROME9_GEM_CPU_GRAB,
        &args,
        sizeof(args));

    if (ret) {
        fprintf(stderr,"cpu grab bo failed\n");
        return ret;
    }

    return 0;
}

static int
via_bo_cpu_release(struct generic_bo *bo)
{
    int ret;
    struct drm_via_chrome9_cpu_release args;
    struct via_bo *vbo = (struct via_bo *)bo;

    args.handle = vbo->handle;

    ret = drmCommandWriteRead(bo->bufmgr->drmfd,
        DRM_VIA_CHROME9_GEM_CPU_RELEASE,
        &args,
        sizeof(args));

    return 0;
}
/**
 * Init Branch buffer, alloc BOs for branch buffer use
 * @bufmgr_ctx
 * @buf_num  number of branch command will be allocated to manage
 * @buf_size size of each branch buffer
 */
static int
via_bo_branch_buffer_init(struct generic_bo_bufmgr *bufmgr_ctx,
            int buf_num, int buf_size)
{
    struct via_branch_buffer_mgr  *via_branchbuf_mgr;
    struct via_bo_bufmgr *vbo_mgr;
    int i = 0;

    vbo_mgr = (struct via_bo_bufmgr *)bufmgr_ctx;
    via_branchbuf_mgr = calloc(1, sizeof(struct via_branch_buffer_mgr));
    via_branchbuf_mgr->buf_bo = calloc(buf_num, sizeof(struct via_branchbuf_bo));

    DRMINITLISTHEAD(&via_branchbuf_mgr->busy);
    DRMINITLISTHEAD(&via_branchbuf_mgr->free);

    /* alloc branch buffer BO */
    while (i < buf_num) {
        via_branchbuf_mgr->buf_bo[i].bo = dri_bo_alloc(bufmgr_ctx, "branch_buf",
                                buf_size, 0, VIA_CHROME9_GEM_DOMAIN_GTT);
        if (!via_branchbuf_mgr->buf_bo[i].bo) {
            fprintf(stderr,"can not alloc the branch buffer bo \n");
            return -1;
        }
        if(dri_bo_map(via_branchbuf_mgr->buf_bo[i].bo, 0)) {
            fprintf(stderr,"can not mmap the branch buffer bo \n");
            return -1;
        }
        /*Init list & add to free list*/
        DRMINITLISTHEAD(&via_branchbuf_mgr->buf_bo[i].list);
        DRMLISTADDTAIL(&via_branchbuf_mgr->buf_bo[i].list,
            &via_branchbuf_mgr->free);
        via_branchbuf_mgr->buf_bo[i].num = i;
        via_branchbuf_mgr->buf_bo[i].reloc_info.max_reloc = 32;
        i++;
    }
    pthread_mutex_init(&via_branchbuf_mgr->lock, NULL);
    via_branchbuf_mgr->buffer_num = buf_num;
    vbo_mgr->branchbuf_mgr = via_branchbuf_mgr;
    return 0;
}

/**
 * Get a branch buffer
 * @cmd_type type of command will be used in this branch buffer
 * @buf_bo return value of branch buffer BO
 * return 0 if success
 */

static int
via_bo_branch_buffer_get(struct generic_bo_bufmgr *bufmgr_ctx,
        uint32_t cmd_type, struct via_cmd_buffer_obj * buf_bo)
{
    struct via_branch_buffer_mgr  *via_branchbuf_mgr;
    struct via_bo_bufmgr *vbo_mgr;
    struct via_branchbuf_bo *vbranch_bo;
    drmMMListHead *item, *temp;
    int i = 0;

    vbo_mgr = (struct via_bo_bufmgr *)bufmgr_ctx;
    via_branchbuf_mgr = vbo_mgr->branchbuf_mgr;

    pthread_mutex_lock(&via_branchbuf_mgr->lock);
    /* If no free branch buffer, try to reclaim*/
    if (DRMLISTEMPTY(&via_branchbuf_mgr->free)) {
reclaim:
        DRMLISTFOREACHSAFE(item, temp, &via_branchbuf_mgr->busy) {
            if (item == &via_branchbuf_mgr->free) {
                /* issue */
                    pthread_mutex_unlock(&via_branchbuf_mgr->lock);
                    return -1;
            }
            vbranch_bo = DRMLISTENTRY(struct via_branchbuf_bo, item, list);
            /* If BO not free*/
            if (0 != via_bo_is_idle(vbranch_bo->bo))
                break;
            /*If BO is free, add to idle list*/
            DRMLISTDEL(&vbranch_bo->list);
            DRMLISTADDTAIL(&vbranch_bo->list, &via_branchbuf_mgr->free);
        }
        /* all branch buffer is busy, wait the fist used one*/
        if (DRMLISTEMPTY(&via_branchbuf_mgr->free)) {
            DRMLISTFOREACHSAFE(item, temp, &via_branchbuf_mgr->busy) {
                vbranch_bo = DRMLISTENTRY(struct via_branchbuf_bo, item, list);
                if (dri_bo_wait(vbranch_bo->bo)) {
                    pthread_mutex_unlock(&via_branchbuf_mgr->lock);
                    return -1;
                }
                DRMLISTDEL(&vbranch_bo->list);
                DRMLISTADDTAIL(&vbranch_bo->list, &via_branchbuf_mgr->free);
                break;
            }
        }
    }

    /* If free list not empty, just get one */
    DRMLISTFOREACHSAFE(item, temp, &via_branchbuf_mgr->free) {
        if (item == &via_branchbuf_mgr->free)
            goto reclaim;

        vbranch_bo = DRMLISTENTRY(struct via_branchbuf_bo, item, list);
        DRMLISTDEL(&vbranch_bo->list);
        buf_bo->bo= vbranch_bo->bo;
        buf_bo->num = vbranch_bo->num;
        buf_bo->type = 0;
        vbranch_bo->cmd_type = cmd_type;
        break;
    }
    pthread_mutex_unlock(&via_branchbuf_mgr->lock);

    return 0;
}

/**
 * Flush buranch buffer command
 * @cmd_bo - branch buffer BO object got from "branch_buffer_get"
 * @length - length of command in BO (In Dword count)
 * @cliprects -
 * @num_cliprects -
 * return 0, if success
 */
static int
via_bo_branch_buffer_flush(struct via_cmd_buffer_obj *cmd_bo, int length,
            drm_clip_rect_t * cliprects, int num_cliprects)
{
    struct via_bo *vbo = (struct via_bo *)cmd_bo->bo;
    struct generic_bo_bufmgr *bo_bufmgr = cmd_bo->bo->bufmgr;
    struct via_bo_bufmgr *vbo_mgr = (struct via_bo_bufmgr *)bo_bufmgr;
    struct drm_via_chrome9_gem_flush args;
    struct via_bo *target_vbo;
    struct drm_via_chrome9_gem_relocation_entry entry;
    struct via_branch_buffer_mgr  *via_branchbuf_mgr;
    struct via_branchbuf_bo *vbranch_bo;
    int ret, i;

    via_branchbuf_mgr = vbo_mgr->branchbuf_mgr;
    vbranch_bo = &via_branchbuf_mgr->buf_bo[cmd_bo->num];

    if (vbranch_bo->exec_objects == NULL &&
        drm_via_chrome9_setup_exec_objects(&vbranch_bo->exec_objects))
        return -errno;

    vbranch_bo->exec_objects->cmd_bo_handle = (uint32_t)vbo->handle;
    vbranch_bo->exec_objects->relocs_ptr = (uint64_t) vbranch_bo->reloc_info.relocs;
    vbranch_bo->exec_objects->buffer_length = length;
    vbranch_bo->exec_objects->relocation_count = vbranch_bo->reloc_info.reloc_count;

    args.buffer_ptr = (uintptr_t)vbranch_bo->exec_objects;
    args.cliprects_ptr = (uintptr_t)cliprects;
    args.num_cliprects = num_cliprects;
    args.flag = VIA_CHROME9_FLUSH_BRANCH_BUFFER;

    if (vbranch_bo->cmd_type)
        args.flag |= vbranch_bo->cmd_type & VIA_CHROME9_CMD_MASK;
    else if (cmd_bo->type)
        args.flag |= cmd_bo->type & VIA_CHROME9_CMD_MASK;

    ret = drmCommandWriteRead(cmd_bo->bo->bufmgr->drmfd,
                            DRM_VIA_CHROME9_GEM_FLUSH,
                            &args,
                            sizeof(args));
    if (ret) {
        fprintf(stderr,"error flush the command %p 0x%08X \n",
            cmd_bo->bo, vbo->handle);
        return ret;
    }

    /* add to branch buffer busy list */
    pthread_mutex_lock(&via_branchbuf_mgr->lock);
    DRMLISTADDTAIL(&vbranch_bo->list, &via_branchbuf_mgr->busy);
    pthread_mutex_unlock(&via_branchbuf_mgr->lock);

    /* update the target bo offset */
    for (i = 0; i < vbranch_bo->reloc_info.reloc_count; i++) {
        target_vbo = vbranch_bo->reloc_info.target_bo_list[i];
        entry = vbranch_bo->reloc_info.relocs[i];

        if (target_vbo->bo.offset != entry.presumed_offset)
            target_vbo->bo.offset = entry.presumed_offset;
        via_bo_unreference((struct generic_bo*)target_vbo);
    }
    vbranch_bo->reloc_info.reloc_count = 0;

    return 0;
}
/**
 * Free all resouce used in Branch buffer
 */
static void
via_bo_branch_buffer_finish(struct generic_bo_bufmgr *bufmgr_ctx)
{
    struct via_branch_buffer_mgr  *via_branchbuf_mgr;
    struct via_bo_bufmgr *vbo_mgr;
    struct via_branchbuf_bo *vbuf_bo;

    int i = 0;

    vbo_mgr = (struct via_bo_bufmgr *)bufmgr_ctx;
    via_branchbuf_mgr = vbo_mgr->branchbuf_mgr;

    /*wait all command exec done then release all branch buffer BO*/
    for (i = 0 ; i < via_branchbuf_mgr->buffer_num; i++){
        vbuf_bo = &via_branchbuf_mgr->buf_bo[i];
        dri_bo_wait(vbuf_bo->bo);
        via_bo_unmap(vbuf_bo->bo);
        via_bo_unreference(vbuf_bo->bo);
        free(vbuf_bo->exec_objects);
        free(vbuf_bo->reloc_info.relocs);
        free(vbuf_bo->reloc_info.target_bo_list);
    }

    free(via_branchbuf_mgr->buf_bo);
    free(via_branchbuf_mgr);
    return;
}

static inline int
via_get_bo_type(struct via_bo *vbo)
{
    return (vbo->domains == VIA_CHROME9_GEM_DOMAIN_VRAM) ? 0 : 1;
}

/* For get bo from bucket
    get a bo from pool, which size may larger than expected.
 */
static inline struct via_bo_bucket *
via_bo_get_bucket_roundup(struct via_bo_pool_mgr *via_pool_mgr,
              int size, int type)
{
    int i;
    struct via_bo_bucket * buck = NULL;

    assert(type == 0 || type == 1);

    for (i = 0; i < VIA_BO_POOL_NUM; i++) {
        if (via_pool_mgr->buckets[type][i].size >= size &&
            via_pool_mgr->buckets[type][i].size < size * 2) {
            buck = &via_pool_mgr->buckets[type][i];
            break;
        }
    }
    return buck;
}

/*
 * Free a bo to the bucket which size >= bo size
 */

static inline struct via_bo_bucket *
via_bo_get_bucket_rounddown(struct via_bo_pool_mgr *via_pool_mgr,
            int size, int type)
{
    int i;
    struct via_bo_bucket * buck = NULL;

    assert(type == 0 || type == 1);

    for (i = 0; i < VIA_BO_POOL_NUM; i++) {
        if (via_pool_mgr->buckets[type][i].size > size / 2 &&
            via_pool_mgr->buckets[type][i].size <= size) {
            buck = &via_pool_mgr->buckets[type][i];
            break;
        }
    }
    return buck;
}

static int
via_bo_add_backet(struct via_bo_bufmgr *via_bo_mgr,
            int size)
{
    int i;
    int slot = via_bo_mgr->bo_pool_mgr->bucket_num;
    struct via_bo_pool_mgr *via_pool_mgr = via_bo_mgr->bo_pool_mgr;

    if (slot >= VIA_BO_POOL_NUM) {
        fprintf(stderr, "ERROR: Exceed Max bucket number !");
        return -1;
    }

    for (i = 0 ; i < VIA_BO_TYPE; i++) {
        assert(slot < VIA_BO_POOL_NUM);
        DRMINITLISTHEAD(&via_pool_mgr->buckets[i][slot].list);
        via_pool_mgr->buckets[i][slot].size = size;
        via_pool_mgr->buckets[i][slot].num = 0;
        if (pthread_mutex_init(&via_pool_mgr->buckets[i][slot].lock, NULL) != 0)
            return -1;
    }
    via_bo_mgr->bo_pool_mgr->bucket_num++;
    return 0;
}

static struct via_bo *
via_bo_pool_get_bo(struct via_bo_pool_mgr *bo_pool_mgr,
          unsigned long size, int type)
{
    struct via_bo *vbo = NULL;
    drmMMListHead *item, *temp;
    struct via_bo_bucket *buck = NULL;
    int size_rp = via_roundup(size, VIA_PAGE_SIZE);

    assert(bo_pool_mgr && bo_pool_mgr->initialized);

    buck = via_bo_get_bucket_roundup(bo_pool_mgr, size_rp, type);
    if (!buck)
        return NULL;
    /* try to get one */
    pthread_mutex_lock(&buck->lock);
    if (buck->num == 0) {
        pthread_mutex_unlock(&buck->lock);
        return NULL;
    } else {
        DRMLISTFOREACHSAFE(item, temp, &buck->list) {
            if (item == &buck->list) {
                /* issue */
                assert(0);
                return NULL;
            }
            vbo = DRMLISTENTRY(struct via_bo, item, list);
            break;
        }
        assert(vbo);
        DRMLISTDELINIT(&vbo->list);
        buck->num--;
    }
    pthread_mutex_unlock(&buck->lock);
    return vbo;

}

static void
via_bo_disable_reuse(struct via_bo *vbo)
{
    vbo->reusable = 0;
}

static int
via_bo_pool_free_bo(struct via_bo_pool_mgr *bo_pool_mgr, struct via_bo *vbo)
{
    struct via_bo_bucket *buck = NULL;
    int size_rp = via_roundup(vbo->bo.size,VIA_PAGE_SIZE);
    int type;

    assert(bo_pool_mgr);
    /* already in pool, Bo may release twice? */
    if (!DRMLISTEMPTY(&vbo->list))
        return 0;

    /* Do Robust check
        some user may release BO before GPU access done(BO not idle yet).
        Those BO should not pooled, let it do release and TTM handle those cases.
    */
    if (via_bo_is_idle(&vbo->bo))
        return -1;

    type = via_get_bo_type(vbo);
    buck = via_bo_get_bucket_rounddown(bo_pool_mgr, size_rp, type);
    /* if size not match */
    if (!buck)
        return -1;
    /* Add to BO pool */

    assert(size_rp >= buck->size);
    pthread_mutex_lock(&buck->lock);

    /* Do not add to list, if exceed the max of bo bucket list */
    if (buck->num >= VIA_POOL_BO_MAX) {
        pthread_mutex_unlock(&buck->lock);
        return -1;
    } else {
        DRMLISTADDTAIL(&vbo->list, &buck->list);
        buck->num++;
    }
    pthread_mutex_unlock(&buck->lock);
    return 0;
}

static int
via_bo_pool_init(struct via_bo_bufmgr *via_bo_mgr)
{
    int i, size;
    via_bo_mgr->bo_pool_mgr = calloc(1, sizeof(*via_bo_mgr->bo_pool_mgr));

    if (via_bo_add_backet(via_bo_mgr, 4096))
        goto error;
    if (via_bo_add_backet(via_bo_mgr, 2 * 4096))
        goto error;
    if (via_bo_add_backet(via_bo_mgr, 3 * 4096))
        goto error;

    for (i = 0, size = 4 * 4096; i < VIA_BO_POOL_NUM - 3; i++, size *= 2) {
        if (via_bo_add_backet(via_bo_mgr, size))
            goto error;
    }

    via_bo_mgr->bo_pool_mgr->initialized = 1;
    return 0;
error:
    free(via_bo_mgr->bo_pool_mgr);
    via_bo_mgr->bo_pool_mgr = NULL;
    return -1;
}

static void
via_bo_pool_finish(struct via_bo_pool_mgr **bo_pool_mgr)
{
    struct via_bo *vbo;
    drmMMListHead *item, *temp;
    struct via_bo_bucket *buck;
    int slot, type;

    (*bo_pool_mgr)->initialized = 0;

    for (type = 0; type < VIA_BO_TYPE; type++) {
        for (slot = 0; slot < VIA_BO_POOL_NUM; slot++) {
            buck = &(*bo_pool_mgr)->buckets[type][slot];
            DRMLISTFOREACHSAFE(item, temp, &buck->list) {
                if (item != &buck->list) {
                    vbo = DRMLISTENTRY(struct via_bo, item, list);
                    via_bo_unreference((struct generic_bo *)vbo);
                }
            }
            buck->size = 0;
            buck->num =0;
            DRMINITLISTHEAD(&buck->list);
        }
    }

    free(*bo_pool_mgr);
    *bo_pool_mgr = NULL;
}

/* The class construction function */
struct generic_bo_bufmgr *
via_bo_bufmgr_con(int drmfd)
{
    struct via_bo_bufmgr *p_via_bo_bufmgr;

    p_via_bo_bufmgr =
        (struct via_bo_bufmgr *)calloc(1, sizeof(struct via_bo_bufmgr));
    if (!p_via_bo_bufmgr)
        return 0;

    via_bo_pool_init(p_via_bo_bufmgr);

    p_via_bo_bufmgr->bo_bufmgr.drmfd = drmfd;
    p_via_bo_bufmgr->bo_bufmgr.bo_alloc = via_bo_alloc;
    p_via_bo_bufmgr->bo_bufmgr.bo_reference = via_bo_reference;
    p_via_bo_bufmgr->bo_bufmgr.bo_unreference = via_bo_unreference;
    p_via_bo_bufmgr->bo_bufmgr.bo_map = via_bo_map;
    p_via_bo_bufmgr->bo_bufmgr.bo_unmap = via_bo_unmap;
    p_via_bo_bufmgr->bo_bufmgr.bo_reloc = via_bo_reloc;
    p_via_bo_bufmgr->bo_bufmgr.bo_branch_buffer_reloc = via_bo_branch_buffer_reloc;
    p_via_bo_bufmgr->bo_bufmgr.bo_set_cmd_type = via_bo_set_cmd_type;
    p_via_bo_bufmgr->bo_bufmgr.bo_flush = via_bo_flush;
    p_via_bo_bufmgr->bo_bufmgr.bo_flink = via_bo_flink;
    p_via_bo_bufmgr->bo_bufmgr.bo_open = via_bo_open;
    p_via_bo_bufmgr->bo_bufmgr.bo_is_idle = via_bo_is_idle;
    p_via_bo_bufmgr->bo_bufmgr.bo_wait= via_bo_wait;
    p_via_bo_bufmgr->bo_bufmgr.bo_set_cpu_domain = via_bo_set_cpu_domain;
    p_via_bo_bufmgr->bo_bufmgr.bo_cpu_grab = via_bo_cpu_grab;
    p_via_bo_bufmgr->bo_bufmgr.bo_cpu_release = via_bo_cpu_release;
    p_via_bo_bufmgr->bo_bufmgr.bo_branch_buffer_init = via_bo_branch_buffer_init;
    p_via_bo_bufmgr->bo_bufmgr.bo_branch_buffer_get = via_bo_branch_buffer_get;
    p_via_bo_bufmgr->bo_bufmgr.bo_branch_buffer_flush = via_bo_branch_buffer_flush;
    p_via_bo_bufmgr->bo_bufmgr.bo_branch_buffer_finish = via_bo_branch_buffer_finish;
    p_via_bo_bufmgr->bo_bufmgr.bo_disable_reuse = via_bo_disable_reuse;
    p_via_bo_bufmgr->reloc_info.max_reloc = 32;

    return &p_via_bo_bufmgr->bo_bufmgr;
}

void
via_bo_bufmgr_decon(struct generic_bo_bufmgr *p_generic_bo_bufmgr)
{
    struct via_bo_bufmgr *vbo_mgr;

    if (!p_generic_bo_bufmgr)
        return ;

    vbo_mgr = (struct via_bo_bufmgr *)p_generic_bo_bufmgr;

    if (vbo_mgr->reloc_info.relocs) {
        free(vbo_mgr->reloc_info.relocs);
        vbo_mgr->reloc_info.relocs = NULL;
    }

    if (vbo_mgr->reloc_info.target_bo_list) {
        free(vbo_mgr->reloc_info.target_bo_list);
        vbo_mgr->reloc_info.target_bo_list = NULL;
    }

    if (vbo_mgr->exec_objects) {
        free(vbo_mgr->exec_objects);
        vbo_mgr->exec_objects = NULL;
    }

    if (vbo_mgr->bo_pool_mgr) {
        via_bo_pool_finish(&vbo_mgr->bo_pool_mgr);
    }

    free(p_generic_bo_bufmgr);
}
/* The class deconstruction function */
