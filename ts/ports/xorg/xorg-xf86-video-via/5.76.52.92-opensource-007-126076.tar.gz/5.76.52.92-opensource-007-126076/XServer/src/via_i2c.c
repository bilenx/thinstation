/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_driver.h"
#include "xf86_OSproc.h"
#include "compiler.h"
#include "xf86Pci.h"
#include "xf86PciInfo.h"
#include "vgaHW.h"
#include "xf86.h"

/*
 * DDC2 support requires DDC_SDA_MASK and DDC_SCL_MASK
 */
#define DDC_SDA_READ_MASK  (1 << 2)
#define DDC_SCL_READ_MASK  (1 << 3)
#define DDC_SDA_WRITE_MASK (1 << 4)
#define DDC_SCL_WRITE_MASK (1 << 5)

#define VIA_I2C_PORT26        0x26
#define VIA_I2C_PORT31        0x31

/* I2C Function */
static void
VIAI2CPutBits(I2CBusPtr b, int clock, int data)
{
    CARD8 reg;
    ScrnInfoPtr pScrn = xf86Screens[b->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    CARD8 subport = b->DriverPrivate.val;

    VGAOUT8(0x3c4, subport);
    reg = VGAIN8(0x3c5);
    reg &= 0xF0;
    reg |= 0x01;               /* Enable DDC */

    if (clock)
        reg |= DDC_SCL_WRITE_MASK;
    else
        reg &= ~DDC_SCL_WRITE_MASK;

    if (data)
        reg |= DDC_SDA_WRITE_MASK;
    else
        reg &= ~DDC_SDA_WRITE_MASK;

    VGAOUT8(0x3c4, subport);
    VGAOUT8(0x3c5, reg);
}

static void
VIAI2CGetBits(I2CBusPtr b, int *clock, int *data)
{
    CARD8 reg;
    ScrnInfoPtr pScrn = xf86Screens[b->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    CARD8 subport = b->DriverPrivate.val;

    VGAOUT8(0x3c4, subport);
    reg = VGAIN8(0x3c5);

    *clock = (reg & DDC_SCL_READ_MASK) != 0;
    *data = (reg & DDC_SDA_READ_MASK) != 0;
}

Bool
VIAI2CInit(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    I2CBusPtr I2CPtr1, I2CPtr2;

    I2CPtr1 = xf86CreateI2CBusRec();
    if (!I2CPtr1)
        return FALSE;

    I2CPtr2 = xf86CreateI2CBusRec();
    if (!I2CPtr2) {
        xf86DestroyI2CBusRec(I2CPtr1, TRUE, FALSE);
        return FALSE;
    }

    I2CPtr1->BusName = "I2C bus 1";
    I2CPtr1->scrnIndex = pScrn->scrnIndex;
    I2CPtr1->I2CPutBits = VIAI2CPutBits;
    I2CPtr1->I2CGetBits = VIAI2CGetBits;
    I2CPtr1->DriverPrivate.val = VIA_I2C_PORT26;

    I2CPtr2->BusName = "I2C bus 2";
    I2CPtr2->scrnIndex = pScrn->scrnIndex;
    I2CPtr2->I2CPutBits = VIAI2CPutBits;
    I2CPtr2->I2CGetBits = VIAI2CGetBits;
    I2CPtr2->DriverPrivate.val = VIA_I2C_PORT31;

    if (!xf86I2CBusInit(I2CPtr1) || !xf86I2CBusInit(I2CPtr2)) {
        xf86DestroyI2CBusRec(I2CPtr1, TRUE, FALSE);
        xf86DestroyI2CBusRec(I2CPtr2, TRUE, FALSE);
        return FALSE;
    }

    pVia->I2C_Port1 = I2CPtr1;
    pVia->I2C_Port2 = I2CPtr2;

    return TRUE;
}
