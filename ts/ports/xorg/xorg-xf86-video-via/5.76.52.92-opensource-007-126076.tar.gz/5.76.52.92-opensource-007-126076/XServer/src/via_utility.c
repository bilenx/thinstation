/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * I N C L U D E S
 */
#include <xorg/xorg-server.h>
#include "Xproto.h"               /* For Xextension */
#include "extnsionst.h"               /* For Xextension */
#include "dixstruct.h"               /* For Xextension */
#include "via_driver.h"
#include "via_utility.h"
#include "via_video.h"
#include "via_eng_regs.h"
#include "via_rotate.h"
#include "via_include.h"

extern int gVIAEntityIndex;
extern Bool via_module_loaded;
extern NEWVIAGRAPHICINFO NEWVIAGraphicInfo;

/* Record screen number. */
int g_ScreenNumber;


/*
    Driver keep a device list but utility keep a different list,
    so we must do a mapping operation from driver to utility.
*/
int
MapFunStateForUT(int FunStateForDrv)
{
    int FunStateForUT;

    if (FunStateForDrv & VIA_DEVICE_CRT1)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_CRT1) | UT_DEVICE_CRT1;

    if (FunStateForDrv & VIA_DEVICE_LCD)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_LCD) | UT_DEVICE_LCD;

    if (FunStateForDrv & VIA_DEVICE_TV)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_TV) | UT_DEVICE_TV;

    if (FunStateForDrv & VIA_DEVICE_DFP)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_DFP) | UT_DEVICE_DFP;

    if (FunStateForDrv & VIA_DEVICE_HDMI)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_HDMI) | UT_DEVICE_HDMI;

    if (FunStateForDrv & VIA_DEVICE_DP)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_DP) | UT_DEVICE_DP;

    if (FunStateForDrv & VIA_DEVICE_DP2)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_DP2) | UT_DEVICE_DP2;

    if (FunStateForDrv & VIA_DEVICE_CRT2)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_CRT2) | UT_DEVICE_CRT2;

    if (FunStateForDrv & VIA_DEVICE_TV2)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_TV2) | UT_DEVICE_TV2;

    if (FunStateForDrv & VIA_DEVICE_DFP2)
        FunStateForUT = (FunStateForDrv - VIA_DEVICE_DFP2) | UT_DEVICE_DFP2;

    return FunStateForUT;
}

/*
    Driver keep a device list but utility keep a different list,
    so we must do a mapping operation from driver to utility.
*/
CARD32
MapDeviceStateForUT(CARD32 DeviceStateForDrv)
{
    CARD32 DeviceStateForUT = 0;

    if (DeviceStateForDrv & VIA_DEVICE_CRT1)
        DeviceStateForUT |= UT_DEVICE_CRT1;

    if (DeviceStateForDrv & VIA_DEVICE_LCD)
        DeviceStateForUT |= UT_DEVICE_LCD;

    if (DeviceStateForDrv & VIA_DEVICE_TV)
        DeviceStateForUT |= UT_DEVICE_TV;

    if (DeviceStateForDrv & VIA_DEVICE_DFP)
        DeviceStateForUT |= UT_DEVICE_DFP;

    if (DeviceStateForDrv & VIA_DEVICE_HDMI)
        DeviceStateForUT |= UT_DEVICE_HDMI;

    if (DeviceStateForDrv & VIA_DEVICE_DP)
        DeviceStateForUT |= UT_DEVICE_DP;

    if (DeviceStateForDrv & VIA_DEVICE_DP2)
        DeviceStateForUT |= UT_DEVICE_DP2;

    if (DeviceStateForDrv & VIA_DEVICE_CRT2)
        DeviceStateForUT |= UT_DEVICE_CRT2;

    if (DeviceStateForDrv & VIA_DEVICE_LCD2)
        DeviceStateForUT |= UT_DEVICE_LCD2;

    if (DeviceStateForDrv & VIA_DEVICE_TV2)
        DeviceStateForUT |= UT_DEVICE_TV2;

    if (DeviceStateForDrv & VIA_DEVICE_DFP2)
        DeviceStateForUT |= UT_DEVICE_DFP2;

    return DeviceStateForUT;

}

CARD32
MapDeviceStateForDrv(CARD32 DeviceStateForUT)
{
    CARD32 DeviceStateForDrv = 0;

    if (DeviceStateForUT & UT_DEVICE_CRT1)
        DeviceStateForDrv |= VIA_DEVICE_CRT1;

    if (DeviceStateForUT & UT_DEVICE_LCD)
        DeviceStateForDrv |= VIA_DEVICE_LCD;

    if (DeviceStateForUT & UT_DEVICE_TV)
        DeviceStateForDrv |= VIA_DEVICE_TV;

    if (DeviceStateForUT & UT_DEVICE_DFP)
        DeviceStateForDrv |= VIA_DEVICE_DFP;

    if (DeviceStateForUT & UT_DEVICE_HDMI)
        DeviceStateForDrv |= VIA_DEVICE_HDMI;

    if (DeviceStateForUT & UT_DEVICE_DP)
        DeviceStateForDrv |= VIA_DEVICE_DP;

    if (DeviceStateForUT & UT_DEVICE_DP2)
        DeviceStateForDrv |= VIA_DEVICE_DP2;

    if (DeviceStateForUT & UT_DEVICE_CRT2)
        DeviceStateForDrv |= VIA_DEVICE_CRT2;

    if (DeviceStateForUT & UT_DEVICE_LCD2)
        DeviceStateForDrv |= VIA_DEVICE_LCD2;

    if (DeviceStateForUT & UT_DEVICE_TV2)
        DeviceStateForDrv |= VIA_DEVICE_TV2;

    if (DeviceStateForUT & UT_DEVICE_DFP2)
        DeviceStateForDrv |= VIA_DEVICE_DFP2;

    if (DeviceStateForUT & UT_DEVICE_HDTV)
        DeviceStateForDrv |= VIA_DEVICE_TV;

    if (DeviceStateForUT & UT_DEVICE_HDTV2)
        DeviceStateForDrv |= VIA_DEVICE_TV2;

    return DeviceStateForDrv;

}

void
VIA_UT_BIOS_GetChipID(ScrnInfoPtr pScrn, CARD32 * pdwChipID)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIA_UT_BIOS_GetChipID\n"));
    VIAPtr pVia = VIAPTR(pScrn);

    *pdwChipID = pVia->ChipId;
}

#define     VIA_BIOS_SIZE_POS               0x2
#define     VIA_BIOS_OFFSET_POS             0x1B

/* The offset of table from table start */
#define     VIA_BIOS_VERSION_POS            0x87
#define     VIA_BIOS_DATE_POS               0x36

#define     VIAGETBIOSDATE                  0x01
#define     VIAGETBIOSVER                   0x02

Bool
VIAGetBIOSInfoFromROM(VIAPtr pVia, unsigned char flags)
{
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    unsigned char *pBIOS = NULL, *pRom, *pTable;
    int romSize, sum, i;

    DEBUG(xf86DrvMsg(pVia->pBIOSInfo->scrnIndex, X_INFO,
        "VIAGetBIOSVerFromROM\n"));
    /* Allocate shadow memory */
    if (!(pBIOS = calloc(1, 0x10000))) {
        ErrorF("Allocate memory fail !!\n");
        return FALSE;
    }
    /* Read BIOS ROM and check! */
    if (xf86ReadBIOS(0xC0000, 0, pBIOS, 0x10000) != 0x10000) {
        free(pBIOS);
        ErrorF("Read VGA BIOS image fail !!\n");
    } else {
        if (*((CARD16 *) pBIOS) != 0xAA55) {
            free(pBIOS);
            ErrorF("VGA BIOS image is wrong!!\n");
            return FALSE;
        } else {
            romSize = *((CARD8 *) (pBIOS + VIA_BIOS_SIZE_POS)) * 512;
            pRom = pBIOS;
            sum = 0;
            for (i = 0; i < romSize; i++) {
                sum += *pRom++;
            }

            if (((CARD8) sum) != 0) {
                free(pBIOS);
                ErrorF("VGA BIOS image is wrong!! CheckSum = %x\n", sum);
                return FALSE;
            }
        }
    }

    /* Get the start of Table */
    pRom = pBIOS + VIA_BIOS_OFFSET_POS;
    pTable = pBIOS + *((CARD16 *) pRom);

    if (flags & VIAGETBIOSDATE) {
        /* Get the start of bcpPost structure */
        pRom = pBIOS + VIA_BIOS_DATE_POS;
        pVia->pChipInfo->biosDateMonth = ((*pRom++) - 48) * 10;
        pVia->pChipInfo->biosDateMonth += (*pRom++) - 48;
        pRom++;
        pVia->pChipInfo->biosDateDay = ((*pRom++) - 48) * 10;
        pVia->pChipInfo->biosDateDay += (*pRom++) - 48;
        pRom++;
        pVia->pChipInfo->biosDateYear = ((*pRom++) - 48) * 10;
        pVia->pChipInfo->biosDateYear += (*pRom) - 48;
        /*xf86DrvMsg(pVia->pBIOSInfo->scrnIndex, X_INFO, "VGA BIOS Date: %d/%d/%d\n" ,
         * pBIOSInfo->BIOSDateMonth, pBIOSInfo->BIOSDateDay, pBIOSInfo->BIOSDateYear); */
    }
    if (flags & VIAGETBIOSVER) {
        pRom = pBIOS + VIA_BIOS_VERSION_POS;
        pVia->pChipInfo->biosVerMinorNum = *(pRom + 3);
        pVia->pChipInfo->biosVerMajorNum = (*(pRom + 2)) & 0x7;
    }

    free(pBIOS);

    return TRUE;

}

void
VIA_UT_BIOS_GetVersion(ScrnInfoPtr pScrn, UTBIOSVERSION *pUTBIOSVERSION)
{
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIA_UT_BIOS_GetVersion\n"));
    VIAGetBIOSInfoFromROM(pVia, VIAGETBIOSVER);
    pUTBIOSVERSION->dwVersion = pVia->pChipInfo->biosVerMajorNum;
    pUTBIOSVERSION->dwRevision = pVia->pChipInfo->biosVerMinorNum;
}

void
VIA_UT_BIOS_GetDate(ScrnInfoPtr pScrn, UTBIOSDATE *pUTBIOSDATE)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIA_UT_BIOS_GetDate\n"));
    VIAPtr pVia = VIAPTR(pScrn);

    VIAGetBIOSInfoFromROM(pVia, VIAGETBIOSDATE);
    pUTBIOSDATE->dwYear = (CARD32) pVia->pChipInfo->biosDateYear + 2000;
    pUTBIOSDATE->dwMonth = (CARD32) pVia->pChipInfo->biosDateMonth;
    pUTBIOSDATE->dwDay = (CARD32) pVia->pChipInfo->biosDateDay;
}

void
VIA_UT_BIOS_GetVideoMemSizeMB(ScrnInfoPtr pScrn, CARD32 *pdwVideoRam)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_BIOS_GetVideoMemSizeMB\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    DevUnion *pPriv;
    VIAEntPtr pVIAEnt;

    pPriv = xf86GetEntityPrivate(pScrn->entityList[0], gVIAEntityIndex);
    pVIAEnt = pPriv->ptr;

    *pdwVideoRam = pScrn->videoRam >> 10;

    if (pVia->pVIAEnt->HasSecondary) {
        *pdwVideoRam = (pVIAEnt->pPrimaryScrn->videoRam >> 10) +
            (pVIAEnt->pSecondaryScrn->videoRam >> 10);
    }
}

void
VIA_UT_BIOS_GetTVChipID(VIABIOSInfoPtr pBIOSInfo, CARD32 *pdwTVChipID)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_BIOS_GetTVChipID\n"));

    *pdwTVChipID = pBIOSInfo->TVSettingInfo.TVEncoder;
}

Bool
VIA_UT_DRIVER_GetFileName(CARD32 dwDriverType, char *szDriverName)
{
    DEBUG(ErrorF("VIA_UT_DRIVER_GetFileName\n"));
    int ret = TRUE;

    char DISPLAY_DRIVER_NAME[] = "via_drv.o     \0";
    char VDO_CAPTURE_DRIVER_NAME[] = "via_v4l_drv.o\0";
    char HWOVERLAY_DRIVER_NAME[] = "libddmpeg.a\0";
    char HWMPEG2_DECODER_NAME[] = "libddmpeg.so\0";

#ifdef XORG_VERSION_CURRENT
    memcpy(DISPLAY_DRIVER_NAME, "via_drv.so    \0", 15);
    memcpy(VDO_CAPTURE_DRIVER_NAME, "via_v4l_drv.so\0", 15);
#endif

    switch (dwDriverType) {
    case DISPLAY_DRIVER:
        memcpy((void *)szDriverName, (void *)DISPLAY_DRIVER_NAME,
            sizeof(DISPLAY_DRIVER_NAME));
        break;

    case VIDEO_CAPTURE_DRIVER:
        memcpy((void *)szDriverName, (void *)VDO_CAPTURE_DRIVER_NAME,
            sizeof(VDO_CAPTURE_DRIVER_NAME));
        break;

    case HWOVERLAY_DRIVER:
        memcpy((void *)szDriverName, (void *)HWOVERLAY_DRIVER_NAME,
            sizeof(HWOVERLAY_DRIVER_NAME));
        break;

    case HWMPEG2_DECODER:
        memcpy((void *)szDriverName, (void *)HWMPEG2_DECODER_NAME,
            sizeof(HWMPEG2_DECODER_NAME));
        break;

    default:
        ret = FALSE;
        break;
    }

    return ret;
}

Bool
VIA_UT_DRIVER_GetStrVersion(CARD32 dwDriverType, char *szStrVersion)
{
    DEBUG(ErrorF("VIA_UT_DRIVER_GetStrVersion\n"));
    int ret = TRUE;

    char DISPLAY_DRIVER_STRNAME[] = "5.76.52.92  \0";
    memcpy((void *)szStrVersion, (void *)DISPLAY_DRIVER_STRNAME,
            sizeof(DISPLAY_DRIVER_STRNAME));   
    return ret;
}


Bool
VIA_UT_DRIVER_GetFileVersion(ScrnInfoPtr pScrn,
    CARD32 dwDriverType, UTDriverVersion *pUTDriverVersion)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DRIVER_GetFileVersion\n"));
#if 0
    unsigned int driver_version;
    int ret = TRUE;

    switch (dwDriverType) {
    case DISPLAY_DRIVER:
        pUTDriverVersion->dwMajorNum = VERSION_MAJOR;
        pUTDriverVersion->dwMinorNum = VERSION_MINOR;
        pUTDriverVersion->dwOSNum = VERSION_OS;
        /* Driver sub version number, Trunk: 0xff */
        pUTDriverVersion->dwReversionNum = PATCHLEVEL;
        break;

    case VIDEO_CAPTURE_DRIVER:
        if (via_module_loaded) {
            //vvaSyncInfo(&driver_version, VIA_VID_GET_VERSION);
            vvaSyncInfo(&driver_version, VIA_GET_VERSION);
        }
        pUTDriverVersion->dwMajorNum = (driver_version & 0xff000000) >> 24;
        pUTDriverVersion->dwMinorNum = (driver_version & 0x00ff0000) >> 16;
        pUTDriverVersion->dwOSNum = (driver_version & 0x0000ff00) >> 8;
        pUTDriverVersion->dwReversionNum = (driver_version & 0x000000ff);
        break;

    case HWOVERLAY_DRIVER:
        pUTDriverVersion->dwMajorNum = VERSION_MAJOR;
        pUTDriverVersion->dwMinorNum = VERSION_MINOR;
        pUTDriverVersion->dwOSNum = VERSION_OS;
        pUTDriverVersion->dwReversionNum = PATCHLEVEL;
        break;

    case HWMPEG2_DECODER:
        pUTDriverVersion->dwMajorNum = VERSION_MAJOR;
        pUTDriverVersion->dwMinorNum = VERSION_MINOR;
        pUTDriverVersion->dwOSNum = VERSION_OS;
        pUTDriverVersion->dwReversionNum = PATCHLEVEL;
        break;

    default:
        ret = FALSE;
        break;
    }

    return ret;
#endif
    return TRUE;
}

CARD32
VIA_UT_DEVICE_GetPanningState(VIABIOSInfoPtr pBIOSInfo)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetPanningState\n"));

    CARD32 PanningState = 0;

    return PanningState;
}

void
VIA_UT_DISPLAY_EnumModes(VIABIOSInfoPtr pBIOSInfo,
    CARD32 ModeNum, LPUTDEVMODE lpDevMode)
{
    VIASUPPORTMODE SupportMode;
    int index = 0, count = -1, RefreshRateNum;
    Bool IsSupported;

    while (VIAEnumModes(pBIOSInfo, index, &SupportMode, &IsSupported)) {
        if (SupportMode.ModeIndex == -1) {
            lpDevMode->ModeIndex = M_INVALID;
            lpDevMode->PelsWidth = 0;
            lpDevMode->PelsHeight = 0;
            break;
        }

        if (IsSupported) {
            count++;

            if (count == ModeNum) {
                lpDevMode->ModeIndex = SupportMode.ModeIndex;
                lpDevMode->PelsWidth = SupportMode.HActive;
                lpDevMode->PelsHeight = SupportMode.VActive;

                /* Enumerate supported refresh rates: */

                RefreshRateNum = 0;

                while (1) {
                    VIAEnumRefreshRate(SupportMode.ModeIndex,
                        RefreshRateNum,
                        &(lpDevMode->RefreshRate[RefreshRateNum]));

                    if (lpDevMode->RefreshRate[RefreshRateNum] == 0)
                        break;

                    RefreshRateNum++;
                }

                lpDevMode->RefreshRateNum = RefreshRateNum;


                break;
            }
        }

        index++;
    }
}

void
VIA_UT_DISPLAY_GetCurrentMode(VIABIOSInfoPtr pBIOSInfo, LPUTDEVMODE lpDevMode)
{
    lpDevMode->ModeIndex = VIAGetModeIndex(pBIOSInfo->CrtcHDisplay,
    pBIOSInfo->CrtcVDisplay);
    lpDevMode->PelsWidth = pBIOSInfo->CrtcHDisplay;
    lpDevMode->PelsHeight = pBIOSInfo->CrtcVDisplay;
    lpDevMode->RefreshRateNum = 1;
    lpDevMode->RefreshRate[0] = pBIOSInfo->FoundRefresh;
}

void
VIA_UT_DISPLAY_GetRotationCaps(ScrnInfoPtr pScrn,
    CARD32 RotateType, CARD32 *pRotationCaps)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DISPLAY_GetRotationCaps\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    *pRotationCaps = UT_ROTATE_NONE;

    switch (RotateType) {
    case UT_ROTATE_TYPE_HW:
        if (IsSupportDirectAccessWindow(pBIOSInfo->Chipset)) {
            *pRotationCaps = UT_ROTATE_90_DEG |
            UT_ROTATE_180_DEG | UT_ROTATE_270_DEG;
        }
        break;

    case UT_ROTATE_TYPE_SW:
        *pRotationCaps = UT_ROTATE_90_DEG |
            UT_ROTATE_180_DEG | UT_ROTATE_270_DEG;
        break;
    }

}

void
VIA_UT_DISPLAY_GetCurrentRotateDegree(ScrnInfoPtr pScrn,
    CARD32 *RotateType, CARD32 *RotateDegree)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DISPLAY_GetCurrentMode\n"));

    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->IsHWRotateEnabled) {
        *RotateType = UT_ROTATE_TYPE_HW;

        switch (pVia->RotateDegree) {
        case VIA_ROTATE_DEGREE_90:
            *RotateDegree = UT_ROTATE_90_DEG;
            break;

        case VIA_ROTATE_DEGREE_180:
            *RotateDegree = UT_ROTATE_180_DEG;
            break;

        case VIA_ROTATE_DEGREE_270:
            *RotateDegree = UT_ROTATE_270_DEG;
            break;
        }
    } else if (pVia->RotateDegree && pVia->shadowFB && pVia->NoAccel) {
        *RotateType = UT_ROTATE_TYPE_SW;

        switch (pVia->RotateDegree) {
        case VIA_ROTATE_DEGREE_90:
            *RotateDegree = UT_ROTATE_90_DEG;
            break;

        case VIA_ROTATE_DEGREE_180:
            *RotateDegree = UT_ROTATE_180_DEG;
            break;

        case VIA_ROTATE_DEGREE_270:
            *RotateDegree = UT_ROTATE_270_DEG;
            break;
        }
    } else {
        *RotateType = UT_ROTATE_TYPE_NONE;
        *RotateDegree = UT_ROTATE_NONE;
    }
}

Bool
VIA_UT_DISPLAY_SetRotateDegree(ScrnInfoPtr pScrn, CARD32 RotateDegree)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DISPLAY_SetRotateDegree\n"));
    return TRUE;
}

void
VIA_UT_DEVICE_GetPanelInfo(VIABIOSInfoPtr pBIOSInfo,
    CARD32 dwPanelType, UTPANELINFO *pPanelInfo)
{
    int dwPanelSize;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetPanelInfo\n"));

    pPanelInfo->dwType = UT_PANEL_TYPE_TFT;

    /* utility should add parameter for
     * distinguish get LCD or DFP info. Before utility change
     * query panel info. parameter. we patch this according
     * desktop or mobile version. */
    /* Add parameter to distinguish
     * getting LCD or DFP information. */
    switch (dwPanelType) {
    case UT_DEVICE_LCD:
        dwPanelSize = pBIOSInfo->LVDSSettingInfo.PanelSizeID;
        pPanelInfo->dwResX = VIA_PANEL_WIDTH(dwPanelSize);
        pPanelInfo->dwResY = VIA_PANEL_HEIGHT(dwPanelSize);
        pPanelInfo->dwDeviceID = UT_DEVICE_LCD;
        break;

    case UT_DEVICE_DFP:
        VIAGetModeSizeByIndex(pBIOSInfo->TMDSSettingInfo.DFPSize,
            &pPanelInfo->dwResX, &pPanelInfo->dwResY);
        pPanelInfo->dwDeviceID = UT_DEVICE_DFP;
        break;

    case UT_DEVICE_HDMI:
        VIAGetModeSizeByIndex(pBIOSInfo->HDMISettingInfo.NativeSizeID,
            &pPanelInfo->dwResX, &pPanelInfo->dwResY);
        pPanelInfo->dwDeviceID = UT_DEVICE_HDMI;
        break;
    }

    if (dwPanelSize == 0) {
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "Unknown Panel Size!\n"));
    }
}

void
VIA_UT_DEVICE_GetSupportExpand(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pdwSupportState)
{
    int panel_w = 0, panel_h = 0;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetSupportExpand\n"));
    /* Don't support expansion if LCD uses IGA1. */
    if ((pBIOSInfo->LVDSSettingInfo.ChipID) &&
        ((pBIOSInfo->LVDSSettingInfo.IGAPath != IGA1) ||
        (pBIOSInfo->LVDSSettingInfo2.ChipID))) {
        panel_w = VIA_PANEL_WIDTH(pBIOSInfo->LVDSSettingInfo.PanelSizeID);
        panel_h = VIA_PANEL_HEIGHT(pBIOSInfo->LVDSSettingInfo.PanelSizeID);
        *pdwSupportState = (pBIOSInfo->SaveHDisplay < panel_w
            || pBIOSInfo->SaveVDisplay <
            panel_h) ? UT_PANEL_SUPPORT_EXPAND_ON :
            UT_PANEL_SUPPORT_EXPAND_OFF;
    } else
        *pdwSupportState = UT_PANEL_SUPPORT_EXPAND_OFF;

}

void
VIA_UT_DEVICE_GetExpandState(VIABIOSInfoPtr pBIOSInfo, CARD32 * dwExpandState)
{
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetExpandState\n"));
}

Bool
VIA_UT_DEVICE_SetExpandState(VIABIOSInfoPtr pBIOSInfo,
    DisplayModePtr mode, UTPANELINFO UTPanelInfo)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_SetExpandState\n"));

    if (UTPanelInfo.dwExpandState == UT_STATE_EXPAND_OFF) {
        pBIOSInfo->s3utility = TRUE;
    } else if (UTPanelInfo.dwExpandState == UT_STATE_EXPAND_ON) {
        pBIOSInfo->s3utility = TRUE;
    } else
        return FALSE;

    VIASaveUserSetting(pBIOSInfo);
    VIASwitchMode(pBIOSInfo->scrnIndex, mode, 0);

    return TRUE;
}

void
VIA_UT_DEVICE_GetPanleMaxViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE *pMaxViewSizeValue, CARD32 dwDeviceType)
{
    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
    "VIA_UT_DEVICE_GetPanleMaxViewSizeValue\n");

    CARD32 dwDevice;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);

    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        break;

    case VIA_DEVICE_HDMI:
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        break;

    case VIA_DEVICE_LCD:
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        break;
    }

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        pMaxViewSizeValue->dwX = pTagert3DScalInfo->XScaleMaximum;
        pMaxViewSizeValue->dwY = pTagert3DScalInfo->YScaleMaximum;
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT__DEVICE_GetPanleMaxViewSizeValue: MaxX=%lu,MaxY=%lu\n",
            pMaxViewSizeValue->dwX, pMaxViewSizeValue->dwY);
    } else {
        pMaxViewSizeValue->dwX = 0;
        pMaxViewSizeValue->dwY = 0;
    }
}

void
VIA_UT_DEVICE_GetPanleViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE *pViewSizeValue, CARD32 dwDeviceType)
{
    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetPanleViewSizeValue\n");

    CARD32 dwDevice;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);

    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        break;

    case VIA_DEVICE_HDMI:
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        break;

    case VIA_DEVICE_LCD:
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        break;
    }

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        pViewSizeValue->dwX = pTagert3DScalInfo->XScaleLevel;
        pViewSizeValue->dwY = pTagert3DScalInfo->YScaleLevel;
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "GetViewSizeValue: X=%lu,Y=%lu\n",
            pViewSizeValue->dwX, pViewSizeValue->dwY);
    } else {
        pViewSizeValue->dwX = 0;
        pViewSizeValue->dwY = 0;
    }

}

Bool
VIA_UT_DEVICE_SetPanleViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE ViewSizeValue, CARD32 dwDeviceType)
{
    CARD32 dwDevice;
    int IGAPath = 0;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);

    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        IGAPath = pBIOSInfo->TMDSSettingInfo.IGAPath;
        break;

    case VIA_DEVICE_HDMI:
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        IGAPath = pBIOSInfo->TMDSSettingInfo.IGAPath;
        break;

    case VIA_DEVICE_LCD:
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        IGAPath = pBIOSInfo->LVDSSettingInfo.IGAPath;
        break;
    }

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT_Panel_SetViewSizeValue:Y=%lu, X=%lu \n",
            ViewSizeValue.dwY, ViewSizeValue.dwX));

        if (ViewSizeValue.dwY == 0xFFFF || ViewSizeValue.dwX == 0xFFFF) {
            ViewSizeValue.dwX = pTagert3DScalInfo->XScaleDefault;
            ViewSizeValue.dwY = pTagert3DScalInfo->YScaleDefault;
            pTagert3DScalInfo->XScaleLevel = pTagert3DScalInfo->XScaleDefault;
            pTagert3DScalInfo->YScaleLevel = pTagert3DScalInfo->YScaleDefault;
        }
        pTagert3DScalInfo->XScaleLevel = ViewSizeValue.dwX;
        pTagert3DScalInfo->YScaleLevel = ViewSizeValue.dwY;
        pTagert3DScalInfo->XSIZEOffset =
            (pTagert3DScalInfo->XScaleDefault -
            pTagert3DScalInfo->XScaleLevel) * pTagert3DScalInfo->XScaleStep;
        pTagert3DScalInfo->YSIZEOffset =
            (pTagert3DScalInfo->YScaleDefault -
            pTagert3DScalInfo->YScaleLevel) * pTagert3DScalInfo->YScaleStep;

        pTagert3DScalInfo->XSIZENow =
            pTagert3DScalInfo->XSIZEMax -
            (pTagert3DScalInfo->XScaleLevel * pTagert3DScalInfo->XScaleStep);
        pTagert3DScalInfo->YSIZENow =
            pTagert3DScalInfo->YSIZEMax -
            (pTagert3DScalInfo->YScaleLevel * pTagert3DScalInfo->YScaleStep);

        pTagert3DScalInfo->bNeedBlack3dScalingBorders = TRUE;

        viaGfxInfo->igaInfo[IGAPath - 1].igagfx3DScaling_info.XSIZEOffset =
            pTagert3DScalInfo->XSIZEOffset;
        viaGfxInfo->igaInfo[IGAPath - 1].igagfx3DScaling_info.YSIZEOffset =
            pTagert3DScalInfo->YSIZEOffset;

        if (via_module_loaded) {
            TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
            if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO)) {
                return FALSE;
            }
        }

        VIAAdjustFrame(pScrn->scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);
        /*Need to add the function for DVI/LCD and so on */
        VIASaveUserSetting(pBIOSInfo);

    }
    return TRUE;
}

void
VIA_UT_DEVICE_GetPanleMaxViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE *pMaxViewPosValue, CARD32 dwDeviceType)
{
    CARD32 dwDevice;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);
    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        break;

    case VIA_DEVICE_HDMI:
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        break;

    case VIA_DEVICE_LCD:
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        break;
    }

    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT__DEVICE_GetPanleMaxViewSizeValue\n");

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        pMaxViewPosValue->dwX = pTagert3DScalInfo->XPOSITIONMaximum;
        pMaxViewPosValue->dwY = pTagert3DScalInfo->YPOSITIONMaximum;
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT__DEVICE_GetPanleMaxViewSizeValue: MaxX=%lu,MaxY=%lu\n",
            pMaxViewPosValue->dwX, pMaxViewPosValue->dwY);
    } else {
        pMaxViewPosValue->dwX = 0;
        pMaxViewPosValue->dwY = 0;
    }

}

void
VIA_UT_DEVICE_GetPanleViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE *pViewPosValue, CARD32 dwDeviceType)
{
    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetPanleViewPositionValue\n");

    CARD32 dwDevice;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);
    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        break;

    case VIA_DEVICE_HDMI:
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        break;

    case VIA_DEVICE_LCD:
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        break;
    }

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        if (pViewPosValue->dwX == 0xFFFF && pViewPosValue->dwY == 0xFFFF) {
            pViewPosValue->dwX = pTagert3DScalInfo->XPOSITIONDefault;
            pViewPosValue->dwY = pTagert3DScalInfo->YPOSITIONDefault;
        } else {
            pViewPosValue->dwX = pTagert3DScalInfo->XPOSITIONLevel;
            pViewPosValue->dwY = pTagert3DScalInfo->YPOSITIONLevel;
        }
        xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "GetViewSizeValue: X=%lu,Y=%lu\n",
            pViewPosValue->dwX, pViewPosValue->dwY);
    } else {
        pViewPosValue->dwX = 0;
        pViewPosValue->dwY = 0;
    }

}

Bool
VIA_UT_DEVICE_SetPanleViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    UTXYVALUE ViewPosValue, CARD32 dwDeviceType)
{
    CARD32 dwDevice;
    int IGAPath = 0;
    VIA3DSclSCNParasPtr pTagert3DScalInfo = NULL;
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    /* Convert utility's device ID into driver's device ID. */
    dwDevice = MapDeviceStateForDrv(dwDeviceType);
    switch (dwDevice) {
    case VIA_DEVICE_DFP:
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "SetPanleViewPositionValue:DVI path \n"));
        pTagert3DScalInfo = &(pBIOSInfo->TMDSSettingInfo.DVI3DScalInfo);
        IGAPath = pBIOSInfo->TMDSSettingInfo.IGAPath;
        break;

    case VIA_DEVICE_HDMI:
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "SetPanleViewPositionValue:HDMI path \n"));
        pTagert3DScalInfo = &(pBIOSInfo->HDMISettingInfo.HDMI3DScalInfo);
        IGAPath = pBIOSInfo->HDMISettingInfo.IGAPath;
        break;

    case VIA_DEVICE_LCD:
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "SetPanleViewPositionValue:LCD path \n"));
        pTagert3DScalInfo = &(pBIOSInfo->LVDSSettingInfo.LCD3DScalInfo);
        IGAPath = pBIOSInfo->LVDSSettingInfo.IGAPath;
        break;
    }

    if (pBIOSInfo->Is3DScalingEnable & dwDevice) {
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT_DEVICE_SetPanleViewPositionValue:Y=%d, X=%d \n",
            ViewPosValue.dwY, ViewPosValue.dwX));

        if (ViewPosValue.dwY == 0xFFFF || ViewPosValue.dwX == 0xFFFF) {
            ViewPosValue.dwX = pTagert3DScalInfo->XPOSITIONDefault;
            ViewPosValue.dwY = pTagert3DScalInfo->YPOSITIONDefault;
            pTagert3DScalInfo->XPOSITIONLevel =
                pTagert3DScalInfo->XPOSITIONDefault;
            pTagert3DScalInfo->YPOSITIONLevel =
                pTagert3DScalInfo->YPOSITIONDefault;
        }
        pTagert3DScalInfo->XPOSITIONLevel = ViewPosValue.dwX;
        pTagert3DScalInfo->YPOSITIONLevel = ViewPosValue.dwY;
        pTagert3DScalInfo->XPOSITIONOffset =
            (pTagert3DScalInfo->XPOSITIONLevel -
            pTagert3DScalInfo->XPOSITIONDefault) *
            pTagert3DScalInfo->XPOSITIONStep;
        pTagert3DScalInfo->YPOSITIONOffset =
            (pTagert3DScalInfo->YPOSITIONLevel -
            pTagert3DScalInfo->YPOSITIONDefault) *
            pTagert3DScalInfo->YPOSITIONStep;

        pTagert3DScalInfo->XPOSITIONNow =
            (pTagert3DScalInfo->XPOSITIONLevel -
            pTagert3DScalInfo->XPOSITIONDefault) *
            pTagert3DScalInfo->XPOSITIONStep;
        pTagert3DScalInfo->YPOSITIONNow =
            (pTagert3DScalInfo->YPOSITIONLevel -
            pTagert3DScalInfo->YPOSITIONDefault) *
            pTagert3DScalInfo->YPOSITIONStep;

        pTagert3DScalInfo->bNeedBlack3dScalingBorders = TRUE;

        viaGfxInfo->igaInfo[IGAPath -
            1].igagfx3DScaling_info.XPOSITIONOffset =
            pTagert3DScalInfo->XPOSITIONOffset;
        viaGfxInfo->igaInfo[IGAPath -
            1].igagfx3DScaling_info.YPOSITIONOffset =
            pTagert3DScalInfo->YPOSITIONOffset;

        if (via_module_loaded) {
            TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
            if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO)) {
                return FALSE;
            }
        }

        VIAAdjustFrame(pScrn->scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);
        VIASaveUserSetting(pBIOSInfo);
    }
    return TRUE;
}

void
VIA_UT_DEVICE_GetSupportState(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetSupportState\n"));

    unsigned int dwSupportState = UT_DEVICE_CRT1;

    if (pBIOSInfo->TVSettingInfo.TVEncoder) {
        /*remove TV support if set below resolution */
        if ((pBIOSInfo->HDisplay == 1280 && pBIOSInfo->VDisplay == 720) ||
            (pBIOSInfo->HDisplay == 1920 && pBIOSInfo->VDisplay == 1080))
            dwSupportState &= ~UT_DEVICE_TV;
        else
            dwSupportState |= UT_DEVICE_TV;

        if (pBIOSInfo->TVSettingInfo.TVEncoder == VIA_VT1625) {
            dwSupportState |= UT_DEVICE_HDTV;
        }

        if (pBIOSInfo->TVSettingInfo.TVEncoder == VIA_INTEGRATED_TV) {
            if (pBIOSInfo->dwProjectIDRevision != UNICHROME_VT3324)
                dwSupportState |= UT_DEVICE_HDTV;
        }

        if ((pBIOSInfo->TVSettingInfo.TVEncoder == VIA_VT1625)
            && pBIOSInfo->TwoCRT)
            dwSupportState |= UT_DEVICE_CRT2;
    }

    if (pBIOSInfo->TVSettingInfo2.TVEncoder
        && (pBIOSInfo->Chipset == VIA_CX700))
        dwSupportState |= UT_DEVICE_TV2 | UT_DEVICE_HDTV2;

    if (pBIOSInfo->TMDSSettingInfo.ChipID)
        dwSupportState |= UT_DEVICE_DFP;

    if (pBIOSInfo->TMDSSettingInfo2.ChipID)
        dwSupportState |= UT_DEVICE_DFP2;

    if (pBIOSInfo->HDMISettingInfo.ChipID)
        dwSupportState |= UT_DEVICE_HDMI;

    if (pBIOSInfo->DPSettingInfo.ChipID)
        dwSupportState |= UT_DEVICE_DP;

    if (pBIOSInfo->DPSettingInfo2.ChipID)
        dwSupportState |= UT_DEVICE_DP2;

    if (pBIOSInfo->LVDSSettingInfo.ChipID)
        dwSupportState |= UT_DEVICE_LCD;

    if (pBIOSInfo->LVDSSettingInfo2.ChipID)
        dwSupportState |= UT_DEVICE_LCD2;

    *pdwSupportState = dwSupportState;

}

void
VIA_UT_DEVICE_GetConnectState(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pdwConnectState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetConnectState\n"));

    unsigned int dwConnectState = VIAGetDeviceDetect(pBIOSInfo);

    /* Map the device state for utility. */
    dwConnectState = MapDeviceStateForUT(dwConnectState);

    if (pBIOSInfo->TVSettingInfo.TVEncoder == VIA_VT1625 ||
        pBIOSInfo->TVSettingInfo.TVEncoder == VIA_INTEGRATED_TV) {
        if (dwConnectState & UT_DEVICE_TV)
            dwConnectState |= UT_DEVICE_HDTV;

        if (dwConnectState & UT_DEVICE_TV2)
            dwConnectState |= UT_DEVICE_HDTV2;

        if ((pBIOSInfo->TVSettingInfo.TVEncoder == VIA_VT1625)
            && pBIOSInfo->TwoCRT)
            dwConnectState |= UT_DEVICE_CRT2;
    }

    *pdwConnectState = dwConnectState;

}

void
VIA_UT_DEVICE_GetPrimaryDevice(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pdwDevicePrimary)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetPrimaryDevice\n"));

    *pdwDevicePrimary = pBIOSInfo->PrimaryDevice;
}

void
VIA_UT_DEVICE_GetSAMMState(VIABIOSInfoPtr pBIOSInfo, CARD32 *pdwSAMMState)
{
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetSAMMState\n"));

    if (pVia->pVIAEnt->HasSecondary)
        *pdwSAMMState = UT_STATE_SAMM_ON;
    else
        *pdwSAMMState = UT_STATE_SAMM_OFF;
}

void
VIA_UT_DEVICE_GetSupportSAMMState(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pdwSAMMState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_GetSupportSAMMState\n"));

    *pdwSAMMState = UT_DEVICE_SUPPORT_SAMM_STATE_ON;
}

Bool
VIA_UT_DEVICE_SetV3OnIGAStatus(ScrnInfoPtr pScrn, CARD32 dwIGAPath)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_SetV3OnIGAStatus\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    static DDUPDATEOVERLAY updateOvlRec;
    LPOVERLAYRECORD pupdateOvlRec;
    int ret = 0;
    int i = 0;
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    if (dwIGAPath == UT_STATE_DuoView_IGA1) {
        if (viaGfxInfo->screenAttr.m1.duoview &&
            ((pBIOSInfo->Chipset == VIA_K8M890) ||
            (pBIOSInfo->Chipset == VIA_P4M890) ||
            (pBIOSInfo->Chipset == VIA_P4M800PRO) ||
            (pBIOSInfo->Chipset == VIA_P4M900)))
            viaGfxInfo->preferedVideoIga = IGA1;

        ret = TRUE;
    } else if (dwIGAPath == UT_STATE_DuoView_IGA2) {
        if (viaGfxInfo->screenAttr.m1.duoview &&
            ((pBIOSInfo->Chipset == VIA_K8M890) ||
            (pBIOSInfo->Chipset == VIA_P4M890) ||
            (pBIOSInfo->Chipset == VIA_P4M800PRO) ||
            (pBIOSInfo->Chipset == VIA_P4M900)))
            viaGfxInfo->preferedVideoIga = IGA2;
        ret = TRUE;
    } else {
        ret = FALSE;
    }

    if (via_module_loaded) {
        TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
        if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO)) {
            return FALSE;
        }

        vvaUpdateOverlay(pScrn->scrnIndex, 0, 0);
    }

    for (i = 0; i < XV_PORT_NUM_OVERLAY; i++) {
        if (pVia->pPriv[i] != NULL) {
            if (pVia->pPriv[i]->videoFlag & VIDEO_ACTIVE) {
                pupdateOvlRec =
                    &pVia->pPriv[i]->ovlInfo[pVia->pPriv[i]->curIGA - 1];

                updateOvlRec.rSrc = pupdateOvlRec->dwOriSrcRect;
                updateOvlRec.rDest = pupdateOvlRec->dwOriDestRect;
                updateOvlRec.dwFlags |= (DDOVER_SHOW | DDOVER_KEYDEST);
                UpdateOverlay(pScrn, pVia->pPriv[i], &updateOvlRec);
            }
        }
    }

    return ret;
}

void
VIA_UT_DEVICE_GetV3OnIGAStatus(ScrnInfoPtr pScrn, CARD32 *pdwStatus)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_DEVICE_SetV3OnIGAStatus\n"));
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    if (pVia->pVIAEnt->pVidData->viaGfxInfo->screenAttr.m1.duoview &&
        ((pBIOSInfo->Chipset == VIA_K8M890) ||
        (pBIOSInfo->Chipset == VIA_P4M890) ||
        (pBIOSInfo->Chipset == VIA_P4M800PRO) ||
        (pBIOSInfo->Chipset == VIA_P4M900))) {
        if (pVia->pVIAEnt->pVidData->viaGfxInfo->preferedVideoIga == IGA2) {
            *pdwStatus = 0x01;
        } else {
            *pdwStatus = 0x00;
        }
    }
}

void
VIA_UT_DEVICE_GetDuoViewStatus(ScrnInfoPtr pScrn, CARD32 *pdwState)
{
    VIAPtr pVia = VIAPTR(pScrn);

    if (pVia->pVIAEnt->pVidData->viaGfxInfo->screenAttr.m1.duoview)
        *pdwState = UT_STATE_DuoView_ON;
    else
        *pdwState = UT_STATE_DuoView_OFF;
}

void
VIA_UT_TV_GetSupportStandardState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSupportStandardState\n"));

    if (pBIOSInfo->HDisplay == 720) {
        if (pBIOSInfo->VDisplay == 480)
            *pdwSupportState = UT_TV_STD_NTSC;
        else if (pBIOSInfo->VDisplay == 576)
            *pdwSupportState = UT_TV_STD_PAL;
        else
            *pdwSupportState = UT_TV_STD_NTSC | UT_TV_STD_PAL;
    } else
        *pdwSupportState = UT_TV_STD_NTSC | UT_TV_STD_PAL;
}

void
VIA_UT_TV_GetStandard(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwStandard)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetStandard\n"));

    switch (pTVSettingInfo->TVType) {
    case TVTYPE_NTSC:
        *pdwStandard = UT_TV_STD_NTSC;
        break;
    case TVTYPE_PAL:
        *pdwStandard = UT_TV_STD_PAL;
        break;
    case TVTYPE_NONE:
    default:
        *pdwStandard = 0;
        break;
    }

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "TVType=%d \n", pTVSettingInfo->TVType));
}

Bool
VIA_UT_TV_SetStandard(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, DisplayModePtr mode, CARD32 dwStandard)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetStandard\n"));

    int ret;

    switch (dwStandard) {
    case UT_TV_STD_NTSC:
        pTVSettingInfo->TVType = TVTYPE_NTSC;
        ret = TRUE;
        break;

    case UT_TV_STD_PAL:
        pTVSettingInfo->TVType = TVTYPE_PAL;
        ret = TRUE;
        break;

    default:
        ret = FALSE;
        break;
    }

    xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
    "TVType=%d\n", pTVSettingInfo->TVType);

    return ret;

}

void
VIA_UT_TV_GetSupportSignalTypeState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSupportSignalTypeState\n"));

    VIAGetActiveDisplay(pBIOSInfo);

    switch (pTVSettingInfo->TVEncoder) {
    case VIA_INTEGRATED_TV:
        *pdwSupportState = UT_TV_SGNL_COMPOSITE | UT_TV_SGNL_S_VIDEO |
            UT_TV_SGNL_SCART | UT_TV_SGNL_COMP_OUTPUT |
            UT_TV_SGNL_COMPOSITE_SVIDEO;
        break;
    case VIA_VT1625:
        *pdwSupportState = UT_TV_SGNL_COMPOSITE | UT_TV_SGNL_S_VIDEO |
            UT_TV_SGNL_SCART | UT_TV_SGNL_COMP_OUTPUT |
            UT_TV_SGNL_COMPOSITE_SVIDEO |
            UT_TV_SGNL_COMPONENT_COMPOSITE_SVIDEO |
            UT_TV_SGNL_RGB_COMPOSITE_SVIDEO;
        break;
    default:
        *pdwSupportState = 0;
        break;
    }
}

void
VIA_UT_TV_GetSignalType(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 * pdwSignalType)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSignalType\n"));

    switch (pTVSettingInfo->TVOutput) {
    case TV_OUTPUT_COMPOSITE:
        *pdwSignalType = UT_TV_SGNL_COMPOSITE;
        break;
    case TV_OUTPUT_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_COMPOSITE_SVIDEO;
        break;
    case TV_OUTPUT_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_S_VIDEO;
        break;
    case TV_OUTPUT_RGB:
        *pdwSignalType = UT_TV_SGNL_SCART;
        break;
    case TV_OUTPUT_YPBPR:
        *pdwSignalType = UT_TV_SGNL_COMP_OUTPUT;
        break;
    case TV_OUTPUT_RGB_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_RGB_COMPOSITE_SVIDEO;
        break;
    case TV_OUTPUT_YPBPR_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_COMPONENT_COMPOSITE_SVIDEO;
        break;
    default:
        *pdwSignalType = 0;
        break;
    }
}

Bool
VIA_UT_TV_SetSignalType(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, DisplayModePtr mode, CARD32 dwSignal)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetSignalType\n"));

    int ret;

    switch (dwSignal) {
    case UT_TV_SGNL_COMPOSITE:
        pTVSettingInfo->TVOutput = TV_OUTPUT_COMPOSITE;
        ret = TRUE;
        break;
    case UT_TV_SGNL_S_VIDEO:
        pTVSettingInfo->TVOutput = TV_OUTPUT_SVIDEO;
        ret = TRUE;
        break;
    case UT_TV_SGNL_SCART:
        pTVSettingInfo->TVOutput = TV_OUTPUT_RGB;
        ret = TRUE;
        break;
    case UT_TV_SGNL_COMP_OUTPUT:
        pTVSettingInfo->TVOutput = TV_OUTPUT_YPBPR;
        ret = TRUE;
        break;
    case UT_TV_SGNL_COMPOSITE_SVIDEO:
        pTVSettingInfo->TVOutput = TV_OUTPUT_COMPOSITE_SVIDEO;
        ret = TRUE;
        break;
    case UT_TV_SGNL_COMPONENT_COMPOSITE_SVIDEO:
        pTVSettingInfo->TVOutput = TV_OUTPUT_YPBPR_COMPOSITE_SVIDEO;
        ret = TRUE;
        break;
    case UT_TV_SGNL_RGB_COMPOSITE_SVIDEO:
        pTVSettingInfo->TVOutput = TV_OUTPUT_RGB_COMPOSITE_SVIDEO;
        ret = TRUE;
        break;
    default:
        ret = FALSE;
        break;
    }
   
    return ret;
}

void
VIA_UT_TV_GetMaxViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTXYVALUE *pMaxViewSizeValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetMaxViewSizeValue\n"));
    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {
        VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);

        pMaxViewSizeValue->dwX = pTV3DScalInfo->XScaleMaximum;
        pMaxViewSizeValue->dwY = pTV3DScalInfo->YScaleMaximum;
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "GetViewMaxSizeValue: MaxX=%d,MaxY=%d\n",
            pMaxViewSizeValue->dwX, pMaxViewSizeValue->dwY));

    } else {
        TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

        pMaxViewSizeValue->dwX = pTVInfo->ScalHLevel;
        pMaxViewSizeValue->dwY = pTVInfo->ScalVLevel;
    }
}

void
VIA_UT_TV_GetViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTXYVALUE * pViewSizeValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetViewSizeValue\n"));

    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {
        VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);

        pViewSizeValue->dwX = pTV3DScalInfo->XScaleLevel;
        pViewSizeValue->dwY = pTV3DScalInfo->YScaleLevel;
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "GetViewSizeValue: X=%d,Y=%d\n",
            pViewSizeValue->dwX, pViewSizeValue->dwY));
    } else {
        TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

        pViewSizeValue->dwX = pTVInfo->CurrentScalH + 1;
        pViewSizeValue->dwY = pTVInfo->CurrentScalV + 1;
    }
}

/*adjust TV/HDTV or other device size, position, we dont need to call
  switch mode */
/*change TV/HDTV or other device, or change TV/HDTV Signal standard, ,
  we need to call switch mode */
void
VIA_UT_TV_SetViewSizeValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo,
    DisplayModePtr mode, UTXYVALUE ViewSizeValue)
{
    VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetViewSizeValue\n"));

    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {

        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT_TV_SetViewSizeValue:Y=%d, X=%d \n",
            ViewSizeValue.dwY, ViewSizeValue.dwX));

        if (ViewSizeValue.dwY == 0xFFFF || ViewSizeValue.dwX == 0xFFFF) {
            ViewSizeValue.dwX = pTV3DScalInfo->XScaleDefault;
            ViewSizeValue.dwY = pTV3DScalInfo->YScaleDefault;
            pTV3DScalInfo->XScaleLevel = pTV3DScalInfo->XScaleDefault;
            pTV3DScalInfo->YScaleLevel = pTV3DScalInfo->YScaleDefault;
            pTVSettingInfo->TVVScan = VIA_TVOVER;
        }
        pTV3DScalInfo->XScaleLevel = ViewSizeValue.dwX;
        pTV3DScalInfo->YScaleLevel = ViewSizeValue.dwY;
        pTV3DScalInfo->XSIZEOffset =
            (pTV3DScalInfo->XScaleDefault -
            pTV3DScalInfo->XScaleLevel) * pTV3DScalInfo->XScaleStep;
        pTV3DScalInfo->YSIZEOffset =
            (pTV3DScalInfo->YScaleDefault -
            pTV3DScalInfo->YScaleLevel) * pTV3DScalInfo->YScaleStep;

        pTV3DScalInfo->XSIZENow =
            pTV3DScalInfo->XSIZEMax -
            (pTV3DScalInfo->XScaleLevel * pTV3DScalInfo->XScaleStep);
        pTV3DScalInfo->YSIZENow =
            pTV3DScalInfo->YSIZEMax -
            (pTV3DScalInfo->YScaleLevel * pTV3DScalInfo->YScaleStep);

        pTV3DScalInfo->bNeedBlack3dScalingBorders = TRUE;

        viaGfxInfo->igaInfo[pBIOSInfo->TVSettingInfo.IGAPath -
            1].igagfx3DScaling_info.XSIZEOffset = pTV3DScalInfo->XSIZEOffset;
        viaGfxInfo->igaInfo[pBIOSInfo->TVSettingInfo.IGAPath -
            1].igagfx3DScaling_info.YSIZEOffset = pTV3DScalInfo->YSIZEOffset;

        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "TV_SetViewSizeValue:igagfx3DScal_info.XSIZEOffset=%ld,"
            "igagfx3DScal_info.YSIZEOffset=%ld \n",
            pTV3DScalInfo->XSIZEOffset, pTV3DScalInfo->YSIZEOffset));

        if (via_module_loaded) {
            TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
            if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO)) {
                return;
            }
        }

        VIAAdjustFrame(pScrn->scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);

        VIASaveUserSetting(pBIOSInfo);
    } else {
        TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

        if (pTVSettingInfo->TVEncoder == VIA_INTEGRATED_TV) {
            AdjustTVSize_IntegratedTV(pBIOSInfo, pTVSettingInfo,
            ViewSizeValue.dwX, ViewSizeValue.dwY);
            VIASaveUserSetting(pBIOSInfo);
        } else {
            if (ViewSizeValue.dwY == 0xFFFF || ViewSizeValue.dwX == 0xFFFF) {
                ViewSizeValue.dwX = pTVInfo->DefaultScalH + 1;
                ViewSizeValue.dwY = pTVInfo->DefaultScalV + 1;
                pTVInfo->CurrentScalH = pTVInfo->DefaultScalH;
                pTVInfo->CurrentScalV = pTVInfo->DefaultScalV;
                pTVSettingInfo->TVVScan = VIA_TVOVER;
            }

            pTVInfo->CurrentScalH = ViewSizeValue.dwX - 1;
            pTVInfo->CurrentScalV = ViewSizeValue.dwY - 1;

            pTVSettingInfo->TVVScan = (int)ViewSizeValue.dwY - 1;

            pBIOSInfo->s3utility = TRUE;
            VIASaveUserSetting(pBIOSInfo);
            VIASwitchMode(pBIOSInfo->scrnIndex, mode, 0);
        }
    }
}

void
VIA_UT_TV_GetMaxViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTXYVALUE *pMaxViewPosValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetMaxViewPositionValue\n"));

    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {
        VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);

        pMaxViewPosValue->dwX = pTV3DScalInfo->XPOSITIONMaximum;
        pMaxViewPosValue->dwY = pTV3DScalInfo->YPOSITIONMaximum;
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "GetMaxViewPositionValue:MaxX=%d,MaxY=%d\n",
            pMaxViewPosValue->dwX, pMaxViewPosValue->dwY));

    } else {
        TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

        pMaxViewPosValue->dwX = pTVInfo->PositionHLevel;
        pMaxViewPosValue->dwY = pTVInfo->PositionVLevel;
    }

}

void
VIA_UT_TV_GetViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTXYVALUE *pViewPosValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetViewPositionValue\n"));

    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {
        VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);

    if (pViewPosValue->dwX == 0xFFFF && pViewPosValue->dwY == 0xFFFF) {
        pViewPosValue->dwX = pTV3DScalInfo->XPOSITIONDefault;
        pViewPosValue->dwY = pTV3DScalInfo->YPOSITIONDefault;
    } else {
        pViewPosValue->dwX = pTV3DScalInfo->XPOSITIONLevel;
        pViewPosValue->dwY = pTV3DScalInfo->YPOSITIONLevel;
    }

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "GetViewPositionValue:X=%d,Y=%d\n",
        pViewPosValue->dwX, pViewPosValue->dwY));
    } else {
        TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

        if (pViewPosValue->dwX == 0xFFFF && pViewPosValue->dwY == 0xFFFF) {
            pViewPosValue->dwX = pTVInfo->DefaultPositionH;
            pViewPosValue->dwY = pTVInfo->DefaultPositionV;
        } else {
            pViewPosValue->dwX = pTVInfo->CurrentPositionH;
            pViewPosValue->dwY = pTVInfo->CurrentPositionV;
        }
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "PositionValue_X = %d\n", pViewPosValue->dwX));
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "PositionValue_Y = %d\n", pViewPosValue->dwY));
    }
}

Bool
VIA_UT_TV_SetViewPositionValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTXYVALUE ViewPosValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetViewPositionValue\n"));

    VIA3DSclSCNParasPtr pTV3DScalInfo = &(pTVSettingInfo->TV3DScalInfo);
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);
    int ret = FALSE;               /* Return value */

    if (pBIOSInfo->Is3DScalingEnable & VIA_DEVICE_TV) {
        DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
            "VIA_UT_TV_SetViewPositionValue:Y=%d, X=%d \n",
            ViewPosValue.dwY, ViewPosValue.dwX));

        if (ViewPosValue.dwY == 0xFFFF || ViewPosValue.dwX == 0xFFFF) {
            ViewPosValue.dwX = pTV3DScalInfo->XPOSITIONDefault;
            ViewPosValue.dwY = pTV3DScalInfo->YPOSITIONDefault;
            pTV3DScalInfo->XPOSITIONLevel = pTV3DScalInfo->XPOSITIONDefault;
            pTV3DScalInfo->YPOSITIONLevel = pTV3DScalInfo->YPOSITIONDefault;
            pTVSettingInfo->TVVScan = VIA_TVOVER;
        }
        pTV3DScalInfo->XPOSITIONLevel = ViewPosValue.dwX;
        pTV3DScalInfo->YPOSITIONLevel = ViewPosValue.dwY;
        pTV3DScalInfo->XPOSITIONOffset =
            (pTV3DScalInfo->XPOSITIONLevel -
            pTV3DScalInfo->XPOSITIONDefault) * pTV3DScalInfo->XPOSITIONStep;
        pTV3DScalInfo->YPOSITIONOffset =
            (pTV3DScalInfo->YPOSITIONLevel -
            pTV3DScalInfo->YPOSITIONDefault) * pTV3DScalInfo->YPOSITIONStep;

        pTV3DScalInfo->XPOSITIONNow =
            (pTV3DScalInfo->XPOSITIONLevel -
            pTV3DScalInfo->XPOSITIONDefault) * pTV3DScalInfo->XPOSITIONStep;
        pTV3DScalInfo->YPOSITIONNow =
            (pTV3DScalInfo->YPOSITIONLevel -
            pTV3DScalInfo->YPOSITIONDefault) * pTV3DScalInfo->YPOSITIONStep;

        pTV3DScalInfo->bNeedBlack3dScalingBorders = TRUE;

        viaGfxInfo->igaInfo[pBIOSInfo->TVSettingInfo.IGAPath -
            1].igagfx3DScaling_info.XPOSITIONOffset =
            pTV3DScalInfo->XPOSITIONOffset;
        viaGfxInfo->igaInfo[pBIOSInfo->TVSettingInfo.IGAPath -
            1].igagfx3DScaling_info.YPOSITIONOffset =
            pTV3DScalInfo->YPOSITIONOffset;

        if (via_module_loaded) {
            TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
            if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo, VIA_SET_2D_INFO)) {
                return FALSE;
            }
        }

        VIAAdjustFrame(pScrn->scrnIndex, pScrn->frameX0, pScrn->frameY0, 0);

        VIASaveUserSetting(pBIOSInfo);
    } else {
        /* Set default Position */
        if (ViewPosValue.dwX == 0xFFFF && ViewPosValue.dwX == 0xFFFF) {
            ViewPosValue.dwX = pTVInfo->DefaultPositionH;
            ViewPosValue.dwY = pTVInfo->DefaultPositionV;
        }

        VIAAdjustTVPos(pBIOSInfo, pTVSettingInfo,
            ViewPosValue.dwX, ViewPosValue.dwY);

        ret = TRUE;

        VIASaveUserSetting(pBIOSInfo);

    }

    return ret;
}

void
VIA_UT_TV_GetSupportTuningState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSupportTuningState\n"));

    switch (pTVSettingInfo->TVEncoder) {
    case VIA_VT1625:
        *pdwSupportState = UT_TV_TUNING_FFILTER |
            UT_TV_TUNING_ADAPTIVE_FFILTER |
            UT_TV_TUNING_BRIGHTNESS | UT_TV_TUNING_CONTRAST;
        /* RGB/YCbCr don't support SATURATION & TINT */
        if (pTVSettingInfo->TVOutput == TV_OUTPUT_COMPOSITE ||
            pTVSettingInfo->TVOutput == TV_OUTPUT_SVIDEO ||
            pTVSettingInfo->TVOutput == TV_OUTPUT_COMPOSITE_SVIDEO) {
            *pdwSupportState |= UT_TV_TUNING_SATURATION | UT_TV_TUNING_TINT;
        }
        break;
    case VIA_INTEGRATED_TV:
        *pdwSupportState = UT_TV_TUNING_FFILTER |
            UT_TV_TUNING_ADAPTIVE_FFILTER |
            UT_TV_TUNING_BRIGHTNESS |
            UT_TV_TUNING_CONTRAST | UT_TV_TUNING_SATURATION;

        /* RGB/YCbCr don't support SATURATION & TINT */
        if (pTVSettingInfo->TVOutput == TV_OUTPUT_COMPOSITE ||
            pTVSettingInfo->TVOutput == TV_OUTPUT_SVIDEO ||
            pTVSettingInfo->TVOutput == TV_OUTPUT_COMPOSITE_SVIDEO) {
            *pdwSupportState |= UT_TV_TUNING_TINT;
        }

        break;
    default:
        *pdwSupportState = 0;
        break;
    }
}

Bool
VIA_UT_TV_GetTuningItemMaxValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo,
    CARD32 dwTuningItem, CARD32 *pdwMaxValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetTuningItemMaxValue\n"));

    TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);
    int ret;

    switch (dwTuningItem) {
    case UT_TV_TUNING_FFILTER:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->FFilterLevel;
        break;
    case UT_TV_TUNING_ADAPTIVE_FFILTER:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->AFFilterLevel;
        break;
    case UT_TV_TUNING_BRIGHTNESS:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->BrightnessLevel;
        break;
    case UT_TV_TUNING_CONTRAST:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->ContrastLevel;
        break;
    case UT_TV_TUNING_SATURATION:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->SaturationLevel;
        break;
    case UT_TV_TUNING_TINT:
        ret = TRUE;
        *pdwMaxValue = pTVInfo->TINTLevel;
        break;
    default:
        ret = FALSE;
        *pdwMaxValue = 0;
        break;
    }

    return ret;
}

Bool
VIA_UT_TV_GetTuningItemValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 dwTuningItem, CARD32 *pdwValue)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetTuningItemValue\n"));

    TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);
    int ret;

    switch (dwTuningItem) {
    case UT_TV_TUNING_FFILTER:
        *pdwValue = pTVInfo->CurrentFFilter;
        ret = TRUE;
        break;
    case UT_TV_TUNING_ADAPTIVE_FFILTER:
        *pdwValue = pTVInfo->CurrentAFFilter;
        ret = TRUE;
        break;
    case UT_TV_TUNING_BRIGHTNESS:
        *pdwValue = pTVInfo->CurrentBrightness;
        ret = TRUE;
        break;
    case UT_TV_TUNING_CONTRAST:
        *pdwValue = pTVInfo->CurrentContrast;
        ret = TRUE;
        break;
    case UT_TV_TUNING_SATURATION:
        *pdwValue = pTVInfo->CurrentSaturation;
        ret = TRUE;
        break;
    case UT_TV_TUNING_TINT:
        *pdwValue = pTVInfo->CurrentTINT;
        ret = TRUE;
        break;
    default:
        *pdwValue = 0;
        ret = FALSE;
        break;
    }
    return ret;
}

Bool
VIA_UT_TV_SetTuningItemValue(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTSETTVTUNINGINFO TuningInfo)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetTuningItemValue\n"));

    int ret = TRUE;

    switch (TuningInfo.dwItemID) {
    case UT_TV_TUNING_FFILTER:
        VIAAdjustTVFFilter(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    case UT_TV_TUNING_ADAPTIVE_FFILTER:
        VIAAdjustTVAFFilter(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    case UT_TV_TUNING_BRIGHTNESS:
        VIAAdjustTVBrightness(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    case UT_TV_TUNING_CONTRAST:
        VIAAdjustTVContrast(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    case UT_TV_TUNING_SATURATION:
        VIAAdjustTVSaturation(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    case UT_TV_TUNING_TINT:
        VIAAdjustTVHue(pBIOSInfo, pTVSettingInfo,
            (CARD32) TuningInfo.dwValue);
        break;

    default:
        ret = FALSE;
        break;
    }

    if (ret)
        VIASaveUserSetting(pBIOSInfo);

    return ret;
}

void
VIA_UT_TV_GetSupportSettingState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSupportSettingState\n"));

    *pdwSupportState |= UT_TV_SETTING_FFILTER;
    switch (pTVSettingInfo->TVEncoder) {
    case VIA_VT1625:
        *pdwSupportState |= UT_TV_SETTING_ADAPTIVE_FFILTER;
        if (pTVSettingInfo->TVType == TVTYPE_NTSC &&
            pTVSettingInfo->TVOutput == TV_OUTPUT_COMPOSITE) {
            *pdwSupportState |= UT_TV_SETTING_DOT_CRAWL;
        }
        break;
    case VIA_INTEGRATED_TV:
        *pdwSupportState |= UT_TV_SETTING_ADAPTIVE_FFILTER;
        break;
    }

}

Bool
VIA_UT_TV_GetSettingItemState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 dwItem, CARD32 *pdwState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_GetSettingItemState\n"));

    TVInfoPtr pTVInfo = &(pTVSettingInfo->TVInfo);

    int ret = FALSE;

    switch (dwItem) {
    case UT_TV_SETTING_FFILTER:
        if (!pTVInfo->AdaptiveFFilterOn)
            *pdwState = UT_STATE_ON;
        else
            *pdwState = UT_STATE_OFF;
        ret = TRUE;
        break;
    case UT_TV_SETTING_ADAPTIVE_FFILTER:
        if (pTVInfo->AdaptiveFFilterOn)
            *pdwState = UT_STATE_ON;
        else
            *pdwState = UT_STATE_OFF;
        ret = TRUE;
        break;
    case UT_TV_SETTING_DOT_CRAWL:
        if (pTVSettingInfo->TVDotCrawl)
            *pdwState = UT_STATE_ON;
        else
            *pdwState = UT_STATE_OFF;
        ret = TRUE;
        break;
    case UT_TV_SETTING_LOCK_ASPECT_RATIO:
        ret = FALSE;
        *pdwState = UT_STATE_OFF;
        break;
    default:
        ret = FALSE;
        *pdwState = UT_STATE_OFF;
        break;
    }

    return ret;
}

Bool
VIA_UT_TV_SetSettingItemState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, UTSETTVITEMSTATE SettingInfo)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_TV_SetSettingItemState\n"));

    int ret = TRUE;

    switch (SettingInfo.dwItemID) {
    case UT_TV_SETTING_FFILTER:
        if (SettingInfo.dwState == UT_STATE_OFF) {
            VIAEnableTVAFFilter(pBIOSInfo, pTVSettingInfo);
        } else if (SettingInfo.dwState == UT_STATE_ON) {
            VIAEnableTVFFilter(pBIOSInfo, pTVSettingInfo);
        } else {
            ret = FALSE;
        }
        if (ret)
            VIASaveUserSetting(pBIOSInfo);
        break;

    case UT_TV_SETTING_ADAPTIVE_FFILTER:
        if (SettingInfo.dwState == UT_STATE_OFF) {
            VIAEnableTVFFilter(pBIOSInfo, pTVSettingInfo);
        } else if (SettingInfo.dwState == UT_STATE_ON) {
            VIAEnableTVAFFilter(pBIOSInfo, pTVSettingInfo);
        } else {
            ret = FALSE;
        }
        if (ret)
            VIASaveUserSetting(pBIOSInfo);
        break;

    case UT_TV_SETTING_DOT_CRAWL:
        if (SettingInfo.dwState == UT_STATE_OFF ||
            SettingInfo.dwState == UT_STATE_DEFAULT) {
            pTVSettingInfo->TVDotCrawl = FALSE;
        } else if (SettingInfo.dwState == UT_STATE_ON) {
            pTVSettingInfo->TVDotCrawl = TRUE;
        } else {
            ret = FALSE;
        }
        if (ret) {
            VIASetTVDotCrawl(pBIOSInfo, pTVSettingInfo);
            VIASaveUserSetting(pBIOSInfo);
            VIARestoreUserTVSetting(pBIOSInfo, pTVSettingInfo);
        }
        break;

    case UT_TV_SETTING_LOCK_ASPECT_RATIO:
    default:
        ret = FALSE;
        break;
    }

    return ret;
}

void
VIA_UT_HDTV_GetSupportStandardState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_GetSupportStandardState\n"));

    switch (pTVSettingInfo->TVEncoder) {
    case VIA_VT1625:
        *pdwSupportState = UT_TV_STD_480P | UT_TV_STD_576P |
            UT_TV_STD_720P | UT_TV_STD_1080I;
        break;

    case VIA_INTEGRATED_TV:
        *pdwSupportState = UT_TV_STD_480P | UT_TV_STD_576P |
            UT_TV_STD_720P | UT_TV_STD_1080I;
        break;

    default:
        *pdwSupportState = 0;
        break;
    }

    if (pBIOSInfo->HDisplay == 720 && pBIOSInfo->VDisplay == 480)
        *pdwSupportState &= ~UT_TV_STD_576P;
    else if (pBIOSInfo->HDisplay == 720 && pBIOSInfo->VDisplay == 576)
        *pdwSupportState &= ~UT_TV_STD_480P;
    else if (pBIOSInfo->HDisplay == 1280 && pBIOSInfo->VDisplay == 720)
        *pdwSupportState &=
            ~(UT_TV_STD_480P | UT_TV_STD_576P | UT_TV_STD_1080I);
    else if (pBIOSInfo->HDisplay == 1920 && pBIOSInfo->VDisplay == 1080)
        *pdwSupportState &=
            ~(UT_TV_STD_480P | UT_TV_STD_576P | UT_TV_STD_720P);
}

void
VIA_UT_HDTV_GetStandard(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwStandard)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_GetStandard\n"));

    switch (pTVSettingInfo->TVType) {
    case TVTYPE_480P:
        *pdwStandard = UT_TV_STD_480P;
        break;
    case TVTYPE_576P:
        *pdwStandard = UT_TV_STD_576P;
        break;
    case TVTYPE_720P:
        *pdwStandard = UT_TV_STD_720P;
        break;
    case TVTYPE_1080I:
        *pdwStandard = UT_TV_STD_1080I;
        break;
    default:
        *pdwStandard = 0;
        break;
    }
}

Bool
VIA_UT_HDTV_SetStandard(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, DisplayModePtr mode, CARD32 dwStandard)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_SetStandard\n"));

    pTVSettingInfo->TVVScan = VIA_TVNORMAL;
    int ret;

    switch (dwStandard) {
    case UT_TV_STD_480P:
        pTVSettingInfo->TVType = TVTYPE_480P;
        ret = TRUE;
        break;
    case UT_TV_STD_576P:
        pTVSettingInfo->TVType = TVTYPE_576P;
        ret = TRUE;
        break;
    case UT_TV_STD_720P:
        pTVSettingInfo->TVType = TVTYPE_720P;
        ret = TRUE;
        break;
    case UT_TV_STD_1080I:
        pTVSettingInfo->TVType = TVTYPE_1080I;
        ret = TRUE;
        break;
    default:
        ret = FALSE;
        break;
    }

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "TVType = 0x%x\n", pBIOSInfo->TVSettingInfo.TVType));

    return ret;
}

void
VIA_UT_HDTV_GetSupportSignalTypeState(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_GetSupportSignalTypeState\n"));

    VIAGetActiveDisplay(pBIOSInfo);
    switch (pTVSettingInfo->TVEncoder) {
    case VIA_VT1625:
    case VIA_INTEGRATED_TV:
        *pdwSupportState = UT_TV_SGNL_COMPOSITE | UT_TV_SGNL_S_VIDEO |
            UT_TV_SGNL_SCART | UT_TV_SGNL_COMP_OUTPUT;
        break;
    default:
        *pdwSupportState = 0;
        break;
    }
}

void
VIA_UT_HDTV_GetSignalType(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, CARD32 *pdwSignalType)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_GetSignalType\n"));

    switch (pTVSettingInfo->TVOutput) {
    case TV_OUTPUT_COMPOSITE:
    case TV_OUTPUT_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_COMPOSITE;
        break;
    case TV_OUTPUT_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_S_VIDEO;
        break;
    case TV_OUTPUT_RGB:
        *pdwSignalType = UT_TV_SGNL_SCART;
        break;
    case TV_OUTPUT_YPBPR:
        *pdwSignalType = UT_TV_SGNL_COMP_OUTPUT;
        break;
    case TV_OUTPUT_YPBPR_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_COMPONENT_COMPOSITE_SVIDEO;
        break;
    case TV_OUTPUT_RGB_COMPOSITE_SVIDEO:
        *pdwSignalType = UT_TV_SGNL_RGB_COMPOSITE_SVIDEO;
        break;
    default:
        *pdwSignalType = 0;
        break;
    }
}

Bool
VIA_UT_HDTV_SetSignalType(VIABIOSInfoPtr pBIOSInfo,
    TVSETTINGINFOPTR pTVSettingInfo, DisplayModePtr mode, CARD32 dwSignalType)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_HDTV_SetSignalType\n"));

    int ret;

/* here we setting the HDTV tvvscan to Normal, because we have just on level timing now*/
    pTVSettingInfo->TVVScan = VIA_TVNORMAL;
    switch (dwSignalType) {
    case UT_TV_SGNL_COMPOSITE:
        pTVSettingInfo->TVOutput = TV_OUTPUT_COMPOSITE;
        ret = TRUE;
        break;
    case UT_TV_SGNL_S_VIDEO:
        pTVSettingInfo->TVOutput = TV_OUTPUT_SVIDEO;
        ret = TRUE;
        break;
    case UT_TV_SGNL_SCART:
        pTVSettingInfo->TVOutput = TV_OUTPUT_RGB;
        ret = TRUE;
        break;
    case UT_TV_SGNL_COMP_OUTPUT:
        pTVSettingInfo->TVOutput = TV_OUTPUT_YPBPR;
        ret = TRUE;
        break;
    default:
        ret = FALSE;
        break;
    }

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "TVType = 0x%x\n", pBIOSInfo->TVSettingInfo.TVType));

    return ret;
}

void
VIA_UT_GAMMA_GetDeviceSupportState(ScrnInfoPtr pScrn,
    CARD32 *pdwSupportState)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_GAMMA_GetDeviceSupportState\n"));

    if (pScrn->bitsPerPixel == 8)
        *pdwSupportState = UT_DEVICE_NONE;
    else
        *pdwSupportState = UT_DEVICE_CRT1 | UT_DEVICE_TV | UT_DEVICE_DFP |
            UT_DEVICE_LCD | UT_DEVICE_HDMI;
}

void
VIA_UT_GAMMA_GetLookUpTable(VIABIOSInfoPtr pBIOSInfo, CARD32 *pGammaLUT)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_GAMMA_GetLookUpTable\n"));

    int i = 0;

    for (i = 0; i < 256; i++) {
        pGammaLUT[i] = ((CARD32) pBIOSInfo->colors[i].red) << 16;
        pGammaLUT[i] |= ((CARD32) pBIOSInfo->colors[i].green) << 8;
        pGammaLUT[i] |= (CARD32) pBIOSInfo->colors[i].blue;
    }
}

Bool
VIA_UT_GAMMA_SetLookUpTable(ScrnInfoPtr pScrn, CARD32 *pGammaLUT)
{
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO,
        "VIA_UT_GAMMA_SetLookUpTable\n"));

    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    int i = 0;
    int ret = 0;

    if (pGammaLUT[0] == 0xFFFFFFFF) {  /* Set default gamma value */
        for (i = 0; i < 256; i++) {
            pBIOSInfo->colors[i].red = i;
            pBIOSInfo->colors[i].green = i;
            pBIOSInfo->colors[i].blue = i;
        }
    } else {
        for (i = 0; i < 256; i++) {
            pBIOSInfo->colors[i].red = (unsigned short)(pGammaLUT[i] >> 16);
            pBIOSInfo->colors[i].green =
                (unsigned short)(pGammaLUT[i] >> 8) & 0x00FF;
            pBIOSInfo->colors[i].blue =
                (unsigned short)(pGammaLUT[i] & 0x000000FF);
        }
    }
    if (VIARestoreGamma(pScrn, pBIOSInfo->colors)) {
        ret = TRUE;
    } else {
        ret = FALSE;
    }

    return ret;
}

void
VIA_UT_GAMMA_GetDefaultLookUpTable(VIABIOSInfoPtr pBIOSInfo,
    CARD32 *pGammaLUT)
{
    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIA_UT_GAMMA_GetDefaultLookUpTable\n"));
    int i = 0;

    for (i = 0; i < 256; i++) {
        pGammaLUT[i] = (CARD32) i << 16;
        pGammaLUT[i] |= (CARD32) i << 8;
        pGammaLUT[i] |= (CARD32) i;
    }
}

Bool
VIASaveUserSetting(VIABIOSInfoPtr pBIOSInfo)
{
    ScrnInfoPtr pScrn = xf86Screens[pBIOSInfo->scrnIndex];
    VIAPtr pVia = VIAPTR(pScrn);

    FILE *VIARC = NULL, *VIAtmp = NULL;
    char filename[40], tmpname[40], buffer[200], *home = NULL;
    int HDisplay, VDisplay, bitsPerPixel, ActiveDevice;
    Bool found = FALSE, ret = FALSE;
    Bool IsCenter;
    int OldCenter, OldTVStandard, OldTVOutput, OldTV2Standard, OldTV2Output;
    int TVStandard, TVOutput, TV2Standard, TV2Output;
    TMDSSETTINGINFOPTR pTmpTMDSSettingInfo = &(pBIOSInfo->TMDSSettingInfo);
    LVDSSETTINGINFOPTR pTmpLVDSSettingInfo = &(pBIOSInfo->LVDSSettingInfo);
    HDMISETTINGINFOPTR pTmpHDMISettingInfo = &(pBIOSInfo->HDMISettingInfo);

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO, "VIASaveUserSetting\n"));

    IsCenter = pBIOSInfo->LVDSSettingInfo.Center;


    home = "/etc/X11";
    if (home) {
        filename[0] = '\0';
        strcpy(filename, home);
        strcat(filename, "/.VIARC");
        if ((VIARC = fopen(filename, "r")) == NULL) {
            xf86Msg(X_DEFAULT, "Open user setting file failed.\n");
            if ((VIARC = fopen(filename, "a")) == NULL) {
                DEBUG(xf86Msg(X_ERROR, "Create .VIARC failure!\n"));
                return FALSE;
            }
        }

        /* save user setting to temp file */
        strcpy(tmpname, home);
        strcat(tmpname, "/.VIAtmp");
        VIAtmp = fopen(tmpname, "w+");
        /* looking for old setting by resolution & color depth index */
        while (fgets(buffer, 200, VIARC) != NULL) {
            sscanf(buffer, "%d %d %d %d %d %d %d %d %d",
            &HDisplay,
            &VDisplay,
            &bitsPerPixel,
            &ActiveDevice,
            &OldCenter,
            &OldTVStandard, &OldTVOutput, &OldTV2Standard, &OldTV2Output);

            if (pVia->pVIAEnt->HasSecondary) {
                /* dual TV's case */
                if (pBIOSInfo->ActualActiveDevice ==
                    (VIA_DEVICE_TV | VIA_DEVICE_TV2)) {
                    TVStandard = OldTVStandard;
                    TVOutput = OldTVOutput;
                    TV2Standard = pBIOSInfo->TVSettingInfo2.TVType;
                    TV2Output = pBIOSInfo->TVSettingInfo2.TVOutput;
					
                } else {           /* non-dual TV's case */

                    TVStandard = pBIOSInfo->TVSettingInfo.TVType;
                    TVOutput = pBIOSInfo->TVSettingInfo.TVOutput;
                    TV2Standard = pBIOSInfo->TVSettingInfo2.TVType;
                    TV2Output = pBIOSInfo->TVSettingInfo2.TVOutput;
                }
            } else {
                TVStandard = pBIOSInfo->TVSettingInfo.TVType;
                TVOutput = pBIOSInfo->TVSettingInfo.TVOutput;
                TV2Standard = pBIOSInfo->TVSettingInfo2.TVType;
                TV2Output = pBIOSInfo->TVSettingInfo2.TVOutput;
            }

            if (HDisplay == pBIOSInfo->SaveHDisplay &&
                VDisplay == pBIOSInfo->SaveVDisplay &&
                bitsPerPixel == pBIOSInfo->bitsPerPixel) {
                /* Also save TV output. */
                fprintf(VIAtmp,
                    "%d %d %d %lu %d %d %d %d %d %lu %lu %lu %lu %lu"
                    " %lu %lu %lu %lu %lu %lu %lu\n",
                    pBIOSInfo->SaveHDisplay, pBIOSInfo->SaveVDisplay,
                    pBIOSInfo->bitsPerPixel, pBIOSInfo->ActualActiveDevice,
                    IsCenter, TVStandard, TVOutput, TV2Standard, TV2Output,
                    pTmpTMDSSettingInfo->DVI3DScalInfo.XScaleLevel,
                    pTmpTMDSSettingInfo->DVI3DScalInfo.YScaleLevel,
                    pTmpTMDSSettingInfo->DVI3DScalInfo.XPOSITIONLevel,
                    pTmpTMDSSettingInfo->DVI3DScalInfo.YPOSITIONLevel,
                    pTmpLVDSSettingInfo->LCD3DScalInfo.XScaleLevel,
                    pTmpLVDSSettingInfo->LCD3DScalInfo.YScaleLevel,
                    pTmpLVDSSettingInfo->LCD3DScalInfo.XPOSITIONLevel,
                    pTmpLVDSSettingInfo->LCD3DScalInfo.YPOSITIONLevel,
                    pTmpHDMISettingInfo->HDMI3DScalInfo.XScaleLevel,
                    pTmpHDMISettingInfo->HDMI3DScalInfo.YScaleLevel,
                    pTmpHDMISettingInfo->HDMI3DScalInfo.XPOSITIONLevel,
                    pTmpHDMISettingInfo->HDMI3DScalInfo.YPOSITIONLevel);

                found = TRUE;
            } else {
                fputs(buffer, VIAtmp);
            }
        }

        if (!found) {
            fprintf(VIAtmp,
                "%d %d %d %lu %d %d %d %d %d %lu %lu %lu %lu %lu %lu %lu %lu\n",
                pBIOSInfo->SaveHDisplay, pBIOSInfo->SaveVDisplay,
                pBIOSInfo->bitsPerPixel, pBIOSInfo->ActualActiveDevice,
                IsCenter, pBIOSInfo->TVSettingInfo.TVType,
                pBIOSInfo->TVSettingInfo.TVOutput,
                pBIOSInfo->TVSettingInfo2.TVType,
                pBIOSInfo->TVSettingInfo2.TVOutput,
                pTmpTMDSSettingInfo->DVI3DScalInfo.XScaleLevel,
                pTmpTMDSSettingInfo->DVI3DScalInfo.YScaleLevel,
                pTmpTMDSSettingInfo->DVI3DScalInfo.XPOSITIONLevel,
                pTmpTMDSSettingInfo->DVI3DScalInfo.YPOSITIONLevel,
                pTmpLVDSSettingInfo->LCD3DScalInfo.XScaleLevel,
                pTmpLVDSSettingInfo->LCD3DScalInfo.YScaleLevel,
                pTmpLVDSSettingInfo->LCD3DScalInfo.XPOSITIONLevel,
                pTmpLVDSSettingInfo->LCD3DScalInfo.YPOSITIONLevel,
                pTmpHDMISettingInfo->HDMI3DScalInfo.XScaleLevel,
                pTmpHDMISettingInfo->HDMI3DScalInfo.YScaleLevel,
                pTmpHDMISettingInfo->HDMI3DScalInfo.XPOSITIONLevel,
                pTmpHDMISettingInfo->HDMI3DScalInfo.YPOSITIONLevel);

        }

        fclose(VIARC);
        fclose(VIAtmp);
        if (remove(filename) != -1) {  /* remove old setting file */
            if (rename(tmpname, filename) == 0) {
                ret = TRUE;
            }
        }

    }
    return ret;
}

void
VIALoadUserDuoViewVideoOutputDeviceSetting(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    FILE *VIADuoView = NULL;
    char filename[40], buffer[2], *home = NULL;
    int nGetV3OnIGAState;
    viaGfxInfoPtr viaGfxInfo = pVia->pVIAEnt->pVidData->viaGfxInfo;

    DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
        "VIALoadUserDuoViewVideoOutputDeviceSetting\n"));
    home = "/etc/X11";
    if (home) {
        filename[0] = '\0';
        strcpy(filename, home);
        strcat(filename, "/.VIADuoView");
        if ((VIADuoView = fopen(filename, "r")) == NULL) {
            DEBUG(xf86Msg(X_WARNING,
                "No user DuoView setting file exist, Create new ones\n"));
            if ((VIADuoView = fopen(filename, "a")) == NULL) {
                DEBUG(xf86Msg(X_ERROR, "Create .VIADuoView failure!\n"));
                return;
            }
        } else {
            while (fgets(buffer, 2, VIADuoView) != NULL) {
                sscanf(buffer, "%d", &nGetV3OnIGAState);
                if (nGetV3OnIGAState == UT_STATE_DuoView_IGA1) {
                    if (viaGfxInfo->screenAttr.m1.duoview &&
                        ((pBIOSInfo->Chipset == VIA_K8M890) ||
                        (pBIOSInfo->Chipset == VIA_P4M890) ||
                        (pBIOSInfo->Chipset == VIA_P4M800PRO) ||
                        (pBIOSInfo->Chipset == VIA_P4M900)))
                    viaGfxInfo->preferedVideoIga = IGA1;
                } else if (nGetV3OnIGAState == UT_STATE_DuoView_IGA2) {
                    if (viaGfxInfo->screenAttr.m1.duoview &&
                        ((pBIOSInfo->Chipset == VIA_K8M890) ||
                        (pBIOSInfo->Chipset == VIA_P4M890) ||
                        (pBIOSInfo->Chipset == VIA_P4M800PRO) ||
                        (pBIOSInfo->Chipset == VIA_P4M900)))
                    viaGfxInfo->preferedVideoIga = IGA2;
                }
            }

            if (!pBIOSInfo->FirstInit) {
                if (via_module_loaded) {
                    TranslateGFXInfo(pScrn, viaGfxInfo, &NEWVIAGraphicInfo);
                    if (FALSE == vvaSyncInfo(&NEWVIAGraphicInfo,
                        VIA_SET_2D_INFO)) {
                        return;
                    }
                }
            }
        }

        fclose(VIADuoView);
    }
}

/* Remove restart flag file for utility */
void
UTRemoveRestartFlag(VIABIOSInfoPtr pBIOSInfo)
{
    char filename[40], *home = NULL;

    filename[0] = '\0';
    home = "/etc/X11";
    if (home) {
        filename[0] = '\0';
        strcpy(filename, home);
        strcat(filename, "/.XWindowNeedtobeRestart");
        if (remove(filename) == -1)
            DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
                "Restart flag file not exist!\n"));
        else
            DEBUG(xf86DrvMsg(pBIOSInfo->scrnIndex, X_INFO,
                "Restart flag file has been remove!\n"));
    }
}

/*
    Query the VIAGFX_API version.
*/
static int
ProcVIAGFXQueryVersion(ClientPtr client)
{
    xVIAGFXQueryVersionReply rep;
    register int n;

    REQUEST_SIZE_MATCH(xVIAGFXQueryVersionReq);
    rep.type = X_Reply;
    rep.length = 0;
    rep.sequenceNumber = client->sequence;
    rep.majorVersion = 2;
    rep.minorVersion = 0;

    if (client->swapped) {
#if XORG_VERSION_CURRENT >=  XF86_VERSION_NUMERIC(1,11,99,0,0)
        swaps(&rep.sequenceNumber);
        swapl(&rep.length);
        swaps(&rep.majorVersion);
        swaps(&rep.minorVersion);
#else
        swaps(&rep.sequenceNumber, n);
        swapl(&rep.length, n);
        swaps(&rep.majorVersion, n);
        swaps(&rep.minorVersion, n);
#endif		
    }

    WriteToClient(client, sizeof(xVIAGFXQueryVersionReply), (char *)&rep);
    return (client->noClientException);
}

/*
*   Receive and process the request from AP.
*/
static int
ProcVIAGFXCommand(ClientPtr client)
{
    REQUEST(xVIAGFXCommandReq);
    xVIAGFXCommandReply rep;
    ExtensionEntry *myext;
    register int n;
    int i;

    REQUEST_SIZE_MATCH(xVIAGFXCommandReq);

    /* copy the request to reply. */
    memcpy(&rep, stuff, sizeof(xVIAGFXCommandReply));

    /* Get pointer to ExtensionEntry */
    if (!(myext = CheckExtension(VIAGFX_PROTOCOL_NAME)))
        return BadMatch;

    /* Process the request. */
    VIAGFXUtilityProc(&rep);

    rep.type = X_Reply;
    rep.length = (sizeof(xVIAGFXCommandReply) - sizeof(xGenericReply)) >> 2;
    rep.sequenceNumber = client->sequence;

    if (client->swapped) {
#if XORG_VERSION_CURRENT >=  XF86_VERSION_NUMERIC(1,11,99,0,0)
        swaps(&rep.sequenceNumber);
        swapl(&rep.length);
        swapl(&rep.command);
        swapl(&rep.primary_id);
        swapl(&rep.secondary_id);
        swapl(&rep.result_header);

        for (i = 0; i < VIAGFX_PARM_NUM; i++) {
            swapl(&rep.parm[i]);
            swapl(&rep.result[i]);
        }	
#else
        swaps(&rep.sequenceNumber, n);
        swapl(&rep.length, n);
        swapl(&rep.command, n);
        swapl(&rep.primary_id, n);
        swapl(&rep.secondary_id, n);
        swapl(&rep.result_header, n);

        for (i = 0; i < VIAGFX_PARM_NUM; i++) {
            swapl(&rep.parm[i], n);
            swapl(&rep.result[i], n);
        }
#endif		
    }

    WriteToClient(client, sizeof(xVIAGFXCommandReply), (char *)&rep);
    return client->noClientException;
}

static void
VIAGFXResetProc(ExtensionEntry *extEntry)
{
    if (extEntry->extPrivate) {
        free(extEntry->extPrivate);
        extEntry->extPrivate = NULL;
    }
}

static int
ProcVIAGFXDispatch(ClientPtr client)
{
    REQUEST(xReq);
    switch (stuff->data) {
    case X_VIAGFXQueryVersion:
        return ProcVIAGFXQueryVersion(client);
    case X_VIAGFXCommand:
        return ProcVIAGFXCommand(client);
    }

    return BadRequest;
}

void
VIADisplayExtensionInit(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;

    ExtensionEntry *extEntry;
    xVIAGFXScreenTable *VIAGFXScrnTbl;

    g_ScreenNumber = pScrn->scrnIndex;

    int viaScrnIndex = 0;

    if (pVia->IsSecondary)
        viaScrnIndex = 1;

    if (!(extEntry = CheckExtension(VIAGFX_PROTOCOL_NAME))) {
        if (!(VIAGFXScrnTbl = calloc(sizeof(xVIAGFXScreenTable), 1)))
            return;

        if (!(extEntry = AddExtension(VIAGFX_PROTOCOL_NAME, 0, 0,
                ProcVIAGFXDispatch,
                ProcVIAGFXDispatch,
                VIAGFXResetProc, StandardMinorOpcode))) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Failed to add VIAGFX extension\n");
            return;
        }

        extEntry->extPrivate = (pointer) VIAGFXScrnTbl;
    } else {
        if (!(VIAGFXScrnTbl = (xVIAGFXScreenTable *) extEntry->extPrivate)) {
            xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "Internal error: Found VIAGFX extension with NULL-private!\n");
            return;
        }
    }

    VIAGFXScrnTbl->HandleVIAGFXCommand[viaScrnIndex] = VIAGFXUtilityProc;
    pBIOSInfo->DisplayExtEntry = extEntry;
}

void
VIADisplayExtUnregister(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);
    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    ExtensionEntry *VIAGFXExt;
    xVIAGFXScreenTable *VIAGFXScreenTbl;

    int viaScrnIndex = 0;

    if (pVia->IsSecondary)
        viaScrnIndex = 1;

    if (!pBIOSInfo->DisplayExtEntry)
        return;

    if ((VIAGFXExt = CheckExtension(VIAGFX_PROTOCOL_NAME))) {
        if ((VIAGFXScreenTbl = (xVIAGFXScreenTable *) VIAGFXExt->extPrivate)) {
            VIAGFXScreenTbl->HandleVIAGFXCommand[viaScrnIndex] = NULL;
        }
    }
}

int
VIAGFXUtilityProc(xVIAGFXCommandReply *rep)
{
    ScrnInfoPtr pScrn = xf86Screens[g_ScreenNumber];
    VIAPtr pVia = VIAPTR(pScrn);

    /*
     * In SAMM case, a driver controls a screen.
     * In the past, we have to move application's window to switch to correct driver.
     * So I add following step to detect which driver we should use to avoid this problem.
     */
    if (pVia->pVIAEnt->HasSecondary) {
        //pScrn = VIAScreenSelection(pScrn, rep->primary_id, rep->secondary_id);
        pVia = VIAPTR(pScrn);
    }

    VIABIOSInfoPtr pBIOSInfo = pVia->pBIOSInfo;
    TVSETTINGINFOPTR pTVSettingInfo;

    /* variables for escape function. */
    CARD32 i;
    char szDriverName[16];
    CARD32 dwSupportState = 0;
    CARD32 dwConnectState = 0;
    CARD32 dwCurrentState = 0;
    CARD32 dwMaxValue = 0;
    CARD32 dwCurrentValue = 0;
    CARD32 dwChipID = 0;
    CARD32 dwVideoRam = 0;
    CARD32 dwGammaLUT[256];
    CARD32 dwRotateDegree = 0;
    CARD32 dwRotateType = 0;
    UTXYVALUE MaxViewSizeValue, ViewSizeValue, MaxViewPosValue, ViewPosValue;
    UTSETTVTUNINGINFO TVTuningInfo;
    UTSETTVITEMSTATE TVSettingItemState;
    UTPANELINFO UTPanelInfo;
    UTBIOSVERSION UTBIOSVersion;
    UTBIOSDATE UTBIOSDate;
    UTDriverVersion UTDriverVer;
    UTDEVMODE DevMode;

    char szDriverStrVersion[20];	

/*
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "VIAGFXUtilityProc\n"));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "rep->primary_id = %x\n", rep->primary_id));
    DEBUG(xf86DrvMsg(pScrn->scrnIndex, X_INFO, "rep->secondary_id = %x\n", rep->secondary_id));
*/
    /* Chose the TV setting info. */
    if ((rep->primary_id == UT_XV_FUNC_TV2)
        || (rep->primary_id == UT_XV_FUNC_HDTV2)) {
        pTVSettingInfo = &(pBIOSInfo->TVSettingInfo2);
    } else {
        pTVSettingInfo = &(pBIOSInfo->TVSettingInfo);
    }

    if (rep->primary_id == UT_XV_FUNC_BIOS) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_BIOS_GetChipID:
            VIA_UT_BIOS_GetChipID(pScrn, &dwChipID);
            rep->result[0] = dwChipID;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_BIOS_GetVersion:
            VIA_UT_BIOS_GetVersion(pScrn, &UTBIOSVersion);
            rep->result[0] = UTBIOSVersion.dwVersion;
            rep->result[1] = UTBIOSVersion.dwRevision;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_BIOS_GetDate:
            VIA_UT_BIOS_GetDate(pScrn, &UTBIOSDate);
            rep->result[0] = UTBIOSDate.dwYear;
            rep->result[1] = UTBIOSDate.dwMonth;
            rep->result[2] = UTBIOSDate.dwDay;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_BIOS_GetVideoMemSizeMB:
            VIA_UT_BIOS_GetVideoMemSizeMB(pScrn, &dwVideoRam);
            rep->result[0] = dwVideoRam;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_BIOS_GetTVChipID:
            VIA_UT_BIOS_GetTVChipID(pBIOSInfo, &dwChipID);
            rep->result[0] = dwChipID;
            rep->result_header = TRUE;
            break;
        }
    } else if (rep->primary_id == UT_XV_FUNC_DRIVER) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_DRIVER_GetFileName:
            if (VIA_UT_DRIVER_GetFileName(rep->parm[0], szDriverName)) {
                memcpy((void *)rep->result, (void *)szDriverName,
                    sizeof(szDriverName));
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

	  case UT_XV_FUNC_DRIVER_GetStrVersion:
            if (VIA_UT_DRIVER_GetStrVersion(rep->parm[0], szDriverStrVersion)) {
                memcpy((void *)rep->result, (void *)szDriverStrVersion,
                    sizeof(szDriverStrVersion));
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_DRIVER_GetFileVersion:
            if (VIA_UT_DRIVER_GetFileVersion(pScrn, rep->parm[0],
                &UTDriverVer)) {
                rep->result[0] = UTDriverVer.dwMajorNum;
                rep->result[1] = UTDriverVer.dwMinorNum;
                rep->result[2] = UTDriverVer.dwOSNum;
                rep->result[3] = UTDriverVer.dwReversionNum;
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;
        case UT_XV_FUNC_DRIVER_VIASync:
            if (pVia->pBIOSInfo->Is3DScalingEnable & DISP_3D_SCALING_ENABLE) {
                if (pVia->pBIOSInfo->IsStableStatus) {
                    // VIADISP3DScalingImageProcessing(pVia);
                }
            }
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DRIVER_GetFuncState:
            if (pVia->DISP3DScalingCaps & DISPLAY_3D_SCALING_SUPPORT) {
                rep->result[0] = MapFunStateForUT(pVia->DISP3DScalingCaps);
            } else {
                rep->result[0] = NO_3DSCALING;
            }
            rep->result_header = TRUE;
            break;
        }
    } else if (rep->primary_id == UT_XV_FUNC_DEVICE) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_DEVICE_GetSupportState:
            VIA_UT_DEVICE_GetSupportState(pBIOSInfo, &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetConnectState:
            VIA_UT_DEVICE_GetConnectState(pBIOSInfo, &dwConnectState);
            rep->result[0] = dwConnectState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetActiveState:
            //VIA_UT_DEVICE_GetActiveState(pScrn, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_SetActiveState:
            if (CheckMVEnabled(pBIOSInfo) &&
                (((rep->parm[0] & UT_DEVICE_HDTV) !=0)
                || ((rep->parm[0] & UT_DEVICE_TV) !=0))) {
                rep->result_header = TRUE;
                break;
            }
            //VIA_UT_DEVICE_SetActiveState(pBIOSInfo, pScrn->currentMode,
            //    rep->parm[0]);
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetSAMMState:
            VIA_UT_DEVICE_GetSAMMState(pBIOSInfo, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetSupportSAMMState:
            VIA_UT_DEVICE_GetSupportSAMMState(pBIOSInfo, &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_SetV3OnIGAStatus:
            if (VIA_UT_DEVICE_SetV3OnIGAStatus(pScrn, rep->parm[0])) {
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_DEVICE_GetV3OnIGAStatus:
            VIA_UT_DEVICE_GetV3OnIGAStatus(pScrn, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetDuoViewStatus:
            VIA_UT_DEVICE_GetDuoViewStatus(pScrn, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetPanningState:
            dwCurrentState = VIA_UT_DEVICE_GetPanningState(pBIOSInfo);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_GetPrimaryDevice:
            VIA_UT_DEVICE_GetPrimaryDevice(pBIOSInfo, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;
        }
    } else if (rep->primary_id == UT_XV_FUNC_PANEL) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_DEVICE_GetPanelInfo:
            VIA_UT_DEVICE_GetPanelInfo(pBIOSInfo, rep->parm[0], &UTPanelInfo);
            rep->result[0] = UTPanelInfo.dwType;
            rep->result[1] = UTPanelInfo.dwResX;
            rep->result[2] = UTPanelInfo.dwResY;
            rep->result[3] = UTPanelInfo.dwDeviceID;
            rep->result[4] = UTPanelInfo.dwExpandState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetSupportExpand:
            VIA_UT_DEVICE_GetSupportExpand(pBIOSInfo, &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_GetExpandState:
            VIA_UT_DEVICE_GetExpandState(pBIOSInfo, &dwCurrentState);
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DEVICE_SetExpandState:
            UTPanelInfo.dwType = rep->parm[0];
            UTPanelInfo.dwResX = rep->parm[1];
            UTPanelInfo.dwResY = rep->parm[2];
            UTPanelInfo.dwDeviceID = rep->parm[3];
            UTPanelInfo.dwExpandState = rep->parm[4];
            if (VIA_UT_DEVICE_SetExpandState(pBIOSInfo, pScrn->currentMode,
                UTPanelInfo)) {
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;
        case UT_XV_FUNC_DEVICE_GetPanleMaxViewSizeValue:
            VIA_UT_DEVICE_GetPanleMaxViewSizeValue(pBIOSInfo,
                &MaxViewSizeValue, rep->parm[0]);
            rep->result[0] = MaxViewSizeValue.dwX;
            rep->result[1] = MaxViewSizeValue.dwY;
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_GetPanleViewSizeValue:
            VIA_UT_DEVICE_GetPanleViewSizeValue(pBIOSInfo, &ViewSizeValue,
                rep->parm[0]);
            rep->result[0] = ViewSizeValue.dwX;
            rep->result[1] = ViewSizeValue.dwY;
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_SetPanleViewSizeValue:
            ViewSizeValue.dwX = rep->parm[0];
            ViewSizeValue.dwY = rep->parm[1];
            VIA_UT_DEVICE_SetPanleViewSizeValue(pBIOSInfo, ViewSizeValue,
                rep->parm[2]);
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_GetPanleMaxViewPositionValue:
            VIA_UT_DEVICE_GetPanleMaxViewPositionValue(pBIOSInfo,
                &MaxViewPosValue, rep->parm[0]);
            rep->result[0] = MaxViewPosValue.dwX;
            rep->result[1] = MaxViewPosValue.dwY;
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_GetPanleViewPositionValue:
            VIA_UT_DEVICE_GetPanleViewPositionValue(pBIOSInfo, &ViewPosValue,
                rep->parm[0]);
            rep->result[0] = ViewPosValue.dwX;
            rep->result[1] = ViewPosValue.dwY;
            rep->result_header = TRUE;
            break;
        case UT_XV_FUNC_DEVICE_SetPanleViewPositionValue:
            ViewPosValue.dwX = rep->parm[0];
            ViewPosValue.dwY = rep->parm[1];
            if (VIA_UT_DEVICE_SetPanleViewPositionValue(pBIOSInfo,
                ViewPosValue, rep->parm[2]))
                rep->result_header = TRUE;
            else
                rep->result_header = FALSE;
            break;
        }
    } else if ((rep->primary_id == UT_XV_FUNC_TV) ||
        (rep->primary_id == UT_XV_FUNC_TV2) ||
        (rep->primary_id == UT_XV_FUNC_HDTV) ||
        (rep->primary_id == UT_XV_FUNC_HDTV2)) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_TV_GetSupportStandardState:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                VIA_UT_TV_GetSupportStandardState(pBIOSInfo, pTVSettingInfo,
                &dwSupportState);
            } else {
                VIA_UT_HDTV_GetSupportStandardState(pBIOSInfo, pTVSettingInfo,
                    &dwSupportState);
            }
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetStandard:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                VIA_UT_TV_GetStandard(pBIOSInfo, pTVSettingInfo,
                &dwCurrentState);
            } else {
                VIA_UT_HDTV_GetStandard(pBIOSInfo, pTVSettingInfo,
                    &dwCurrentState);
            }
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_SetStandard:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                if (CheckMVEnabled(pBIOSInfo)) {
                    rep->result_header = TRUE;
                    break;
                }

                if (VIA_UT_TV_SetStandard(pBIOSInfo, pTVSettingInfo,
                    pScrn->currentMode, rep->parm[0]))
                    rep->result_header = TRUE;
                else
                    rep->result_header = FALSE;
            } else {
                if (VIA_UT_HDTV_SetStandard(pBIOSInfo, pTVSettingInfo,
                    pScrn->currentMode, rep->parm[0]))
                    rep->result_header = TRUE;
                else
                    rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_TV_GetSupportSignalTypeState:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                VIA_UT_TV_GetSupportSignalTypeState(pBIOSInfo, pTVSettingInfo,
                    &dwSupportState);
            } else {
                VIA_UT_HDTV_GetSupportSignalTypeState(pBIOSInfo,
                    pTVSettingInfo, &dwSupportState);
            }
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetSignalType:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                VIA_UT_TV_GetSignalType(pBIOSInfo, pTVSettingInfo,
                    &dwCurrentState);
            } else {
                VIA_UT_HDTV_GetSignalType(pBIOSInfo, pTVSettingInfo,
                    &dwCurrentState);
            }
            rep->result[0] = dwCurrentState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_SetSignalType:
            if ((rep->primary_id == UT_XV_FUNC_TV)
                || (rep->primary_id == UT_XV_FUNC_TV2)) {
                if (CheckMVEnabled(pBIOSInfo)) {
                    rep->result_header = TRUE;
                    break;
                }

                if (VIA_UT_TV_SetSignalType(pBIOSInfo, pTVSettingInfo,
                    pScrn->currentMode, rep->parm[0]))
                    rep->result_header = TRUE;
                else
                    rep->result_header = FALSE;
            } else {
                if (VIA_UT_HDTV_SetSignalType(pBIOSInfo, pTVSettingInfo,
                    pScrn->currentMode, rep->parm[0]))
                    rep->result_header = TRUE;
                else
                    rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_TV_GetMaxViewSizeValue:
            VIA_UT_TV_GetMaxViewSizeValue(pBIOSInfo, pTVSettingInfo,
                &MaxViewSizeValue);
            rep->result[0] = MaxViewSizeValue.dwX;
            rep->result[1] = MaxViewSizeValue.dwY;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetViewSizeValue:
            VIA_UT_TV_GetViewSizeValue(pBIOSInfo, pTVSettingInfo,
                &ViewSizeValue);
            rep->result[0] = ViewSizeValue.dwX;
            rep->result[1] = ViewSizeValue.dwY;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_SetViewSizeValue:
            ViewSizeValue.dwX = rep->parm[0];
            ViewSizeValue.dwY = rep->parm[1];
            VIA_UT_TV_SetViewSizeValue(pBIOSInfo, pTVSettingInfo,
            pScrn->currentMode, ViewSizeValue);
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetMaxViewPositionValue:
            VIA_UT_TV_GetMaxViewPositionValue(pBIOSInfo, pTVSettingInfo,
                &MaxViewPosValue);
            rep->result[0] = MaxViewPosValue.dwX;
            rep->result[1] = MaxViewPosValue.dwY;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetViewPositionValue:
            VIA_UT_TV_GetViewPositionValue(pBIOSInfo, pTVSettingInfo,
                &ViewPosValue);
            rep->result[0] = ViewPosValue.dwX;
            rep->result[1] = ViewPosValue.dwY;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_SetViewPositionValue:
            ViewPosValue.dwX = rep->parm[0];
            ViewPosValue.dwY = rep->parm[1];
            if (VIA_UT_TV_SetViewPositionValue(pBIOSInfo, pTVSettingInfo,
                ViewPosValue))
                rep->result_header = TRUE;
            else
                rep->result_header = FALSE;
            break;

        case UT_XV_FUNC_TV_GetSupportTuningState:
            VIA_UT_TV_GetSupportTuningState(pBIOSInfo, pTVSettingInfo,
                &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetTuningItemMaxValue:    /* 0 BASE */
            if (VIA_UT_TV_GetTuningItemMaxValue(pBIOSInfo, pTVSettingInfo,
                rep->parm[0], &dwMaxValue)) {
                rep->result[0] = dwMaxValue;
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_TV_GetTuningItemValue:
            if (VIA_UT_TV_GetTuningItemValue(pBIOSInfo, pTVSettingInfo,
                rep->parm[0], &dwCurrentValue)) {
                rep->result[0] = dwCurrentValue;
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_TV_SetTuningItemValue:
            TVTuningInfo.dwItemID = rep->parm[0];
            TVTuningInfo.dwValue = rep->parm[1];
            if (VIA_UT_TV_SetTuningItemValue(pBIOSInfo, pTVSettingInfo,
                TVTuningInfo))
                rep->result_header = TRUE;
            else
                rep->result_header = FALSE;
            break;

        case UT_XV_FUNC_TV_GetSupportSettingState:
            VIA_UT_TV_GetSupportSettingState(pBIOSInfo, pTVSettingInfo,
                &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_TV_GetSettingItemState:
            if (VIA_UT_TV_GetSettingItemState(pBIOSInfo, pTVSettingInfo,
                rep->parm[0], &dwCurrentState)) {
                rep->result[0] = dwCurrentState;
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_XV_FUNC_TV_SetSettingItemState:
            TVSettingItemState.dwItemID = rep->parm[0];
            TVSettingItemState.dwState = rep->parm[1];
            if (VIA_UT_TV_SetSettingItemState(pBIOSInfo, pTVSettingInfo,
                TVSettingItemState))
                rep->result_header = TRUE;
            else
                rep->result_header = FALSE;
            break;

        default:
            rep->result_header = FALSE;
            break;
        }
    } else if (rep->primary_id == UT_XV_FUNC_GAMMA) {
        switch (rep->secondary_id) {
        case UT_ESC_FUNC_GAMMA_GetDeviceSupportState:
            VIA_UT_GAMMA_GetDeviceSupportState(pScrn, &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_ESC_FUNC_GAMMA_GetLookUpTable:
            VIA_UT_GAMMA_GetLookUpTable(pBIOSInfo, dwGammaLUT);
            for (i = 0; i < 256; i++) {
                rep->result[i] = dwGammaLUT[i];
            }
            rep->result_header = TRUE;
            break;

        case UT_ESC_FUNC_GAMMA_SetLookUpTable:
            for (i = 0; i < 256; i++) {
                dwGammaLUT[i] = rep->parm[i];
            }

            if (VIA_UT_GAMMA_SetLookUpTable(pScrn, dwGammaLUT)) {
                rep->result_header = TRUE;
            } else {
                rep->result_header = FALSE;
            }
            break;

        case UT_ESC_FUNC_GAMMA_GetDefaultLookUpTable:
            VIA_UT_GAMMA_GetDefaultLookUpTable(pBIOSInfo, dwGammaLUT);
            for (i = 0; i < 256; i++) {
                rep->result[i] = dwGammaLUT[i];
            }
            rep->result_header = TRUE;
            break;
        }
    } else if (rep->primary_id == UT_XV_FUNC_DISPLAY) {
        switch (rep->secondary_id) {
        case UT_XV_FUNC_DISPLAY_EnumModes:
            VIA_UT_DISPLAY_EnumModes(pBIOSInfo, rep->parm[0], &DevMode);
            rep->result[0] = DevMode.ModeIndex;
            rep->result[1] = DevMode.PelsWidth;
            rep->result[2] = DevMode.PelsHeight;
            rep->result[3] = DevMode.RefreshRateNum;

            for (i = 0; i < DevMode.RefreshRateNum; i++) {
                rep->result[i + 4] = DevMode.RefreshRate[i];
            }
            rep->result_header = TRUE;

            break;

        case UT_XV_FUNC_DISPLAY_GetCurrentMode:
            VIA_UT_DISPLAY_GetCurrentMode(pBIOSInfo, &DevMode);
            rep->result[0] = DevMode.ModeIndex;
            rep->result[1] = DevMode.PelsWidth;
            rep->result[2] = DevMode.PelsHeight;
            rep->result[3] = DevMode.RefreshRateNum;

            for (i = 0; i < DevMode.RefreshRateNum; i++) {
                rep->result[i + 4] = DevMode.RefreshRate[i];
            }
            rep->result_header = TRUE;

            break;

        case UT_XV_FUNC_DISPLAY_GetCurrentRotateDegree:
            VIA_UT_DISPLAY_GetCurrentRotateDegree(pScrn, &dwRotateType,
                &dwRotateDegree);
            rep->result[0] = dwRotateType;
            rep->result[1] = dwRotateDegree;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DISPLAY_GetRotateCaps:
            VIA_UT_DISPLAY_GetRotationCaps(pScrn, rep->parm[0],
                &dwSupportState);
            rep->result[0] = dwSupportState;
            rep->result_header = TRUE;
            break;

        case UT_XV_FUNC_DISPLAY_SetRotateDegree:
            VIA_UT_DISPLAY_SetRotateDegree(pScrn, rep->parm[1]);
            rep->result_header = TRUE;
            break;
        }
    }

    return Success;
}
