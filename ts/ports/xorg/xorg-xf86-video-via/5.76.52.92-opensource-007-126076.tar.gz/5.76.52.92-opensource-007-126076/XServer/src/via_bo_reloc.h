/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef VIA_BO_RELOC_H
#define VIA_BO_RELOC_H

#include "via_chrome9_drm.h"
#include "via_bo_gem.h"

static int
drm_via_chrome9_setup_reloc(struct via_bo_reloc_info *vbo_reloc)
{
    unsigned int max_relocs_count = vbo_reloc->max_reloc;

    vbo_reloc->relocs = calloc(max_relocs_count,
                        sizeof(struct drm_via_chrome9_gem_relocation_entry));
    vbo_reloc->target_bo_list = calloc(max_relocs_count,
                                    sizeof(struct via_bo *));
    if ((vbo_reloc->relocs == NULL) || (vbo_reloc->target_bo_list == NULL))
        return 1;

    return 0;
}

static int
drm_via_chrome9_setup_exec_objects(
            struct drm_via_chrome9_gem_exec_object **exec_obj)
{
   *exec_obj = calloc(1, sizeof(struct drm_via_chrome9_gem_exec_object));
    if (*exec_obj == NULL)
        return 1;

    return 0;
}

static int
via_gem_write_reloc(unsigned int *buffer_ptr, unsigned long offset,
            struct generic_bo *target_bo, uint32_t delta,
            enum drm_via_chrome9_reloc_type type)
{
    unsigned int *cmdbuf = buffer_ptr + offset;
    struct via_bo *vbo = (struct via_bo*)target_bo;
    unsigned int target_bo_offset = target_bo->offset;
    unsigned int subaddr;

    switch (type) {
    case VIA_RELOC_2D:
        *cmdbuf = (target_bo_offset + delta) >> 3;
        break;
    case VIA_RELOC_3D:
        subaddr = (*cmdbuf) & 0xff000000;
        *cmdbuf = subaddr | ((target_bo_offset + delta) >> 8);
        break;
    case VIA_RELOC_HQV0:
    case VIA_RELOC_HQV1:
    case VIA_RELOC_VIDEO:
    case VIA_RELOC_VD:
        /* local system dynamic buffer */
        *cmdbuf = (target_bo_offset + delta) | \
                    ((vbo->domains & VIA_CHROME9_GEM_DOMAIN_GTT) ? 0x1 : 0x0);
        break;
    case VIA_RELOC_VERTEX_STREAM_L:
        subaddr = (*cmdbuf) & 0xfff00fff;
        *cmdbuf = (subaddr) | \
                    ((((target_bo_offset + delta) & 0x000003FF) >> 2) << 12);
        break;
    case VIA_RELOC_VERTEX_STREAM_H:
        subaddr = (*cmdbuf) & 0x000003FF;
        *cmdbuf = (subaddr) |  (((target_bo_offset + delta) >> 10) << 10);
        break;
    default:
        fprintf(stderr, "via_gem_write_reloc: unkown command type\n");
        break;
    }

    return 0;
}

#endif
