/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * EDID info by http://en.wikipedia.org/wiki/Extended_display_identification_data
 */

#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <linux/version.h>
#include "via_driver.h"

#ifdef VIA_RANDR12_SUPPORT
#include "globals.h"
#include "debug.h"               /* for DBG_DD */
#ifndef XSERVER_LIBPCIACCESS
#include "xf86RAC.h"
#endif
#include "xf86Priv.h"
#include "xf86Crtc.h"
#include "xf86RandR12.h"
#include "via_bios.h"
#include "via_rotate.h"
#include "via_eng_regs.h"
#include "viamode.h"
#include "X11/Xatom.h"
#include "via_modedata.h"
#include "via_common.h"
#include "via_serial.h"
#include "via_regs.h"
#include "via_output.h"
#include "via_disptv.h"
#include "via_displcd.h"
#include "via_disphdmi.h"
#include "via_dp.h"

/*External data structures and functions*/
extern Bool IsValidMode(CARD16 HDisplay, CARD16 VDisplay);
extern CARD32 viaDPHotplugTimer(OsTimerPtr timer, CARD32 now, pointer arg);

extern Bool ad9389_module_loaded;
extern Bool sil164_module_loaded;
extern Bool ch7301_module_loaded;

/*********************************************/
/*              Output property              */
/*********************************************/

void
viaSetOutputPath(int scrnIndex, CARD32 diPort, int igaPath, int chipset)
{
    /*Set Iga source and turn on DI port clk */
    switch (diPort) {
    case DISP_DI_DVP0:
        if (igaPath == IGA1)
            /* DVP0 Data Source Selection. */
            viaWriteVgaIoBits(REG_CR96, 0x00, BIT4);
        else
            /* DVP0 Data Source Selection. */
            viaWriteVgaIoBits(REG_CR96, 0x10, BIT4);
        /* enable dvp0 under CX700 */
        if (VIA_CX700 == chipset)
            viaWriteVgaIoBits(REG_CR91, 0x00, BIT5);

        /*Turn on DVP0 clk */
        viaWriteVgaIoBits(REG_SR1E, 0xC0, BIT6 + BIT7);
        break;
    case DISP_DI_DVP1:
        if (igaPath == IGA1)
            viaWriteVgaIoBits(REG_CR9B, 0x00, BIT4);
        else
            viaWriteVgaIoBits(REG_CR9B, 0x10, BIT4);

        /* enable dvp1 under this chipset */
        if ((VIA_CX700 == chipset) ||
            (VIA_VX800 == chipset) ||
            (VIA_VX855 == chipset) || (VIA_VX900 == chipset))
            viaWriteVgaIoBits(REG_CRD3, 0x00, BIT5);
        /*Turn on DVP1 clk */
        viaWriteVgaIoBits(REG_SR1E, 0x30, BIT4 + BIT5);
        break;

    case DISP_DI_DFPH:
        if (igaPath == IGA1) {
            /*3324,3353 CR96[4] control DVP0 */
            if ((VIA_CX700 != chipset) &&
            (VIA_VX800 != chipset) &&
            (VIA_VX855 != chipset) && (VIA_VX900 != chipset))
            viaWriteVgaIoBits(REG_CR96, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR97, 0x00, BIT4);
        } else {
            /*3324,3353 CR96[4] control DVP0 */
            if ((VIA_CX700 != chipset) &&
            (VIA_VX800 != chipset) &&
            (VIA_VX855 != chipset) && (VIA_VX900 != chipset))
            viaWriteVgaIoBits(REG_CR96, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR97, 0x10, BIT4);
        }

        /*Turn on DFPH clk */
        viaWriteVgaIoBits(REG_SR2A, 0x0C, BIT2 + BIT3);
        break;

    case DISP_DI_DFPL:
        if (igaPath == IGA1) {
            /*3324,3353 CR9B[4] control DVP1 */
            if ((VIA_CX700 != chipset) &&
            (VIA_VX800 != chipset) &&
            (VIA_VX855 != chipset) && (VIA_VX900 != chipset))
            viaWriteVgaIoBits(REG_CR9B, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x00, BIT4);
        } else {
            /*3324,3353 CR9B[4] control DVP1 */
            if ((VIA_CX700 != chipset) &&
            (VIA_VX800 != chipset) &&
            (VIA_VX855 != chipset) && (VIA_VX900 != chipset))
            viaWriteVgaIoBits(REG_CR9B, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x10, BIT4);
        }

        /*Turn on DFPL clk */
        viaWriteVgaIoBits(REG_SR2A, 0x03, BIT1 + BIT0);
        break;

    case DISP_DI_DFP:
        if ((VIA_K8M890 == chipset) || (VIA_P4M890 == chipset))
            viaWriteVgaIoBits(REG_CR97, 0x84, BIT7 + BIT2 + BIT1 + BIT0);
        if (igaPath == IGA1) {
            viaWriteVgaIoBits(REG_CR97, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x00, BIT4);
        } else {
            viaWriteVgaIoBits(REG_CR97, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x10, BIT4);
        }

        /*Turn on DFP clk */
        viaWriteVgaIoBits(REG_SR2A, 0x0F, BIT3 + BIT2 + BIT1 + BIT0);
        break;

    /*For TTL Type LCD */
    case (DISP_DI_DFPL + DISP_DI_DVP1):
        if (igaPath == IGA1) {
            viaWriteVgaIoBits(REG_CR99, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR9B, 0x00, BIT4);
        } else {
            viaWriteVgaIoBits(REG_CR99, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR9B, 0x10, BIT4);
        }

        /*Turn on DFPL, DVP1 clk */
        viaWriteVgaIoBits(REG_SR2A, 0x03, BIT1 + BIT0);
        viaWriteVgaIoBits(REG_SR1E, 0x30, BIT4 + BIT5);
        break;

    /*For 409 TTL Type LCD */
    case (DISP_DI_DFPH + DISP_DI_DFPL + DISP_DI_DVP1):
        if (igaPath == IGA1) {
            viaWriteVgaIoBits(REG_CR97, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x00, BIT4);
            viaWriteVgaIoBits(REG_CR9B, 0x00, BIT4);
        } else {
            viaWriteVgaIoBits(REG_CR97, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR99, 0x10, BIT4);
            viaWriteVgaIoBits(REG_CR9B, 0x10, BIT4);
        }

        /*Turn on DFPHL, DVP1 clk */
        viaWriteVgaIoBits(REG_SR2A, 0x0F, BIT3 + BIT2 + BIT1 + BIT0);
        viaWriteVgaIoBits(REG_SR1E, 0x30, BIT4 + BIT5);
        break;

    default:
        DEBUG(xf86DrvMsg(scrnIndex, X_ERROR,
            "viaSetOutputPath: No DIPort.\n"));
        break;

    }

    /* If Iga2 is used, enable Iga2 output for DI port.
     * In order to enable Iga2, 3324,3353,3293 use CR91 and CRD3 to control
     * DVP0 and DVP1 seperately, but other chip only use CR91 to control all Di port */
    if (IGA2 == igaPath && VIA_CX700 != chipset)
        viaWriteVgaIoBits(REG_CR91, 0x00, BIT5);

}

/* detect CRT VSYNC signal*/
xf86OutputStatus
viaDetectCRTVsync(VIAPtr pVia)
{
    CARD8 regSR01, regCR36, regSR40;
    xf86OutputStatus status;

    regSR01 = viaReadVgaIo(REG_SR01);
    regCR36 = viaReadVgaIo(REG_CR36);
    regSR40 = viaReadVgaIo(REG_SR40);
    /* Screen On */
    viaWriteVgaIoBits(REG_SR01, 0x0, BIT5);
    /* Power On DPMS */
    viaWriteVgaIoBits(REG_CR36, 0x0, BIT4 + BIT5 + BIT6 + BIT7);

    /*delay 16ms for Vertical Blank */
    viaDelay_Nmsec(pVia, 16);

    /* Enable CRT Sense */
    viaWriteVgaIoBits(REG_SR40, BIT7, BIT7);

    if ((VIA_CX700 == pVia->Chipset) ||
        (VIA_VX800 == pVia->Chipset) ||
        (VIA_VX855 == pVia->Chipset) || (VIA_VX900 == pVia->Chipset))
        viaWriteVgaIoBits(REG_SR40, 0, BIT7);

    /*
     * 324,353: SR40[7]=1 --> SR40[7] = 0 --> check 3C2[4]
     * other: SR40[7]=1 --> check 3C2[4] --> SR40[7]=0
     */
    if (STANDVGA_R8(0x3C2) & BIT4) {
        status = XF86OutputStatusConnected;
        DEBUG(ErrorF("CRT Connected\n"));
    } else {
        status = XF86OutputStatusDisconnected;
        DEBUG(ErrorF("CRT Dis-connected\n"));
    }

    if ((VIA_CX700 != pVia->Chipset) &&
        (VIA_VX800 != pVia->Chipset) &&
        (VIA_VX855 != pVia->Chipset) && (VIA_VX900 != pVia->Chipset))
        viaWriteVgaIoBits(REG_SR40, 0, BIT7);

    /* Restore */
    viaWriteVgaIo(REG_SR40, regSR40);
    viaWriteVgaIo(REG_CR36, regCR36);
    viaWriteVgaIo(REG_SR01, regSR01);
    return status;
}

void
viaDIPortPadOn(int scrnIndex, int DIPort)
{
    switch (DIPort) {
    case DISP_DI_DVP0:
        viaWriteVgaIoBits(REG_SR1E, BIT6 + BIT7, BIT6 + BIT7);
        break;

    case DISP_DI_DVP1:
        viaWriteVgaIoBits(REG_SR1E, BIT4 + BIT5, BIT4 + BIT5);
        break;

    case DISP_DI_DFPH:
        viaWriteVgaIoBits(REG_SR2A, BIT2 + BIT3, BIT2 + BIT3);
        break;

    case DISP_DI_DFPL:
        viaWriteVgaIoBits(REG_SR2A, BIT0 + BIT1, BIT0 + BIT1);
        break;

    case DISP_DI_DFP:
        viaWriteVgaIoBits(REG_SR2A, BIT2 + BIT3 + BIT1 + BIT0,
            BIT2 + BIT3 + BIT1 + BIT0);
        break;

    /*TTL LCD */
    case DISP_DI_DFPL + DISP_DI_DVP1:
        viaWriteVgaIoBits(REG_SR1E, BIT4 + BIT5, BIT4 + BIT5);
        viaWriteVgaIoBits(REG_SR2A, BIT0 + BIT1, BIT0 + BIT1);
        break;

    case DISP_DI_DAC:
        break;

    default:
        DEBUG(xf86DrvMsg(scrnIndex, X_ERROR, "viaDIPortPadOn: No DIPort.\n"));
        break;
    }
}

void
viaDIPortPadOff(int scrnIndex, int DIPort)
{
    switch (DIPort) {
    case DISP_DI_DVP0:
        viaWriteVgaIoBits(REG_SR1E, 0x00, BIT6 + BIT7);
        break;

    case DISP_DI_DVP1:
        viaWriteVgaIoBits(REG_SR1E, 0x00, BIT4 + BIT5);
        break;

    case DISP_DI_DFPH:
        viaWriteVgaIoBits(REG_SR2A, 0x00, BIT2 + BIT3);
        break;

    case DISP_DI_DFPL:
        viaWriteVgaIoBits(REG_SR2A, 0x00, BIT0 + BIT1);
        break;

    case DISP_DI_DFP:
        viaWriteVgaIoBits(REG_SR2A, 0x00, BIT2 + BIT3 + BIT1 + BIT0);
        break;

    /*TTL LCD */
    case DISP_DI_DFPL + DISP_DI_DVP1:
        viaWriteVgaIoBits(REG_SR1E, 0x00, BIT4 + BIT5);
        viaWriteVgaIoBits(REG_SR2A, 0x00, BIT0 + BIT1);
        break;

    case DISP_DI_DFPH + DISP_DI_DFPL + DISP_DI_DVP1:
        viaWriteVgaIoBits(REG_SR1E, 0x00, BIT4 + BIT5);
        viaWriteVgaIoBits(REG_SR2A, 0x00, BIT3 + BIT2 + BIT0 + BIT1);
        break;

    case DISP_DI_DAC:
        break;

    default:
        DEBUG(xf86DrvMsg(scrnIndex, X_ERROR,
            "viaDIPortPadOff: No DIPort.\n"));
        break;
    }
}

void
setDiportSyncPolarity(int scrnIndex, CARD32 port, DisplayModePtr mode)
{
    CARD8 syncreg = 0;

    if (mode->Flags & XF86CONF_NVSYNC)
        syncreg |= NEGATIVE << 1;
    if (mode->Flags & XF86CONF_NHSYNC)
        syncreg |= NEGATIVE;

    switch (port) {
    case DISP_DI_DAC:
        viaWriteMiscIo((viaReadMiscIo() & (~(BIT6 + BIT7))) | (syncreg << 6));
        break;
    case VIA_DI_DVP0:
        viaWriteVgaIoBits(REG_CR96, syncreg << 5, BIT6 | BIT5);
        break;
    case VIA_DI_DVP1:
        viaWriteVgaIoBits(REG_CR9B, syncreg << 5, BIT6 | BIT5);
        break;
    case VIA_DI_DFPHIGH:
        viaWriteVgaIoBits(REG_CR97, syncreg << 5, BIT6 | BIT5);
        break;
    case VIA_DI_DFPLOW:
        viaWriteVgaIoBits(REG_CR99, syncreg << 5, BIT6 | BIT5);
        break;
    default:
        DEBUG(xf86DrvMsg(scrnIndex, X_ERROR,
            "setDiportSyncPolarity: No DIPort.\n"));
        break;
    }
}

/*
 *     This function changes the destination of scaling up/down and CRTC timing registers
 *     IgaPath : for which IGA
 *     Scaletype : upscaling(VIA_EXPAND) or downscaling(VIA_SCALING_HW)
 */
void
viaSetScalePath(CARD32 IgaPath, CARD32 ScaleType)
{
    CARD8 regCRfd = viaReadVgaIo(REG_CRFD);

    if (g_ChipCaps & (CAPS_IGA1_DOWNSCALING |
        CAPS_IGA1_EXPAND | CAPS_IGA2_DOWNSCALING)) {
        if (IgaPath == IGA1) {
            /* Register reuse: select IGA1 path */
            regCRfd |= BIT7;
        } else {
            /* Register reuse: select IGA2 path */
            regCRfd &= ~BIT7;
        }
    }

    /* only IGA1 up scaling need to clear this bit CRFD.5. */
    if (g_ChipCaps & CAPS_IGA1_EXPAND) {
        if ((IgaPath == IGA1) && ((VIA_HOR_EXPAND & ScaleType) ||
            (VIA_VER_EXPAND & ScaleType))) {
            regCRfd &= ~BIT5;
        }
    }

    /* CRFD.0 = 0 : common IGA2,     = 1 : downscaling IGA   */
    if (g_ChipCaps & (CAPS_IGA1_DOWNSCALING | CAPS_IGA2_DOWNSCALING)) {
        switch (ScaleType) {
        case VIA_NONE_SCALING:
        case VIA_EXPAND:
        case VIA_HOR_EXPAND:
        case VIA_VER_EXPAND:
            /* Register reuse: as common IGA2 */
            regCRfd &= ~BIT0;
            break;
        case VIA_SCALING_HW:
            /* Register reuse: as downscaling IGA */
            regCRfd |= BIT0;
            break;
        default:
            break;
        }
    }

    viaWriteVgaIo(REG_CRFD, regCRfd);
}

static void
patchCrtDvp1DPA(CARD32 chipset, CARD32 subChipName)
{
    switch (chipset) {
    case VIA_VX900:
        if (SUBCHIP_CH7301 == subChipName) {
            viaWriteVgaIoBits(REG_CR9B, 0x0A, 0x0F);
        }
        break;
    default:
        break;
    }
}

static void
loadCrtDefaultDPASetting(CARD32 chipset, CARD32 port, CARD32 subChipName)
{
    switch (port) {
    case DISP_DI_DVP1:
        patchCrtDvp1DPA(chipset, subChipName);
    default:
        break;
    }
}

/*
*   Purpose: Set DPA value to register.
*/
static void
setDPA(CARD32 port, GFX_DPA_VALUE_PTR pGfxDPASetting)
{
    DEBUG(ErrorF("VIASetDPA_Gfx, Use Port %x.\n", port));

    switch (port) {
    case DISP_DI_DVP0:
        /* DVP0 Clock Polarity and Adjust: */
        viaWriteVgaIoBits(REG_CR96, pGfxDPASetting->DVP0, 0x0F);

        /* DVP0 Clock and Data Pads Driving: */
        viaWriteVgaIoBits(REG_SR1E, pGfxDPASetting->DVP0ClockDri_S, BIT2);
        viaWriteVgaIoBits(REG_SR2A, pGfxDPASetting->DVP0ClockDri_S1, BIT4);
        viaWriteVgaIoBits(REG_SR1B, pGfxDPASetting->DVP0DataDri_S, BIT1);
        viaWriteVgaIoBits(REG_SR2A, pGfxDPASetting->DVP0DataDri_S1, BIT5);
        break;
    case DISP_DI_DVP1:
        /* DVP1 Clock Polarity and Adjust: */
        viaWriteVgaIoBits(REG_CR9B, pGfxDPASetting->DVP1, 0x0F);

        /* DVP1 Clock and Data Pads Driving: */
        viaWriteVgaIoBits(REG_SR65, pGfxDPASetting->DVP1Driving, 0x0F);
        break;
    case DISP_DI_DFPH:
        viaWriteVgaIoBits(REG_CR97, pGfxDPASetting->DFPHigh, 0x0F);
        break;
    case DISP_DI_DFPL:
        viaWriteVgaIoBits(REG_CR99, pGfxDPASetting->DFPLow, 0x0F);
        break;
    case DISP_DI_DFP:
        viaWriteVgaIoBits(REG_CR97, pGfxDPASetting->DFPHigh, 0x0F);
        viaWriteVgaIoBits(REG_CR99, pGfxDPASetting->DFPLow, 0x0F);
        break;
    default:
        break;
    }
}

void
LoadUserGfxDPASetting(CARD32 port, ViaGfxDPAPtr pVal)
{
    switch (port) {
    case DISP_DI_DVP0:
        if (pVal->isClkPolarityUsed)
            viaWriteVgaIoBits(REG_CR96, pVal->clkPolarity << 3, BIT3);
        if (pVal->isClkAdjustUsed)
            viaWriteVgaIoBits(REG_CR96, pVal->clkAdjust, 0x07);
        if (pVal->isClkDrivingSelUsed) {
            /*pVal->clkDrivingSel[1:0],
             * Bit0's value is S0, bit1's value is S1 */
            viaWriteVgaIoBits(REG_SR1E, pVal->clkDrivingSel << 2, BIT2);
            viaWriteVgaIoBits(REG_SR2A, pVal->clkDrivingSel << 4, BIT4);
        }
        if (pVal->isDataDrivingSelUsed) {
            /*pVal->clkDrivingSel[1:0],
             * Bit0's value is S0, bit1's value is S1 */
            viaWriteVgaIoBits(REG_SR1B, pVal->dataDrivingSel << 1, BIT1);
            viaWriteVgaIoBits(REG_SR2A, pVal->dataDrivingSel << 5, BIT5);
        }
        break;
    case DISP_DI_DVP1:
        if (pVal->isClkPolarityUsed)
            viaWriteVgaIoBits(REG_CR9B, pVal->clkPolarity << 3, BIT3);
        if (pVal->isClkAdjustUsed)
            viaWriteVgaIoBits(REG_CR9B, pVal->clkAdjust, 0x07);
        if (pVal->isClkDrivingSelUsed)
            viaWriteVgaIoBits(REG_SR65, pVal->clkDrivingSel << 2, 0x0C);
        if (pVal->isDataDrivingSelUsed)
            viaWriteVgaIoBits(REG_SR65, pVal->dataDrivingSel, 0x03);
        break;
    case DISP_DI_DFPH:
        if (pVal->isClkPolarityUsed)
            viaWriteVgaIoBits(REG_CR97, pVal->clkPolarity << 3, BIT3);
        if (pVal->isClkAdjustUsed)
            viaWriteVgaIoBits(REG_CR97, pVal->clkAdjust, 0x07);
        break;
    case DISP_DI_DFPL:
        if (pVal->isClkPolarityUsed)
            viaWriteVgaIoBits(REG_CR99, pVal->clkPolarity << 3, BIT3);
        if (pVal->isClkAdjustUsed)
            viaWriteVgaIoBits(REG_CR99, pVal->clkAdjust, 0x07);
        break;
    case DISP_DI_DFP:
        if (pVal->isClkPolarityUsed) {
            viaWriteVgaIoBits(REG_CR97, pVal->clkPolarity << 3, BIT3);
            viaWriteVgaIoBits(REG_CR99, pVal->clkPolarity << 3, BIT3);
        }
        if (pVal->isClkAdjustUsed) {
            viaWriteVgaIoBits(REG_CR97, pVal->clkAdjust, 0x07);
            viaWriteVgaIoBits(REG_CR99, pVal->clkAdjust, 0x07);
        }
        break;
    default:
        break;
    }
}

/* Set lvds subchip DPA Setting*/
static void
LoadUserLvdsDPASetting(CARD32 subchipName, CARD32 serialPort,
    ViaLvdsDPAPtr pVal)
{
    switch (subchipName) {
    case SUBCHIP_VT1636:
        if (pVal->isVt1636ClkSelST1Used)
            viaSerialWriteByteMask(serialPort, SUBCHIP_VT1636_SLAVE_ADDR,
                0x09, pVal->Vt1636ClkSelST1, 0x1F);
        if (pVal->isVt1636ClkSelST2Used)
            viaSerialWriteByteMask(serialPort, SUBCHIP_VT1636_SLAVE_ADDR,
                0x08, pVal->Vt1636ClkSelST2, 0x0F);
        break;
    default:
        break;
    }
}

/*For LCD DPA. Compute clock range*/
static int
getClkRangeIndex(CARD32 Clk)
{
    if (Clk < DPA_CLK_30M) {
        return DPA_CLK_RANGE_30M;
    } else if ((DPA_CLK_30M < Clk) && (Clk < DPA_CLK_50M)) {
        return DPA_CLK_RANGE_30_50M;
    } else if ((DPA_CLK_50M < Clk) && (Clk < DPA_CLK_70M)) {
        return DPA_CLK_RANGE_50_70M;
    } else if ((DPA_CLK_70M < Clk) && (Clk < DPA_CLK_100M)) {
        return DPA_CLK_RANGE_70_100M;
    } else if ((DPA_CLK_100M < Clk) && (Clk < DPA_CLK_150M)) {
        return DPA_CLK_RANGE_100_150M;
    } else {
        return DPA_CLK_RANGE_150M;
    }
}

static void
loadLcdGfxDPA(CARD32 chipset, CARD32 subchipName, CARD32 port, CARD32 clock)
{
    int i, rangeIdx;
    GFX_DPA_INFO_TABLE_PTR pGfxDPAInfoTbl = NULL;
    GFX_DPA_VALUE_PTR pDPASettingValue = NULL;

    /* To find the record set according to chipset. */
    for (i = 0; i < NUM_GFX_DPA_TABLE; i++) {
        if (GFX_DPA_INDEX_TBL[i].ChipSet == chipset)
            break;
    }

    if (i == NUM_GFX_DPA_TABLE)
        return;
    rangeIdx = getClkRangeIndex(clock);

    switch (subchipName) {
    case SUBCHIP_VT1636:
        pGfxDPAInfoTbl = GFX_DPA_INDEX_TBL[i].pVT1636DPATbl;
        break;
    case SUBCHIP_HARDWIRED_LVDS:
    case SUBCHIP_TTL:
        pGfxDPAInfoTbl = GFX_DPA_INDEX_TBL[i].pHardwiredDPATbl;
        break;
    default:
        break;
    }

    if (pGfxDPAInfoTbl)
        pDPASettingValue = pGfxDPAInfoTbl[rangeIdx].pDPASettingValue;

    if (pDPASettingValue)
        setDPA(port, pDPASettingValue);
}

static void
loadLvdsTransmitterDPA(CARD32 chipset, CARD32 subchipName,
    CARD32 serialPort, CARD32 panelIndex)
{
    int i;
    TRANSMITTER_DPA_INFO_PTR pGfxDPAInfoTbl = NULL;
    CARD32 *pDPASetting = NULL;
    CARD8 index, data, mask;
    unsigned short slaveAddr = SUBCHIP_VT1636_SLAVE_ADDR;

    /* To find the record set according to chipset. */
    for (i = 0; i < NUM_TRANSMITTER_DPA_TABLE; i++) {
        if (TRANSMITTER_DPA_INDEX_TBL[i].ChipSet == chipset)
            break;
    }
    if (i == NUM_TRANSMITTER_DPA_TABLE)
        return;

    /* Find the desired DPA table according to the transmitter type. */
    switch (subchipName) {
    case SUBCHIP_VT1636:
        if (TRANSMITTER_DPA_INDEX_TBL[i].pVT1636DPATbl)
            pGfxDPAInfoTbl = TRANSMITTER_DPA_INDEX_TBL[i].pVT1636DPATbl;
        break;
    default:                   /* Table havn't defined. */
        break;
    }
    if (!pGfxDPAInfoTbl)
        return;

    /* Find the DPA setting value table according to the panel size. */
    while (pGfxDPAInfoTbl->Index != VIA_INVALID) {
        if (pGfxDPAInfoTbl->Index == panelIndex) {
            pDPASetting = pGfxDPAInfoTbl->pTransmitterDPASetting;
            break;
        }
        pGfxDPAInfoTbl++;
    }

    if (!pDPASetting)
        return;

    while (*pDPASetting != 0xFFFFFF) {
        index = (*pDPASetting) & 0xFF;
        mask = (*pDPASetting >> 8) & 0xFF;
        data = (*pDPASetting >> 16) & 0xFF;
        viaSerialWriteByteMask(serialPort, slaveAddr, index, data, mask);
        pDPASetting++;
    }
}

static void
loadLcdDefaultDPASetting(xf86OutputPtr output, CARD32 clock)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaLcdPrivateInfoPtr lcdInfo =
        (ViaLcdPrivateInfoPtr) (output->driver_private);
    CARD32 subchipName = lcdInfo->commonInfo.subChipName;
    CARD32 serialPort = lcdInfo->commonInfo.serialPort;
    CARD32 diPort = lcdInfo->commonInfo.diPort;
    CARD32 panelWidth = lcdInfo->commonInfo.physicalWidth;
    CARD32 panelHeigh = lcdInfo->commonInfo.physicalHeight;
    CARD32 panelIndex = VIA_MAKE_ID(panelWidth, panelHeigh);

    loadLcdGfxDPA(pVia->Chipset, subchipName, diPort, clock * 1000);
    loadLvdsTransmitterDPA(pVia->Chipset, subchipName, serialPort,
    panelIndex);
}

static void
loadTvGfxDPA(TV_DPA_TABLE_PTR pTvDPATable, CARD32 standard,
    CARD32 scan, CARD32 port)
{
    GFX_DPA_TVTYPE_MAP_TABLE_PTR pGfxDPATVTypeMapTable = NULL;
    GFX_DPA_TVSIZE_MAP_TABLE_PTR pGfxDPATVSizeMapTable = NULL;
    GFX_DPA_VALUE_PTR pDPASettingValue = NULL;

    if (!pTvDPATable)
        return;

    pGfxDPATVTypeMapTable = pTvDPATable->pGfxDPATVTypeMapTable;
    if (!pGfxDPATVTypeMapTable)
        return;

    /*Find TV scan map table according to standard */
    switch (standard) {
    case TV_STANDARD_NTSC:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->StdNTSC);
        break;
    case TV_STANDARD_PAL:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->StdPAL);
        break;
    case TV_STANDARD_480P:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->Std480p);
        break;
    case TV_STANDARD_576P:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->Std576P);
        break;
    case TV_STANDARD_720P:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->Std720p);
        break;
    case TV_STANDARD_1080I:
        pGfxDPATVSizeMapTable = &(pGfxDPATVTypeMapTable->Std1080i);
        break;
    default:
        break;
    }
    if (!pGfxDPATVSizeMapTable)
        return;

    /*Get the DPA table */
    switch (scan) {
    case TV_SCAN_NORMAL:
        pDPASettingValue = pGfxDPATVSizeMapTable->pNormalscan;
        break;
    case TV_SCAN_FIT:
        pDPASettingValue = pGfxDPATVSizeMapTable->pFitscan;
        break;
    case TV_SCAN_OVER:
        pDPASettingValue = pGfxDPATVSizeMapTable->pOverscan;
        break;
    default:
        break;
    }
    if (!pDPASettingValue)
        return;

    setDPA(port, pDPASettingValue);
}

static void
loadTvEncorderDPA(TV_DPA_TABLE_PTR pTvDPATable, CARD32 standard,
    CARD32 scan, CARD32 serialPort)
{
    TV_DPA_TVTYPE_MAP_TABLE_PTR pTVDPATVTypeMapTable = NULL;
    TV_DPA_TVSIZE_MAP_TABLE_PTR pTVDPATVSizeMapTable = NULL;
    CARD32 *pTVDPASettingValue = NULL;
    unsigned short slaveAddr = SUBCHIP_VT1625_SLAVE_ADDR;
    CARD8 index, data, mask;

    if (!pTvDPATable)
        return;

    pTVDPATVTypeMapTable = pTvDPATable->pTVDPATVTypeMapTable;
    if (!pTVDPATVTypeMapTable)
        return;

    /*Find TV scan map table according to standard */
    switch (standard) {
    case TV_STANDARD_NTSC:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->StdNTSC);
        break;
    case TV_STANDARD_PAL:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->StdPAL);
        break;
    case TV_STANDARD_480P:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->Std480p);
        break;
    case TV_STANDARD_576P:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->Std576P);
        break;
    case TV_STANDARD_720P:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->Std720p);
        break;
    case TV_STANDARD_1080I:
        pTVDPATVSizeMapTable = &(pTVDPATVTypeMapTable->Std1080i);
        break;
    default:
        break;
    }
    if (!pTVDPATVSizeMapTable)
        return;

    /*Get the DPA table */
    switch (scan) {
    case TV_SCAN_NORMAL:
        pTVDPASettingValue = pTVDPATVSizeMapTable->pNormalscan;
        break;
    case TV_SCAN_FIT:
        pTVDPASettingValue = pTVDPATVSizeMapTable->pFitscan;
        break;
    case TV_SCAN_OVER:
        pTVDPASettingValue = pTVDPATVSizeMapTable->pOverscan;
        break;
    default:
        break;
    }
    if (!pTVDPASettingValue)
        return;

    /*Write VT1625 register */
    while (*pTVDPASettingValue != 0xFFFFFFFF) {
        index = *pTVDPASettingValue & 0xFF;
        mask = (*pTVDPASettingValue >> 8) & 0xFF;
        data = (*pTVDPASettingValue >> 16) & 0xFF;
        viaSerialWriteByteMask(serialPort, slaveAddr, index, data, mask);
        pTVDPASettingValue++;
    }
}

void
loadTvDefaultDPASetting(xf86OutputPtr output, CARD32 chipset, CARD32 resIndex)
{
    int i;
    TV_DPA_TABLE_PTR pGfxDPAInfoTbl = NULL;
    ViaTvPrivateInfoPtr tvInfo =
    (ViaTvPrivateInfoPtr) (output->driver_private);
    CARD32 subchipName = tvInfo->commonInfo.subChipName;
    CARD32 diPort = tvInfo->commonInfo.diPort;
    CARD32 serialPort = tvInfo->commonInfo.serialPort;
    CARD32 standard = tvInfo->standard;
    CARD32 scan = tvInfo->scan;

    /* To find the record set according to chipset. */
    for (i = 0; i < NUM_GFX_DPA_TABLE; i++) {
        if (GFX_DPA_INDEX_TBL[i].ChipSet == chipset)
            break;
    }
    if (i == NUM_GFX_DPA_TABLE)
        return;

    /*Find VT1625 DPA table */
    switch (subchipName) {
    case SUBCHIP_VT1625:
        pGfxDPAInfoTbl = GFX_DPA_INDEX_TBL[i].pVT1625DPATbl;
        break;
    default:
        break;
    }
    if (pGfxDPAInfoTbl == NULL)
        return;

    /*Find TV standard map table according to resolution index */
    while (pGfxDPAInfoTbl->ModeIndex != VIA_INVALID) {
        if (pGfxDPAInfoTbl->ModeIndex == resIndex)
            break;
        pGfxDPAInfoTbl++;
    }
    if (pGfxDPAInfoTbl->ModeIndex == VIA_INVALID)
        return;

    /*1. Load Gfx DPA setting */
    loadTvGfxDPA(pGfxDPAInfoTbl, standard, scan, diPort);
    /*2. Load VT1625 TV encorder DPA setting */
    loadTvEncorderDPA(pGfxDPAInfoTbl, standard, scan, serialPort);
}

static void
patchDviDvp0DPA(CARD32 chipset, int modeH, int modeV)
{
    switch (chipset) {
    case VIA_P4M890:
        if ((modeH == 1600) && (modeV == 1200))
            viaWriteVgaIoBits(REG_CR96, 0x03, BIT0 + BIT1 + BIT2);
        else
            viaWriteVgaIoBits(REG_CR96, 0x07, BIT0 + BIT1 + BIT2);
        break;
    case VIA_P4M900:
        /* Validate by CN896(VT5943A-2), VN896(VT6363A1-2) */
        /* and P4M900(VT8450C/VT8450D). */
        viaWriteVgaIoBits(REG_CR96, 0x02, BIT0 + BIT1 + BIT2);
        break;
    default:
        break;
    }
}

static void
patchDviDvp1DPA(CARD32 chipset, CARD32 subChipName)
{
    switch (chipset) {
    case VIA_VX900:
        if (SUBCHIP_VT1632 == subChipName ||
            SUBCHIP_SIL164 == subChipName || SUBCHIP_CH7301 == subChipName)
            viaWriteVgaIoBits(REG_CR9B, 0x0A, 0x0F);
        break;
    default:
        break;
    }
}

static void
patchDviDfpLowDPA(CARD32 chipset)
{
    switch (chipset) {
    case VIA_K8M890:
        viaWriteVgaIoBits(REG_CR99, 0x03, BIT0 + BIT1);
        break;
    case VIA_P4M900:
        /* Validate by CN896(VT5943A-2), VN896(VT6363A1-2) */
        /* and P4M900(VT8450C/VT8450D). */
        viaWriteVgaIoBits(REG_CR99, 0x09, BIT0 + BIT1 + BIT2 + BIT3);
        break;
    case VIA_P4M890:
        viaWriteVgaIoBits(REG_CR99, 0x0F, BIT0 + BIT1 + BIT2 + BIT3);
        break;
    default:
        break;
    }
}

static void
loadDviDefaultDPASetting(CARD32 chipset, CARD32 port, DisplayModePtr mode,
    CARD32 subChipName)
{
    switch (port) {
    case DISP_DI_DVP0:
        patchDviDvp0DPA(chipset, mode->HDisplay, mode->VDisplay);
        break;
    case DISP_DI_DVP1:
        patchDviDvp1DPA(chipset, subChipName);
    case DISP_DI_DFPL:
        patchDviDfpLowDPA(chipset);
        break;
    default:
        break;
    }
}

xf86OutputStatus
vt1632_detect(CARD32 serialPort)
{
    CARD8 reg9;

    viaSerialReadByte(serialPort, SUBCHIP_VT1632_SLAVE_ADDR, 0x09, &reg9);
    if (reg9 & BIT2)
        return XF86OutputStatusConnected;
    else
        return XF86OutputStatusDisconnected;
}

static void
viaGetMonitorPhysicalSize(xf86MonPtr edidMon, CARD32 * phyW, CARD32 * phyH)
{
    CARD32 width = 0, height = 0;
    CARD32 i = 0;

    /* established timing */
    if (edidMon->timings1.t1 & 0xD0) {
        width = 720;
        height = 400;
    }
    if (edidMon->timings1.t1 & 0x3D) {
        width = 640;
        height = 480;
    }
    if (edidMon->timings1.t1 & 0x03) {
        width = 800;
        height = 600;
    }
    if (edidMon->timings1.t2 & 0xD0) {
        width = 800;
        height = 600;
    }
    if (edidMon->timings1.t2 & 0x20) {
        width = 832;
        height = 624;
    }
    if (edidMon->timings1.t2 & 0x1E) {
        width = 1024;
        height = 768;
    }
    if (edidMon->timings1.t2 & 0x01) {
        width = 1280;
        height = 1024;
    }

    /* standard timing */
    for (i = 0; i < STD_TIMINGS; i++) {
        if (edidMon->timings2[i].hsize > width)
            width = edidMon->timings2[i].hsize;
        if (edidMon->timings2[i].vsize > height)
            height = edidMon->timings2[i].vsize;
    }

    /* detail timing */
    for (i = 0; i < DET_TIMINGS; i++) {
        if (edidMon->det_mon[i].type == DT) {
            if (edidMon->det_mon[i].section.d_timings.h_active > width)
                width = edidMon->det_mon[i].section.d_timings.h_active;
            if (edidMon->det_mon[i].section.d_timings.v_active > height)
                height = edidMon->det_mon[i].section.d_timings.v_active;
        }
    }

    *phyW = width;
    *phyH = height;
}

void
viaSetIntegratedDVIMode(DisplayModePtr mode, CARD32 usedIga)
{
    /* 135MHz ~ 270MHz */
    if (mode->Clock >= 135000)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x00000000, 0xC0000000);
    /* 67.5MHz ~ <135MHz */
    else if (mode->Clock >= 67500)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x40000000, 0xC0000000);
    /* 33.75MHz ~ <67.5MHz */
    else if (mode->Clock >= 33750)
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x80000000, 0xC0000000);
    /* 25MHz ~ <33.75MHz */
    else
        MMIO_WR_MASK(DP_EPHY_PLL_REG, 0xC0000000, 0xC0000000);
    /* Power down TPLL to reset */
    MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x00000000, 0x06000000);
    /* Enable */
    MMIO_WR_MASK(DP_DATA_PASS_ENABLE_REG, 0x00000001, 0x00000001);
    /* Select EPHY as HDMI mode */
    MMIO_WR_MASK(DP_EPHY_MISC_PWR_REG, 0, BIT0);
    /* Enable HDMI with DVI mode */
    MMIO_WR_MASK(0xC280, 0x40, 0x40);
    /* select AC mode */
    MMIO_WR_MASK(0xC74C, 0x40, 0x40);
    /* Set status of Lane0~3 */
    MMIO_WR_MASK(0xC744, 0x00FFFF00, 0x00FFFF00);
    /* Disable InfoFrame */
    MMIO_WR_MASK(0xC284, 0x00000000, 0x00000002);
    /* EPHY Control Register */
    MMIO_WR_MASK(DP_EPHY_PLL_REG, 0x1EC46E6F, 0x3FFFFFFF);
    /* Select PHY Function as HDMI */
    viaWriteVgaIoBits(REG_CRFF, BIT0, BIT0);
    /* Select HDTV0 source */
    if (usedIga == IGA1)
        viaWriteVgaIoBits(REG_CRFF, 0, BIT1);
    else
        viaWriteVgaIoBits(REG_CRFF, BIT1, BIT1);

    /* in 640x480 case, MPLL is different */
    /* For VT3410 internal transmitter 640x480 issue */
    if (mode->HDisplay == 640 && mode->VDisplay == 480) {
        MMIO_WR(DP_EPHY_PLL_REG, 0xD8C29E6F);
        MMIO_WR(DP_EPHY_PLL_REG, 0xDEC29E6F);
    }
}

static Bool
viaDetectDeviceByReadEdid(xf86OutputPtr output, CARD8 deviceType)
{
    ScrnInfoPtr pScrn = output->scrn;
    Bool result = FALSE;
    ViaCrtPrivateInfoPtr viaDeviceInfo = output->driver_private;
    CARD8 edidHeader[2], inputType, i;

    if (DISP_DEFAULT_SETTING == viaDeviceInfo->commonInfo.ddcPort) {
        for (i = 0; i < NUM_SERIAL_PORT; i++) {
            
            /* Ensure if EDID exists. Check first 2 bytes of EDID header */
            if (TRUE == serialPortTable[i].isFree) {
                if (viaSerialReadBytes(serialPortTable[i].serialPort, 0xA0, 0,
                    edidHeader, 2)) {
                    if ((edidHeader[0] == 0x00) && (edidHeader[1] == 0xFF)) {
                         
                        /* Check input type of EDID. EDID byte 20 bit 7 is input type:
                         * 0:analog, 1:digital
                         * VGA: analog input
                         * LCD/DVI: digital input */
                        if (viaSerialReadByte(serialPortTable[i].serialPort,
                            0xA0, 20, &inputType)) {
                            inputType = (inputType & 0x80) >> 7;
                            if (inputType == deviceType) {
                                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                                    "== Detect monitor %s ==\n",
                                    output->name);
                                viaDeviceInfo->commonInfo.ddcPort =
                                    serialPortTable[i].serialPort;
                                serialPortTable[i].isFree = FALSE;
                                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                                    "%s has occupied the ddcport: 0x%x \n",
                                    output->name,
                                    (unsigned int)(serialPortTable[i].
                                    serialPort));
                                result = TRUE;
                                break;
                            }
                        }
                    }
                }
            }
        }
    } else {
         
        /* Ensure if EDID exists. Check first 2 bytes of EDID header */
        viaSerialReadBytes(viaDeviceInfo->commonInfo.ddcPort, 0xA0, 0,
            edidHeader, 2);
        if ((edidHeader[0] == 0x00) && (edidHeader[1] == 0xFF)) {
             
            /* Check input type of EDID. EDID byte 20 bit 7 is input type:
             * 0:analog, 1:digital
             * VGA: analog input
             * LCD/DVI: digital input */
            viaSerialReadByte(viaDeviceInfo->commonInfo.ddcPort, 0xA0, 20,
                &inputType);
            inputType = (inputType & 0x80) >> 7;
            if (inputType == deviceType) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "== Detect monitor %s ==\n", output->name);
                result = TRUE;
            }
        }
    }

    return result;
}

/* ====================================================*/
/*                  Output Callback Functions          */
/* ====================================================*/
/*****************************************************/
/*                    CRT                            */
/*****************************************************/
/*
* Saves the crtc's state for restoration on VT switch.

static void
via_crt_save (xf86OutputPtr output)
{
}
*/
/*
* Restore's the crtc's state at VT switch.

static void
via_crt_restore (xf86OutputPtr output)
{
}
*/
static void
via_crt_destroy(xf86OutputPtr output)
{
    ViaCrtPrivateInfoPtr viaCrtInfo = output->driver_private;

    if (viaCrtInfo != NULL) {
        if (viaCrtInfo->commonInfo.rawEDID != NULL) {
            free(viaCrtInfo->commonInfo.rawEDID);
        }
        free(viaCrtInfo);
    }
    output->driver_private = NULL;
}

/*
* switch the level of DPMS. we should turn on/off the device in this function.
*/
static void
via_crt_dpms(xf86OutputPtr output, int mode)
{
    DEBUG(ErrorF("via_crt_dpms, mode = %d\n", mode));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaCrtPrivateInfoPtr viaCrtInfo =
    (ViaCrtPrivateInfoPtr) (output->driver_private);
    CARD32 serialPort = viaCrtInfo->commonInfo.serialPort;
    CARD32 diPort = viaCrtInfo->commonInfo.diPort;
    CARD32 subChipName = viaCrtInfo->commonInfo.subChipName;
    CARD32 subChipSlaveAddr = viaCrtInfo->commonInfo.slaveAddress;

    /*  assign usedIga value in dpms on, because when dpms off, output->crtc may be NULL */
    int usedIga;

    /* Clear DPMS setting ?? */
    switch (mode) {
    case DPMSModeOn:
        usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;
        if (NONE_SUBCHIP == subChipName) {
            switch (usedIga) {
            case IGA1:
                viaWriteVgaIoBits(REG_SR16, 0x00, BIT6);
                break;
            case IGA2:
                viaWriteVgaIoBits(REG_SR16, 0x40, BIT6);
                break;
            }
            viaWriteVgaIoBits(REG_CR36, 0x00, BIT4 + BIT5);
        } else if (SUBCHIP_VT1625 == subChipName) {
            /*Set DAC as CRT */
            viaSerialWriteByteMask(serialPort, SUBCHIP_VT1625_SLAVE_ADDR,
                0x1C, 0x20, BIT5);
            /*Set output path information */
            viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga,
                pVia->Chipset);
        } else if (SUBCHIP_CH7301 == subChipName) {
            if (ch7301_module_loaded) {
                viaCrtEnableCh7301(serialPort, subChipSlaveAddr);
                /*Set output path information */
                viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga,
                    pVia->Chipset);
            }
        }
        break;

    case DPMSModeStandby:           /* 1 */
    case DPMSModeSuspend:           /* 2 */
    case DPMSModeOff:               /* 3 */
        if (NONE_SUBCHIP == subChipName) {
            viaWriteVgaIoBits(REG_CR36, BIT5 + BIT4, BIT5 + BIT4);
            /*Reset CRT source to IGA1 */
            viaWriteVgaIoBits(REG_SR16, 0x00, BIT6);
        } else if (SUBCHIP_VT1625 == subChipName) {
            /*Reset DAC as TV */
            viaSerialWriteByteMask(serialPort, SUBCHIP_VT1625_SLAVE_ADDR,
                0x1C, 0x00, BIT5);
        } else if (SUBCHIP_CH7301 == subChipName) {
            if (ch7301_module_loaded) {
                viaCrtDisableCh7301(serialPort, subChipSlaveAddr);
            }
        }
        /*Turn off DI port clk */
        viaDIPortPadOff(pScrn->scrnIndex, diPort);
        break;

    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

static void
via_crt_mode_set(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaCrtPrivateInfoPtr viaCrtInfo =
        (ViaCrtPrivateInfoPtr) (output->driver_private);
    CARD32 serialPort = viaCrtInfo->commonInfo.serialPort;
    CARD32 diPort = viaCrtInfo->commonInfo.diPort;
    CARD32 subChipName = viaCrtInfo->commonInfo.subChipName;
    CARD32 subChipSlaveAddr = viaCrtInfo->commonInfo.slaveAddress;

    if (SUBCHIP_VT1625 == subChipName) {
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x00, 0x03);
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x02, 0xA0);
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x0E, 0x38);
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x1C, 0x20);
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x1E, 0x40);
        /* do sw reset */
        viaSerialWriteByte(serialPort, SUBCHIP_VT1625_SLAVE_ADDR, 0x1D, 0x80);
    } else if (SUBCHIP_CH7301 == subChipName) {
        if (ch7301_module_loaded) {
            viaCrtInitCh7301(serialPort, subChipSlaveAddr,
            adjusted_mode->Clock, pVia);
        }
    }
    /* update sync polarity */
    setDiportSyncPolarity(pScrn->scrnIndex, diPort, adjusted_mode);

    /*Patch for clock skew */
    loadCrtDefaultDPASetting(pVia->Chipset, diPort, subChipName);
    LoadUserGfxDPASetting(diPort, &viaCrtInfo->userGfxDPA);
}

/* To detect if the device is connect. */
static xf86OutputStatus
via_crt_detect(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_crt_detect\n"));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputStatus status = XF86OutputStatusDisconnected;
    Bool result = FALSE;
    ViaCrtPrivateInfoPtr viaCrtInfo = output->driver_private;
    CARD32 serialPort = viaCrtInfo->commonInfo.serialPort;
    CARD32 subChipSlaveAddr = viaCrtInfo->commonInfo.slaveAddress;

    /* CRT detect first read EDID, if can't get EDID,detect vsync */
    if (!viaCrtInfo->commonInfo.NoDDCValue) {
        result = viaDetectDeviceByReadEdid(output, ANALOG_DEVICE);
    }

    if (result) {
        status = XF86OutputStatusConnected;
    } else {
        switch (viaCrtInfo->commonInfo.subChipName) {
        case NONE_SUBCHIP:
            status = viaDetectCRTVsync(pVia);
            break;
        case SUBCHIP_CH7301:
            if (ch7301_module_loaded) {
                status = viaCrtDetectCh7301(serialPort, subChipSlaveAddr);
                if (XF86OutputStatusConnected == status) {
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "detect CRT device on CH7301 card! \n");
                }
            }
            break;
        case SUBCHIP_VT1625:
            break;
        default:
            break;
        }
    }
    return status;
}

static void
via_crt_prepare(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOff);
}

static void
via_crt_commit(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOn);
}

static DisplayModePtr
via_crt_get_modes(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_crt_get_modes\n"));
    ScrnInfoPtr pScrn = output->scrn;
    DisplayModePtr modes = NULL;
    xf86MonPtr edid_mon;
    ViaCrtPrivateInfoPtr viaCrtInfo = output->driver_private;

    /* if "NoDDCValue", set physical size as 4096x2048,
     * now, only support mode from modeline and xorg build-in */
    if (output->MonInfo != NULL)
        free(output->MonInfo);
    output->MonInfo = NULL;

    if (!viaCrtInfo->commonInfo.NoDDCValue) {
        if (viaCrtInfo->commonInfo.rawEDID == NULL) {
            viaCrtInfo->commonInfo.rawEDID =
            calloc(1, sizeof(unsigned char) * (128));
            viaSerialReadBytes(viaCrtInfo->commonInfo.ddcPort, 0xA0, 0,
                viaCrtInfo->commonInfo.rawEDID, 128);
        }

        /* Parse the EDID block */
        if ((viaCrtInfo->commonInfo.rawEDID[0] == 0x00) &&
            (viaCrtInfo->commonInfo.rawEDID[1] == 0xFF)) {

            edid_mon =
                xf86InterpretEDID(pScrn->scrnIndex,
            viaCrtInfo->commonInfo.rawEDID);
            if (edid_mon) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "== EDID of monitor %s ==\n", output->name);
                xf86PrintEDID(edid_mon);
                xf86OutputSetEDID(output, edid_mon);
                modes = xf86OutputGetEDIDModes(output);
            }
        }
    }

    /* return a mode list, not a single mode */
    return modes;
}

/*
 * To check whether the input mode is supported of not in our driver.
 */
static int
via_crt_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    /* Check Clock Range */
    if (mode->Clock > 400000)
        return MODE_CLOCK_HIGH;
    if (mode->Clock < 25000)
        return MODE_CLOCK_LOW;

    /* Check Resolution Range */
    if (IsValidMode(mode->HDisplay, mode->VDisplay) == 0)
        return MODE_BAD;
    return MODE_OK;
}

/* To fix up the input mode */
static Bool
via_crt_mode_fixup(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    return TRUE;
}

static const xf86OutputFuncsRec via_crt_output_funcs = {
    .dpms = via_crt_dpms,
    .save = NULL,
    .restore = NULL,
    .mode_valid = via_crt_mode_valid,
    .mode_fixup = via_crt_mode_fixup,
    .prepare = via_crt_prepare,
    .mode_set = via_crt_mode_set,
    .commit = via_crt_commit,
    .detect = via_crt_detect,
    .get_modes = via_crt_get_modes,
    .destroy = via_crt_destroy,
};

/*****************************************************/
/*                    LCD                              */
/*****************************************************/
/* Create a device dependent properties */
static void
via_lvds_create_resources(xf86OutputPtr output)
{
    ScrnInfoPtr pScrn = output->scrn;
    CARD32 centering =
    ((ViaLcdPrivateInfoPtr) (output->driver_private))->center;
    int err, i;

    /*Now we only support one LCD dynamic change feature: Centering or not Centering */

    /* Set up the Lcd_centering property, which takes effect on mode set
     * and accepts strings that match exactly
     */
    lcd_centering_atom = MakeAtom(LCD_CENTERING_NAME,
    sizeof(LCD_CENTERING_NAME) - 1, TRUE);

    for (i = 0; i < LCD_CENTERING_NUM; i++) {
        lcd_centering_name_atoms[i] = MakeAtom(lcd_centering_names[i],
            strlen(lcd_centering_names[i]), TRUE);
    }

    err = RRConfigureOutputProperty(output->randr_output, lcd_centering_atom,
        TRUE, FALSE, FALSE,
        LCD_CENTERING_NUM, (INT32 *) lcd_centering_name_atoms);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "RRConfigureOutputProperty error, %d\n", err);
    }

    err = RRChangeOutputProperty(output->randr_output, lcd_centering_atom,
        XA_ATOM, 32, PropModeReplace, 1,
        &lcd_centering_name_atoms[centering], FALSE, TRUE);
    if (err != 0) {
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
            "failed to set panel fitting mode, %d\n", err);
    }
}

static Bool
via_lvds_set_property(xf86OutputPtr output, Atom property,
    RRPropertyValuePtr value)
{
    DEBUG(ErrorF("via_lvds_set_property\n"));
    ScrnInfoPtr pScrn = output->scrn;
    ViaLcdPrivateInfoPtr viaLcdInfo = output->driver_private;
    Atom atom;
    const char *name;
    int center = -1;

    if (lcd_centering_atom == property) {
        if (value->type != XA_ATOM || value->format != 32 || value->size != 1) {
            return FALSE;
        }

        memcpy(&atom, value->data, 4);
        name = NameForAtom(atom);

        if (!xf86NameCmp(name, lcd_centering_names[0])) {
            DEBUG(ErrorF("Apply expand\n"));
            center = FALSE;
        }

        if (!xf86NameCmp(name, lcd_centering_names[1])) {
            DEBUG(ErrorF("Apply center\n"));
            center = TRUE;
        }

        if (center < 0) {
            return FALSE;
        }

        if (viaLcdInfo->center == center) {
            return TRUE;
        }

        viaLcdInfo->center = center;

        /*Note:Xorg call xf86CrtcSetMode when we set property if the property is Atom
         * so we needn't do it here.But now I am not very sure of it, so I still do it here.
         * Need TODO */
        if (output->crtc) {
            xf86CrtcPtr crtc = output->crtc;

            if (crtc->enabled) {
                if (!xf86CrtcSetMode(crtc, &crtc->desiredMode,
                    crtc->desiredRotation,
                    crtc->desiredX, crtc->desiredY)) {
                    xf86DrvMsg(pScrn->scrnIndex, X_ERROR,
                        "Failed to set mode after panel fitting change!\n");
                    return FALSE;
                }
            }
        }
    }
    return TRUE;
}

static void
via_lvds_dpms(xf86OutputPtr output, int mode)
{
    DEBUG(ErrorF("via_lvds_dpms, mode = %d\n", mode));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    int usedIga;
    ViaOutputInfo commonInfo =
        ((ViaLcdPrivateInfoPtr) (output->driver_private))->commonInfo;
    CARD32 panelSizeId =
        ((ViaLcdPrivateInfoPtr) (output->driver_private))->panelIndex;
    CARD32 serialPort = commonInfo.serialPort;
    CARD32 subChipName = commonInfo.subChipName;
    CARD32 diPort = commonInfo.diPort;
    BOOL dualChannel =
        ((ViaLcdPrivateInfoPtr) (output->driver_private))->dualChannel;

    /*if the panel is swg panel, we need a panelSizeId to set power sequence */
    if (!panelSizeId) {
        panelSizeId = VIA_MAKE_ID(commonInfo.physicalHeight,
            commonInfo.physicalWidth);
    }

    switch (mode) {
    case DPMSModeOn:
        usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;

        /*when using the EPIA-EX board, if we do not set this bit, light LCD will failed
         * in nonRandR structure, when light LCD this bit is always setted, but I don't know
         * why, here need TODO*/
        viaWriteVgaIoBits(REG_CR6A, 0x08, BIT3);

        /*1. Turn on DI port clock, set Iga source for DI port */
        if (diPort)
            viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga,
                pVia->Chipset);

        /*2. Enable spread spectrum */
        if (pVia->pChipInfo->biosIsSpreadSpectrum) {
            if ((pVia->Chipset == VIA_CX700) ||
                (pVia->Chipset == VIA_VX800) ||
                (pVia->Chipset == VIA_VX855) ||
                (pVia->Chipset == VIA_VX900)) {
                /* GPIO-4/5 are used for spread spectrum, we must clear
                 * SR3D[7:6] to disable GPIO-4/5 output */
                viaWriteVgaIoBits(REG_SR3D, 0x01, 0xC1);
            } else {
                viaWriteVgaIoBits(REG_SR2C, 0x01, BIT0);
            }
                viaWriteVgaIoBits(REG_SR1E, 0x08, BIT3);
        }

        /*3. Enable LVDS transmitter */
        if (SUBCHIP_INTEGRATED_LVDS == subChipName) {
            enableInternalLvds(pVia, diPort, panelSizeId, dualChannel);
        } else if (SUBCHIP_VT1636 == subChipName) {
            enableLcdViaVt1636(serialPort);
        } else if (SUBCHIP_TTL == subChipName) {

            if (pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) {
                /* For 409, 410 18bit TTL panel */
                viaWriteVgaIoBits(REG_CRF3, 0x80, BIT7);
                /* Power on LVDS channel. */
                viaWriteVgaIoBits(REG_CRD2, 0x00, BIT6 + BIT7);
                /*Enable LCD */
                viaWriteVgaIoBits(REG_CR6A, 0x08, BIT3);
            } else {
                viaWriteVgaIoBits(REG_CRF3, 0x80, BIT7);
                /* Power on LVDS channel. */
                viaWriteVgaIoBits(REG_CRD2, 0x00, BIT7);

                /* Software control Power Sequence */
                ttlLcdPowerSequenceOn(pVia);
            }
        } else {
            /*Hw wired Lcd */
            /*Turn on display period in the panel path(LCD only), turn on back light */
            viaWriteVgaIoBits(REG_CR91, 0x00, BIT6 + BIT7);
            /*Enable LCD */
            viaWriteVgaIoBits(REG_CR6A, 0x08, BIT3);
        }
        break;

    case DPMSModeStandby:
    case DPMSModeSuspend:
    case DPMSModeOff:
        /*1.Disable spread spectrum, we put it to crtc DPMSModeOff */

        /*2.Disable LVDS transmitter and turn off panel */
        if (SUBCHIP_INTEGRATED_LVDS == subChipName) {
            disableInternalLvds(pVia, diPort, panelSizeId, dualChannel);
        } else if (SUBCHIP_VT1636 == subChipName) {
            disableLcdViaVt1636(serialPort);
        } else if (SUBCHIP_TTL == subChipName) {
            if (pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) {
                /*Turn off display period in the panel path(LCD only), turn off back light */
                viaWriteVgaIoBits(REG_CR91, 0xC0, BIT6 + BIT7);
                /*Disable LCD */
                viaWriteVgaIoBits(REG_CR6A, 0x00, BIT3);
            } else {
                ttlLCDPowerSequenceOff(pVia);
                /* Power off LVDS channel. */
                viaWriteVgaIoBits(REG_CRD2, 0x80, BIT7);
            }
        } else {
            /*Hw wired Lcd */
            /*Turn off display period in the panel path(LCD only), turn off back light */
            viaWriteVgaIoBits(REG_CR91, 0xC0, BIT6 + BIT7);
            /*Disable LCD */
            viaWriteVgaIoBits(REG_CR6A, 0x00, BIT3);
        }

        /* 4. Turn off DI port clk */
        viaDIPortPadOff(pScrn->scrnIndex, diPort);
        break;

    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

/*
* Saves the lvds's state for restoration on VT switch.

static void
via_lvds_save (xf86OutputPtr output)
{

}
*/
/*
* Restore's the lvds's state at VT switch.

static void
via_lvds_restore (xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    VIAPtr                     pVia = VIAPTR(pScrn);

    if (pVia->pChipInfo->biosActiveDev & VIA_DEVICE_LCD) {
        via_lvds_dpms(output, DPMSModeOn);
    }
}
*/
/*
 * Callback for testing a video mode for a given output.
 *
 * This function should only check for cases where a mode can't be supported
 * on the pipe specifically, and not represent generic CRTC limitations.
 *
 * return MODE_OK if the mode is valid, or another MODE_* otherwise.
 */
static int
via_lvds_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaOutputInfo commonInfo =
        ((ViaLcdPrivateInfoPtr) (output->driver_private))->commonInfo;
    if (!memcmp(mode->name, "PanelMode", 9)) {
        mode->type |= M_T_PREFERRED;
        return MODE_OK;
    }

    if (commonInfo.physicalWidth && commonInfo.physicalHeight) {
        /*Don't support mode larger than physical size */
        if (pVia->Chipset != VIA_VX900) {
            if (mode->HDisplay > commonInfo.physicalWidth)
                return MODE_PANEL;
            if (mode->VDisplay > commonInfo.physicalHeight)
                return MODE_PANEL;
        } else {
            /* HW limitation 410 only can do <= 1.33 scaling */
            if (mode->HDisplay > commonInfo.physicalWidth * 1.33)
                return MODE_PANEL;
            if (mode->VDisplay > commonInfo.physicalHeight * 1.33)
                return MODE_PANEL;
            /* Now we can not support H V different scale */
            if ((mode->HDisplay > commonInfo.physicalWidth) &&
                (mode->VDisplay < commonInfo.physicalHeight))
                return MODE_PANEL;
            if ((mode->HDisplay < commonInfo.physicalWidth) &&
                (mode->VDisplay > commonInfo.physicalHeight))
                return MODE_PANEL;
        }
    }

    return MODE_OK;
}

static Bool
via_lvds_mode_fixup(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    VIACrtcPrivatePtr crtcPriv = VIACrtcPrivate(output->crtc);
    CARD32 usedIga = crtcPriv->iga;
    ViaLcdPrivateInfoPtr lcdPriv =
        (ViaLcdPrivateInfoPtr) (output->driver_private);
    CARD32 isCenter = lcdPriv->center;
    CARD32 panelWidth = lcdPriv->commonInfo.physicalWidth;
    CARD32 panelHeight = lcdPriv->commonInfo.physicalHeight;

    /*initial igastatus */
    crtcPriv->igastatus = 0;

    /*If mode is equal to panel physical size, don't change it
     * Maybe we should discuss it! */
    if ((mode->HDisplay != panelWidth) || (mode->VDisplay != panelHeight)) {

        if (lcdPriv->confMode) {
            memcpy(adjusted_mode, lcdPriv->confMode, sizeof(DisplayModeRec));
        } else {
            /*Get build-in timing */
            ViaTimingTablePtr panelCrtcTable = NULL;

            panelCrtcTable =
            getDriverTiming(LCD_MODE_TABLE, lcdPriv->panelIndex);
            if (!panelCrtcTable)
                return FALSE;

            fillModeByDriverTiming(panelCrtcTable, adjusted_mode);
        }

        xf86SetModeCrtc(adjusted_mode, 0);
        /*Take care of 410 downscaling */
        if ((mode->HDisplay > panelWidth) || (mode->VDisplay > panelHeight)) {
            if ((usedIga == IGA2) && (g_ChipCaps & CAPS_IGA2_DOWNSCALING)) {
                crtcPriv->igastatus = VIA_SCALING_HW;
            } else if ((usedIga == IGA1)
                && (g_ChipCaps & CAPS_IGA1_DOWNSCALING)) {
                crtcPriv->igastatus = VIA_SCALING_HW;
            } else
                DEBUG(ErrorF("Error mode! This mode should be filtered.\n"));
        } else {
            if (isCenter)
                /*Do centering according to mode and adjusted_mode */
                centeringTiming(mode, adjusted_mode);
            else {
                /* UpScaling */
                if ((usedIga & IGA1) && (g_ChipCaps & CAPS_IGA1_EXPAND) == 0)
                    centeringTiming(mode, adjusted_mode);
                else {
                    if (mode->HDisplay < panelWidth)
                        crtcPriv->igastatus |= VIA_HOR_EXPAND;
                    if (mode->VDisplay < panelHeight)
                        crtcPriv->igastatus |= VIA_VER_EXPAND;

                }
            }
        }
    }

    return TRUE;
}

static void
via_lvds_mode_set(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ViaLcdPrivateInfoPtr lcdPriv =
        (ViaLcdPrivateInfoPtr) (output->driver_private);
    CARD32 diPort = lcdPriv->commonInfo.diPort;
    CARD32 subchipName = lcdPriv->commonInfo.subChipName;
    CARD32 serialPort = lcdPriv->commonInfo.serialPort;

    /*Patch for clock skew */
    loadLcdDefaultDPASetting(output, adjusted_mode->Clock);
    LoadUserGfxDPASetting(diPort, &lcdPriv->userGfxDPA);
    LoadUserLvdsDPASetting(subchipName, serialPort, &lcdPriv->userLvdsDPA);
}

static xf86OutputStatus
via_lvds_detect(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_lvds_detect\n"));
    ViaLcdPrivateInfoPtr viaLcdInfo =
        (ViaLcdPrivateInfoPtr) output->driver_private;
    CARD32 panelSizeId = viaLcdInfo->panelIndex;
    xf86OutputStatus status = XF86OutputStatusDisconnected;

    /**
     * if users set panelSizeId, we consider the lcd has no EDID
     * if users don't set panelSizeId, we consider the lcd is SPWG panel.
     */
    if (panelSizeId) {
        return XF86OutputStatusConnected;
    } else {
        if (TRUE == viaDetectDeviceByReadEdid(output, DIGITER_DEVICE)) {
            return XF86OutputStatusConnected;
        }
    }
    return status;
}

static void
via_lvds_destroy(xf86OutputPtr output)
{
    ViaLcdPrivateInfoPtr viaLcdInfo = output->driver_private;

    if (viaLcdInfo != NULL) {
        if (viaLcdInfo->commonInfo.rawEDID != NULL) {
            free(viaLcdInfo->commonInfo.rawEDID);
        }
        free(viaLcdInfo);
    }
    output->driver_private = NULL;
}

static void
via_lvds_prepare(xf86OutputPtr output)
{
    via_lvds_dpms(output, DPMSModeOff);
}

static void
via_lvds_commit(xf86OutputPtr output)
{
    via_lvds_dpms(output, DPMSModeOn);
}

static DisplayModePtr
via_lvds_get_modes(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_lvds_get_modes\n"));
    ScrnInfoPtr pScrn = output->scrn;
    DisplayModePtr modes = NULL;
    xf86MonPtr edid_mon = NULL;
    ViaLcdPrivateInfoPtr viaLcdInfo = output->driver_private;

    if (output->MonInfo != NULL)
        free(output->MonInfo);
    output->MonInfo = NULL;

    if (viaLcdInfo->confMode) {
        edid_mon = calloc(1, sizeof(xf86Monitor));
        if (edid_mon) {
            /* Set wide sync ranges so we get all modes
             * handed to valid_mode for checking
             */
            edid_mon->det_mon[0].type = DS_RANGES;
            edid_mon->det_mon[0].section.ranges.min_v = 0;
            edid_mon->det_mon[0].section.ranges.max_v = 200;
            edid_mon->det_mon[0].section.ranges.min_h = 0;
            edid_mon->det_mon[0].section.ranges.max_h = 200;

            output->MonInfo = edid_mon;
        }
        return NULL;
    }

    /* if users set panelIndex, we add the related buildin mode timing to xorg */
    if (viaLcdInfo->panelIndex) {
        modes = viaGetPanelModeRecord(pScrn, viaLcdInfo->panelIndex);
    } else {
        if (viaLcdInfo->commonInfo.rawEDID == NULL) {
            viaLcdInfo->commonInfo.rawEDID =
                calloc(1, sizeof(unsigned char) * (128));
            viaSerialReadBytes(viaLcdInfo->commonInfo.ddcPort, 0xA0, 0,
                viaLcdInfo->commonInfo.rawEDID, 128);
        }

        /* Parse the EDID block */
        if ((viaLcdInfo->commonInfo.rawEDID[0] == 0x00) &&
            (viaLcdInfo->commonInfo.rawEDID[1] == 0xFF)) {

            edid_mon =
                xf86InterpretEDID(pScrn->scrnIndex,
                viaLcdInfo->commonInfo.rawEDID);
            if (edid_mon) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "== EDID of monitor %s ==\n", output->name);
                xf86PrintEDID(edid_mon);
                /*how to get physicalWidth and physicalHeight of LCD */
                viaGetMonitorPhysicalSize(edid_mon,
                    &viaLcdInfo->commonInfo.physicalWidth,
                    &viaLcdInfo->commonInfo.physicalHeight);
                viaLcdInfo->panelIndex =
                    VIA_MAKE_ID(viaLcdInfo->commonInfo.physicalWidth,
                    viaLcdInfo->commonInfo.physicalHeight);
                xf86OutputSetEDID(output, edid_mon);
                modes = xf86OutputGetEDIDModes(output);
            }
        }
    }

    if (!output->MonInfo) {
        edid_mon = calloc(1, sizeof(xf86Monitor));
        if (edid_mon) {
            /*defaultly display support continuous-freqencey
             * if the parameter is not set, the xorg build in modes will not add,
             * then lcd do not have edid, will have only one valid mode */
            edid_mon->features.msc |= 0x1;
            /* Set wide sync ranges so we get all modes
             * handed to valid_mode for checking
             */
            edid_mon->det_mon[0].type = DS_RANGES;
            edid_mon->det_mon[0].section.ranges.min_v = 0;
            edid_mon->det_mon[0].section.ranges.max_v = 200;
            edid_mon->det_mon[0].section.ranges.min_h = 0;
            edid_mon->det_mon[0].section.ranges.max_h = 200;

            output->MonInfo = edid_mon;
        }
    }

    /* return a mode list, not a single mode */
    return modes;
}

static const xf86OutputFuncsRec via_lvds_output_funcs = {
    .create_resources = via_lvds_create_resources,
    .set_property = via_lvds_set_property,
    .dpms = via_lvds_dpms,
    .save = NULL,
    .restore = NULL,
    .mode_valid = via_lvds_mode_valid,
    .mode_fixup = via_lvds_mode_fixup,
    .prepare = via_lvds_prepare,
    .mode_set = via_lvds_mode_set,
    .commit = via_lvds_commit,
    .detect = via_lvds_detect,
    .get_modes = via_lvds_get_modes,
    .destroy = via_lvds_destroy,
};

/*****************************************************/
/*                    DVI                              */
/*****************************************************/

static void
via_tmds_dpms(xf86OutputPtr output, int mode)
{
    DEBUG(ErrorF("via_tmds_dpms, mode = %d\n", mode));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    int usedIga;
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;
    CARD32 serialPort = viaDviInfo->commonInfo.serialPort;
    CARD32 subChipName = viaDviInfo->commonInfo.subChipName;
    CARD32 diPort = viaDviInfo->commonInfo.diPort;
    CARD32 subChipSlaveAddr = viaDviInfo->commonInfo.slaveAddress;

    switch (mode) {
    case DPMSModeOn:
        usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;
        if (NONE_SUBCHIP == subChipName)
            return;

        /*1. Turn on DI port clock, set Iga source for DI port */
        viaSetOutputPath(pScrn->scrnIndex, diPort, usedIga, pVia->Chipset);
        /*2. Enable TMDS transmitter */
        if (SUBCHIP_VT1632 == subChipName) {
            /*Power on Vt1632 */
            viaSerialWriteByte(serialPort, SUBCHIP_VT1632_SLAVE_ADDR,
                0x08, 0x3B);
        } else if (SUBCHIP_INTEGRATED_TMDS == subChipName) {
            /*Internal TMDS only use DFP_L */
            /*Turn on DVI panel path(Only for internal), otherwise,
             * the screen of DVI will be black. */
            viaWriteVgaIoBits(REG_CR91, 0x00, BIT7);
            /*Power on TMDS */
            viaWriteVgaIoBits(REG_CRD2, 0x00, BIT3);
        } else if (SUBCHIP_SIL164 == subChipName) {
            if (sil164_module_loaded) {
                sil164_dpms(serialPort, mode);
            }
        } else if (SUBCHIP_CH7301 == subChipName) {
            if (ch7301_module_loaded) {
                viaTmdsEnableCh7301(serialPort, subChipSlaveAddr);
            }
        } else if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            /* Enable HDMI */
            MMIO_WR_MASK(0xC280, 0x02, 0x02);
        }
        break;

    case DPMSModeStandby:           /* 1 */
    case DPMSModeSuspend:           /* 2 */
    case DPMSModeOff:               /* 3 */
        if (NONE_SUBCHIP == subChipName)
            return;

        if (SUBCHIP_VT1632 == subChipName) {
            /*Power on Vt1632 */
            viaSerialWriteByteMask(serialPort,
                SUBCHIP_VT1632_SLAVE_ADDR, 0x08, 0x00, BIT0);
        } else if (SUBCHIP_INTEGRATED_TMDS == subChipName) {
            viaWriteVgaIoBits(REG_CR91, 0x80, BIT7);
            /*Power off TMDS */
            viaWriteVgaIoBits(REG_CRD2, 0x08, BIT3);
        } else if (SUBCHIP_SIL164 == subChipName) {
            if (sil164_module_loaded) {
                sil164_dpms(serialPort, mode);
            }
        } else if (SUBCHIP_CH7301 == subChipName) {
            if (ch7301_module_loaded) {
                viaTmdsDisableCh7301(serialPort, subChipSlaveAddr);
            }
        } else if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            /* Disable HDMI */
            MMIO_WR_MASK(0xC280, 0x0, 0x2);
        }
        viaDIPortPadOff(pScrn->scrnIndex, diPort);
        break;

    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

/*
* Saves the crtc's state for restoration on VT switch.

static void
via_tmds_save (xf86OutputPtr output)
{
}
*/
/*
* Restore's the crtc's state at VT switch.

static void
via_tmds_restore (xf86OutputPtr output)
{
    ScrnInfoPtr             pScrn = output->scrn;
    VIAPtr                     pVia = VIAPTR(pScrn);

    if (pVia->pChipInfo->biosActiveDev & VIA_DEVICE_DFP) {
        via_tmds_dpms(output, DPMSModeOn);
    }
}
*/
/*
 * Callback for testing a video mode for a given output.
 *
 * This function should only check for cases where a mode can't be supported
 * on the pipe specifically, and not represent generic CRTC limitations.
 *
 * return MODE_OK if the mode is valid, or another MODE_* otherwise.
 */
static int
via_tmds_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;

    /**
     * Check Pixel Clock Range :
     * Now we only support single channel TMDS( by daughter card ),
     * so the pixel clock range should be changed to 25MHz ~ 165MHz.
     */
    if (mode->Clock > 165000)
        return MODE_CLOCK_HIGH;
    if (mode->Clock < 25000)
        return MODE_CLOCK_LOW;

    /* Check monitor physical size */
    if (mode->HDisplay > viaDviInfo->commonInfo.physicalWidth)
        return MODE_BAD_HVALUE;
    if (mode->VDisplay > viaDviInfo->commonInfo.physicalHeight)
        return MODE_BAD_VVALUE;

    /* Check Resolution Range */
    if (IsValidMode(mode->HDisplay, mode->VDisplay) == 0)
        return MODE_BAD;

    return MODE_OK;
}

static Bool
via_tmds_mode_fixup(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    return TRUE;
}

static void
via_tmds_mode_set(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;
    CARD32 diPort = viaDviInfo->commonInfo.diPort;
    CARD32 subChipName = viaDviInfo->commonInfo.subChipName;
    CARD32 usedIga =
        ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;
    CARD32 serialPort = viaDviInfo->commonInfo.serialPort;
    CARD32 subChipSlaveAddr = viaDviInfo->commonInfo.slaveAddress;

    if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
        viaSetIntegratedDVIMode(adjusted_mode, usedIga);
    } else if (SUBCHIP_SIL164 == subChipName) {
        if (sil164_module_loaded) {
            viaTmdsInitSil164(serialPort);
        }
    } else if (SUBCHIP_CH7301 == subChipName) {
        if (ch7301_module_loaded) {
            viaTmdsInitCh7301(serialPort, subChipSlaveAddr,
                adjusted_mode->Clock, pVia);
        }
    }
    /* update sync polarity */
    setDiportSyncPolarity(pScrn->scrnIndex, diPort, adjusted_mode);

    /*Patch for clock skew */
    loadDviDefaultDPASetting(pVia->Chipset, diPort, adjusted_mode,
        subChipName);
    LoadUserGfxDPASetting(diPort, &viaDviInfo->userGfxDPA);
}

static xf86OutputStatus
via_tmds_detect(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_tmds_detect\n"));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputStatus status = XF86OutputStatusDisconnected;
    Bool result = FALSE;
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;
    CARD32 subChipName = viaDviInfo->commonInfo.subChipName;
    CARD32 serialPort = viaDviInfo->commonInfo.serialPort;
    CARD32 subChipSlaveAddr = viaDviInfo->commonInfo.slaveAddress;
    CARD8 edidHeader[2], inputType;
    CARD8 regSR3e;
    CARD32 hotPlugSts;

    if (!viaDviInfo->commonInfo.NoDDCValue) {
        if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            
            /**
                 * Internal HDMI device for DVI
                 * Ensure if EDID exists. Check first 2 bytes of EDID header
                 */
            viaSerialReadBytesByHDMI(0xA0, 0, edidHeader, 2);
            if ((edidHeader[0] == 0x00) && (edidHeader[1] == 0xFF)) {
                
                /* Check input type of EDID. EDID byte 20 bit 7 is input type:
                 * 0:analog, 1:digital
                 * VGA: analog input
                 * LCD/DVI: digital input */
                viaSerialReadByteByHDMI(0xA0, 20, &inputType);
                inputType = (inputType & 0x80) >> 7;
                if (DIGITER_DEVICE == inputType) {
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                        "== Detect monitor %s ==\n", output->name);
                    result = TRUE;
                }
            }
        } else {
            /* else type for DVI, use ddcport to read EDID */
            result = viaDetectDeviceByReadEdid(output, DIGITER_DEVICE);
        }
    }

    if (result) {
        status = XF86OutputStatusConnected;
    } else {
        switch (subChipName) {
        case SUBCHIP_INTEGRATED_TMDS:
            regSR3e = viaReadVgaIo(REG_SR3E);
            if (BIT5 & regSR3e) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "detect internal DVI device! \n");
                status = XF86OutputStatusConnected;
            } else {
                status = XF86OutputStatusDisconnected;
            }
            break;
        case SUBCHIP_INTEGRATED_HDMI:
            /**
                 * On 410MB:
                 * DP1 and DP2 interrupt enable bit was tied to 1 by HW
                 * DP1 and internal HDMI use the same ephy, so share the same
                 * registers.
                 * if HDMI device used by DVI mode, the hotplug status is
                 * standard for device's connected status.
                 */
            hotPlugSts = MMIO_RD(AUX_TIMER_REG) & 0xC0000000;
            switch (hotPlugSts) {
            case 0x80000000:
                /* status: hot-unplug */
                status = XF86OutputStatusDisconnected;
                break;
            case 0x40000000:
                /* status: hot-plug */
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "internal HDMI port DVI device connected!\n");
                status = XF86OutputStatusConnected;
                break;
            case 0xC0000000:
            default:
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "via_tmds_detect(): status = 0x%x\n", hotPlugSts);
                break;
            }
            break;
        case SUBCHIP_CH7301:
            if (ch7301_module_loaded) {
                status = viaTmdsDetectCh7301(serialPort, subChipSlaveAddr);
                if (XF86OutputStatusConnected == status) {
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                        "detect DVI device on CH7301 card! \n");
                }
            }
            break;
        case SUBCHIP_SIL164:
            if (sil164_module_loaded) {
                status = sil164_detect(serialPort);
                if (XF86OutputStatusConnected == status) {
                    xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "detect DVI device on SIL164 card! \n");
                }
            }
            break;
        case SUBCHIP_VT1632:
            status = vt1632_detect(serialPort);
            if (XF86OutputStatusConnected == status) {
                xf86DrvMsg(pScrn->scrnIndex, X_INFO,
                    "detect DVI device on VT1632 card! \n");
            }
            break;
        default:
            break;
        }
    }

    return status;
}

static void
via_tmds_destroy(xf86OutputPtr output)
{
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;

    if (viaDviInfo != NULL) {
        if (viaDviInfo->commonInfo.rawEDID != NULL) {
            free(viaDviInfo->commonInfo.rawEDID);
        }
        free(viaDviInfo);
    }
    output->driver_private = NULL;
}

static void
via_tmds_prepare(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOff);
}

static void
via_tmds_commit(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOn);
}

static DisplayModePtr
via_tmds_get_modes(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_tmds_get_modes\n"));
    ScrnInfoPtr pScrn = output->scrn;
    DisplayModePtr modes = NULL;
    xf86MonPtr edid_mon;
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;
    CARD32 subChipName = viaDviInfo->commonInfo.subChipName;

    if (output->MonInfo != NULL)
        free(output->MonInfo);
    output->MonInfo = NULL;

    /* if "NoDDCValue", set physical size as 4096x2048,
     * now, only support mode from modeline and xorg build-in */
    if (viaDviInfo->commonInfo.NoDDCValue) {
        viaDviInfo->commonInfo.physicalWidth = 4096;
        viaDviInfo->commonInfo.physicalHeight = 2048;
        return NULL;
    }

    if (viaDviInfo->commonInfo.rawEDID == NULL) {
        viaDviInfo->commonInfo.rawEDID =
            calloc(1, sizeof(unsigned char) * (128));
        if (SUBCHIP_INTEGRATED_HDMI == subChipName) {
            /* Internal DVI use HDMI port to read EDID */
            viaSerialReadBytesByHDMI(0xA0, 0, viaDviInfo->commonInfo.rawEDID,
                128);
        } else {
            /* Parse the EDID block */
            viaSerialReadBytes(viaDviInfo->commonInfo.ddcPort,
                0xA0, 0, viaDviInfo->commonInfo.rawEDID, 128);
        }
    }

    if ((viaDviInfo->commonInfo.rawEDID[0] == 0x00) &&
        (viaDviInfo->commonInfo.rawEDID[1] == 0xFF)) {

        edid_mon =
            xf86InterpretEDID(pScrn->scrnIndex,
                viaDviInfo->commonInfo.rawEDID);
        if (edid_mon) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "== EDID of monitor %s ==\n",
                output->name);
            xf86PrintEDID(edid_mon);
            viaGetMonitorPhysicalSize(edid_mon,
                &viaDviInfo->commonInfo.physicalWidth,
                &viaDviInfo->commonInfo.physicalHeight);
            xf86OutputSetEDID(output, edid_mon);
            modes = xf86OutputGetEDIDModes(output);
        }
    }
    /* return a mode list, not a single mode */
    return modes;
}

static const xf86OutputFuncsRec via_tmds_output_funcs = {
    .dpms = via_tmds_dpms,
    .save = NULL,
    .restore = NULL,
    .mode_valid = via_tmds_mode_valid,
    .mode_fixup = via_tmds_mode_fixup,
    .prepare = via_tmds_prepare,
    .mode_set = via_tmds_mode_set,
    .commit = via_tmds_commit,
    .detect = via_tmds_detect,
    .get_modes = via_tmds_get_modes,
    .destroy = via_tmds_destroy,
};

/******************************************************/
/*                                   DisplayPort                                           */
/*****************************************************/
static void
via_dp_dpms(xf86OutputPtr output, int mode)
{
    DEBUG(ErrorF("via_dp_dpms, mode = %d\n", mode));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    int usedIga;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    ViaOutputInfo commonInfo = ((ViaDPPrivateInfoPtr)
    (output->driver_private))->commonInfo;
    CARD32 serialPort = commonInfo.serialPort;
    CARD32 subChipName = commonInfo.subChipName;
    CARD32 diPort = commonInfo.diPort;

    switch (mode) {
    case DPMSModeOn:
        usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;
        if (NONE_SUBCHIP == subChipName)
            return;

        if (SUBCHIP_INTEGRATED_DP == subChipName) {
            viaEnableDP(output);
        }
        if (SUBCHIP_INTEGRATED_DP2 == subChipName) {
            viaEnableDP2(output);
        }
        if (commonInfo.hasHotplug && (!viaDPInfo->hotplugTimer)) {
            viaDPInfo->hotplugTimer = TimerSet(NULL, 0, 5000,
            viaDPHotplugTimer, output);
        }
        break;

    case DPMSModeStandby:           /* 1 */
    case DPMSModeSuspend:           /* 2 */
    case DPMSModeOff:               /* 3 */
        if (viaDPInfo->hotplugTimer) {
            TimerCancel(viaDPInfo->hotplugTimer);
            viaDPInfo->hotplugTimer = NULL;
        }
        if (NONE_SUBCHIP == subChipName)
            return;

        if (SUBCHIP_INTEGRATED_DP == subChipName) {
            viaDisableDP(output);
        }
        if (SUBCHIP_INTEGRATED_DP2 == subChipName) {
            viaDisableDP2(output);
        }
        break;

    default:
        xf86DrvMsg(pScrn->scrnIndex, X_ERROR, "Invalid DPMS mode %d\n", mode);
        break;
    }
}

static int
via_dp_mode_valid(xf86OutputPtr output, DisplayModePtr mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    /* Check Clock Range */
    if (mode->Clock > 400000)
        return MODE_CLOCK_HIGH;
    if (mode->Clock < 25000)
        return MODE_CLOCK_LOW;

    /* Check monitor physical size */
    if (mode->HDisplay > viaDPInfo->commonInfo.physicalWidth)
        return MODE_BAD_HVALUE;
    if (mode->VDisplay > viaDPInfo->commonInfo.physicalHeight)
        return MODE_BAD_VVALUE;

    /* Check Resolution Range */
    if (IsValidMode(mode->HDisplay, mode->VDisplay) == 0)
        return MODE_BAD;

    /* Hardware limitation: TU ratio only 15 bits. */
    viaCalculate_TU(output, mode->Clock, pScrn->bitsPerPixel);
    if (viaDPInfo->TURatio > 0x7FFF)
        return MODE_BAD;

    return MODE_OK;
}

static Bool
via_dp_mode_fixup(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    return TRUE;
}

static void
via_dp_prepare(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOff);
}

static void
via_dp_mode_set(xf86OutputPtr output,
    DisplayModePtr mode, DisplayModePtr adjusted_mode)
{
    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    int usedIga;

    usedIga = ((VIACrtcPrivatePtr) (output->crtc->driver_private))->iga;

    //source select: DP
    write_reg_mask(CRFF, VIACR, 0x0, BIT0);

    switch (viaDPInfo->commonInfo.subChipName) {
    case SUBCHIP_INTEGRATED_DP:
        // disable video
        MMIO_WR(DP_ENABLE_IF_REG, MMIO_RD(DP_ENABLE_IF_REG) & 0xFFFFFFF7);
        // select DP mode
        MMIO_WR_MASK(DP_ENABLE_IF_REG, 0x00000001, 0x00000001);
        // DP channel selection
        if (usedIga == IGA1) {
            write_reg_mask(CRFF, VIACR, 0x00, BIT1);
        } else {
            write_reg_mask(CRFF, VIACR, BIT1, BIT1);
        }

        viaDPSetupMainLink(output, mode);

        // Let HW use AUX channel
        MMIO_WR(AUX_TIMER_REG, 0x0);
        break;
    case SUBCHIP_INTEGRATED_DP2:
        // disable video
        MMIO_WR(DP2_ENABLE_IF_REG, MMIO_RD(DP2_ENABLE_IF_REG) & 0xFFFFFFF7);
        // select DP mode
        MMIO_WR_MASK(DP2_ENABLE_IF_REG, 0x00000001, 0x00000001);
        // DP channel selection
        if (usedIga == IGA1) {
            write_reg_mask(CRFF, VIACR, 0x00, BIT2);
        } else {
            write_reg_mask(CRFF, VIACR, BIT2, BIT2);
        }

        viaDP2SetupMainLink(output, mode);

        // Let HW use AUX channel
        MMIO_WR(DP2_AUX_TIMER_REG, 0x0);
        break;
    }

}

static void
via_dp_commit(xf86OutputPtr output)
{
    output->funcs->dpms(output, DPMSModeOn);
}

static xf86OutputStatus
via_dp_detect(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_dp_detect\n"));

    ScrnInfoPtr pScrn = output->scrn;
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputStatus status = XF86OutputStatusDisconnected;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    Bool isEPHYEnabled = FALSE;

    if (viaDPInfo->commonInfo.NoDDCValue) {
        status = XF86OutputStatusConnected;
    } else {
        switch (viaDPInfo->commonInfo.subChipName) {
        case SUBCHIP_INTEGRATED_DP:
            viaDPReadDPCDVersion(output);
            if (viaDPInfo->DPCDVersion) {
                status = XF86OutputStatusConnected;
            }
            break;
        case SUBCHIP_INTEGRATED_DP2:
            viaDP2ReadDPCDVersion(output);
            if (viaDPInfo->DPCDVersion) {
                status = XF86OutputStatusConnected;
            }
            break;
        }
    }

    if (status == XF86OutputStatusConnected) {

        viaDPInfo->IsDPConnected = TRUE;

        switch (viaDPInfo->commonInfo.subChipName) {
        case SUBCHIP_INTEGRATED_DP:
            viaDPGetLinkSpeed(output);
            break;
        case SUBCHIP_INTEGRATED_DP2:
            viaDP2GetLinkSpeed(output);
            break;
        }
    } else
        viaDPInfo->IsDPConnected = FALSE;

    return status;
}

static DisplayModePtr
via_dp_get_modes(xf86OutputPtr output)
{
    DEBUG(ErrorF("via_dp_get_modes\n"));
    ScrnInfoPtr pScrn = output->scrn;
    DisplayModePtr modes = NULL;
    xf86MonPtr edid_mon;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    if (output->MonInfo != NULL)
        free(output->MonInfo);
    output->MonInfo = NULL;

    /* if "NoDDCValue", set physical size as 4096x2048,
     * now, only support mode from modeline and xorg build-in */
    if (viaDPInfo->commonInfo.NoDDCValue) {
        viaDPInfo->commonInfo.physicalWidth = 4096;
        viaDPInfo->commonInfo.physicalHeight = 2048;
        return NULL;
    }

    if (viaDPInfo->commonInfo.rawEDID == NULL) {
        viaDPInfo->commonInfo.rawEDID =
            calloc(1, sizeof(unsigned char) * (128));
        /* It probably is hardware issue,
            we can't read EDID on VT3410 A0 A1, may remove it future */
        VIAPtr pVia = VIAPTR(pScrn);

        if (VIAGetChipsetRevisionID() > REVISION_VX900_A1) {
            /* Parse the EDID block */
            viaGetDPEDIDBlockData(output, viaDPInfo->commonInfo.rawEDID);
        }
    }

    if ((viaDPInfo->commonInfo.rawEDID[0] == 0x00)
        && (viaDPInfo->commonInfo.rawEDID[1] == 0xFF)) {

        edid_mon =
            xf86InterpretEDID(pScrn->scrnIndex,
            viaDPInfo->commonInfo.rawEDID);
        if (edid_mon) {
            xf86DrvMsg(pScrn->scrnIndex, X_INFO, "== EDID of monitor %s ==\n",
                output->name);
            xf86PrintEDID(edid_mon);
            viaGetMonitorPhysicalSize(edid_mon,
                &viaDPInfo->commonInfo.physicalWidth,
                &viaDPInfo->commonInfo.physicalHeight);
            xf86OutputSetEDID(output, edid_mon);
            modes = xf86OutputGetEDIDModes(output);
        }
    }
    /* return a mode list, not a single mode */
    return modes;
}

static void
via_dp_destroy(xf86OutputPtr output)
{
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    if (viaDPInfo != NULL) {
        if (viaDPInfo->commonInfo.rawEDID != NULL) {
            free(viaDPInfo->commonInfo.rawEDID);
        }
        free(viaDPInfo);
    }
    output->driver_private = NULL;
}

static const xf86OutputFuncsRec via_dp_output_funcs = {
    .dpms = via_dp_dpms,
    .save = NULL,
    .restore = NULL,
    .mode_valid = via_dp_mode_valid,
    .mode_fixup = via_dp_mode_fixup,
    .prepare = via_dp_prepare,
    .mode_set = via_dp_mode_set,
    .commit = via_dp_commit,
    .detect = via_dp_detect,
    .get_modes = via_dp_get_modes,
    .destroy = via_dp_destroy,
};

typedef enum
{
    OPTION_CRT_TYPE,
    OPTION_CRT_DIPORT,
    OPTION_CRT_SERIALPORT,
    OPTION_CRT_DDCPORT,
    OPTION_CRT_NoDDCValue,
    OPTION_CRT_CLOCK_POLARITY,
    OPTION_CRT_CLOCK_ADJUST,
    OPTION_CRT_CLOCK_DRIVING_SELECTION,
    OPTION_CRT_DATA_DRIVING_SELECTION
} ViaCrtOpts;

typedef enum
{
    OPTION_DVI_TYPE,
    OPTION_DVI_DIPORT,
    OPTION_DVI_SERIALPORT,
    OPTION_DVI_DDCPORT,
    OPTION_DVI_NoDDCValue,
    OPTION_DVI_CLOCK_POLARITY,
    OPTION_DVI_CLOCK_ADJUST,
    OPTION_DVI_CLOCK_DRIVING_SELECTION,
    OPTION_DVI_DATA_DRIVING_SELECTION
} ViaDviOpts;

typedef enum
{
    OPTION_LCD_TYPE,
    OPTION_LCD_DIPORT,
    OPTION_LCD_SERIALPORT,
    OPTION_LCD_DDCPORT,
    OPTION_LCD_PANEL_SIZE,
    OPTION_LCD_DUAL_CHANNEL,
    OPTION_LCD_MSB,
    OPTION_LCD_NO_DITHERING,
    OPTION_LCD_CENTER,
    OPTION_LCD_FIXONIGA1,
    OPTION_LCD_CLOCK_POLARITY,
    OPTION_LCD_CLOCK_ADJUST,
    OPTION_LCD_CLOCK_DRIVING_SELECTION,
    OPTION_LCD_DATA_DRIVING_SELECTION,
    OPTION_LCD_VT1636_CLOCK_SEL_ST1,
    OPTION_LCD_VT1636_CLOCK_SEL_ST2
} ViaLcdOpts;

typedef enum
{
    OPTION_DP_TYPE,
    OPTION_DP_NoDDCValue,
    OPTION_DP_Hotplug
} ViaDPOpts;

static OptionInfoRec ViaCrtOptions[] = {
    {OPTION_CRT_TYPE, "Type", OPTV_STRING, {0}, FALSE},
    {OPTION_CRT_DIPORT, "DIPort", OPTV_STRING, {0}, FALSE},
    {OPTION_CRT_SERIALPORT, "SerialPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_CRT_DDCPORT, "DDCPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_CRT_NoDDCValue, "NoDDCValue", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_CRT_CLOCK_POLARITY, "ClockPolarity", OPTV_INTEGER, {0}, FALSE},
    {OPTION_CRT_CLOCK_ADJUST, "ClockAdjust", OPTV_INTEGER, {0}, FALSE},
    {OPTION_CRT_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection",
        OPTV_INTEGER, {0}, FALSE},
    {OPTION_CRT_DATA_DRIVING_SELECTION, "DataDrivingSelection", OPTV_INTEGER,
        {0}, FALSE},
    {-1, NULL, OPTV_NONE, {0}, FALSE}
};

static OptionInfoRec ViaDviOptions[] = {
    {OPTION_DVI_TYPE, "Type", OPTV_STRING, {0}, FALSE},
    {OPTION_DVI_DIPORT, "DIPort", OPTV_STRING, {0}, FALSE},
    {OPTION_DVI_SERIALPORT, "SerialPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_DVI_DDCPORT, "DDCPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_DVI_NoDDCValue, "NoDDCValue", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_DVI_CLOCK_POLARITY, "ClockPolarity", OPTV_INTEGER, {0}, FALSE},
    {OPTION_DVI_CLOCK_ADJUST, "ClockAdjust", OPTV_INTEGER, {0}, FALSE},
    {OPTION_DVI_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection",
        OPTV_INTEGER, {0}, FALSE},
    {OPTION_DVI_DATA_DRIVING_SELECTION, "DataDrivingSelection", OPTV_INTEGER,
        {0}, FALSE},
    {-1, NULL, OPTV_NONE, {0}, FALSE}
};

static OptionInfoRec ViaLcdOptions[] = {
    {OPTION_LCD_TYPE, "Type", OPTV_STRING, {0}, FALSE},
    {OPTION_LCD_DIPORT, "DIPort", OPTV_STRING, {0}, FALSE},
    {OPTION_LCD_SERIALPORT, "SerialPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_LCD_DDCPORT, "DDCPort", OPTV_INTEGER, {0}, FALSE},
    {OPTION_LCD_PANEL_SIZE, "PanelSize", OPTV_STRING, {0}, FALSE},
    {OPTION_LCD_DUAL_CHANNEL, "DualChannel", OPTV_STRING, {0}, FALSE},
    {OPTION_LCD_MSB, "MSB", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_LCD_NO_DITHERING, "NoDithering", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_LCD_CENTER, "Center", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_LCD_FIXONIGA1, "FixOnIGA1", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_LCD_CLOCK_POLARITY, "ClockPolarity", OPTV_INTEGER, {0}, FALSE},
    {OPTION_LCD_CLOCK_ADJUST, "ClockAdjust", OPTV_INTEGER, {0}, FALSE},
    {OPTION_LCD_CLOCK_DRIVING_SELECTION, "ClockDrivingSelection",
        OPTV_INTEGER, {0}, FALSE},
    {OPTION_LCD_DATA_DRIVING_SELECTION, "DataDrivingSelection", OPTV_INTEGER,
        {0}, FALSE},
    {OPTION_LCD_VT1636_CLOCK_SEL_ST1, "Vt1636ClockSelST1", OPTV_INTEGER, {0},
        FALSE},
    {OPTION_LCD_VT1636_CLOCK_SEL_ST2, "Vt1636ClockSelST2", OPTV_INTEGER, {0},
        FALSE},
    {-1, NULL, OPTV_NONE, {0}, FALSE}
};

static OptionInfoRec ViaDPOptions[] = {
    {OPTION_DP_TYPE, "Type", OPTV_STRING, {0}, FALSE},
    {OPTION_DP_NoDDCValue, "NoDDCValue", OPTV_BOOLEAN, {0}, FALSE},
    {OPTION_DP_Hotplug, "Hotplug", OPTV_BOOLEAN, {0}, FALSE},
    {-1, NULL, OPTV_NONE, {0}, FALSE}
};

CARD32
transformDiPort(char *pStr)
{
    if (!xf86NameCmp(pStr, "DFP_HIGH"))
        return DISP_DI_DFPH;
    else if (!xf86NameCmp(pStr, "DFP_LOW"))
        return DISP_DI_DFPL;
    else if (!xf86NameCmp(pStr, "DFP_HIGHLOW"))
        return DISP_DI_DFP;
    else if (!xf86NameCmp(pStr, "DVP0"))
        return DISP_DI_DVP0;
    else if (!xf86NameCmp(pStr, "DVP1"))
        return DISP_DI_DVP1;
    else if (!xf86NameCmp(pStr, "DFP_LOW,DVP1"))    /*Quanta TTL */
        return DISP_DI_DFPL + DISP_DI_DVP1;
    else if (!xf86NameCmp(pStr, "DFP_HIGHLOW,DVP1"))    /*409 TTL */
        return DISP_DI_DFPH + DISP_DI_DFPL + DISP_DI_DVP1;
    else
    return DISP_DI_NONE;

}

CARD32
transformOutputType(char *pStr)
{
    if (!xf86NameCmp(pStr, "HardWired"))
        return DISP_TYPE_HARDWIRED;
    else if (!xf86NameCmp(pStr, "External"))
        return DISP_TYPE_EXTERNAL;
    else if (!xf86NameCmp(pStr, "TTL"))
        return DISP_TYPE_TTL;
    else
        return DISP_TYPE_INTERNAL;

}

static CARD32
transformPort(CARD32 port)
{
    switch (port) {
    case DISP_SERIALP_25:
    case DISP_SERIALP_26:
    case DISP_SERIALP_2C:
    case DISP_SERIALP_31:
    case DISP_SERIALP_3D:
        return port;
    default:
        return DISP_DEFAULT_SETTING;
    }
}

static void
viaSetDefaultLCDPanelInfo(ViaLcdPrivateInfoPtr viaLcdInfo)
{
    switch (viaLcdInfo->panelIndex) {
    case VIA_1280X1024:
    case VIA_1400X1050:
    case VIA_1440X900:
    case VIA_1600X1200:
    case VIA_1920X1080:
        viaLcdInfo->dualChannel = TRUE;
        break;
    default:
        viaLcdInfo->dualChannel = FALSE;
        break;
    }
}

static void
parseCrtOption(xf86OutputPtr output)
{
    char *s = NULL;
    int value = 0;
    int sPort = DISP_SERIALP_NONE;
    int dPort = DISP_SERIALP_NONE;
    ViaCrtPrivateInfoPtr viaCrtInfo = output->driver_private;
    OptionInfoPtr tempRecOptionsPtr;

    viaCrtInfo->userGfxDPA.isClkPolarityUsed = FALSE;
    viaCrtInfo->userGfxDPA.isClkAdjustUsed = FALSE;
    viaCrtInfo->userGfxDPA.isClkDrivingSelUsed = FALSE;
    viaCrtInfo->userGfxDPA.isDataDrivingSelUsed = FALSE;

    /* Default value */
    viaCrtInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
    viaCrtInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    viaCrtInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
    viaCrtInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;
    viaCrtInfo->commonInfo.NoDDCValue = FALSE;

    if (!(tempRecOptionsPtr = (OptionInfoPtr) malloc(sizeof(ViaCrtOptions)))) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, ViaCrtOptions, sizeof(ViaCrtOptions));
    /* if no "CRT" monitor section, all use default settting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr);
    }

    /* parse option "DIPort" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_CRT_DIPORT)))
        viaCrtInfo->commonInfo.diPort = transformDiPort(s);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_CRT_TYPE)))
        viaCrtInfo->commonInfo.type = transformOutputType(s);

    /* parse option "SerialPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_CRT_SERIALPORT,
        &sPort))
        viaCrtInfo->commonInfo.serialPort = transformPort(sPort);

    /* parse option "DDCPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_CRT_DDCPORT, &dPort))
        viaCrtInfo->commonInfo.ddcPort = transformPort(dPort);

    /* parse option "NoDDCValue" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_CRT_NoDDCValue, FALSE))
        viaCrtInfo->commonInfo.NoDDCValue = TRUE;

    /* parse user clock skew setting */
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_CRT_CLOCK_POLARITY,
        &value)) {
        viaCrtInfo->userGfxDPA.clkPolarity = value & BIT0;
        viaCrtInfo->userGfxDPA.isClkPolarityUsed = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_CRT_CLOCK_ADJUST,
        &value)) {
        viaCrtInfo->userGfxDPA.clkAdjust = value;
        viaCrtInfo->userGfxDPA.isClkAdjustUsed = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_CRT_CLOCK_DRIVING_SELECTION, &value)) {
        viaCrtInfo->userGfxDPA.clkDrivingSel = value;
        viaCrtInfo->userGfxDPA.isClkDrivingSelUsed = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_CRT_DATA_DRIVING_SELECTION, &value)) {
        viaCrtInfo->userGfxDPA.dataDrivingSel = value;
        viaCrtInfo->userGfxDPA.isDataDrivingSelUsed = TRUE;
    }

    free(tempRecOptionsPtr);
}

static void
parseDviOption(xf86OutputPtr output)
{
    char *s = NULL;
    int value = 0;
    int sPort = DISP_SERIALP_NONE;
    int dPort = DISP_SERIALP_NONE;
    OptionInfoPtr tempRecOptionsPtr;
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;

    viaDviInfo->userGfxDPA.isClkPolarityUsed = FALSE;
    viaDviInfo->userGfxDPA.isClkAdjustUsed = FALSE;
    viaDviInfo->userGfxDPA.isClkDrivingSelUsed = FALSE;
    viaDviInfo->userGfxDPA.isDataDrivingSelUsed = FALSE;

    /* Default value */
    viaDviInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
    viaDviInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    viaDviInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
    viaDviInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;
    viaDviInfo->commonInfo.NoDDCValue = FALSE;

    if (!(tempRecOptionsPtr = (OptionInfoPtr) malloc(sizeof(ViaDviOptions)))) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, ViaDviOptions, sizeof(ViaDviOptions));
    /* if no "DVI" monitor section, all use default setting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr);
    }

    /* parse option "DIPort" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_DVI_DIPORT)))
        viaDviInfo->commonInfo.diPort = transformDiPort(s);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_DVI_TYPE)))
        viaDviInfo->commonInfo.type = transformOutputType(s);

    /* parse option "SerialPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_DVI_SERIALPORT,
        &sPort))
        viaDviInfo->commonInfo.serialPort = transformPort(sPort);

    /* parse option "DDCPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_DVI_DDCPORT, &dPort))
        viaDviInfo->commonInfo.ddcPort = transformPort(dPort);

    /* parse option  "NoDDCValue" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_DVI_NoDDCValue, FALSE))
        viaDviInfo->commonInfo.NoDDCValue = TRUE;

    /* parse user clock skew setting */
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_DVI_CLOCK_POLARITY,
        &value)) {
        viaDviInfo->userGfxDPA.clkPolarity = value & BIT0;
        viaDviInfo->userGfxDPA.isClkPolarityUsed = TRUE;
    }
    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_DVI_CLOCK_ADJUST,
        &value)) {
        viaDviInfo->userGfxDPA.clkAdjust = value;
        viaDviInfo->userGfxDPA.isClkAdjustUsed = TRUE;
    }
    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_DVI_CLOCK_DRIVING_SELECTION, &value)) {
        viaDviInfo->userGfxDPA.clkDrivingSel = value;
        viaDviInfo->userGfxDPA.isClkDrivingSelUsed = TRUE;
    }
    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_DVI_DATA_DRIVING_SELECTION, &value)) {
        viaDviInfo->userGfxDPA.dataDrivingSel = value;
        viaDviInfo->userGfxDPA.isDataDrivingSelUsed = TRUE;
    }

    free(tempRecOptionsPtr);
}

static void
parseLcdOption(xf86OutputPtr output)
{
    char *s = NULL, *b = NULL;
    int value = 0;
    int sPort = DISP_SERIALP_NONE;
    int dPort = DISP_SERIALP_NONE;
    unsigned int panelWidth = 0, panelHeight = 0;
    OptionInfoPtr tempRecOptionsPtr;
    ViaLcdPrivateInfoPtr viaLcdInfo = output->driver_private;

    viaLcdInfo->userGfxDPA.isClkPolarityUsed = FALSE;
    viaLcdInfo->userGfxDPA.isClkAdjustUsed = FALSE;
    viaLcdInfo->userGfxDPA.isClkDrivingSelUsed = FALSE;
    viaLcdInfo->userGfxDPA.isDataDrivingSelUsed = FALSE;
    viaLcdInfo->userLvdsDPA.isVt1636ClkSelST1Used = FALSE;
    viaLcdInfo->userLvdsDPA.isVt1636ClkSelST2Used = FALSE;

    /* Default value */
    viaLcdInfo->commonInfo.diPort = DISP_DEFAULT_SETTING;
    viaLcdInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    viaLcdInfo->commonInfo.serialPort = DISP_DEFAULT_SETTING;
    viaLcdInfo->commonInfo.ddcPort = DISP_DEFAULT_SETTING;
    viaLcdInfo->commonInfo.physicalWidth = 0;
    viaLcdInfo->commonInfo.physicalHeight = 0;
    viaLcdInfo->panelIndex = 0;
    viaLcdInfo->dualChannel = FALSE;
    viaLcdInfo->noDithering = FALSE;
    viaLcdInfo->msb = FALSE;
    viaLcdInfo->center = FALSE;
    viaLcdInfo->fixOnIGA1 = FALSE;

    if (!(tempRecOptionsPtr = (OptionInfoPtr) malloc(sizeof(ViaLcdOptions)))) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, ViaLcdOptions, sizeof(ViaLcdOptions));
    /* if no LCD monitor section, all use default setting */
    if (output->conf_monitor) {
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr);
    }
    /* parse option "DIPort" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_LCD_DIPORT)))
        viaLcdInfo->commonInfo.diPort = transformDiPort(s);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_LCD_TYPE)))
        viaLcdInfo->commonInfo.type = transformOutputType(s);

    /* parse option "SerialPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_LCD_SERIALPORT,
        &sPort))
        viaLcdInfo->commonInfo.serialPort = transformPort(sPort);

    /* parse option "DDCPort" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_LCD_DDCPORT, &dPort))
        viaLcdInfo->commonInfo.ddcPort = transformPort(dPort);

    /* parse option  "PanelSize" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_LCD_PANEL_SIZE))) {
        b = strdup(s);
        s = strtok(b, "x");
        panelWidth = (CARD32) atoi(s);
        s = strtok(NULL, "x");
        panelHeight = (CARD32) atoi(s);
        /*1020 */
        viaLcdInfo->panelIndex = VIA_MAKE_ID(panelWidth, panelHeight);
        /*Check if the panel size is valid */
        if (viaGetPanelSize(viaLcdInfo->panelIndex, &viaLcdInfo->commonInfo)) {
            viaSetDefaultLCDPanelInfo(viaLcdInfo);
        } else {
            viaLcdInfo->panelIndex = VIA_INVALID;
            /*Give a chance to get physical size from EDID */
            ErrorF("parseLcdOption: Panel size %dx%d is not valid!\n",
                panelWidth, panelHeight);
        }
    }

    /* get panel modeline from xorg.conf for special panel size */
    viaGetPanelModeLine(output);

    /* parse option "DualChannel" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_LCD_DUAL_CHANNEL))) {
        if ((*s == '\0') ||
            !xf86NameCmp(s, "TRUE") ||
            !xf86NameCmp(s, "True") || !xf86NameCmp(s, "true"))
            viaLcdInfo->dualChannel = TRUE;
        else if (!xf86NameCmp(s, "FALSE") ||
            !xf86NameCmp(s, "False") || !xf86NameCmp(s, "false"))
            viaLcdInfo->dualChannel = FALSE;
    }

    /* parse option "Dithering" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_LCD_NO_DITHERING,
        FALSE))
        viaLcdInfo->noDithering = TRUE;

    /* parse option "MSB" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_LCD_MSB, FALSE))
        viaLcdInfo->msb = TRUE;

    /* parse option "Center" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_LCD_CENTER, FALSE))
        viaLcdInfo->center = TRUE;

    /* parse option "FixOnIGA1" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_LCD_FIXONIGA1, FALSE))
        viaLcdInfo->fixOnIGA1 = TRUE;

    /* parse user clock skew setting */
    /* 1. parse option "ClockPolarity" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_LCD_CLOCK_POLARITY,
        &value)) {
        viaLcdInfo->userGfxDPA.clkPolarity = value & BIT0;
        viaLcdInfo->userGfxDPA.isClkPolarityUsed = TRUE;
    }

    /* 2. parse option "ClockAdjust" */
    if (xf86GetOptValInteger(tempRecOptionsPtr, OPTION_LCD_CLOCK_ADJUST,
        &value)) {
        viaLcdInfo->userGfxDPA.clkAdjust = value;
        viaLcdInfo->userGfxDPA.isClkAdjustUsed = TRUE;
    }

    /* 3. parse option "ClockDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_LCD_CLOCK_DRIVING_SELECTION, &value)) {
        viaLcdInfo->userGfxDPA.clkDrivingSel = value;
        viaLcdInfo->userGfxDPA.isClkDrivingSelUsed = TRUE;
    }

    /* 4. parse option "DataDrivingSelection" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_LCD_DATA_DRIVING_SELECTION, &value)) {
        viaLcdInfo->userGfxDPA.dataDrivingSel = value;
        viaLcdInfo->userGfxDPA.isDataDrivingSelUsed = TRUE;
    }

    /* 5. parse option "Vt1636ClockSelST1" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_LCD_VT1636_CLOCK_SEL_ST1, &value)) {
        viaLcdInfo->userLvdsDPA.Vt1636ClkSelST1 = value;
        viaLcdInfo->userLvdsDPA.isVt1636ClkSelST1Used = TRUE;
    }

    /* 6. parse option "Vt1636ClockSelST2" */
    if (xf86GetOptValInteger(tempRecOptionsPtr,
        OPTION_LCD_VT1636_CLOCK_SEL_ST2, &value)) {
        viaLcdInfo->userLvdsDPA.Vt1636ClkSelST2 = value;
        viaLcdInfo->userLvdsDPA.isVt1636ClkSelST2Used = TRUE;
    }

    free(tempRecOptionsPtr);
}

static void
parseDPOption(xf86OutputPtr output)
{
    char *s = NULL;
    OptionInfoPtr tempRecOptionsPtr;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;

    /* Default value */
    viaDPInfo->commonInfo.type = DISP_DEFAULT_SETTING;
    viaDPInfo->commonInfo.NoDDCValue = FALSE;
    viaDPInfo->commonInfo.hasHotplug = FALSE;

    if (!(tempRecOptionsPtr = (OptionInfoPtr) malloc(sizeof(ViaDPOptions)))) {
        ErrorF("%s:Allocate memory Failed\n", __FUNCTION__);
        return;
    }
    memcpy(tempRecOptionsPtr, ViaDPOptions, sizeof(ViaDPOptions));
    /* if no "DP" monitor section, all use default setting */
    if (output->conf_monitor)
        xf86ProcessOptions(output->scrn->scrnIndex,
            output->conf_monitor->mon_option_lst, tempRecOptionsPtr);

    /* parse option "Type" */
    if ((s = xf86GetOptValString(tempRecOptionsPtr, OPTION_DP_TYPE)))
        viaDPInfo->commonInfo.type = transformOutputType(s);

    /* parse option  "NoDDCValue" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_DP_NoDDCValue, FALSE))
        viaDPInfo->commonInfo.NoDDCValue = TRUE;

    /* parse option  "HotPlug" */
    if (xf86ReturnOptValBool(tempRecOptionsPtr, OPTION_DP_Hotplug, FALSE))
        viaDPInfo->commonInfo.hasHotplug = TRUE;

    free(tempRecOptionsPtr);
}

/*
Function Name:  checkDiPortUsage
Description:    Check whether the DI port is already occupied or not
*/
Bool
checkDiPortUsage(VIAPtr pVia, CARD32 diPort)
{
    if (diPort != DISP_DI_NONE) {
        if (!(diPort & pVia->MbDiPortUsedInfo))
            return TRUE;
    }
    return FALSE;
}

static CARD32
fetchSubChipName(subChipVerInfoPtr chip, CARD32 * serialPort)
{
    CARD32 i = 0, j = 0;
    CARD8 retVersion[5];
    CARD32 retVal = NONE_SUBCHIP;

    if (chip) {
        /* if user doesn't set port or set wrong port,
         * sense chip: 0x2c->0x31->0x25->0x3D->0x26 */
        if (*serialPort == DISP_DEFAULT_SETTING) {
            for (i = 0; i < NUM_SERIAL_PORT; i++) {
                for (j = 0; j < chip->numOfRevReg; j++) {
                    if (TRUE == serialPortTable[i].isFree) {
                        if (viaSerialReadByte(serialPortTable[i].serialPort,
                            chip->address, chip->revOffset[j],
                            &retVersion[j])) {
                            if (retVersion[j] != chip->revId[j]) {
                                break;
                            }
                            if (j == chip->numOfRevReg - 1) {
                                *serialPort = serialPortTable[i].serialPort;
                                serialPortTable[i].isFree = FALSE;
                                retVal = chip->subChipName;
                                return retVal;
                            }
                        }
                    }
                }
            }
        } else {
            /* if user set port, just use user setting */
            for (j = 0; j < chip->numOfRevReg; j++) {
                if (viaSerialReadByte(*serialPort, chip->address,
                    chip->revOffset[j], &retVersion[j])) {
                    if (retVersion[j] != chip->revId[j]) {
                        break;
                    }
                    if (j == chip->numOfRevReg - 1) {
                        retVal = chip->subChipName;
                        return retVal;
                    }
                }
            }
        }
    }

    return retVal;
}

/*
Function Name:  senseSubChip
Description:    Check if sub chip exist or not
Note: if serial port is set to default value,
it will be modified if the sub chip is found
*/
CARD32
senseSubChip(ViaOutputInfoPtr commonInfo, CARD32 subChipName)
{
    subChipVerInfoPtr chip = NULL;
    CARD32 *serialPort = &commonInfo->serialPort;
    CARD32 retVal = NONE_SUBCHIP;

    switch (subChipName) {
    case SUBCHIP_VT1632:
        chip = &vt1632Info;
        retVal = fetchSubChipName(chip, serialPort);
        break;
    case SUBCHIP_VT1625:
        chip = &vt1625Info;
        retVal = fetchSubChipName(chip, serialPort);
        break;
    case SUBCHIP_VT1636:
        chip = &vt1636Info;
        retVal = fetchSubChipName(chip, serialPort);
        break;
    case SUBCHIP_SIL164:
        chip = &sil164Info;
        retVal = fetchSubChipName(chip, serialPort);
        break;
    case SUBCHIP_AD9389:
        /* AD9389 doesn't have chip id */
        if (viaSenseAD9389(serialPort)) {
            retVal = SUBCHIP_AD9389;
        }
        break;
    case SUBCHIP_CH7301:
        chip = &ch7301Info_Ec;
        retVal = fetchSubChipName(chip, serialPort);
        if (NONE_SUBCHIP != retVal) {
            commonInfo->slaveAddress = chip->address;
            return retVal;
        }
        chip = &ch7301Info_Ea;
        retVal = fetchSubChipName(chip, serialPort);
        commonInfo->slaveAddress = chip->address;
        break;
    default:
        break;
    }

    return retVal;
}

/*
Function Name:  checkCrtSupport
Description:    Check if CRT supported by platform
*/
static Bool
checkCrtSupport(VIAPtr pVia, xf86OutputPtr output)
{
    Bool retVal = FALSE;
    ViaCrtPrivateInfoPtr viaCrtInfo = output->driver_private;

    /* default CRT type is internal CRT */
    if (viaCrtInfo->commonInfo.type == DISP_DEFAULT_SETTING)
        viaCrtInfo->commonInfo.type = DISP_TYPE_INTERNAL;

    /* deault CRT DIPort */
    if (viaCrtInfo->commonInfo.diPort == DISP_DEFAULT_SETTING) {
        if (viaCrtInfo->commonInfo.type == DISP_TYPE_INTERNAL)
            /* for internal CRT: DAC */
            viaCrtInfo->commonInfo.diPort = DISP_DI_DAC;
        else if (viaCrtInfo->commonInfo.type == DISP_TYPE_EXTERNAL)
            /* for external CRT: DVP1 */
            viaCrtInfo->commonInfo.diPort = DISP_DI_DVP1;
        else
            /* for hard-wired CRT, reserved */
            viaCrtInfo->commonInfo.diPort = DISP_DI_NONE;
    }

    /* check if CRT DI port is free */
    if (checkDiPortUsage(pVia, viaCrtInfo->commonInfo.diPort)) {
        /* for internal CRT: no serial port */
        if (viaCrtInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
            viaCrtInfo->commonInfo.diPort = DISP_DI_DAC;
            viaCrtInfo->commonInfo.serialPort = DISP_SERIALP_NONE;

            viaCrtInfo->commonInfo.subChipName = NONE_SUBCHIP;
            viaCrtInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
            pVia->MbDiPortUsedInfo |= viaCrtInfo->commonInfo.diPort;
            retVal = TRUE;
        } else if (viaCrtInfo->commonInfo.type == DISP_TYPE_EXTERNAL) {
            /* for external CRT: check DIPort, sense subchip */
            /* Case that graphic chip before 3324:
             * If user set CRT(In fact is VT1625) on DVP0, but found SR12[5]=0
             * (jumper on MB set DVI use DVP0), CRT support will fail */
            if (DISP_DI_DVP0 == viaCrtInfo->commonInfo.diPort &&
                !(DISP_DEV_TV & pVia->MbDvp0Device)) {
                pVia->MbDiPortUsedInfo &= ~DISP_DI_DVP0;
            } else {
                /* Sense VT1625 */
                if (senseSubChip(&viaCrtInfo->commonInfo, SUBCHIP_VT1625)) {
                    viaCrtInfo->commonInfo.subChipName = SUBCHIP_VT1625;
                    viaCrtInfo->commonInfo.slaveAddress =
                        SUBCHIP_VT1625_SLAVE_ADDR;
                    if (viaCrtInfo->commonInfo.ddcPort ==
                        DISP_DEFAULT_SETTING) {
                        viaCrtInfo->commonInfo.ddcPort =
                            viaCrtInfo->commonInfo.serialPort;
                    }
                    /* here we occupy the di port since we have detected the subchip */
                    pVia->MbDiPortUsedInfo |= viaCrtInfo->commonInfo.diPort;
                    retVal = TRUE;
                } else if (ch7301_module_loaded &&
                    senseSubChip(&viaCrtInfo->commonInfo, SUBCHIP_CH7301)) {
                    viaCrtInfo->commonInfo.subChipName = SUBCHIP_CH7301;
                    if (viaCrtInfo->commonInfo.ddcPort ==
                        DISP_DEFAULT_SETTING) {
                        viaCrtInfo->commonInfo.ddcPort =
                            viaCrtInfo->commonInfo.serialPort;
                    }
                    /* here we occupy the di port since we have detected the subchip */
                    pVia->MbDiPortUsedInfo |= viaCrtInfo->commonInfo.diPort;
                    retVal = TRUE;
                }
            }
        } else {
        }
        /* for hard-wired CRT, reserved */
    }

    return retVal;
}

/*
Function Name:  checkDviSupport
Description:    Check if DVI supported by platform
*/
static Bool
checkDviSupport(VIAPtr pVia, xf86OutputPtr output)
{
    Bool retVal = FALSE;
    ViaDviPrivateInfoPtr viaDviInfo = output->driver_private;
    ScrnInfoPtr pScrn = output->scrn;

    /* default DVI type is internal */
    if (viaDviInfo->commonInfo.type == DISP_DEFAULT_SETTING) {
        if (pVia->GfxDispCaps & (INTERNAL_TMDS | INTERNAL_HDMI))
            /* if the chip have the cap of integrated TMDS */
            viaDviInfo->commonInfo.type = DISP_TYPE_INTERNAL;
        else
            /* if the chip doesn't have, return FALSE directly */
            return retVal;
    }

    /* deault DVI DIPort */
    if (viaDviInfo->commonInfo.diPort == DISP_DEFAULT_SETTING) {
        if (viaDviInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
            if (VIA_VX900 == pVia->Chipset) {
                /* for 410 MB internal HDMI by DVI mode, do not occupy DIPort */
                viaDviInfo->commonInfo.diPort = DISP_DI_NONE;
            } else {
                /* for 324 or 353( if has internal DVI ) internal TMDS: DFP_LOW */
                viaDviInfo->commonInfo.diPort = DISP_DI_DFPL;
            }
        } else {
            /* for external and hard-wired TMDS: use DVP1 as default port */
            viaDviInfo->commonInfo.diPort = DISP_DI_DVP1;
        }
    }

    /*if DVI DI port is free */
    if (checkDiPortUsage(pVia, viaDviInfo->commonInfo.diPort)) {
        /* internal TMDS */
        if (viaDviInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
            /* if the platform doesn't support internal TMDS, it fails  */
            if (INTERNAL_TMDS & pVia->GfxDispCaps) {
                viaDviInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_TMDS;
                viaDviInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
                /* default serial port (internal TMDS), NONE */
            if (viaDviInfo->commonInfo.serialPort == DISP_DEFAULT_SETTING)
                viaDviInfo->commonInfo.serialPort = DISP_SERIALP_NONE;
                /* DI port is occupied, and internal TMDS cap is lost */
                pVia->MbDiPortUsedInfo |= viaDviInfo->commonInfo.diPort;
                pVia->GfxDispCaps &= ~INTERNAL_TMDS;
                retVal = TRUE;
            }
            /* external TMDS */
        } else if (viaDviInfo->commonInfo.type == DISP_TYPE_EXTERNAL) {
            /*Case that graphic chip before 3324:
             * If user set DVI use DVP0, but found SR12[5]=1(jumper on MB set
             * TV use DVP0), DVI support will fail */
            if (DISP_DI_DVP0 == viaDviInfo->commonInfo.diPort &&
                !(DISP_DEV_DVI & pVia->MbDvp0Device)) {
                pVia->MbDiPortUsedInfo &= ~DISP_DI_DVP0;
            } else {
                /* Sense VT1632 */
                /* VT1632A needn't the clk on when sonsored through I2C,but VT1632 needs.
                 * Turn on relevant clk according to diport used by vt1632. */
                viaDIPortPadOn(pScrn->scrnIndex,
                    viaDviInfo->commonInfo.diPort);
                if (senseSubChip(&viaDviInfo->commonInfo, SUBCHIP_VT1632)) {
                    viaDviInfo->commonInfo.subChipName = SUBCHIP_VT1632;
                    viaDviInfo->commonInfo.slaveAddress =
                        SUBCHIP_VT1632_SLAVE_ADDR;
                    if (viaDviInfo->commonInfo.ddcPort ==
                        DISP_DEFAULT_SETTING)
                    viaDviInfo->commonInfo.ddcPort =
                        viaDviInfo->commonInfo.serialPort;
                    pVia->MbDiPortUsedInfo |= viaDviInfo->commonInfo.diPort;
                    retVal = TRUE;
                } else if (ch7301_module_loaded &&
                    senseSubChip(&viaDviInfo->commonInfo, SUBCHIP_CH7301)) {
                    viaDviInfo->commonInfo.subChipName = SUBCHIP_CH7301;
                    if (viaDviInfo->commonInfo.ddcPort ==
                        DISP_DEFAULT_SETTING) {
                        viaDviInfo->commonInfo.ddcPort =
                            viaDviInfo->commonInfo.serialPort;
                    }
                    pVia->MbDiPortUsedInfo |= viaDviInfo->commonInfo.diPort;
                    retVal = TRUE;
                } else if (sil164_module_loaded &&
                    senseSubChip(&viaDviInfo->commonInfo, SUBCHIP_SIL164)) {
                    viaDviInfo->commonInfo.subChipName = SUBCHIP_SIL164;
                    viaDviInfo->commonInfo.slaveAddress =
                        SUBCHIP_SIL164_SLAVE_ADDR;
                    if (viaDviInfo->commonInfo.ddcPort ==
                        DISP_DEFAULT_SETTING)
                    viaDviInfo->commonInfo.ddcPort =
                        viaDviInfo->commonInfo.serialPort;
                    pVia->MbDiPortUsedInfo |= viaDviInfo->commonInfo.diPort;
                    retVal = TRUE;
                } else {
                    if (!sil164_module_loaded) {
                        xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                            "Failed to load sil164 module, "
                            "so we don't creat dvi output "
                            "if you need dvi output, please load the submodule.\n");
                    }
                    if (!ch7301_module_loaded) {
                        xf86DrvMsg(pScrn->scrnIndex, X_WARNING,
                            "Failed to load ch7301 module, "
                            "so we don't creat dvi output "
                            "if you need dvi output, please load the submodule.\n");
                    }
                }
            }
            /*Turn off relevant di port clk set on previously to keep things consistent */
            viaDIPortPadOff(pScrn->scrnIndex, viaDviInfo->commonInfo.diPort);
        }
    } else {
        if ((DISP_TYPE_INTERNAL == viaDviInfo->commonInfo.type) &&
            (DISP_DI_NONE == viaDviInfo->commonInfo.diPort)) {
            /* HDMI transmit can be compatible with DVI */
            if (INTERNAL_HDMI & pVia->GfxDispCaps) {
                viaDviInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_HDMI;
                viaDviInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
                pVia->GfxDispCaps &= ~INTERNAL_HDMI;
                retVal = TRUE;
            }
        } else {
            viaDviInfo->commonInfo.subChipName = SUBCHIP_HARDWIRED_TMDS;
            viaDviInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
            viaDviInfo->commonInfo.serialPort = DISP_SERIALP_NONE;
            viaDviInfo->commonInfo.ddcPort = DISP_SERIALP_NONE;
            pVia->MbDiPortUsedInfo |= viaDviInfo->commonInfo.diPort;
            retVal = TRUE;
        }
    }
    return retVal;
}

Bool
checkLcdSupport(VIAPtr pVia, xf86OutputPtr output)
{
    Bool retVal = FALSE;
    ViaLcdPrivateInfoPtr viaLcdInfo = output->driver_private;
    ViaOutputInfoPtr LcdCommonInfo = &viaLcdInfo->commonInfo;

    /*For default type */
    if (LcdCommonInfo->type == DISP_DEFAULT_SETTING) {
        if (pVia->GfxDispCaps & INTERNAL_LVDS) {
            /* if Gfx have integrated LVDS capability, default as integrated LVDS */
            LcdCommonInfo->type = DISP_TYPE_INTERNAL;
        } else {
            /* if Gfx have no integrated LVDS capability, return FALSE directly */
            return retVal;
        }
    }

    /*For default DI port */
    if (LcdCommonInfo->diPort == DISP_DEFAULT_SETTING) {
        if (LcdCommonInfo->type == DISP_TYPE_INTERNAL) {
            /* MB 409 and 410's internal LVDS use DFP_LOW as default DIPort */
            if ((VIA_VX855 == pVia->Chipset) || (VIA_VX900 == pVia->Chipset)) {
                LcdCommonInfo->diPort = DISP_DI_DFPL;
            } else {
                /* Other MB's internal LVDS use DFP_HIGH as default DIPort */
                LcdCommonInfo->diPort = DISP_DI_DFPH;
            }
        } else if (LcdCommonInfo->type == DISP_TYPE_TTL) {
            if (pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900) {
                LcdCommonInfo->diPort =
                    DISP_DI_DFPH | DISP_DI_DFPL | DISP_DI_DVP1;

                /* Patch for 409, 410 18bit TTL panel */
                /* DFP_HIGH is disabled when check MB strapping, since 409 and 410 only */
                /* support LVDS0. But DFP_HIGH can be used and is needed for TTL, so we */
                /* enable it here to make TTL pass the check of DiPort. */
                pVia->MbDiPortUsedInfo &= ~DISP_DI_DFPH;

            } else {
                LcdCommonInfo->diPort = DISP_DI_DFPL | DISP_DI_DVP1;
            }
        } else {
            /*External and Hardwired use DVP1 as default DI port,
             * actually we recommend user set DI port on these cases! */
            LcdCommonInfo->diPort = DISP_DI_DVP1;
        }
    }

    /*If LCD DI port is free */
    if (checkDiPortUsage(pVia, LcdCommonInfo->diPort)) {
        /*If user use internal LVDS, but found platform don't support
         * internal LVDS or DI port set wrong, it will fail */
        if (LcdCommonInfo->type == DISP_TYPE_INTERNAL) {
            if ((INTERNAL_LVDS & pVia->GfxDispCaps) &&
                ((DISP_DI_DFPL | DISP_DI_DFPH) & LcdCommonInfo->diPort)) {
                LcdCommonInfo->subChipName = SUBCHIP_INTEGRATED_LVDS;
                /* default serial port (internal LVDS), NONE */
                if (LcdCommonInfo->serialPort == DISP_DEFAULT_SETTING) {
                    LcdCommonInfo->serialPort = DISP_SERIALP_NONE;
                }
                LcdCommonInfo->slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
                /* DI port is occupied */
                if (viaLcdInfo->dualChannel)
                    pVia->MbDiPortUsedInfo |= (DISP_DI_DFPL | DISP_DI_DFPH);
                else
                    pVia->MbDiPortUsedInfo |= LcdCommonInfo->diPort;
                retVal = TRUE;
            }
        } else if (LcdCommonInfo->type == DISP_TYPE_EXTERNAL) {
            /*3324, 3353, 3293 don't need to care SR12(MB strapping)
             * so MbDvp0Device will be 0, but other chip need. */
            if ((DISP_DI_DVP0 == LcdCommonInfo->diPort) &&
                !(DISP_DEV_LCD & pVia->MbDvp0Device)) {
                pVia->MbDiPortUsedInfo &= ~DISP_DI_DVP0;
                retVal = FALSE;
            } else {
                /* Sense VT1636 */
                if (senseSubChip(LcdCommonInfo, SUBCHIP_VT1636)) {
                    LcdCommonInfo->subChipName = SUBCHIP_VT1636;
                    LcdCommonInfo->slaveAddress = SUBCHIP_VT1636_SLAVE_ADDR;
                    if (LcdCommonInfo->ddcPort == DISP_DEFAULT_SETTING) {
                        LcdCommonInfo->ddcPort = LcdCommonInfo->serialPort;
                    }
                    pVia->MbDiPortUsedInfo |= LcdCommonInfo->diPort;
                    retVal = TRUE;
                }
            }
        } else if (LcdCommonInfo->type == DISP_TYPE_TTL) {
            LcdCommonInfo->subChipName = SUBCHIP_TTL;
            LcdCommonInfo->slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
            /* default serial port NONE */
            LcdCommonInfo->serialPort = DISP_SERIALP_NONE;
            pVia->MbDiPortUsedInfo |= LcdCommonInfo->diPort;
            retVal = TRUE;
        } else {
            /*Hardwried */
            LcdCommonInfo->subChipName = SUBCHIP_HARDWIRED_LVDS;
            LcdCommonInfo->slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
            /* No need to program subchip */
            LcdCommonInfo->serialPort = DISP_SERIALP_NONE;
            pVia->MbDiPortUsedInfo |= LcdCommonInfo->diPort;
            retVal = TRUE;
        }
    } else {
        /*if LCD DI port is occupied or unsupported */
        retVal = FALSE;
    }

    /* Patch for 409, 410 18bit TTL panel. */
    /* We enable DFP_HIGH when set TTL, but DFP_HIGH is not avaliable except TTL,
     * /* so we need to ensure DFP_HIGH is disabled again. */
    if (pVia->Chipset == VIA_VX855 || pVia->Chipset == VIA_VX900)
        pVia->MbDiPortUsedInfo |= DISP_DI_DFPH;

    return retVal;
}

static Bool
checkDPSupport(VIAPtr pVia, xf86OutputPtr output, CARD32 DPType)
{
    Bool retVal = FALSE;
    ViaDPPrivateInfoPtr viaDPInfo = output->driver_private;
    ScrnInfoPtr pScrn = output->scrn;

    /* default DP type is internal */
    if (viaDPInfo->commonInfo.type == DISP_DEFAULT_SETTING) {
        if (pVia->GfxDispCaps & INTERNAL_DP)
            /* if the chip have the cap of integrated DP */
            viaDPInfo->commonInfo.type = DISP_TYPE_INTERNAL;
        else
            /* if the chip doesn't have, return FALSE directly */
            return retVal;
    }

    /* internal DisplayPort */
    if (viaDPInfo->commonInfo.type == DISP_TYPE_INTERNAL) {
        /* if the platform doesn't support internal DP, it fails  */
        if (INTERNAL_DP & pVia->GfxDispCaps) {
            if (DPType == DISP_DEV_DP) {
                /* the internal DP1 using the same Path with internal HDMI */
                if (INTERNAL_HDMI & pVia->GfxDispCaps) {
                    viaDPInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_DP;
                    viaDPInitEPHY(output);
                    pVia->GfxDispCaps &= ~INTERNAL_HDMI;
                    retVal = TRUE;
                }
            } else {
                viaDPInfo->commonInfo.subChipName = SUBCHIP_INTEGRATED_DP2;
                viaDP2InitEPHY(output);
                retVal = TRUE;
            }
            viaDPInfo->commonInfo.slaveAddress = NONE_SUBCHIP_SLAVE_ADDR;
        }
    }

    return retVal;
}

xf86OutputPtr
viaOutputCreate(ScrnInfoPtr pScrn,
    const xf86OutputFuncsRec *funcs, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr output, *outputs;
    int len;

    if (name)
        len = strlen(name) + 1;
    else
        len = 0;

    output = calloc(sizeof(xf86OutputRec) + len, 1);
    if (!output)
        return NULL;
    output->scrn = pScrn;
    output->funcs = funcs;
    if (name) {
        output->name = (char *)(output + 1);
        strcpy(output->name, name);
    }

    if (pVia->ignoredOutput)
        outputs = realloc(pVia->ignoredOutput,
            (pVia->numIgnoredOutput + 1) * sizeof(xf86OutputPtr));
    else
        outputs =
            malloc((pVia->numIgnoredOutput + 1) * sizeof(xf86OutputPtr));
    if (!outputs) {
        free(output);
        return NULL;
    }

    pVia->ignoredOutput = outputs;
    pVia->ignoredOutput[pVia->numIgnoredOutput] = output;

    pVia->numIgnoredOutput++;

    return output;
}

void
via_crt_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr outputCrt;
    ViaCrtPrivateInfoPtr viaCrtInfo;

    outputCrt = xf86OutputCreate(pScrn, &via_crt_output_funcs, name);
    if (!outputCrt) {
        DEBUG(ErrorF("xf86OutputCreate %s Fail.\n", name));
        return;
    }
    viaCrtInfo = xnfcalloc(sizeof(ViaCrtPrivateInfo), 1);
    if (!viaCrtInfo) {
        xf86OutputDestroy(outputCrt);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }
    outputCrt->driver_private = viaCrtInfo;
    viaCrtInfo->commonInfo.rawEDID = NULL;

    /* Read CRT options in CRT monitor section */
    parseCrtOption(outputCrt);

    if (checkCrtSupport(pVia, outputCrt)) {
        outputCrt->possible_crtcs = 0x1 | 0x2;
        outputCrt->possible_clones = 0;
        outputCrt->interlaceAllowed = TRUE;
        outputCrt->doubleScanAllowed = FALSE;

        if (!xf86NameCmp(name, OUTPUT_CRT_NAME))
            pVia->crt1Created = TRUE;
    } else
        /* also free crt private date */
        xf86OutputDestroy(outputCrt);

}

void
via_dvi_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr outputDvi;
    ViaDviPrivateInfoPtr viaDviInfo;

    outputDvi = xf86OutputCreate(pScrn, &via_tmds_output_funcs, name);
    if (!outputDvi) {
        DEBUG(ErrorF("xf86OutputCreate %s Fail.\n", name));
        return;
    }
    viaDviInfo = xnfcalloc(sizeof(ViaDviPrivateInfo), 1);
    if (!viaDviInfo) {
        xf86OutputDestroy(outputDvi);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }
    outputDvi->driver_private = viaDviInfo;
    viaDviInfo->commonInfo.rawEDID = NULL;

    /* Read Dvi options in DVI monitor section */
    parseDviOption(outputDvi);

    if (checkDviSupport(pVia, outputDvi)) {
        if (viaDviInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_TMDS)
            pVia->numOfEmbDvi++;

        outputDvi->possible_crtcs = 0x1 | 0x2;
        outputDvi->possible_clones = 0;
        outputDvi->interlaceAllowed = FALSE;
        outputDvi->doubleScanAllowed = FALSE;

        if (!xf86NameCmp(name, OUTPUT_DVI_NAME))
            pVia->dvi1Created = TRUE;
    } else
        /* also free DVI private date */
        xf86OutputDestroy(outputDvi);

}

void
via_lcd_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr outputLcd;
    ViaLcdPrivateInfoPtr viaLcdInfo;

    outputLcd = xf86OutputCreate(pScrn, &via_lvds_output_funcs, name);
    if (!outputLcd) {
        DEBUG(ErrorF("xf86OutputCreate %s Fail.\n", name));
        return;
    }
    viaLcdInfo = xnfcalloc(sizeof(ViaLcdPrivateInfo), 1);
    if (!viaLcdInfo) {
        xf86OutputDestroy(outputLcd);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }
    outputLcd->driver_private = viaLcdInfo;
    viaLcdInfo->commonInfo.rawEDID = NULL;

    /* Read Lcd options in LCD monitor section */
    parseLcdOption(outputLcd);

    if (checkLcdSupport(pVia, outputLcd)) {
        if (viaLcdInfo->commonInfo.subChipName == SUBCHIP_INTEGRATED_LVDS) {
            pVia->numOfEmbLcd++;
            if (viaLcdInfo->dualChannel)
                pVia->dualChannelEmbLcdExist = TRUE;
        }

        if (viaLcdInfo->fixOnIGA1)
            outputLcd->possible_crtcs = 0x01;
        else
            outputLcd->possible_crtcs = 0x02;

        outputLcd->possible_clones = 0;
        outputLcd->interlaceAllowed = FALSE;
        outputLcd->doubleScanAllowed = FALSE;

        if (!xf86NameCmp(name, OUTPUT_LCD_NAME))
            pVia->lcd1Created = TRUE;
    } else
        /* also free LCD private date */
        xf86OutputDestroy(outputLcd);

}

void
via_dp_init(ScrnInfoPtr pScrn, const char *name)
{
    VIAPtr pVia = VIAPTR(pScrn);
    xf86OutputPtr outputDP;
    ViaDPPrivateInfoPtr viaDPInfo;

    outputDP = xf86OutputCreate(pScrn, &via_dp_output_funcs, name);
    CARD32 DPType = DISP_DEV_DP;

    if (!outputDP) {
        DEBUG(ErrorF("xf86OutputCreate %s Fail.\n", name));
        return;
    }
    viaDPInfo = xnfcalloc(sizeof(ViaDPPrivateInfo), 1);
    if (!viaDPInfo) {
        xf86OutputDestroy(outputDP);
        DEBUG(ErrorF("Allocate %s private info Fail.\n", name));
        return;
    }
    outputDP->driver_private = viaDPInfo;
    viaDPInfo->commonInfo.rawEDID = NULL;

    /* Read DP options in DP monitor section */
    parseDPOption(outputDP);

    if (!xf86NameCmp(name, "DP-2")) {
        DPType = DISP_DEV_DP2;
    }

    if (checkDPSupport(pVia, outputDP, DPType)) {
        outputDP->possible_crtcs = 0x1 | 0x2;
        outputDP->possible_clones = 0;
        outputDP->interlaceAllowed = FALSE;
        outputDP->doubleScanAllowed = FALSE;
    } else
        /* also free DP private date */
        xf86OutputDestroy(outputDP);
}

void
via_output_init(ScrnInfoPtr pScrn)
{
    VIAPtr pVia = VIAPTR(pScrn);

    /* init value */
    pVia->numOfEmbLcd = 0;
    pVia->numOfEmbDvi = 0;
    pVia->dualChannelEmbLcdExist = FALSE;
    pVia->numOfEmbTv = 0;

    pVia->crt1Created = FALSE;
    pVia->lcd1Created = FALSE;
    pVia->dvi1Created = FALSE;
    pVia->tv1Created = FALSE;
    pVia->hdmi1Created = FALSE;

    pScrn->adjustFlags |= INTERLACE_HALVE_V;
    /* CRT1 */
    via_crt_init(pScrn, OUTPUT_CRT_NAME);

    /* HDMI */
    via_hdmi_init(pScrn, OUTPUT_HDMI_NAME);

    /* LCD1 */
    via_lcd_init(pScrn, OUTPUT_LCD_NAME);

    /* TV1 */
    via_tv_init(pScrn, OUTPUT_TV_NAME);

    /* DVI1 */
    via_dvi_init(pScrn, OUTPUT_DVI_NAME);

    /* DisplayPort */
    via_dp_init(pScrn, OUTPUT_DP_NAME);

    /* DisplayPort2 */
    via_dp_init(pScrn, OUTPUT_DP2_NAME);

    /* LCD2 */
    if (pVia->lcd1Created)
        via_lcd_init(pScrn, OUTPUT_LCD2_NAME);

    /* TV2 */
    if (pVia->tv1Created)
        via_tv_init(pScrn, OUTPUT_TV2_NAME);

    /* DVI2 */
    if (pVia->dvi1Created)
        via_dvi_init(pScrn, OUTPUT_DVI2_NAME);

    /* HDMI2 */
    if (pVia->hdmi1Created)
        via_hdmi_init(pScrn, OUTPUT_HDMI2_NAME);

    /* CRT2 */
    if (pVia->crt1Created)
        via_crt_init(pScrn, OUTPUT_CRT2_NAME);

}

#endif /*VIA_RANDR12_SUPPORT */
