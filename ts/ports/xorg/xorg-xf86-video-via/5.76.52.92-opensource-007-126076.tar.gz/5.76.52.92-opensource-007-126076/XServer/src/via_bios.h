/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef _VIA_BIOS_H_
#define _VIA_BIOS_H_ 1

/* ------- mergedfb support ------ */
    /* Psuedo Xinerama support */
#define NEED_REPLIES          /* ? */
#define EXTENSION_PROC_ARGS void *
#include "extnsionst.h"      /* required */
#include "panoramiXproto.h"      /* required */
#define VIA_XINERAMA_MAJOR_VERSION  1
#define VIA_XINERAMA_MINOR_VERSION  1

#ifdef XF86DRI
#include "xf86drm.h"
#include "sarea.h"
#endif

#define IGA_NONE  0
#define IGA1        1
#define IGA2        2


/* Video Mode Index (FB device driver's res. index)*/
#define M480x640        0x000
#define M640x480        0x001
#define M720x480        0x002
#define M720x576        0x003
#define M800x480        0x004
#define M800x600        0x005
#define M848x480        0x006
#define M852x480        0x007
#define M960x600        0x008
#define M1000x600       0x009
#define M1024x512       0x00A
#define M1024x576       0x00B
#define M1024x600       0x00C
#define M1024x768       0x00D
#define M1024x768_I     0x20D   /* Interlace Mode */
#define M1088x612       0x00E
#define M1152x720       0x00F
#define M1152x864       0x010
#define M1152x864_I     0x210   /* Interlace Mode */
#define M1200x720       0x011
#define M1280x600       0x012
#define M1280x720       0x013
#define M1280x768       0x014
#define M1280x800       0x015
#define M1280x960       0x016
#define M1280x1024      0x017
#define M1280x1024_I    0x217   /* Interlace Mode */
#define M1360x768       0x018
#define M1360x768_RB    0x118   /* Reduce Banking */
#define M1366x768       0x019
#define M1368x768       0x01A
#define M1400x1050      0x01B
#define M1400x1050_RB   0x11B   /* Reduce Banking */
#define M1440x900       0x01C
#define M1440x900_RB    0x11C   /* Reduce Banking */
#define M1440x1050      0x01D
#define M1600x900       0x01E
#define M1600x900_RB    0x11E   /* Reduce Banking */
#define M1600x1024      0x01F
#define M1600x1200      0x020
#define M1600x1200_I    0x220   /* Interlace Mode */
#define M1680x600       0x021
#define M1680x1050      0x022
#define M1680x1050_RB   0x122   /* Reduce Banking */
#define M1792x1344      0x023
#define M1856x1392      0x024
#define M1920x1080      0x025
#define M1920x1080_RB   0x125   /* Reduce Banking */
#define M1920x1080_I    0x225   /* Interlace Mode */
#define M1920x1200      0x026
#define M1920x1200_RB   0x126   /* Reduce Banking */
#define M1920x1440      0x027
#define M2048x1536      0x028
#define M800x480_GEN    0x029   /* General timing, only for LCD*/
#define M720x400        0x030
#define M832x624        0x031
#define M1280x854       0x032
#define M_INVALID       0xFFF


/*Generate a index according to width and height*/
#define     VIA_MAKE_ID(w,h)                (((h) << 16) | (w))

/*via index for tv and lcd use*/
#define     VIA_480X640                 VIA_MAKE_ID(480,640)
#define     VIA_640X480                 VIA_MAKE_ID(640,480)
#define     VIA_800X600                 VIA_MAKE_ID(800,600)
#define     VIA_800X480_GEN             VIA_MAKE_ID(800,480)
#define     VIA_800X480                 VIA_MAKE_ID(800,480)
#define     VIA_1024X600                VIA_MAKE_ID(1024,600)
#define     VIA_1024X768                VIA_MAKE_ID(1024,768)
#define     VIA_848X480                 VIA_MAKE_ID(848,480)
#define     VIA_720X480                 VIA_MAKE_ID(720,480)
#define     VIA_720X576                 VIA_MAKE_ID(720,576)
#define     VIA_1280X720                VIA_MAKE_ID(1280,720)
#define     VIA_1280X768                VIA_MAKE_ID(1280,768)
#define     VIA_1280X800                VIA_MAKE_ID(1280,800)
#define     VIA_1280X1024               VIA_MAKE_ID(1280,1024)
#define     VIA_1360X768                VIA_MAKE_ID(1360,768)
#define     VIA_1366X768                VIA_MAKE_ID(1366,768)
#define     VIA_1440X900                VIA_MAKE_ID(1440,900)
#define     VIA_1400X1050               VIA_MAKE_ID(1400,1050)
#define     VIA_1600X1200               VIA_MAKE_ID(1600,1200)
#define     VIA_1920X1080               VIA_MAKE_ID(1920,1080)
#define     VIA_INVALID                 0

/*Get LCD panel size from panel ID*/
#define     VIA_PANEL_WIDTH(ID)             ((ID) & 0xFFFF)
#define     VIA_PANEL_HEIGHT(ID)            (((ID)>> 16) & 0xFFFF)

#define     VIA_NONETRANSMITTER             0x00
#define     VIA_VT1631                      0x01
#define     VIA_VT1632                      0x09
#define     VIA_VT1636                      0x0E    /* VT1636 LVDS. */
#define     VIA_Hardwired                   0x0F
#define     VIA_INTEGRATED_LVDS             0x41
#define     VIA_INTEGRATED_TMDS             0x42
#define     VIA_INTEGRATED_DP               0x43
#define     VIA_INTEGRATED_DP2              0x44
#define     VIA_INTEGRATED_HDMI             0x46
#define     VIA_AD9389                      0x10  /*HDMI*/
#define     CHIPID_SIL164                   0x45


#define     TVTYPE_NONE                     0x00
#define     TVTYPE_NTSC                     0x01
#define     TVTYPE_PAL                      0x02
#define     TVTYPE_480P                     0X03
#define     TVTYPE_576P                     0X04
#define     TVTYPE_720P                     0X05
#define     TVTYPE_1080I                    0X06

/* Definition TV Ouput Signal */
#define     TV_OUTPUT_NONE                      0
#define     TV_OUTPUT_COMPOSITE                 1
#define     TV_OUTPUT_SVIDEO                    2
#define     TV_OUTPUT_COMPOSITE_SVIDEO          3
#define     TV_OUTPUT_RGB                       4
#define     TV_OUTPUT_YPBPR                     5
#define     TV_OUTPUT_RGB_COMPOSITE             6
#define     TV_OUTPUT_YPBPR_COMPOSITE           7
#define     TV_OUTPUT_SDTV_PROGRESSIVE_RGB      8
#define     TV_OUTPUT_SDTV_PROGRESSIVE_YPBPR    9
#define     TV_OUTPUT_HDTV_720P_RGB             10
#define     TV_OUTPUT_HDTV_720P_YPBPR           11
#define     TV_OUTPUT_HDTV_1080I_RGB            12
#define     TV_OUTPUT_HDTV_1080I_YPBPR          13
#define     TV_OUTPUT_HDTV_1080P_RGB            14
#define     TV_OUTPUT_HDTV_1080P_YPBPR          15
#define     TV_OUTPUT_DEDOTCRAWL                16
#define     TV_OUTPUT_YPBPR_COMPOSITE_SVIDEO    17
#define     TV_OUTPUT_RGB_COMPOSITE_SVIDEO      18

#define     VIA_NONETV                      0
#define     VIA_VT1625                      11      /* VT1625 */
#define     VIA_INTEGRATED_TV               12      /* Integrated TV */

#define     VIA_TVNORMAL                    0
#define     VIA_TVFIT                       1
#define     VIA_TVOVER                      2

#define     VIA_NO_TVSCALE                  0
#define     VIA_TVSCALE1                    1
#define     VIA_TVSCALE2                    2
#define     VIA_TVSCALE3                    3
#define     VIA_TVSCALE4                    4
#define     VIA_TVSCALE5                    5


#define     VIA_DEVICE_CRT1                 0x01
#define     VIA_DEVICE_LCD                  0x02
#define     VIA_DEVICE_TV                   0x04
#define     VIA_DEVICE_DFP                  0x08
#define     VIA_DEVICE_CRT2                 0x10
#define     VIA_DEVICE_LCD2                 0x20
#define     VIA_DEVICE_TV2                  0x40
#define     VIA_DEVICE_DFP2                 0x80
#define     VIA_DEVICE_HDMI                 0x100
#define     VIA_DEVICE_HDMI2                0x200
#define     VIA_DEVICE_DP                   0x400
#define     VIA_DEVICE_DP2                  0x800
#define     VIA_DEVICE_ALL                  0xFFF
/* bytes */ /* We reserve 3MB now. */
#define INTEGRATED_TV_BUFFER_SIZE   0x300000


/* Digital Output Bus Width */
#define        VIA_DI_12BIT                    0x00
#define        VIA_DI_24BIT                    0x01

/* For 205 or later, there are many case for digital out put.
 * for example: TV can use DVP0(AMR slot), DFP High-half, DFP Low-half
 *              or DVP1 (mobile version).
 * We must distinguish which digital port has been using by device.
 */
/* Digital Output Bus Port */
#define     VIA_DI_NONE                     0x000
#define     VIA_DI_DVP0                     0x001
#define     VIA_DI_DVP1                     0x002
#define     VIA_DI_DFPHIGH                  0x004
#define     VIA_DI_DFPLOW                   0x008
#define     VIA_DI_DFPHIGHLOW               0x010
#define     VIA_DI_LVDS0                    0x020
#define     VIA_DI_LVDS1                    0x040
#define     VIA_DI_LVDS0LVDS1               0x080
#define     VIA_DI_TMDS                     0x100
#define     VIA_DI_LVDS0DVP1                0x200
#define     VIA_DI_LVDS1DVP1                0x400
#define     VIA_DI_TTL                      0x800
#define     VIA_DI_LVDS0LVDS1DVP1           0x1000
#define     VIA_DI_PHY                      0x2000


#define     NOT_FOUND_DEV               0
#define     FOUND_INTERNAL_DEV          1
#define     FOUND_EXTERNAL_DEV_BY_I2C   2
#define     FOUND_EXTERNAL_DEV_BY_GPIO  3

/* Definition TV Encoder I2C Slave Address */
#define     TV_I2C_ADDR_VT1625      0x40

/* LVDS Transmitter I2C Slave Address */
#define     LVDS_I2C_ADDR_VT1636    0x80
#define     LVDS_I2C_ADDR_VT1631    0x70
#define     LVDS_I2C_ADDR_CHRONTEL  0xEA

/*for 3D scaling function used for multi-device*/
#define DISP_3D_SCALING_ENABLE          0x8000
#define DISP_3D_SCALING_BUFNUM_ONESET   3
/* We reserve 9MB for each scaling buffernow. */
#define DISP_3D_SCALING_BUFFER_SIZE     0x900000  /* bytes */

/* For VT3353 */
/* There is no need to focus on 353 A now, thus not specify the revison for A*/
#define REVISION_VX800_A    0x3530f
#define REVISION_VX800_B0    0x35310
#define REVISION_VX800_B1    0x35311
#define REVISION_VX800_B2   0x35312

/* For VT3409 */
#define REVISION_VX855_A0    0x40900
#define REVISION_VX855_A1    0x40901
#define REVISION_VX855_A2    0x40902

/* For VT3410 */
#define REVISION_VX900_A0   0x41000
#define REVISION_VX900_A1   0x41001
#define REVISION_VX900_A2   0x41002
#define REVISION_VX900_A3   0x41003


/*for mergedfb*/
typedef enum {
   viaLeftOf,
   viaRightOf,
   viaAbove,
   viaBelow,
   viaClone
} VIAScrn2Rel;


typedef struct _GPIOI2C_INFO
{
    CARD8       bGPIOPort;
    CARD8       bSlaveAddr;
    int         I2C_WAIT_TIME;
    int         STARTTIMEOUT;
    int         BYTETIMEOUT;
    int         HOLDTIME;
    int         BITTIMEOUT;
} GPIOI2C_INFO, *PGPIOI2C_INFO;


typedef struct _3DSCAL_SCREENPARAS
{
    /* DISPLAY 3D SCALING PARAMETERS*/
    /* The Max size(physical size,unit:pixel) */
    long            XSIZEMax;
    long            YSIZEMax;

    /*/adjust size*/
    /* this is the range  parametsers for SIZE (unit:pixel)*/
    long            XSIZEMaxRange;
    long            YSIZEMaxRange;

    /*  step of X, Y scaling step value(unit:pixel)*/
    long            XScaleStep;
    long            YScaleStep;

    /* X Current Scale level [0~MAX-1](unit:Level)*/
    long            XScaleLevel;
    /* X Default Scale level*/
    long            XScaleDefault;
    /* X  max Scale level*/
    long            XScaleMaximum;

    long            YScaleLevel;
    long            YScaleDefault;
    long            YScaleMaximum;

    /* the scaling offset of the size*/
    long            XSIZEOffset;
    long            YSIZEOffset;

    /* the scaling result of the size*/
    long            XSIZENow;
    long            YSIZENow;

    /*adjust position*/
    /* this is the range  parametsers for position (unit:pixel)*/
    long            XPOSITIONMaxRange;
    long            YPOSITIONMaxRange;

    /*  Position adjust step value(unit:pixel)*/
    long            XPOSITIONStep;
    long            YPOSITIONStep;

    /* X current position level [0~MAX-1](unit:level)*/
    long            XPOSITIONLevel;
    /* X position level default value*/
    long            XPOSITIONDefault;
    /* X position max level*/
    long            XPOSITIONMaximum;

    long            YPOSITIONLevel;
    long            YPOSITIONDefault;
    long            YPOSITIONMaximum;

    /* the scaling offset of the POSITION*/
    long            XPOSITIONOffset;
    long            YPOSITIONOffset;

    long            XPOSITIONNow;
    long            YPOSITIONNow;

    /*flag to black the borders when adjust size and position*/
    Bool              bNeedBlack3dScalingBorders;
    CARD32            AspectStatus;     /* Aspect ratio lock*/
} VIA3DSclSCRNParas, *VIA3DSclSCNParasPtr;


typedef struct _VIADISP3DSCALCTRL
{
    Bool    getShareArea;
    drm_context_t     xcontext;
    int     drmFD;
    unsigned int hSArea;
    unsigned int pSArea;
    drmLock    *plock;
    int     VirtualHActive;
    int     OrigHActive;
    int     OrigVActive;
    int     RealHActive;
    int     RealVActive;
    int     BitsPerPixel;
    int     DISP3DScalIGAPath;
    int     OrigFBAddress;
    int     PanningX;
    int     PanningY;
    int     DISP3DScalingBufIndex; /*the buffer is on screen now*/
    CARD32  DISP3DScalingBufPitch;
    CARD32  DISP3DScalingBufAddr[DISP_3D_SCALING_BUFNUM_ONESET];
    int     CursorX;
    int     CursorY;
}VIADISP3DSCALCTRL, *VIADISP3DSCALCTRLPtr;

typedef struct _TVINFO
{
    Bool    HasUserSetting;

    CARD32  DefaultScalH;
    CARD32  CurrentScalH;
    CARD32  ScalHLevel;

    CARD32  DefaultScalV;
    CARD32  CurrentScalV;
    CARD32  ScalVLevel;

    CARD32  DefaultPositionH;
    CARD32  CurrentPositionH;
    CARD32  PositionHLevel;

    CARD32  DefaultPositionV;
    CARD32  CurrentPositionV;
    CARD32  PositionVLevel;

    Bool    AdaptiveFFilterOn;

    CARD32  DefaultFFilter;
    CARD32  CurrentFFilter;
    CARD32  FFilterLevel;

    CARD32  DefaultAFFilter;
    CARD32  CurrentAFFilter;
    CARD32  AFFilterLevel;

    CARD32  DefaultBrightness;
    CARD32  CurrentBrightness;
    CARD32  BrightnessLevel;

    CARD32  DefaultContrast;
    CARD32  CurrentContrast;
    CARD32  ContrastLevel;

    CARD32  DefaultSaturation;
    CARD32  CurrentSaturation;
    CARD32  SaturationLevel;

    CARD32  DefaultTINT;
    CARD32  CurrentTINT;
    CARD32  TINTLevel;
    /*the size and position info for scaling*/
    CARD32  XScalingLevel;
    CARD32  YScalingLevel;
    CARD32  XScalPosLevel;
    CARD32  YScalPosLevel;
} TVInfoRec, *TVInfoPtr;


typedef struct _CRTSETTINGINFO {
    int     ModeIndex;
    int     HActive;
    int     VActive;
    int     IGAPath;
    int     MonitorSizeH;
    int     MonitorSizeV;
    int     PreferModeH;
    int     PreferModeV;
    Bool    IsPanning;
    Bool    IsFlatMonitor;
    int     MaxPixelClock;
} CRTSETTINGINFO, *CRTSETTINGINFOPTR;


typedef struct _TMDSSETTINGINFO {
    unsigned char   ChipID;
    int             I2CPort;
    unsigned char   I2CAddress;
    int             DFPSize;        /* DVI panel size */
    int             DFPDIPort;      /* DVI DI port */
    int     ModeIndex;
    int     HActive;
    int     VActive;
    int     IGAPath;
    CARD32     PanelSizeH;
    CARD32     PanelSizeV;
    Bool    IsPanning;
    Bool    IsDownScaling;
    int     MaxPixelClock;
    VIA3DSclSCRNParas DVI3DScalInfo;
    Bool    IsPreSetting;
    Bool   HasUserSetting;
    long    XScalingLevel;
    long    YScalingLevel;
    long    XScalPosLevel;
    long    YScalPosLevel;
    /* For VT3410 internal HDMI tranmitter 640x480 issue */
    Bool    Is640x480Mode;
} TMDSSETTINGINFO, *TMDSSETTINGINFOPTR;


typedef struct _LVDSSETTINGINFO {
    unsigned char   ChipID;
    int             I2CPort;
    unsigned char   I2CAddress;
    /* Digital Output Bus Width */
    unsigned char   BusWidth;
    /* mean add-on card is 2CH or Dual or DDR */
    Bool    IsDualEdge;
    /* Dithering Enable is for 18 bits panel and Disable is for 24 bits panel.*/
    Bool    IsDithering;
    int     DIPort;
    int     IGAPath;
    CARD32  VClk;           /* Clock of the mode table. */
    int     PanelSizeID;    /* LCD panel size ID */
    int     PanelSizeX;
    int     PanelSizeY;
    int     ModeIndex;
    int     HActive;
    int     VActive;
    Bool    Center;
    Bool    IsPanning;
    Bool    IsDownScaling;
    VIA3DSclSCRNParas LCD3DScalInfo;
    Bool    IsPreSetting;
    Bool    HasUserSetting;
    long    XScalingLevel;
    long    YScalingLevel;
    long    XScalPosLevel;
    long    YScalPosLevel;
    Bool    MsbEnable;           /* data ouput format is MSB or not */
} LVDSSETTINGINFO, *LVDSSETTINGINFOPTR;


typedef struct _TVSETTINGINFO {
    int     ModeIndex;
    int     HActive;
    int     VActive;
    int     IGAPath;
    Bool    IsPanning;
    int     TVEncoder;
    int     TVType;
    int     TVOutput;
    int     TVVScan;
    unsigned int    resTVMode;
    Bool    TVDotCrawl;
    int     TVHScale;
    int     TVVScale;
    VIA3DSclSCRNParas TV3DScalInfo;
    TVInfoRec TVInfo;
    Bool    TVTypeIsNTSCJ;
    Bool    IsPreSetting;
    Bool    TVAutoSense;  /*only affect VT1625*/
} TVSETTINGINFO, *TVSETTINGINFOPTR;


typedef struct _HDMISETTINGINFO {
    CARD8   ChipID;
    int     HDMIDIPort;
    int     I2CPort;
    CARD8   I2CAddress;
    CARD8   SinkDevType;
    int     ModeIndex;   /* Desired Mode */
    int     HActive;
    int     VActive;
    int     IGAPath;
    int     NativeSizeID;
    CARD32  PanelSizeH;
    CARD32  PanelSizeV;
    Bool    IsPanning;
    Bool    IsDownScaling;
    int     PixelClock;
    int     MaxPixelClock;
    Bool    IsPreSetting;
    Bool    HasUserSetting;
    VIA3DSclSCRNParas HDMI3DScalInfo;
    long    XScalingLevel;
    long    YScalingLevel;
    long    XScalPosLevel;
    long    YScalPosLevel;
    CARD8   SavedReg[0xC9];
} HDMISETTINGINFO, *HDMISETTINGINFOPTR;

#include "hw.h"

typedef struct _DPSETTINGINFO {
    CARD8   ChipID;
    int     I2CPort;
    CARD8   I2CAddress;
    int     ModeIndex;   /* Desired Mode */
    int     HActive;
    int     VActive;
    int     IGAPath;
    CARD32  PanelSizeH;
    CARD32  PanelSizeV;
    Bool    IsPanning;
    int     DPSize;        /* DP panel size */
    Bool    IsDownScaling;
    int     MaxPixelClock;
    int     LinkSpeed;
    int     DPCDVersion;
    CARD32  TURatio;
    Bool IsLinkTrainingDone;
} DPSETTINGINFO, *DPSETTINGINFOPTR;


typedef struct _IGASETTINGINFO {
    Bool    IsPanning;
    Bool    IsDownScaling;
    Bool    IsDISP3DScaling;
    int     HActive;
    int     VActive;
    /* record the value we down timing(HActive),
       is used for video parameter transfer*/
    int     CrtcWidth;
    /* record the value we down timing(VActive),
       is used for video parameter transfer*/
    int     CrtcHeight;
    int     CountWidthByQWord;
    int     OffsetWidthByQWord;
    /* If not panning, we can use this flag to force to reset */
    /* starting address when set mode. */
    Bool    SetStartingAddrFirstTime;
    /* Use to indicate if this IGA is in use. */
    Bool    IsActive;
    VIADISP3DSCALCTRL DISP3DSCALCTRLInfo;
    CARD16  deviceActived;
} IGASETTINGINFO, *IGASETTINGINFOPTR;


/****************************************************************************/
/*                  Transmitter DPA Setting Structure                       */
/****************************************************************************/
#include "via_tblDPASetting.h"

/* For adjusting DPA by option. (User Specified)*/
typedef struct VT1636_DPA_SETTING {
    int     PanelSizeID;
    CARD8   CLK_SEL_ST1;
    CARD8   CLK_SEL_ST2;
} VT1636DPASETTING, *VT1636DPASETTINGPTR;


typedef struct USER_DPA_SETTING_INFO {
    Bool                    HasUserSetting_Gfx;
    Bool                    HasUserSetting_VT1636;
    Bool                    HasUserSetting_VT1625;
    GFX_DPA_VALUE   GfxDPA;
    VT1636DPASETTING        VT1636DPA;
    CARD8                   VT1625DPA;
} USERDPASETTINGINFO, *USERDPASETTINGINFOPTR;

/****************************************************************************/
/*                  VIA BIOS INFO Structure                                 */
/****************************************************************************/
typedef struct _VIABIOSINFO {

    int                 Chipset;
    int                 ChipRev;
    unsigned char*      MapBase;
    Bool                FirstInit;
    unsigned char*      FBBase;
    unsigned char*      IntegratedTVMapBase;
    unsigned long       videoRambytes;
    int                 scrnIndex;

    int                 countWidthByQWord;
    int                 offsetWidthByQWord;
    Bool                EnableExtendedFIFO;

    CARD16              ConnectedDevice;

    /*
       On the SAMM mode, pBIOSInfo->ActiveDevice only keep its own device state.
       So we can't know whose devices are actually active.
       So I add this variable to keep the actual active device state.
    */
    CARD32              ActualActiveDevice;
    /* For integrated TV sense only. */
    Bool                FirstTimeToSenseIntegratedTV;

    /* Here are all the BIOS Relative Options */
    /* Simplify Device ID + Revision ID combination */
    int                 dwProjectIDRevision;
    Bool                IsBiosSupportLCD;
    Bool                TwoCRT;     /*for Dual CRT with TV card vt1625*/
    Bool                DuoView;    /*=* DuoView, only support for CN400 *=*/
    Bool                Panning;    /* Virtual Desktop or Not ? */
    int                 TVDIPort;
    int                 CRTDIPort;
    int                 OptRefresh;
    int                 Refresh;
    int                 FoundRefresh;

    CRTSETTINGINFO      CRTSettingInfo;
    TVSETTINGINFO       TVSettingInfo;
    TMDSSETTINGINFO     TMDSSettingInfo;
    LVDSSETTINGINFO     LVDSSettingInfo;    /* For LCD1. */
    HDMISETTINGINFO     HDMISettingInfo;
    DPSETTINGINFO       DPSettingInfo;      /* For DisplayPort */

    /* For dual devices, like dual LCD, dual TV. Only for VT3324 now. */
    TVSETTINGINFO       TVSettingInfo2;
    LVDSSETTINGINFO     LVDSSettingInfo2;   /* For LCD2. */
    CRTSETTINGINFO      CRTSettingInfo2;    /* For CRT2 on VT1625. */
    DPSETTINGINFO       DPSettingInfo2;      /* For DisplayPort */
    TMDSSETTINGINFO     TMDSSettingInfo2;   /*For integrated DVI */
    HDMISETTINGINFO     HDMISettingInfo2;   /* For HDMI2 */

    /* IGA setting */
    IGASETTINGINFO      IGA1SettingInfo;
    IGASETTINGINFO      IGA2SettingInfo;

    USERDPASETTINGINFO  UserDPASettingInfo;

    /* LCD Simultaneous Expand Mode HWCursor Y Scale */
    Bool                scaleY;

    /* Some Used Member of ScrnInfoRec */
    int                 bitsPerPixel;   /* fb bpp */
    int                 displayWidth;   /* memory pitch */
    int                 frameX1;        /* viewport position */
    int                 frameY1;
    int                 VirtualX;
    int                 VirtualY;
    int                 ActualDesktopSizeX;
    int                 ActualDesktopSizeY;

    /* Some Used Member of DisplayModeRec */
    int                 Clock;          /* pixel clock freq */
    int                 HTotal;
    int                 VTotal;
    int                 HDisplay;       /* horizontal timing */
    int                 VDisplay;       /* vertical timing */
    int                 SaveHDisplay;
    int                 SaveVDisplay;
    int                 CrtcHDisplay;
    int                 CrtcVDisplay;
    int                 SaveVirtualX;
    int                 SaveVirtualY;

    /* For HW strapping issue. */
    int                 TVI2CPort;

    /* I2C & DDC */
    GPIOI2C_INFO        GPIOI2CInfo;

    unsigned char       TVI2CAdd;
    unsigned char       TVRegs[0xFF];

    /* MHS */
    CARD16              PrimaryDevice;

    /* Utility User Setting */
    /* Gamma value. LOCO typedef in colormapst.h */
    LOCO                colors[256];
    /*The function call is from s3utility*/
    Bool                s3utility;

    /*for mergedfb*/
    Bool                MergedFB;
    VIAScrn2Rel         Scrn2Position;

    int                 maxScrn1_X1, maxScrn1_X2, maxScrn1_Y1, maxScrn1_Y2;
    int                 maxScrn2_X1, maxScrn2_X2, maxScrn2_Y1, maxScrn2_Y2;
    Bool                UseVIAXinerama;

    ExtensionEntry*     XineramaExtEntry;
    int                 VIAXineramaVX, VIAXineramaVY;

    /*to set secondary screen's start address*/
    int                 HalfLine;
    unsigned long       HalfScreen;

    /* For utility api. */
    ExtensionEntry*     DisplayExtEntry;

    /* Display SW 3D scaling function enable flag */
    /* Reprent the TV scaling function are enable and
       which device with this function*/
    unsigned long       Is3DScalingEnable;
    Bool                IsStableStatus;

    /* Move NoDDCValue from VIAPtr struct to here. */
    Bool                NoDDCValue;

    /* For Down Scale Used */
    Bool                IsDownScaleEnable;
    int                 HorDownScaleSize;
    int                 VerDownScaleSize;

    /* For interlace mode. */
    Bool                IsEnableInterlaceMode;

    Bool                IsExtend;

    /* For auto detection and mode line */
    Bool                IsAutoDectectEnable;
    int                 ModeLineStatus;
    int                 EDIDType;
    Bool                isPanelModeLine;
    struct crt_mode_table UserSpecifiedMode;
} VIABIOSInfoRec, *VIABIOSInfoPtr;

typedef struct _VIASUPPORTMODE {
    char  Name[10];
    int   ModeIndex;
    int   HActive;
    int   VActive;
} VIASUPPORTMODE;


/* Functions protype */

Bool VIAFindRefreshRate(VIABIOSInfoPtr pBIOSInfo, int ModeIndex);
Bool VIAFindModeUseBIOSTable(ScrnInfoPtr pScrn);
extern _X_EXPORT void VIADelayIn_usec(VIABIOSInfoPtr pBIOSInfo, int usec);
int VIAGetModeIndex(int HorResolution, int VerResolution);
void VIAGetModeSizeByName(char *pName, int *pHSize, int *pVSize);

void ViaModesAttachHelper(ScrnInfoPtr pScrn, MonPtr monitorp,
        DisplayModePtr Modes);

int VIAGetFBSize(ScrnInfoPtr pScrn); /* query NB to get frame buffer size */

#endif  /* _VIA_BIOS_H_ */

