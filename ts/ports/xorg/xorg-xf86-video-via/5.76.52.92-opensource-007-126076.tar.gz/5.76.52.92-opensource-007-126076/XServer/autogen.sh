#! /bin/sh

CONFIGURE_AC="./configure.ac"
SRC_MAKEFILE_AM="./src/Makefile.am"

# input    : sub module's path name
# function : to Modify the file "configure.ac" and "./src/Makefile.am"
ModifyFiles()
{
    # delete SubModule component in ./configure.ac and ./src/Makefile.am fisrt, no matter it is exist or not.
    sed -i "/src\/$1\/Makefile/"d $CONFIGURE_AC 
    sed -i "s/ $1//g" $SRC_MAKEFILE_AM
    if [  -d "./src/$1" ];  then              # if the SubModule exists
        # add string to the end of line beginning of "SUBDIRS" in src/Makefile.am
        sed -i "/^SUBDIRS/s/$/ $1/" $SRC_MAKEFILE_AM
        # add a line below the line "man/Makefile" in configure.ac
        sed -i "/man\/Makefile/a\	src\/$1\/Makefile" $CONFIGURE_AC
        echo ".... SubModule <$1> found."
    else
        echo ".... SubModule <$1> not found."
    fi
}

srcdir=`dirname $0`
test -z "$srcdir" && srcdir=.

ORIGDIR=`pwd`
cd $srcdir
if [ ! -d m4 ];then
    mkdir  m4
fi

#ModifyFiles vt1625
#ModifyFiles AD9389
#ModifyFiles SIL164
#ModifyFiles CH7301

autoreconf -v --install || exit 1
cd $ORIGDIR || exit $?

$srcdir/configure --enable-maintainer-mode --disable-debug "$@"
