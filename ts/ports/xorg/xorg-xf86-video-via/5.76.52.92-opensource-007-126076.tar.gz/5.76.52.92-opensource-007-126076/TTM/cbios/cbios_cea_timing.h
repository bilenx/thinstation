/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_uma.h"

// CEA 861 Timing Tbl
typedef struct _CEA_861_Timing_Tbl
{
    WORD    Video_ID_Code;                // Video ID code

    WORD    rRateX100;                    // RefreshRate
    DWORD   PLL_SEED;                     // Seed to generate MRN value
    DWORD   PLL_MRN;                      // HW PLL value with format 0MRN 

    BYTE    HPolarity;                    // H Sync Polarity  
    BYTE    VPolarity;                    // V Sync Polarity
    BYTE    AspectRatio;                  // Format Aspect Ratio 

    WORD    HTotal;                       // HTotal     
    WORD    HDisEnd;                      // HDisEnd    
    WORD    HBlankStart;                  // HBlankStart    
    WORD    HBlankEnd;                    // HBlankEnd      
    WORD    HSyncStart;                   // HSyncStart 
    WORD    HSyncEnd;                     // HSyncEnd   
    WORD    VTotal;                       // VTotal     
    WORD    VDisEnd;                      // VDisEnd    
    WORD    VBlankStart;                  // VBlankStart    
    WORD    VBlankEnd;                    // VBlankEnd      
    WORD    VSyncOffset;                  // VSyncOffset (in pixel clock cycle)  
    WORD    VSyncStart;                   // VSyncStart 
    WORD    VSyncEnd;                     // VSyncEnd 

    BYTE    Interlaced;                   // Interlace or progressive
    
}CEA_861_Timing_Tbl, *PCEA_861_Timing_Tbl;  

typedef struct _CEA861_FORMAT_RES
{
    WORD    Video_ID_Code;                  // Video ID code
    WORD    XRes;                           // H Resolution size
    WORD    YRes;                           // V Resolution size
    WORD    rRateX100;                      // refresh rate
    BYTE    Interlaced;                     // Interlace or progressive
    BYTE    isvalid;                        // depend on HW, 409 support interlace mode
}CEA861_FORMAT_RES, *PCEA861_FORMAT_RES;

// current CEA_861 spec defines 59 formats
// video code ID from 1 to 59
#define CEA861_FORMAT_NUM       59
// current CEA supports 5 basic resolutions
#define CEA861_FORMAT_RES_NUM   (5*2)
// current CEA duplicated mode number
extern const DWORD CEA_DUPLICATED_MODE_NUM;

// CEA extension format resolution table
extern const DWORD CEA861_FormatResTbl[CEA861_FORMAT_RES_NUM];
// CEA extension format and H / V resolution mapping table
extern const CEA861_FORMAT_RES CEA861_FormatTbl[CEA861_FORMAT_NUM];
// CEA extension duplicated mode
extern const WORD CEA_DUPLICATED_MODE[];
// CEA extension format timing table
extern CEA_861_Timing_Tbl CEA861_FormatTimingTbl[CEA861_FORMAT_NUM];


