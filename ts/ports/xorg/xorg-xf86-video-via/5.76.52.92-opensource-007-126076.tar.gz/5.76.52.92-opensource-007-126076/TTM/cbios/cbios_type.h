/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _S3_H
#ifndef _CBIOS_TYPES_H_
#define _CBIOS_TYPES_H_

#if defined (__linux__)

#ifndef DBG
#define DBG     1
#endif

#else
#ifndef _EFI_GOP_H_
#include <memory.h>
#endif
#endif

//
// For S3_EXTBIOS_INFO (0x4F14) services
//
#define S3_EXTBIOS_INFO         0x4F14  // S3 Extended BIOS services

#define S3_GET_UMAFB_BASE   0x000D  // Get FB Base (not aperture base) on UMA architecture


#define S3_VBE_INFO         0x0000  // fn00: Query S3/VBE info
#define UMA_GET_BIOS_INFO   0x0100  // fn00: sub10 Query TX_ID
#define UMA_GET_MISC_INFO   0x0200  // fn00: sub00: Get Misc Information of BIOS
#define S3_SET_REFRESH      0x0001  // fn01,sub00: Set Refresh Rate for Mode
#define S3_GET_REFRESH      0x0101  // fn01,sub01: Get Refresh Rate for Mode
#define S3_QUERY_REFRESH    0x0201  // fn01,sub02: Query Refresh Rates for Mode
#define S3_QUERY_MODELIST   0x0202  // fn02,sub02: Query Mode List
#define S3_QUERY_DISPLAY_DEVICE 0x0203 // fn02,sub03: Query Display Device
#define S3_GET_EXT_MODEINFO 0x0302  // fn02,sub03: Get Extended Mode Info
#define S3_SET_ACTIVE_DISP  0x0003  // fn03,sub00: Set Active Display
#define S3_GET_ACTIVE_DISP  0x0103  // fn03,sub01: Get Active Display
#define S3_GET_ACTIVE_INFO  0x0103  // fn03,sub01: Get Active Display Information, only for CastleRock only
#define S3_SET_DEVICE_POWER_STATE 0x0403  // fn03,sub04: Set display devices power state, only for CastleRock only
#define S3_SET_EXT_DISPLAY  0x8003  // fn03,sub80: Alt Set Active Display
#define S3_GET_NEXT_DISPLAY 0x8103  // fn03,sub81: Query Next Display Config
#define S3_SWITCH_COMPLETE  0x8203  // fn03,sub82: Notify Display Switch Done
#define S3_GET_CMOS_DISPLAY 0x8303  // fn03,sub83: Query CMOS Display Config
#define S3_SET_CMOS_DISPLAY 0X8503  // fn03, sub 85: Set Active Display Device to CMOS
#define S3_QUERY_ATTACHED   0x0004  // fn04,sub00: Query detected displays
#define S3_SET_CLOCKS       0x0005  // fn05,sub00: Set Clocks
#define S3_GET_CLOCKS       0x0105  // fn05,sub01: Get Clocks
#define S3_GET_FLATP_INFO   0x0006  // fn06,sub00: Get Flat Panel Info
#define S3_GET_DVI_INFO     0x0006  // fn06,sub00: Get DVI Info (CSR)
//#define S3_SET_CTREXP       0x0106  // fn06,sub01: Set Center/Expansion
//#define S3_GET_CTREXP       0x0206  // fn06,sub02: Get Center/Expansion
#define S3_SET_CTREXP_EX    0x0306  // fn06,sub03: Alternate Set Center/Expansion (CSR)
#define S3_GET_CTREXP_EX    0x0406  // fn06,sub04: Alternate Get Center/Expansion (CSR)
#define S3_GET_CMOS_CTREXP_EX    0x8406  // fn06,sub84: Alternate Get Center/Expansion from SysBIOS (CSR)
#define S3_SET_LCD_REFRESH  0x0506  // fn06,sub05: Set Flat Panel Refresh Rate
#define S3_GET_SCALING_FACTOR 0x0506  // fn06,sub05: Get scaling factor, only for CastleRock only
#define S3_GET_LCD_REFRESH  0x0606  // fn06,sub06: Get current Flat Panel Refresh Rate
#define S3_GET_LCD_REFRESH_SUPPORT 0x0706 // fn06,sub07: Get supported Flat Panel Refresh Rates
#define S3_GET_DISPLAY_DEVICE_INFO 0x0806 // fn06,sub08: Get Display Device info.
#define S3_GET_LCD_INFO     0x8106  // fn06,sub08: Get flat panel info.(CSR)
#define S3_SET_TV_CONFIG    0x0007  // fn07,sub00: Set TV Configuration
#define S3_GET_TV_CONFIG    0x0107  // fn07,sub01: Get TV Configuration
#define S3_GET_TV_SUPPORT   0x0207  // fn07,sub02: Get TV Standard Support
#define S3_GET_QUERY_TV_CONFIG 0x8107  // fn07,sub81: Get or Get TV Configuration
#define S3_QUERY_HDTV_SUBMODE  0x8207  // fn07,sub82: Query HDTV SubMode list
#define S3_GET_RESUME_STATUS 0x090A // fn0a,sub09; Get Resume status

//
//  and the subfunctions for FUNC CONTROL classes, in DL
//
#define S3_TV_FN_SET_UMA              0x00
#define S3_TV_FN_GET_UMA              0x01
#define S3_TV_FN_SET_DEFAULT_UMA      0x02
#define S3_TV_FN_QUERY_MAX_RANGE_UMA  0x03

#define S3_TV_CNST_SET              0x00
#define S3_TV_CNST_GET              0x01
#define S3_TV_CNST_SET_DEFAULT      0x02
#define S3_TV_CNST_QUERY_MAX_RANGE  0x03

//
//  Savage-family BIOS functions make BX just Main Function/Category, with
//  subfunctions in DX.
//
#define S3_TV_CONTRAST_CONTROL      0x0307  // fn07,class3: Contrast
#define S3_TV_SATURATION_CONTROL    0x0407  // fn07,class4: Saturation
#define S3_TV_HUE_CONTROL           0x0507  // fn07,class5: Hue
#define S3_TV_BRIGHTNESS_CONTROL    0x0607  // fn07,class6: Brightness
#define S3_TV_FFILTER_CONTROL       0x0707  // fn07,class7: Flicker Filter
#define S3_TV_SIT_CONTROL           0x0807  // fn07,class8: Interpolative
                                            //              Threshold
#define S3_TV_APERTURE_CONTROL      0x0907  // fn07,class9: Aperture
#define S3_TV_POSITION_CONTROL      0x0B07  // fn07,classB: Position

//set flickerfilter/adaptive flickerfiler
#define ENABLE_NORM_FLICKERFILTER  0x01
#define ENABLE_ADAPTIVE_FLICKERFILTER  0x00

//
// Bit masks for MISC_OUTPUT_WRITE_REG (3C2)
//
#define SEL_IOA_COLOR   0x01    // Bit 0 set means color emulation.  Address
                                // base at 0x3Dx. Else mono, at 0x3Bx.
#define ENABLE_VIDEO_RAM 0x02   // Bit 1 set means enable access of
                                // the display memory from the CPU
#define SEL_SPECIAL_CLK 0x08    // Bit 3 set means we're not selecting a
                                // normal clock but may be enabling load of
                                // DCLK PLL parms in SR12, SR13.
#define SEL_NEG_VSYNC   0x80    // Bit 7 of 3C2, if set, selects negative
                                // vertical retrace sync pulse
#define SEL_POS_VSYNC   0x7F    // AND mask to clear bit 7 of 3C2, selecting

//
// SEQUENCER REGISTERS  (SR##)
//
// (indices to SEQ_DATA_REG at 0x03C5)
//

#define RESET_SEQREG            0x00  // Reset Register
#define CLK_MODE_SR1            0x01  // Clocking Mode Register
#define MEMORY_MODE_SEQREG      0x04  // Memory Mode Control Register

// Bit mask for Clocking Mode Register (SR1)
//
#define SCREEN_OFF_BIT             0x20     // bit 5 set turns the screen off.

#define _BIT(n)  (1 << (n))

#ifndef BIT0
#define BIT0  _BIT(0 )
#endif
#ifndef BIT1
#define BIT1  _BIT(1 )
#endif
#ifndef BIT2
#define BIT2  _BIT(2 )
#endif
#ifndef BIT3
#define BIT3  _BIT(3 )
#endif
#ifndef BIT4
#define BIT4  _BIT(4 )
#endif
#ifndef BIT5
#define BIT5  _BIT(5 )
#endif
#ifndef BIT6
#define BIT6  _BIT(6 )
#endif
#ifndef BIT7
#define BIT7  _BIT(7 )
#endif
#ifndef BIT8
#define BIT8  _BIT(8 )
#endif
#ifndef BIT9
#define BIT9  _BIT(9 )
#endif
#ifndef BIT10
#define BIT10 _BIT(10)
#endif
#ifndef BIT11
#define BIT11 _BIT(11)
#endif
#ifndef BIT12
#define BIT12 _BIT(12)
#endif
#ifndef BIT13
#define BIT13 _BIT(13)
#endif
#ifndef BIT14
#define BIT14 _BIT(14)
#endif
#ifndef BIT15
#define BIT15 _BIT(15)
#endif
#ifndef BIT16
#define BIT16 _BIT(16)
#endif
#ifndef BIT17
#define BIT17 _BIT(17)
#endif
#ifndef BIT18
#define BIT18 _BIT(18)
#endif
#ifndef BIT19
#define BIT19 _BIT(19)
#endif
#ifndef BIT20
#define BIT20 _BIT(20)
#endif
#ifndef BIT21
#define BIT21 _BIT(21)
#endif
#ifndef BIT22
#define BIT22 _BIT(22)
#endif
#ifndef BIT23
#define BIT23 _BIT(23)
#endif
#ifndef BIT24
#define BIT24 _BIT(24)
#endif
#ifndef BIT25
#define BIT25 _BIT(25)
#endif
#ifndef BIT26
#define BIT26 _BIT(26)
#endif
#ifndef BIT27
#define BIT27 _BIT(27)
#endif
#ifndef BIT28
#define BIT28 _BIT(28)
#endif
#ifndef BIT29
#define BIT29 _BIT(29)
#endif
#ifndef BIT30
#define BIT30 _BIT(30)
#endif
#ifndef BIT31
#define BIT31 _BIT(31)
#endif

/******************************************************************************/
/* from types.h */


#define ON  1
#define OFF 0

#ifdef FALSE
#undef FALSE
#endif
#define FALSE   0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE    1

#ifndef NULL
#define NULL    0
#endif

#ifndef VOID
#define VOID void
#endif

typedef unsigned char UCHAR, *PUCHAR;
typedef unsigned short USHORT, *PUSHORT;
#ifdef LINUX_BUILD_ENVIRMENT
typedef unsigned int ULONG, *PULONG;
#else
typedef unsigned long ULONG, *PULONG;
#endif

typedef unsigned char       BYTE;
typedef BYTE                *PBYTE;
typedef unsigned short      WORD, *PWORD;
#ifdef LINUX_BUILD_ENVIRMENT
typedef unsigned int       DWORD, *PDWORD;
#else
typedef unsigned long       DWORD, *PDWORD;
#endif


typedef char CHAR, *PCHAR;
typedef short SHORT;
#ifdef LINUX_BUILD_ENVIRMENT
typedef int LONG;
#else
typedef long LONG;
#endif

typedef int BOOL;
typedef int INT;

typedef void *PVOID;
typedef unsigned int     UINT32;
typedef unsigned char    UINT8;

#if defined (__linux__)
    typedef unsigned long long LONGLONG;
    typedef unsigned long long DWORDLONG;
    #define MAXLONGLONG     (0x7fffffffffffffff)
#else

#if (!defined(MIDL_PASS) || defined(__midl)) && (!defined(_M_IX86) || (defined(_INTEGRAL_MAX_BITS) && _INTEGRAL_MAX_BITS >= 64))
    typedef __int64 LONGLONG;
    typedef unsigned __int64 DWORDLONG;

    #define MAXLONGLONG     (0x7fffffffffffffff)
#else
    typedef double LONGLONG;
    typedef double DWORDLONG;
#endif

#endif

/*
// if we don't include s3gvideoport.h, we have to open below define
typedef ULONG *ULONG_PTR;

typedef union _LARGE_INTEGER {
    struct {
        ULONG LowPart;
        LONG HighPart;
    };
    struct {
        ULONG LowPart;
        LONG HighPart;
    } u;
    LONGLONG QuadPart;
} LARGE_INTEGER;


//#define S3GDebugPrint(arg)                 
//#define ASSERT(x) 

typedef LARGE_INTEGER PHYSICAL_ADDRESS;
*/
//
// Define structure used to call the BIOS int 10 function
//

typedef struct _VIDEO_X86_BIOS_ARGUMENTS {
    ULONG Eax;
    ULONG Ebx;
    ULONG Ecx;
    ULONG Edx;
    ULONG Esi;
    ULONG Edi;
    ULONG Ebp;
} VIDEO_X86_BIOS_ARGUMENTS, *PVIDEO_X86_BIOS_ARGUMENTS;

#define ULONGLONG unsigned long long
typedef   char   *LPSTR;
#define CONST const

#define OUT
#define IN
#define INOUT

#if DBG

#ifndef ASSERT

#if !defined (__linux__)
#define ASSERT(x) if(!(x)) __debugbreak()
#else
#define ASSERT(x)   
#endif

#endif

#else

#ifndef ASSERT
#define ASSERT(x)  
#endif

#endif

#if defined(_WIN64)
 typedef unsigned __int64 ULONG_PTR;
#else
 typedef unsigned long ULONG_PTR;
#endif

#endif /* _CBIOS_TYPES_H_ */
#endif /* _S3_H */
