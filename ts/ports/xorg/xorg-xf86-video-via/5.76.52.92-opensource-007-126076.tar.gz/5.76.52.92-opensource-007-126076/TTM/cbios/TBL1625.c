/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "TBL1625.h"
//-----------------------------------------------------------------------------
//                              Normal scan level 
//-----------------------------------------------------------------------------
TVTBLDATA_UMA csTVModeTbl_1625[] = { 
        { MODE640,      NTSC_640,       PAL_640,       NTSC_CRTC_640,      PAL_CRTC_640 },    // 04 -> 640x480 tv modes
        { MODE800,      NTSC_800,       PAL_800,       NTSC_CRTC_800,      PAL_CRTC_800 },    // 05 -> 800x600 tv modes
        { MODE1024,     NTSC_1024,      PAL_1024,      NTSC_CRTC_1024,     PAL_CRTC_1024 },   // 06 -> 1024x768 tv modes
        //{ MODE848,      NTSC_848,       PAL_848,       NTSC_CRTC_848,      PAL_CRTC_848 },    // 07 -> 848x480 tv modes
        { MODE720X480,  NTSC_720X480,   NULL,          NTSC_CRTC_720X480,  NULL },            // 08 -> NTSC 720x480 tv modes
        { MODE720X576,  NULL,           PAL_720X576,   NULL,               PAL_CRTC_720X576 },// 09 -> PAL  720x576 tv modes
        { 0xFF,         NULL, 		   NULL, 	      NULL,				  NULL} 	         // end of table
};        


//-----------------------Normal scan TV output type Table----------------------------
 TV_FUNCTION_UMA NTSC_640 [] = {
        {TV_FUNC,           N640_TV_VN},       // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     N640_SDTV_VN},     // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N640_SDTV_VN},     // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N640_DotCrawl_VN}, // enable dot crawl
        {0xFF ,			    NULL }			   // End of table	
};

 TV_FUNCTION_UMA NTSC_800 [] = {
        {TV_FUNC,           N800_TV_VN},       // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     N800_SDTV_VN},     // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N800_SDTV_VN},     // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N800_DotCrawl_VN}, // enable dot crawl
        {0xFF ,             NULL }              // End of table  
};

 TV_FUNCTION_UMA NTSC_1024 [] = {
        {TV_FUNC,           N1024_TV_VN},      // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     N1024_SDTV_VN},    // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N1024_SDTV_VN},    // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N1024_DotCrawl_VN},// enable dot crawl
        {0xFF ,             NULL }              // End of table  
};

 TV_FUNCTION_UMA NTSC_848 [] = {
        {TV_FUNC,           N848_TV_VN},       // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     N848_SDTV_VN},     // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N848_SDTV_VN},     // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N848_DotCrawl_VN}, // enable dot crawl
        {0xFF ,             NULL }              // End of table  
};

 TV_FUNCTION_UMA NTSC_720X480 [] = {
        {TV_FUNC,           N720X480_TV_VN},       // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},           // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},         // output YCbCr signal
        {SDTV_RGB_FUNC,     N720X480_SDTV_VN},     // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N720X480_SDTV_VN},     // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N720x480_DotCrawl_VN}, // enable dot crawl
        {YCBCR_IN_FUNC,     N720X480_YCbCr_IN_VN}, // input YCbCr signal
        {0xFF ,             NULL }                  // End of table  
};

 TV_FUNCTION_UMA NTSC_720 [] = {
        {TV_FUNC,           N720_TV_VN},           // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},           // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},         // output YCbCr signal
        {SDTV_RGB_FUNC,     N720_SDTV_VN},         // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   N720_SDTV_VN},         // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,     N720_DotCrawl_VN},     // enable dot crawl
        {0xFF ,             NULL }                  // End of table  
};

 TV_FUNCTION_UMA PAL_640 [] = {
        {TV_FUNC,           P640_TV_VN},     // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},     // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},   // output YCbCr signal
        {SDTV_RGB_FUNC,     P640_SDTV_VN},   // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P640_SDTV_VN},   // output SDTV_YPbPr signal
        {0xFF ,             NULL }            // End of table  
};

 TV_FUNCTION_UMA PAL_800 [] = {        
        {TV_FUNC,           P800_TV_VN},     // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},     // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},   // output YCbCr signal
        {SDTV_RGB_FUNC,     P800_SDTV_VN},   // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P800_SDTV_VN},   // output SDTV_YPbPr signal
        {0xFF ,             NULL }            // End of table  
};

 TV_FUNCTION_UMA PAL_1024 [] = { 
        {TV_FUNC,           P1024_TV_VN},    // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},     // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},   // output YCbCr signal
        {SDTV_RGB_FUNC,     P1024_SDTV_VN},  // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P1024_SDTV_VN},  // output SDTV_YPbPr signal
        {0xFF ,             NULL }            // End of table  
};

 TV_FUNCTION_UMA PAL_848 [] = {
        {TV_FUNC,           P848_TV_VN},     // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},     // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},   // output YCbCr signal
        {SDTV_RGB_FUNC,     P848_SDTV_VN},   // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P848_SDTV_VN},   // output SDTV_YPbPr signal
        {0xFF ,             NULL }            // End of table  
};

 TV_FUNCTION_UMA PAL_720X576 [] = {
        {TV_FUNC,           P720X576_TV_VN},   // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     P720X576_SDTV_VN}, // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P720X576_SDTV_VN}, // output SDTV_YPbPr signal
        {0xFF ,             NULL }              // End of table  
};

 TV_FUNCTION_UMA PAL_720 [] = {
        {TV_FUNC,           P720_TV_VN},       // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,          TV_OUT_RGB},       // output RGB signal
        {YCBCR_FUNC,        TV_OUT_YCbCr},     // output YCbCr signal
        {SDTV_RGB_FUNC,     P720_SDTV_VN},     // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,   P720_SDTV_VN},     // output SDTV_YPbPr signal
        {0xFF ,             NULL }             // End of table  
};


//-------------------------Normal scan level-------------------------------
 BYTE N640_TV_VN  [] = {
        0x03,0x00,0x10,0x1F,0x00,     // TV.00-04
        0x00,0x00,0x29,0x40,0x0B,     // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0xFA,0x21,     // TV.0F-13
        0xE0,0x68,0xD6,0x7B,0xF0,     // TV.14-18
        0x21,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x10,0x1C,0x2A,0xCB,     // TV.1E-22
        0x77,0x00,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F

        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F

        // Set Video Timing
        // TV CRTC registers
        0x0F,0x81,0x23,0x57,0x22,    // TV.50-54
        // TV Timing registers
        0x59,0x7c,0x7F,0x23,0x91,    // TV.55-59
        0xD2,0x13,0x7C,0x16,         // TV.5A-5D
        // TV CRTC
        0x49,0x0a,0x92,0x28,0xFF,    // TV.5E-62
        0x7F,0x03,                  // TV.63-64

        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD NTSC_CRTC_640 [] = {    
        784,                        // H_Total
        640,                        // H_Display_End
        640,                        // H_Blanking_Start
        784,                        // H_Blanking_End
        688,                        // H_Sync_Start
        744,                        // H_Sync_End
        600,                        // V_Total
        480,                        // V_Display_End
        480,                        // V_Blanking_Start
        600,                        // V_Blanking_End
        488,                        // V_Sync_Start
        495                         // V_Sync_End
};

 BYTE  N800_TV_VN [] = {  
        0x03,0x00,0x10,0x90,0x00,     // TV.00-04
        0x00,0x00,0x58,0x45,0x09,     // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0xED,0x21,     // TV.0F-13
        0xBE,0x34,0xD6,0x7B,0xF0,     // TV.14-18
        0x21,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x10,0x1C,0x0A,0xC9,     // TV.1E-22
        0x77,0x00,                  // TV.23-24

        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x27,0x22,0x34,0xED,0x22,     // TV.50-54
        // TV Timing registers
        0x59,0x7B,0x7F,0x23,0x8C,     // TV.55-59
        0xD2,0x13,0x7A,0x16,          // TV.5A-5D
        // TV CRTC
        0xDB,0x1A,0xB6,0xAA,0xFF,     // TV.5E-62
        0xEF,0x05,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD NTSC_CRTC_800 [] = { 
        1064,                       // H_Total
        800,                        // H_Display_End
        800,                        // H_Blanking_Start
        1064,                       // H_Blanking_End
        840,                        // H_Sync_Start
        976,                        // H_Sync_End
        750,                        // V_Total
        600,                        // V_Display_End
        600,                        // V_Blanking_Start
        750,                        // V_Blanking_End
        606,                        // V_Sync_Start
        621                         // V_Sync_End
};

 BYTE N1024_TV_VN [] = {
        0x03,0x00,0x10,0x9A,0x00,     // TV.00-04
        0x00,0x00,0x11,0x7A,0x0C,     // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0x28,0x0D,     // TV.0F-13
        0x28,0x14,0xB4,0x83,0x0F,     // TV.14-18
        0x16,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x00,0x12,0xFF,0xA5,     // TV.1E-22
        0x77,0x0C,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x5F,0x02,0x44,0xDD,0x03,     // TV.50-54
        // TV Timing registers
        0x27,0xA4,0xC3,0x35,0xE2,     // TV.55-59
        0x47,0xA0,0xFF,0x59,          // TV.5A-5D
        // TV CRTC
        0x5F,0xCC,0xF1,0x28,0xFF,     // TV.5E-62
        0x3F,0x08,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};
        
 WORD NTSC_CRTC_1024 [] = {
        1120,                       // H_Total
        1024,                       // H_Display_End
        1024,                       // H_Blanking_Start
        1120,                       // H_Blanking_End
        1072,                       // H_Sync_Start
        1104,                       // H_Sync_End
        990,                        // V_Total
        768,                        // V_Display_End
        768,                        // V_Blanking_Start
        990,                        // V_Blanking_End
        800,                        // V_Sync_Start
        806                         // V_Sync_End
};

 BYTE N848_TV_VN [] = { 
        0x84,0x00,0x10,0x04,0x03,     // TV.00-04
        0x00,0x20,0xa7,0xc1,0x07,     // TV.05-09
        0x50,0x00,0x50,0x39,0x3F,     // TV.0A-0E
        0x00,0x00,0x00,0xF0,0x29,     // TV.0F-13
        0x67,0x31,0x63,0xa8,0x3c,     // TV.14-18
        0x1d,0x00,0x10,0x03,0x80,     // TV.19-1D
        0x00,0x33,0x11,0x08,0x47,     // TV.1E-22
        0x73,0x0c,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x01,0x10,     // TV.4A-4E
        0x39,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xaF,0x4F,0x34,0x44,0x02,     // TV.50-54
        // TV Timing registers
        0xe3,0xbF,0x93,0x63,0xad,     // TV.55-59
        0xFd,0x1b,0x6F,0x17,          // TV.5A-5D
        // TV CRTC
        0x6d,0xd4,0x04,0x00,0x01,     // TV.5E-62
        0x2F,0x05,                   // TV.63-64

        0x00,0x00,0x00,0x00,0x00,     // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};        

#define    NTSCCRTC848  20
 BYTE NTSC_CRTC_848 [NTSCCRTC848 + 30] = { 
        NTSCCRTC848 - 1,            // number of setting CRTC's registers 19
        0x91,0x69,0x69,0x95,0x6d,     // CRTC 0-4
        0x01,0x43,0x3e,0x40,0xeF,     // CRTC 5-7 9 & 10
        0xdF,0xdF,0x44,              // CRTC 12 15-16
        0x00,                       // CRTC 33.BIT[5]
        0x40,0x00,0x00,              // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N,      // Vclk 3c5.46-47
      
        // TV work on IGA2         
        0xaF,0x4F,0x4F,0xaF,0xe3,     // CRTC 50-54
        0x34,0xc7,0x07,0x44,0xdF,     // CRTC 55-59
        0xdF,0x44,0x11,0x0a,0xeF,     // CRTC 5A-5E
        0x3c,                       // CRTC 5F
        0x35,0x6a,0x00,              // CRTC 65-67 for 848x480 8bpp
        0x6a,0xd4,0x40,              // CRTC 65-67 for 848x480 16bpp
        0xd4,0xa8,0xC1,              // CRTC 65-67 for 848x480 32bpp
        0x80,0x00,0x80,              // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N      // LCK 3c5.44-45
};


 BYTE N720X480_TV_VN [] = {
        // normal registers
        0x03,0x00,0x10,0x1F,0x00,     // TV.00-04
        0x00,0x00,0x2A,0x41,0x0A,     // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,     // TV.0A-0E
        0xB7,0x00,0x80,0xAB,0x27,     // TV.0F-13
        0x70,0x2C,0xD6,0x7B,0xF0,     // TV.14-18
        0x21,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x10,0x1C,0x08,0xCB,     // TV.1E-22
        0x77,0x02,                  // TV.23-24

        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x0F,0xCF,0x23,0x57,0x22,     // TV.50-54
        // TV Timing registers
        0x59,0x83,0x7F,0x23,0x91,     // TV.55-59
        0xD2,0x13,0x7A,0x16,         // TV.5A-5D
        // TV CRTC
        0x49,0xF1,0x92,0xA8,0xFF,     // TV.5E-62
        0x7F,0x03,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};


 WORD NTSC_CRTC_720X480 [] = {
        784,                        // H_Total
        720,                        // H_Display_End
        720,                        // H_Blanking_Start
        784,                        // H_Blanking_End
        728,                        // H_Sync_Start
        744,                        // H_Sync_End
        600,                        // V_Total
        480,                        // V_Display_End
        480,                        // V_Blanking_Start
        600,                        // V_Blanking_End
        490,                        // V_Sync_Start
        496                         // V_Sync_End
};

 BYTE N720_TV_VN [] = {
        // normal registers
        0x03,0x00,0x10,0x1F,0x00,     // TV.00-04
        0x00,0x00,0x62,0x48,0xF6,     // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0x0B,0x03,     // TV.0F-13
        0x09,0x2C,0x8C,0x71,0x1C,     // TV.14-18
        0x1F,0x00,0x50,0x00,0x80,     // TV.19-1D
        0x00,0x01,0x1A,0x08,0x8B,     // TV.1E-22
        0x77,0x00,                   // TV.23-24
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xA7,0xD1,0x23,0x0C,0x02,     // TV.50-54
                                    // TV Timing registers
        0xA7,0xAF,0x8A,0x23,0x99,     // TV.55-59
        0xE4,0x2B,0x14,0x17,          // TV.5A-5D
        // TV CRTC
        0x00,0x62,0x80,0x28,0xFF,     // TV.5E-62
        0xA7,0x03,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD NTSC_CRTC_720 [] = {
        832,                        // H_Total
        640,                        // H_Display_End
        640,                        // H_Blanking_Start
        1304,                       // H_Blanking_End
        664,                        // H_Sync_Start
        760,                        // H_Sync_End
        525,                        // V_Total
        400,                        // V_Display_End
        407,                        // V_Blanking_Start
        442,                        // V_Blanking_End
        467,                        // V_Sync_Start
        480                         // V_Sync_End
};

 BYTE P640_TV_VN [] = { 
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,     // TV.00-04
        0x00,0x00,0xF2,0x42,0x0A,     // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,     // TV.0A-0E
        0xB0,0x00,0x80,0x0A,0x09,     // TV.0F-13
        0x19,0x28,0xCB,0x8A,0x09,     // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x10,0x17,0x1C,0x35,     // TV.1E-22
        0x7D,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F

        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x51,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xE7,0x81,0x23,0x57,0x22,     // TV.50-54
        // TV Timing registers
        0x5F,0x6F,0x7F,0x23,0x94,     // TV.55-59
        0xD0,0x1C,0x8F,0x16,          // TV.5A-5D
        // TV CRTC
        0xE1,0x38,0x7A,0x28,0xFF,     // TV.5E-62
        0xBF,0x03,                   // TV.63-64    
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD PAL_CRTC_640 [] = {  
        1000,                       // H_Total
        640,                        // H_Display_End
        640,                        // H_Blanking_Start
        1000,                       // H_Blanking_End
        704,                        // H_Sync_Start
        760,                        // H_Sync_End
        600,                        // V_Total
        480,                        // V_Display_End
        480,                        // V_Blanking_Start
        600,                        // V_Blanking_End
        500,                        // V_Sync_Start
        506                         // V_Sync_End
};


 BYTE P800_TV_VN [] = {
        // normal registers
        0x03,0x00,0x10,0x90,0x03,     // TV.00-04
        0x00,0x00,0x28,0x41,0x0F,     // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0x12,0x04,     // TV.0F-13
        0x17,0x48,0xCB,0x8A,0x09,     // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x10,0x17,0x1C,0x31,     // TV.1E-22
        0x7D,0x02,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x51,                       // TV.4F
               
        // Set Video Timing
        // TV CRTC registers
        0x97,0x22,0x33,0xED,0x22,     // TV.50-54
        // TV Timing registers
        0x5F,0x73,0x7F,0x23,0x94,     // TV.55-59
        0xD0,0x27,0x8F,0x16,          // TV.5A-5D
        // TV CRTC
        0x99,0x38,0x99,0xAA,0xFF,     // TV.5E-62
        0x4F,0x04,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};   


 WORD PAL_CRTC_800 [] = {
        920,                        // H_Total
        800,                        // H_Display_End
        800,                        // H_Blanking_Start
        920,                        // H_Blanking_End
        816,                        // H_Sync_Start
        880,                        // H_Sync_End
        750,                        // V_Total
        600,                        // V_Display_End
        600,                        // V_Blanking_Start
        750,                        // V_Blanking_End
        606,                        // V_Sync_Start
        621                         // V_Sync_End
};


 BYTE P1024_TV_VN [] = {
        // normal registers
        0x03,0x00,0x10,0x9A,0x03,     // TV.00-04
        0x00,0x00,0x89,0x64,0x0D,     // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,     // TV.0A-0E
        0x9E,0x00,0x80,0x2D,0x08,     // TV.0F-13
        0x27,0x24,0x87,0x5C,0x06,     // TV.14-18
        0x1C,0x00,0x50,0x01,0x80,     // TV.19-1D
        0x00,0x00,0x1D,0x1C,0x89,     // TV.1E-22
        0x7D,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x51,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xAF,0x02,0x44,0xCE,0x03,     // TV.50-54
        // TV Timing registers
        0x0F,0xA4,0xBE,0x35,0xDC,     // TV.55-59
        0x3E,0xB5,0xDB,0x59,          // TV.5A-5D
        // TV CRTC
        0xAE,0xCD,0xC7,0x28,0xFF,     // TV.5E-62
        0x4F,0x07,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD PAL_CRTC_1024 [] = {
        1200,                        // H_Total
        1024,                        // H_Display_End
        1024,                        // H_Blanking_Start
        1200,                        // H_Blanking_End
        1048,                        // H_Sync_Start
        1064,                        // H_Sync_End
        975,                         // V_Total
        768,                         // V_Display_End
        768,                         // V_Blanking_Start
        975,                         // V_Blanking_End
        800,                         // V_Sync_Start
        806                          // V_Sync_End
};


 BYTE P848_TV_VN [] = {
        // normal registers
        0x04,0x00,0x10,0x06,0x00,      // TV.00-04
        0x00,0x20,0xa7,0xe6,0x06,      // TV.05-09
        0x5c,0x00,0x4e,0x41,0x3F,      // TV.0A-0E
        0x00,0x00,0x00,0xe6,0x23,      // TV.0F-13
        0x84,0x18,0x18,0x28,0x87,      // TV.14-18
        0x1F,0x00,0x10,0x01,0x80,      // TV.19-1D
        0x00,0xcc,0x0F,0x0c,0x60,      // TV.1E-22
        0x79,0x00,                    // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x01,0x10,       // TV.4A-4E
        0x40,                         // TV.4F
              
        // Set Video Timing
        // TV CRTC registers
        0xaF,0x4F,0x34,0x57,0x02,       // TV.50-54
        // TV Timing registers
        0x7F,0x31,0xa9,0x74,0xd1,       // TV.55-59
        0x2b,0x41,0xa5,0x58,           // TV.5A-5D
                                     // TV CRTC
        0xd7,0x26,0x03,0x00,0x01,       // TV.5E-62
        0x7F,0x04,                     // TV.63-64

        0x00,0x00,0x00,0x00,0x00,       // TV.6B-6F
        0x00,0x00,0x00,0x00             // TV.70-73
};

#define PALCRTC848 19

 BYTE PAL_CRTC_848  [PALCRTC848 + 30 + 1] = {
        PALCRTC848,                  // number of setting CRTC's registers 19
        0x91,0x69,0x69,0x95,0x6d,       // CRTC 0-4
        0x01,0x56,0x3e,0x40,0xF2,       // CRTC 5-7 9 & 10
        0xdF,0xdF,0x57,                // CRTC 12 15-16
        0x00,                         // CRTC 33.BIT[5]
        0x40,0x00,0x00,                // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N,        // Vclk 3c5.46-47
    
        // TV work on IGA2       
        0xaF,0x4F,0x4F,0xaF,0xe3,       // CRTC 50-54
        0x34,0xcF,0x07,0x57,0xdF,       // CRTC 55-59
        0xdF,0x57,0x11,0x0a,0xF2,       // CRTC 5A-5E
        0x3d,                         // CRTC 5F
        0x35,0x6a,0x00,                // CRTC 65-67 for 848x480 8bpp
        0x6a,0xd4,0x40,                // CRTC 65-67 for 848x480 16bpp
        0xd4,0xa8,0xC1,                // CRTC 65-67 for 848x480 32bpp
        0x80,0x00,0x80,                // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N         // LCK 3c5.44-45
};       

 BYTE P720X576_TV_VN [] = {               
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,       // TV.00-04
        0x00,0x00,0xC9,0x4C,0x10,       // TV.05-09
        0x7C,0x00,0x56,0x57,0x3F,       // TV.0A-0E
        0xBF,0x00,0x80,0x09,0x08,       // TV.0F-13
        0x17,0x24,0xCB,0x8A,0x09,       // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,       // TV.19-1D
        0x00,0x10,0x14,0x0C,0x32,       // TV.1E-22
        0x7E,0x00,                     // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x00,       // TV.4A-4E
        0x4B,                         // TV.4F
               
        // Set Video Timing
        // TV CRTC registers
        0xE7,0xD2,0x23,0xB1,0x22,      // TV.50-54
        // TV Timing registers
        0x5F,0x61,0x7F,0x23,0x90,      // TV.55-59
        0xCD,0x35,0x83,0x16,           // TV.5A-5D
        // TV CRTC
        0x4F,0x76,0x8D,0xA9,0xFF,      // TV.5E-62
        0x4F,0x04,                    // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};
      
 WORD PAL_CRTC_720X576 [] = {
        1000,                        // H_Total
        720,                         // H_Display_End
        720,                         // H_Blanking_Start
        1000,                        // H_Blanking_End
        760,                         // H_Sync_Start
        800,                         // H_Sync_End
        690,                         // V_Total
        576,                         // V_Display_End
        576,                         // V_Blanking_Start
        690,                         // V_Blanking_End
        577,                         // V_Sync_Start
        580                          // V_Sync_End
};


 BYTE P720_TV_VN [] = { 
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,      // TV.00-04
        0x00,0x00,0x61,0x3F,0x05,      // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,      // TV.0A-0E
        0xB7,0x00,0x80,0x0C,0x08,      // TV.0F-13
        0x17,0x30,0x6F,0x6F,0xDD,      // TV.14-18
        0x2B,0x00,0x50,0x00,0x80,      // TV.19-1D
        0x00,0x10,0x1A,0x22,0xA7,      // TV.1E-22
        0x7D,0x00,                   // TV.23-24
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,      // TV.25-29
        0x00,0x00,0x00,0x00,0x00,      // TV.2A-2E
        0x00,                        // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,      // TV.4A-4E
        0x51,                        // TV.4F
               
        // Set Video Timing
        // TV CRTC registers
        0x83,0xD1,0x23,0x3E,0x02,      // TV.50-54
        // TV Timing registers
        0x3B,0x55,0x7A,0x23,0x8D,      // TV.55-59
        0xC7,0x1B,0x49,0x16,           // TV.5A-5D
        // TV CRTC
        0xC2,0xAA,0x75,0xA9,0xFF,      // TV.5E-62
        0x3B,0x03,                    // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};


 WORD PAL_CRTC_720 [] = {
        800,                        // H_Total
        640,                        // H_Display_End
        640,                        // H_Blanking_Start
        800,                        // H_Blanking_End
        680,                        // H_Sync_Start
        728,                        // H_Sync_End
        575,                        // V_Total
        400,                        // V_Display_End
        400,                        // V_Blanking_Start
        575,                        // V_Blanking_End
        450,                        // V_Sync_Start
        460                         // V_Sync_End
};

#define N640_SDTV_REG_BUFLEN_VN  (19 * 2 + 1)     
#define N640_SDTV_REG_NUM_VN  (N640_SDTV_REG_BUFLEN_VN - 1) /2    

 BYTE N640_SDTV_VN [N640_SDTV_REG_BUFLEN_VN] = {
        N640_SDTV_REG_NUM_VN,          // update number of registers 19   
        RegIndexVal(0x03, 0x40),        // 04003h Filter Selection
        RegIndexVal(0x04, 0x10),        // 01004h Output Mode
        RegIndexVal(0x07, 0x28),        // 02807h Start Active Video
        RegIndexVal(0x08, 0x47),        // 04708h, 01509h adjust TV's Position
        RegIndexVal(0x09, 0x15),
        RegIndexVal(0x0B, 0x00),        // 0000Bh Blanking Level set to zero
        RegIndexVal(0x1A, 0x00),        // reserved Additional Register
        RegIndexVal(0x1C, 0x00),        
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x51, 0x83),        // 08351h, 08056h TV Timing
        RegIndexVal(0x56, 0x80),
        RegIndexVal(0x62, 0x00),        // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),        
        RegIndexVal(0x6E, 0x00),        // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6F, 0x00),
        RegIndexVal(0x70, 0x00),       
        RegIndexVal(0x72, 0x00),        // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x73, 0x00)
};

#define N800_SDTV_REG_BUFLEN_VN  (29 * 2 + 1)     
#define N800_SDTV_REG_NUM_VN  (N800_SDTV_REG_BUFLEN_VN - 1) /2    

 BYTE N800_SDTV_VN [N800_SDTV_REG_BUFLEN_VN] = {
        N800_SDTV_REG_NUM_VN,           // update number of registers 29   
        RegIndexVal(0x03, 0xC0),         // 0C003h Filter Selection
        RegIndexVal(0x04, 0x10),         // 01004h Output Mode
        RegIndexVal(0x07, 0x56),         // 05607h Start Active Video
        RegIndexVal(0x08, 0x4B),         // 04B08h, 01409h adjust TV's Position
        RegIndexVal(0x09, 0x14),
        RegIndexVal(0x0B, 0x00),         // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),         // reserved Additional Register
        RegIndexVal(0x1C, 0x00),         
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x2F),         // 02F20h TV Sync step
        RegIndexVal(0x51, 0x25),         // 02551h, 07D56h TV Timing
        RegIndexVal(0x56, 0x7D),
        RegIndexVal(0x62, 0x00),         // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x28, 0x00),         // reserved
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),        
        RegIndexVal(0x2D, 0x00),
        RegIndexVal(0x2E, 0x00),
        RegIndexVal(0x2F, 0x00),
        RegIndexVal(0x6B, 0x00),         // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),
        RegIndexVal(0x6F, 0x00),
        RegIndexVal(0x70, 0x00),         // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A   
        RegIndexVal(0x72, 0x00),
        RegIndexVal(0x73, 0x00)
};

#define N1024_SDTV_REG_BUFLEN_VN  (15 * 2 + 1)     
#define N1024_SDTV_REG_NUM_VN   (N1024_SDTV_REG_BUFLEN_VN - 1) /2    

 BYTE N1024_SDTV_VN [N1024_SDTV_REG_BUFLEN_VN] = {  
        N1024_SDTV_REG_NUM_VN,          // update number of registers 15   
        RegIndexVal(0x03, 0xC0),         // 0C003h Filter Selection
        RegIndexVal(0x04, 0x10),         // 01004h Output Mode
        RegIndexVal(0x07, 0x0F),         // 00F07h Start Active Video
        RegIndexVal(0x08, 0x80),         // 08008h, 01409h adjust TV's Position
        RegIndexVal(0x09, 0x14),
        RegIndexVal(0x0B, 0x00),         // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),         // reserved Additional Register
        RegIndexVal(0x1C, 0x00),         
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x25),         // 02520h TV Sync step
        RegIndexVal(0x51, 0x04),         // 00451h, 0A756h TV Timing
        RegIndexVal(0x56, 0xA7),
        RegIndexVal(0x62, 0x00)          // 00062h Adaptive Deflicker Disable
};

#define N848_SDTV_REG_BUFLEN_VN  (11 * 2 + 1)     
#define N848_SDTV_REG_NUM_VN  (N848_SDTV_REG_BUFLEN_VN - 1) /2

 BYTE N848_SDTV_VN [N848_SDTV_REG_BUFLEN_VN] = {
        N848_SDTV_REG_NUM_VN,           // update number of registers 11   
        RegIndexVal(0x02, 0x2A),         // 02a02h, 00b04h output SDTV type
        RegIndexVal(0x04, 0x0B),
        RegIndexVal(0x08, 0xB5),         // 0b508h, 00009h, 0001ch adjust TV's Position
        RegIndexVal(0x09, 0x00),
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x00, 0x04),         // 00400h, 00003h disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),         // 0004dh Y_DELAY = 0 
        RegIndexVal(0x65, 0x82),         // 08265h, 08066h, 08167h adjust SDTV Amplitude factor
        RegIndexVal(0x66, 0x80),
        RegIndexVal(0x67, 0x81)
};

#define N720X480_SDTV_REG_BUFLEN_VN  (15 * 2 + 1)     
#define N720X480_SDTV_REG_NUM_VN  (N720X480_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE N720X480_SDTV_VN [N720X480_SDTV_REG_BUFLEN_VN] = {    
        N720X480_SDTV_REG_NUM_VN,       //  update number of registers  15  
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x10),         // 01004h Output Mode
        RegIndexVal(0x09, 0x14),         // 01409h adjust TV's Position
        RegIndexVal(0x0B, 0x00),         // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),         // reserved Additional Register
        RegIndexVal(0x1C, 0x00),         
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x2F),         // 02F20h TV Sync step
        RegIndexVal(0x62, 0x00),         // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),         // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),         // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x6F, 0x00),         //  NTSC 480p mode- WSS timing
        RegIndexVal(0x70, 0x00),        
        RegIndexVal(0x72, 0x00),         
        RegIndexVal(0x73, 0x00)      
};

#define N720_SDTV_REG_BUFLEN_VN  (13 * 2 + 1)     
#define N720_SDTV_REG_NUM_VN  (N720_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE N720_SDTV_VN [N720_SDTV_REG_BUFLEN_VN] = {  
        N720_SDTV_REG_NUM_VN,           // update number of registers 13
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x10),         // 01004h Output Mode
        RegIndexVal(0x08, 0x4E),         // 04E08h, 0EB09h adjust TV's Position
        RegIndexVal(0x09, 0xEB),
        RegIndexVal(0x0B, 0x00),         // 0000Bh Blanking Level set to zero
        RegIndexVal(0x1C, 0x00),         // reserved Additional Register
        RegIndexVal(0x62, 0x00),         // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),         // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),         // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x6F, 0x00),         // NTSC 480p mode- WSS timing
        RegIndexVal(0x70, 0x00),     
        RegIndexVal(0x72, 0x00),        
        RegIndexVal(0x73, 0x00)       
};

#define P640_SDTV_REG_BUFLEN_VN  (17 * 2 + 1)     
#define P640_SDTV_REG_NUM_VN  (P640_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P640_SDTV_VN [P640_SDTV_REG_BUFLEN_VN] = {   
        P640_SDTV_REG_NUM_VN,           // update number of registers 17   
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),         // 01304h Output Mode
        RegIndexVal(0x07, 0xF0),         // 0F007h Start Active Video
        RegIndexVal(0x08, 0x4E),         // 04E08h, 01409h adjust TV's Position
        RegIndexVal(0x09, 0x14),
        RegIndexVal(0x1A, 0x00),         // reserved Additional Register
        RegIndexVal(0x1C, 0x00),         
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),         // reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x1C),         // 01C20h TV Sync step
        RegIndexVal(0x51, 0x83),         // 08351h, 07156h TV Timing
        RegIndexVal(0x56, 0x71),
        RegIndexVal(0x62, 0x00)          // 00062h Adaptive Deflicker Disable
      
};

#define P800_SDTV_REG_BUFLEN_VN  (25 * 2 + 1)     
#define P800_SDTV_REG_NUM_VN  (P800_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P800_SDTV_VN [P800_SDTV_REG_BUFLEN_VN] = {   
        P800_SDTV_REG_NUM_VN,           // update number of registers 25   
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),         // 01304h Output Mode
        RegIndexVal(0x07, 0x26),         // 02607h Start Active Video
        RegIndexVal(0x08, 0x4A),         // 04A08h, 01909h adjust TV's Position
        RegIndexVal(0x09, 0x19),
        RegIndexVal(0x1A, 0x00),         // reserved Additional Registerh
        RegIndexVal(0x1C, 0x00),         
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),         // reserved Additional Register        
        RegIndexVal(0x2B, 0x00),         
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x1C),         // 01C20h TV Sync step
        RegIndexVal(0x51, 0x25),         // 02551h, 07556h TV Timing
        RegIndexVal(0x56, 0x75),
        RegIndexVal(0x62, 0x00),         // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x28, 0x00),         // reserved
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),        
        RegIndexVal(0x2D, 0x00),
        RegIndexVal(0x2E, 0x00),
        RegIndexVal(0x2F, 0x00)
};

#define P1024_SDTV_REG_BUFLEN_VN  (17 * 2 + 1)     
#define P1024_SDTV_REG_NUM_VN  (P1024_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P1024_SDTV_VN [P1024_SDTV_REG_BUFLEN_VN] = {  
        P1024_SDTV_REG_NUM_VN,          // update number of registers  17
        RegIndexVal(0x03, 0xC0),         // 0C003h Filter Selection
        RegIndexVal(0x04, 0x13),         // 01304h Output Mode
        RegIndexVal(0x07, 0x87),         // 08707h Start Active Video
        RegIndexVal(0x08, 0x6C),         // 06C08h, 01909h adjust TV's Position
        RegIndexVal(0x09, 0x19),
        RegIndexVal(0x1A, 0x00),         // reserved Additional Register  
        RegIndexVal(0x1C, 0x00),        
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),         // reserved Additional Register         
        RegIndexVal(0x2B, 0x00),        
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x1C),         // 01C20h TV Sync step
        RegIndexVal(0x51, 0x04),         // 00451h, 0A556h TV Timing
        RegIndexVal(0x56, 0xA5),
        RegIndexVal(0x62, 0x00)          // 00062h Adaptive Deflicker Disable
};

#define P848_SDTV_REG_BUFLEN_VN  (11 * 2 + 1)     
#define P848_SDTV_REG_NUM_VN  (P848_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P848_SDTV_VN [P848_SDTV_REG_BUFLEN_VN] = {    
        P848_SDTV_REG_NUM_VN,           // update number of registers 11    
        RegIndexVal(0x02, 0x2A),         // 02a02h, 00804h output SDTV_RGB type
        RegIndexVal(0x04, 0x08),
        RegIndexVal(0x08, 0xDE),         // 0de08h, 00F09h, 0011ch adjust TV's Position
        RegIndexVal(0x09, 0x0F),
        RegIndexVal(0x1C, 0x01),
        RegIndexVal(0x00, 0x04),         // 00400h, 00003h disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),         // 0004dh Y_DELAY = 0 
        RegIndexVal(0x65, 0x82),         // 08265h, 08066h, 08167h        
        RegIndexVal(0x66, 0x80),         // adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x67, 0x81)
};

#define P720X576_SDTV_REG_BUFLEN_VN  (22 * 2 + 1)     
#define P720X576_SDTV_REG_NUM_VN  (P720X576_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P720X576_SDTV_VN [P720X576_SDTV_REG_BUFLEN_VN] = {
        P720X576_SDTV_REG_NUM_VN,       // update number of registers 22   
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),         // 01304h Output Mode
        RegIndexVal(0x07, 0xC7),         // 0C707h, 05508h, 01F09h adjust TV's Position
        RegIndexVal(0x08, 0x55),
        RegIndexVal(0x09, 0x1F),
        RegIndexVal(0x0A, 0x88),         // 0880Ah, 0550Ch, 05E0Dh Y/Cb/Cr Amplitude Factor
        RegIndexVal(0x0C, 0x55),
        RegIndexVal(0x0D, 0x5E),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x25),         // 02520h TV Sync step
        RegIndexVal(0x23, 0x7A),         // 07A23h TV Blank level
        RegIndexVal(0x4F, 0x51),         // 0514Fh Burst Max Amplitude
        RegIndexVal(0x56, 0x63),         // 06356h, 08057h, 09459h TV timing
        RegIndexVal(0x57, 0x80),
        RegIndexVal(0x59, 0x94),
        RegIndexVal(0x5A, 0xD0),         // 0D05Ah, 0195Bh, 06C5Ch TV timing
        RegIndexVal(0x5B, 0x19),
        RegIndexVal(0x5C, 0x6C),
        RegIndexVal(0x62, 0x00),         // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x65, 0x52),         // 05265h, 04E66h, 04E67h PY/Pb/Pr Amplitude Factor
        RegIndexVal(0x66, 0x4E),
        RegIndexVal(0x67, 0x4E)
};

#define P720_SDTV_REG_BUFLEN_VN  (6 * 2 + 1)     
#define P720_SDTV_REG_NUM_VN  (P720_SDTV_REG_BUFLEN_VN - 1) /2  

 BYTE P720_SDTV_VN [P720_SDTV_REG_BUFLEN_VN] = {
        P720_SDTV_REG_NUM_VN ,          // update number of registers 6
        RegIndexVal(0x03, 0x40),         // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),         // 01304h Output Mode
        RegIndexVal(0x08, 0x48),         // 04808h, 00D09h adjust TV's Position
        RegIndexVal(0x09, 0x0D),
        RegIndexVal(0x1F, 0x01),         // 0011Fh Filter Switch
        RegIndexVal(0x62, 0x00)          // 00062h Adaptive Deflicker Disable
};

#define N640_DOT_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N640_DOT_REG_NUM_VN  (N640_DOT_REG_BUFLEN_VN - 1) /2

 BYTE N640_DotCrawl_VN [N640_DOT_REG_BUFLEN_VN] = {    
        N640_DOT_REG_NUM_VN,            // update number of registers  3  
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xBE),         // 0be16h, 08717h adjust TV FSCI
        RegIndexVal(0x17, 0x87)
};

#define N800_DOT_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N800_DOT_REG_NUM_VN  (N800_DOT_REG_BUFLEN_VN - 1) /2

 BYTE N800_DotCrawl_VN [N800_DOT_REG_BUFLEN_VN] = {
        N800_DOT_REG_NUM_VN,            // update number of registers 3   
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16 ,0x12),         // 01216h, 04917h adjust TV FSCI
        RegIndexVal(0x17, 0x49)
};

#define N1024_DOT_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N1024_DOT_REG_NUM_VN  (N1024_DOT_REG_BUFLEN_VN - 1) /2

 BYTE N1024_DotCrawl_VN [N1024_DOT_REG_BUFLEN_VN] = {
        N1024_DOT_REG_NUM_VN,           // update number of registers  3  
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x18),         // 01816h, 06117h adjust TV FSCI
        RegIndexVal(0x17, 0x61)
};

#define N848_DOT_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N848_DOT_REG_NUM_VN  (N848_DOT_REG_BUFLEN_VN - 1) /2

 BYTE N848_DotCrawl_VN [N848_DOT_REG_BUFLEN_VN] = {
        N848_DOT_REG_NUM_VN,            // update number of registers 3   
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x5B),         // 05b16h, 0a017h adjust TV FSCI
        RegIndexVal(0x17, 0xA0)
};

#define N720x480_DOT_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N720x480_DOT_REG_NUM_VN  (N720x480_DOT_REG_BUFLEN_VN - 1) /2

 BYTE N720x480_DotCrawl_VN [N720x480_DOT_REG_BUFLEN_VN] = {    
        N720x480_DOT_REG_NUM_VN,        // update number of registers 3   
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xC3),         // 0c316h, 04c17h adjust TV FSCI
        RegIndexVal(0x17, 0x4C)
};

#define N720_DOT_REG_BUFLEN  (3 * 2 + 1)     
#define N720_DOT_REG_NUM  (N720_DOT_REG_BUFLEN - 1) /2

 BYTE N720_DotCrawl_VN [N720_DOT_REG_BUFLEN] = {    
        N720_DOT_REG_NUM,               // update number of registers 3   
        RegIndexVal(0x11, 0x08),         // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x01),         // 00116h, 06917h adjust TV FSCI
        RegIndexVal(0x17, 0x69)
};

#define N720X480_YCbCr_IN_REG_BUFLEN_VN  (3 * 2 + 1)     
#define N720X480_YCbCr_IN_REG_NUM_VN  (N720X480_YCbCr_IN_REG_BUFLEN_VN - 1) /2

 BYTE N720X480_YCbCr_IN_VN [N720X480_YCbCr_IN_REG_BUFLEN_VN] = {
        N720X480_YCbCr_IN_REG_NUM_VN,   // update number of registers 3
        RegIndexVal(0x00, 0x3A),         // 03A00h Input Format Selection
        RegIndexVal(0x03, 0x10),         // 01003h DeFlicker Disable
        RegIndexVal(0x4C, 0x08)          // 0084Ch Undershoot check
};




//--------------------------------------------------------------------------
//                           Fit scan level  
//--------------------------------------------------------------------------
TVTBLDATA_UMA   csTVModeFitTbl_1625[] = {   
       { MODE640,      Fit_NTSC_640,      Fit_PAL_640,        Fit_NTSC_CRTC_640,      Fit_PAL_CRTC_640 },	// 04 -> 640x480 tv modes
       { MODE800 ,     Fit_NTSC_800,      Fit_PAL_800,        Fit_NTSC_CRTC_800,      Fit_PAL_CRTC_800 },	// 05 -> 800x600 tv modes
       { MODE1024,     Fit_NTSC_1024,     Fit_PAL_1024,       Fit_NTSC_CRTC_1024,     Fit_PAL_CRTC_1024},	// 06 -> 1024x768 tv modes
        //{ MODE848,      Fit_NTSC_848,      Fit_PAL_848,        Fit_NTSC_CRTC_848,      Fit_PAL_CRTC_848},	// 07 -> 848x480 tv modes
        { MODE720X480,  Fit_NTSC_720X480,  NULL,               Fit_NTSC_CRTC_720X480,  NULL },				// 08 -> NTSC 720x480 tv modes
        { MODE720X576,  NULL,              Fit_PAL_720X576,    NULL,                   Fit_PAL_CRTC_720X576},// 09 -> PAL  720x576 tv modes
        { 0xFF,         NULL, 		      NULL, 	     	  NULL,				      NULL}					// end of table
};

//---------------------------Fit scan TV output type table-----------------------------------
 TV_FUNCTION_UMA Fit_NTSC_640[] = {    
         {TV_FUNC,             N640_TV_VF},         // Set TV mode (output CVBS and S-VIDEO)
         {RGB_FUNC,            TV_OUT_RGB},         // output RGB signal
         {YCBCR_FUNC,          TV_OUT_YCbCr},       // output YCbCr signal
         {SDTV_RGB_FUNC,       N640_SDTV_VF},       // output SDTV_RGB signal
         {SDTV_YPBPR_FUNC,     N640_SDTV_VF},       // output SDTV_YPbPr signal
         {DOTCRAWL_FUNC,       N640_DotCrawl_VF},   // enable dot crawl
         {0xFF ,                   NULL }               // End of table 
};
        

 TV_FUNCTION_UMA Fit_NTSC_800 [] = {  
        {TV_FUNC,             N800_TV_VF},          // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,            TV_OUT_RGB},          // output RGB signal
        {YCBCR_FUNC,          TV_OUT_YCbCr},        // output YCbCr signal
        {SDTV_RGB_FUNC,       N800_SDTV_VF},        // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,     N800_SDTV_VF},        // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,       N800_Dotcrawl_VF},    // enable dot crawl
        {0xFF ,               NULL}                 // End of table
};

 TV_FUNCTION_UMA Fit_NTSC_1024 [] = {  
        {TV_FUNC,             N1024_TV_VF},         // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,            TV_OUT_RGB},          // output RGB signal
        {YCBCR_FUNC,          TV_OUT_YCbCr},        // output YCbCr signal
        {SDTV_RGB_FUNC,       N1024_SDTV_VF},       // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,     N1024_SDTV_VF},       // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,       N1024_DotCrawl_VF},   // enable dot crawl
        {0xFF ,               NULL }                // End of table
};

 TV_FUNCTION_UMA Fit_NTSC_848  [] = {
        {TV_FUNC,             N848_TV_VF},          // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,            TV_OUT_RGB},          // output RGB signal
        {YCBCR_FUNC,          TV_OUT_YCbCr},        // output YCbCr signal
        {SDTV_RGB_FUNC,       N848_SDTV_VF},        // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,     N848_SDTV_VF},        // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,       N848_DotCrawl_VF},    // enable dot crawl
        {0xFF ,               NULL }                // End of table
};

 TV_FUNCTION_UMA Fit_NTSC_720X480 [] = {
        {TV_FUNC,             N720X480_TV_VF},      // Set TV mode (output CVBS and S-VIDEO)
        {RGB_FUNC,            TV_OUT_RGB},          // output RGB signal
        {YCBCR_FUNC,          TV_OUT_YCbCr},        // output YCbCr signal
        {SDTV_RGB_FUNC,       N720X480_SDTV_VF},    // output SDTV_RGB signal
        {SDTV_YPBPR_FUNC,     N720X480_SDTV_VF},    // output SDTV_YPbPr signal
        {DOTCRAWL_FUNC,       N720x480_DotCrawl_VF},// enable dot crawl
        {0xFF ,               NULL }                // End of table
};

 TV_FUNCTION_UMA Fit_PAL_640 [] = {
       {TV_FUNC,              P640_TV_VF},          // Set TV mode (output CVBS and S-VIDEO)
       {RGB_FUNC,             TV_OUT_RGB},          // output RGB signal
       {YCBCR_FUNC,           TV_OUT_YCbCr},        // output YCbCr signal
       {SDTV_RGB_FUNC,        P640_SDTV_VF},        // output SDTV_RGB signal
       {SDTV_YPBPR_FUNC,      P640_SDTV_VF},        // output SDTV_YPbPr signal
       {0xFF,                 NULL }                // End of table
};

 TV_FUNCTION_UMA Fit_PAL_800  [] = {
       {TV_FUNC,              P800_TV_VF},          // Set TV mode (output CVBS and S-VIDEO)
       {RGB_FUNC,             TV_OUT_RGB},          // output RGB signal
       {YCBCR_FUNC,           TV_OUT_YCbCr},        // output YCbCr signal
       {SDTV_RGB_FUNC,        P800_SDTV_VF},        // output SDTV_RGB signal
       {SDTV_YPBPR_FUNC,      P800_SDTV_VF},        // output SDTV_YPbPr signal
       {0xFF,                 NULL}                 // End of table
};

 TV_FUNCTION_UMA Fit_PAL_1024 [] = {
       {TV_FUNC,              P1024_TV_VF},         // Set TV mode (output CVBS and S-VIDEO)
       {RGB_FUNC,             TV_OUT_RGB},          // output RGB signal
       {YCBCR_FUNC,           TV_OUT_YCbCr},        // output YCbCr signal
       {SDTV_RGB_FUNC,        P1024_SDTV_VF},       // output SDTV_RGB signal
       {SDTV_YPBPR_FUNC,      P1024_SDTV_VF},       // output SDTV_YPbPr signal
       {0xFF,                 NULL}                 // End of table
};

 TV_FUNCTION_UMA Fit_PAL_848  [] = {
       {TV_FUNC,              P848_TV_VF},          // Set TV mode (output CVBS and S-VIDEO)
       {RGB_FUNC,             TV_OUT_RGB},          // output RGB signal
       {YCBCR_FUNC,           TV_OUT_YCbCr},        // output YCbCr signal
       {SDTV_RGB_FUNC,        P848_SDTV_VF},        // output SDTV_RGB signal
       {SDTV_YPBPR_FUNC,      P848_SDTV_VF},        // output SDTV_YPbPr signal
       {0xFF,                 NULL}                 // End of table
};

 TV_FUNCTION_UMA Fit_PAL_720X576 [] = {
       {TV_FUNC,              P720X576_TV_VF},      // Set TV mode (output CVBS and S-VIDEO)
       {RGB_FUNC,             TV_OUT_RGB},          // output RGB signal
       {YCBCR_FUNC,           TV_OUT_YCbCr},        // output YCbCr signal
       {SDTV_RGB_FUNC,        P720X576_SDTV_VF},    // output SDTV_RGB signal
       {SDTV_YPBPR_FUNC,      P720X576_SDTV_VF},    // output SDTV_YPbPr signal
       {0xFF,                 NULL}                 // End of table
};

 //-------------------------Fit scan level-------------------------------------

  BYTE N640_TV_VF [] = {
        // normal registers     
        0x03,0x00,0x10,0x1F,0x00 ,   // TV.00-04
        0x00,0x00,0x59,0x30,0x05,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0xF6,0x27,    // TV.0F-13
        0xA4,0x2C,0xAC,0xE6,0x63,    // TV.14-18
        0x2C,0x00,0x50,0x01,0x80,    // TV.19-1D
        0x80,0x18,0x1C,0x2A,0x20,    // TV.1E-22
        0x77,0x04,			         // TV.23-24

        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F

        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                        // TV.4F

        // Set Video Timing
        // TV CRTC registers
        0xAF,0x82,0x24,0x3D,0x02,    // TV.50-54
        // TV Timing registers
        0x8F,0xF3,0x61,0x12,0x6A,    // TV.55-59
        0x9E,0xCA,0xEB,0x04,	     // TV.5A-5D

        // TV CRTC
        0xF2,0x43,0x8B,0x2A,0xFF,    // TV.5E-62
        0x1F,0x05,				     // TV.63-64

        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00, 		  // TV.70-73
};

// TV work on IGA1
 WORD Fit_NTSC_CRTC_640   []  = {            
        1200,                       // H_Total
        640,                        // H_Display_End
        640,                        // H_Blanking_Start
        1200,                       // H_Blanking_End
        1040,                       // H_Sync_Start
        1112,                       // H_Sync_End
        574,                        // V_Total
        480,                        // V_Display_End
        480,                        // V_Blanking_Start
        574,                        // V_Blanking_End
        488,                        // V_Sync_Start
        495,                        // V_Sync_End
};


 BYTE N800_TV_VF [] = {                
        // normal registers
        0x03,0x00,0x10,0x90,0x00,    // TV.00-04
        0x00,0x00,0x87,0x37,0xFE,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB7,0x00,0x80,0x29,0x0B,    // TV.0F-13
        0x30,0x24,0xD6,0x7B,0xF0,    // TV.14-18
        0x21,0x00,0x50,0x01,0x80,    // TV.19-1D
        0x00,0x10,0x1C,0x2A,0xC8,    // TV.1E-22
        0x77,0x00,			         // TV.23-24
      
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
      
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x4A,                       // TV.4F
              
        // Set Video Timing
        // TV CRTC registers
        0xAF,0x23,0x34,0xD7,0x22,   // TV.50-54
        // TV Timing registers
        0x59,0x91,0x7F,0x23,0x90,   // TV.55-59
        0xD2,0x13,0x7A,0x16,        // TV.5A-5D
        // TV CRTC
        0x7E,0xC5,0xB1,0xA9,0xFF,   // TV.5E-62
        0x7F,0x06,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00, 		  // TV.70-73
};       

		
 WORD Fit_NTSC_CRTC_800 [] = { 
         1200,                        // H_Total
         800 ,                        // H_Display_End
         800 ,                        // H_Blanking_Start
         1200 ,                       // H_Blanking_End
         848 ,                        // H_Sync_Start
         1064 ,                       // H_Sync_End
         728 ,                        // V_Total
         600 ,                        // V_Display_End
         600 ,                        // V_Blanking_Start
         728 ,                        // V_Blanking_End
         656 ,                        // V_Sync_Start
         665                          // V_Sync_End
};



 BYTE N1024_TV_VF [] = {   
        // normal registers
        0x03,0x00,0x10,0x9A,0x00 ,   // TV.00-04
        0x00,0x00,0x97,0x40,0x10,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0xF6,0x27,    // TV.0F-13
        0x0C,0x2D,0x6D,0x07,0x2A,    // TV.14-18
        0x1B,0x00,0x50,0x03,0x80,    // TV.19-1D
        0x00,0x0C,0x16,0xFF,0x1B,    // TV.1E-22
        0x77,0x00,		             // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
       
       
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                        // TV.4F
            
        // Set Video Timing
        // TV CRTC registers
        0xAF,0x03,0x44,0xA9,0x03,    // TV.50-54
        // TV Timing registers
        0x2F,0x3B,0x9F,0x34,0xB6,    // TV.55-59
        0x09,0x54,0x1D,0x58,		 // TV.5A-5D
        // TV CRTC
        0xB1,0xEC,0xE4,0xA9,0xFF,    // TV.5E-62
        0x5F,0x08,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};        



 WORD Fit_NTSC_CRTC_1024 [] = {
        1200,                        // H_Total
        1024,                        // H_Display_End
        1024,                        // H_Blanking_Start
        1200,                        // H_Blanking_End
        1032,                        // H_Sync_Start
        1048,                        // H_Sync_End
        938 ,                        // V_Total
        768 ,                        // V_Display_End
        768 ,                        // V_Blanking_Start
        938 ,                        // V_Blanking_End
        777 ,                        // V_Sync_Start
        786  				 // V_Sync_End
};


 BYTE N848_TV_VF [] = {    
        // normal registers
        0x04,0x00,0x10,0x06,0x03,   // TV.00-04
        0x00,0x20,0x47,0xb5,0x0b,   // TV.05-09
        0x53,0x00,0x50,0x3a,0x3F,   // TV.0A-0E
        0x00,0x00,0x00,0xed,0x23,   // TV.0F-13
        0x0e,0x35,0x84,0x84,0xF6,   // TV.14-18
        0x1a,0x00,0x10,0x03,0x80,   // TV.19-1D
        0x00,0x44,0x11,0x0a,0x78,   // TV.1E-22
        0x73,0x04,                 	// TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x04,0x00,   // TV.4A-4E
        0x39,                       // TV.4F
             
        // Set Video Timing
        // TV CRTC registers
        0xe7,0x4F,0x33,0x36,0x02,   // TV.50-54
        // TV Timing registers
        0x37,0x39,0x9F,0x74,0xb7,   // TV.55-59
        0x12,0x3a,0x12,0x58,        // TV.5A-5D
        // TV CRTC
        0x52,0x1a,0x04,0x00,0x01,   // TV.5E-62
        0x37,0x04,                  // TV.63-64

        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};



 BYTE Fit_NTSC_CRTC_848 [] = {
        19,                		   // number of setting CRTC's registers 19
        0x78,0x69,0x69,0x9c,0x6b,  // CRTC 0-4
        0x94,0x35,0x3e,0x40,0xea,  // CRTC 5-7 9 & 10
        0xdF,0xdF,0x36,            // CRTC 12 15-16
        0x20,                      // CRTC 33.BIT[5]
        0x40,0x00,0x00,       	   // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N,     // Vclk 3c5.46-47    
    
                                   // TV work on IGA2
        0xe7,0x4F,0x4F,0xe7,0xdb,  // CRTC 50-54
        0x33,0x67,0x9F,0x36,0xdF,  // CRTC 55-59
        0xdF,0x36,0x51,0x0a,0xe4,  // CRTC 5A-5E
        0x2b,					   // CRTC 5F
        0x35,0x6a,0x00,            // CRTC 65-67 for 848x480 8bpp
        0x6a,0xd4,0x40,            // CRTC 65-67 for 848x480 16bpp
        0xd4,0xa8,0xC1,            // CRTC 65-67 for 848x480 32bpp
        0x80,0x00,0x80, 	       // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N      // LCK 3c5.44-45
};


 BYTE N720X480_TV_VF [] = {                  
        // normal registers
        0x03,0x00,0x10,0x1F,0x00,   // TV.00-04 
        0x00,0x00,0x41,0x3B,0x0B,   // TV.05-09 
        0x7B,0x15,0x50,0x57,0x3F,   // TV.0A-0E 
        0xB7,0x00,0x80,0xCD,0x21,   // TV.0F-13
        0x73,0x34,0xD6,0x7B,0xF0,   // TV.14-18
        0x21,0x00,0x50,0x03,0x80,   // TV.19-1D
        0x00,0x10,0x1C,0x08,0xCA,   // TV.1E-22
        0x77,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,   // TV.4A-4E 
        0x4A,                       // TV.4F 
                    
        // Set Video Timing
        // TV CRTC registers
        0x47,0xCF,0x23,0x3E,0x22,   // TV.50-54
        // TV Timing registers
        0x59,0x8B,0x7F,0x23,0x91,   // TV.55-59
        0xD2,0x13,0x7A,0x16,        // TV.5A-5D
        // TV CRTC
        0x30,0xD4,0x8C,0x28,0xFF,   // TV.5E-62
        0x97,0x03,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};


 WORD Fit_NTSC_CRTC_720X480 [] = {
        840,                        // H_Total
        720,                        // H_Display_End
        720,                        // H_Blanking_Start
        840,                        // H_Blanking_End
        728,                        // H_Sync_Start
        776,                        // H_Sync_End
        575,                        // V_Total
        480,                        // V_Display_End
        480,                        // V_Blanking_Start
        575,                        // V_Blanking_End
        484,                        // V_Sync_Start
        499                         // V_Sync_End
};


 BYTE P640_TV_VF [] = { 
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,   // TV.00-04
        0x00,0x00,0x52,0x3A,0x05,   // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,   // TV.0A-0E
        0xB7,0x00,0x80,0xCC,0x24,   // TV.0F-13
        0x73,0x30,0xCB,0x8A,0x09,   // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,   // TV.19-1D
        0x00,0x10,0x17,0x1C,0x35,   // TV.1E-22
        0x7D,0x00,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,   // TV.4A-4E
        0x51,                       // TV.4F
             
        // Set Video Timing
        // TV CRTC registers
        0xE7,0x81,0x23,0x3E,0x22,   // TV.50-54
        // TV Timing registers
        0x5F,0x80,0x7F,0x23,0x94,   // TV.55-59
        0xD1,0x27,0x8F,0x16,        // TV.5A-5D
        // TV CRTC
        0xC2,0x00,0x75,0x20,0xFF,   // TV.5E-62
        0x97,0x03,		            // TV.63-64    
        
        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};


 WORD  Fit_PAL_CRTC_640 [] = {
        1000,                       //H_Total
        640,                        //H_Display_End
        640,                        //H_Blanking_Start
        1000,                       //H_Blanking_End
        840,                        //H_Sync_Start
        920,                        //H_Sync_End
        575,                        //V_Total
        480,                        //V_Display_End
        480,                        //V_Blanking_Start
        575,                        //V_Blanking_End
        501,                        //V_Sync_Start
        504                         //V_Sync_End
};



 BYTE P800_TV_VF [] = { 
        // normal registers
        0x03,0x00,0x10,0x90,0x03,   // TV.00-04
        0x00,0x00,0x48,0x37,0x13,   // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,   // TV.0A-0E
        0xB0,0x00,0x80,0xE9,0x30,   // TV.0F-13
        0x91,0x24,0xCB,0x8A,0x09,   // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,   // TV.19-1D
        0x00,0x10,0x17,0x1C,0x32,   // TV.1E-22
        0x7D,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
      
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,   // TV.4A-4E
        0x51,                       // TV.4F
             
        // Set Video Timing
        // TV CRTC registers
        0xE7,0x21,0x33,0xD4,0x22,   // TV.50-54
        // TV Timing registers
        0x5F,0x87,0x7F,0x23,0x94,   // TV.55-59
        0xD1,0x27,0x8F,0x16,       	// TV.5A-5D
        // TV CRTC
        0x7A,0xE8,0x94,0xA9,0xFF,   // TV.5E-62
        0x87,0x04,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};      



 WORD Fit_PAL_CRTC_800 [] = {
        1000,                       //H_Total
        800,                        //H_Display_End
        800,                        //H_Blanking_Start
        1000,                       //H_Blanking_End
        848,                        //H_Sync_Start
        928,                        //H_Sync_End
        725,                        //V_Total
        600,                        //V_Display_End
        600,                        //V_Blanking_Start
        725,                        //V_Blanking_End
        602,                        //V_Sync_Start
        603                         //V_Sync_End
};


 BYTE P1024_TV_VF [] = {                
        //normal registers
        0x03,0x00,0x10,0x9A,0x03,   // TV.00-04
        0x00,0x00,0x98,0x40,0x0F,   // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,   // TV.0A-0E
        0xB5,0x00,0x80,0xF8,0x24,   // TV.0F-13
        0x03,0x39,0x7A,0xE0,0x0E,   // TV.14-18
        0x23,0x00,0x50,0x01,0x80,   // TV.19-1D
        0x00,0x10,0x1D,0x1C,0xBA,   // TV.1E-22
        0x7D,0x00,                 	// TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,   // TV.4A-4E
        0x51,                       // TV.4F
             
        // Set Video Timing
        // TV CRTC registers
        0xAF,0x02,0x44,0x9C,0x03,   // TV.50-54
        // TV Timing registers
        0x0B,0x07,0x98,0x34,0xB2,   // TV.55-59
        0xFB,0x4E,0xF5,0x17,       	// TV.5A-5D
        // TV CRTC
        0x70,0x94,0xBD,0xAA,0xFF,   // TV.5E-62
        0xEF,0x06,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};


 WORD Fit_PAL_CRTC_1024 [] = {  
        1200,                        // H_Total
        1024,                        // H_Display_End
        1024,                        // H_Blanking_Start
        1200,                        // H_Blanking_End
        1032,                        // H_Sync_Start
        1048,                        // H_Sync_End
        925,                         // V_Total
        768,                         // V_Display_End
        768,                         // V_Blanking_Start
        925,                         // V_Blanking_End
        778,                         // V_Sync_Start
        784                          // V_Sync_End
};

 BYTE P848_TV_VF [] ={
        // normal registers
        0x04,0x00,0x10,0x06,0x00,    // TV.00-04
        0x00,0x20,0x4a,0xc8,0x41,    // TV.05-09
        0x5b,0x00,0x4d,0x3F,0x3F,    // TV.0A-0E
        0x00,0x00,0x00,0xea,0x2a,    // TV.0F-13
        0xFd,0x30,0x93,0x13,0xe6,    // TV.14-18
        0x20,0x00,0x10,0x03,0x80,    // TV.19-1D
        0x00,0xcc,0x12,0x0c,0x29,    // TV.1E-22
        0x79,0x08,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x04,0x00,    // TV.4A-4E
        0x40,                        // TV.4F
             
        // Set Video Timing
        // TV CRTC registers
        0xe7,0x4F,0x33,0x3e,0x02,    // TV.50-54
        // TV Timing registers
        0x4F,0x38,0xa2,0x74,0xbe,    // TV.55-59
        0x0b,0x3c,0x47,0x58,         // TV.5A-5D
        // TV CRTC
        0xae,0x1c,0x03,0x00,0x01,    // TV.5E-62
        0x97,0x03,                   // TV.63-64

        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};        


 BYTE Fit_PAL_CRTC_848 [] = {
        // TV work on IGA1
        19,							 // number of setting CRTC's registers 19
        0x78,0x69,0x69,0x9c,0x6b,    // CRTC 0-4
        0x94,0x3d,0x3e,0x40,0xea,    // CRTC 5-7 9 & 10
        0xdF,0xdF,0x3e,              // CRTC 12 15-16
        0x20,                    	 // CRTC 33.BIT[5]
        0x40,0x00,0x00,       		 // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N,       // Vclk 3c5.46-47

        // TV work on IGA2         
        0xe7,0x4F,0x4F,0xe7,0xdb,    // CRTC 50-54
        0x33,0x57,0x9F,0x3e,0xdF,    // CRTC 55-59
        0xdF,0x3e,0x51,0x0a,0xe5,    // CRTC 5A-5E
        0x28,                     	 // CRTC 5F
        0x35,0x6a,0x00,              // CRTC 65-67 for 848x480 8bpp
        0x6a,0xd4,0x40,              // CRTC 65-67 for 848x480 16bpp
        0xd4,0xa8,0xC1,              // CRTC 65-67 for 848x480 32bpp
        0x80,0x00,0x80,        	  	 // CRTC 6A-6C
        TV_Clock_D,TV_Clock_N        // LCK 3c5.44-45
};


 BYTE P720X576_TV_VF [] = {                  
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,    // TV.00-04
        0x00,0x10,0x03,0x39,0x06,    // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0x69,0x18,    // TV.0F-13
        0x43,0x24,0xCB,0x8A,0x09,    // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,    // TV.19-1D
        0x00,0x10,0x17,0x0C,0x32,    // TV.1E-22
        0x7D,0x02,                 	 // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x51,                        // TV.4F
            
        // Set Video Timing
        // TV CRTC registers
        0xE7,0xCF,0x23,0x9D,0x22,    // TV.50-54
        // TV Timing registers
        0x5F,0x83,0x7E,0x23,0x94,    // TV.55-59
        0xD0,0x27,0x8F,0x16,         // TV.5A-5D
        // TV CRTC
        0x37,0xF3,0x89,0x28,0xFF,    // TV.5E-62
        0x2F,0x04,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,   // TV.6B-6F
        0x00,0x00,0x00,0x00     	// TV.70-73
};

 WORD Fit_PAL_CRTC_720X576 [] = {
        1000,                        // H_Total
        720,                         // H_Display_End
        720,                         // H_Blanking_Start
        1000,                        // H_Blanking_End
        728,                         // H_Sync_Start
        744,                         // H_Sync_End
        670,                         // V_Total
        576,                         // V_Display_End
        576,                         // V_Blanking_Start
        670,                         // V_Blanking_End
        586,                         // V_Sync_Start
        592                          // V_Sync_End
};


#define N640_SDTV_REG_BUFLEN_VF  (27 * 2 + 1)
#define N640_SDTV_REG_NUM_VF  (N640_SDTV_REG_BUFLEN_VF - 1) /2


 BYTE N640_SDTV_VF  [N640_SDTV_REG_BUFLEN_VF] = {    
        N640_SDTV_REG_NUM_VF,           // update number of registers    27
        RegIndexVal(0x03,  0x40),		// 04003h   Filter Selection
        RegIndexVal(0x04,  0x10),		// 01004h   Output Mode
        RegIndexVal(0x07,  0x56),		// 05607h  Start Active Video
        RegIndexVal(0x08,  0x38),		// 03808h   adjust TV's Position 
        RegIndexVal(0x0B,  0x00),		//0000Bh   Blanking Level set to zero 
        RegIndexVal(0x1F,  0x01),		// 0011Fh   Filter Switch
        RegIndexVal(0x51,  0x84),		// 08451h   TV Timing
        RegIndexVal(0x54,  0x02),		// 00254h, 03355h, 07956h, 07957h  ; TV Timing
        RegIndexVal(0x55,  0x33),
        RegIndexVal(0x56,  0x79),
        RegIndexVal(0x57,  0x79),
        RegIndexVal(0x59,  0x85),		// 08559h, 0CA5Ah, 0075Bh   TV Timing
        RegIndexVal(0x5A,  0xCA),
        RegIndexVal(0x5B,  0x07),
        RegIndexVal(0x5C,  0x32),		// 0325Ch, 0165Dh, 0F25Eh, 0225Fh  TV Timing
        RegIndexVal(0x5D,  0x16),
        RegIndexVal(0x5E,  0xF2),
        RegIndexVal(0x5F,  0x22),
        RegIndexVal(0x60,  0x8B),		// 08B60h, 02861h  Scaling
        RegIndexVal(0x61,  0x28),
        RegIndexVal(0x62,  0x00),		// 00062h  Adaptive Deflicker Disable
        RegIndexVal(0x6B,  0x00),		// register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E,  0x00),
        RegIndexVal(0x6F,  0x00),
        RegIndexVal(0x70,  0x00),		// spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x72,  0x00),
        RegIndexVal(0x73,  0x00)
};     

#define N800_SDTV_REG_BUFLEN_VF  (18 * 2 + 1)
#define N800_SDTV_REG_NUM_VF  (N800_SDTV_REG_BUFLEN_VF - 1) / 2

 BYTE N800_SDTV_VF [N800_SDTV_REG_BUFLEN_VF] = {  
        N800_SDTV_REG_NUM_VF,       //  update number of registers  18
        RegIndexVal(0x03, 0xC0),		//  0C003h  Filter Selection
        RegIndexVal(0x04, 0x10),		//  01004h  Output Mode
        RegIndexVal(0x07, 0x86),		//  08607h  Start Active Video
        RegIndexVal(0x08, 0x3F),		//  03F08h, 0FC09h  adjust TV's Position
        RegIndexVal(0x09, 0xFC), 
        RegIndexVal(0x0B, 0x00),		//  0000Bh  Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),		//  reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x20, 0x2F),		// 02F20h  TV Sync step
        RegIndexVal(0x62, 0x00),		// 00062h  Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),		// register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),
        RegIndexVal(0x6F, 0x00),
        RegIndexVal(0x70, 0x00),		// spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x72, 0x00),
        RegIndexVal(0x73, 0x00)
};

#define N1024_SDTV_REG_BUFLEN_VF   (15*2 + 1)
#define N1024_SDTV_REG_NUM_VF      (N1024_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE N1024_SDTV_VF [N1024_SDTV_REG_BUFLEN_VF] = {
        N1024_SDTV_REG_NUM_VF,      //  update number of registers    15
        RegIndexVal(0x03, 0xC0),		//  0C003h  Filter Selection
        RegIndexVal(0x04, 0x10),		//  01004h  Output Mode
        RegIndexVal(0x07, 0x96),		//  09607h  Start Active Video
        RegIndexVal(0x08, 0x46),		//  04608h, 00D09h  adjust TV's Position
        RegIndexVal(0x09, 0x0D),
        RegIndexVal(0x0B, 0x00),		//  0000Bh  Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),		//  reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),		//  0011Fh   Filter Switch
        RegIndexVal(0x20, 0x25),		//  02520h   TV Sync step
        RegIndexVal(0x51, 0x05),		//  00551h, 03D56h  TV Timing
        RegIndexVal(0x56, 0x3D),
        RegIndexVal(0x62, 0x00)		//	00062h  Adaptive Deflicker Disable
};

#define N848_SDTV_REG_REGLEN_VF  (11 * 2 + 1)
#define N848_SDTV_REG_NUM_VF  (N848_SDTV_REG_REGLEN_VF - 1) /2

 BYTE N848_SDTV_VF [N848_SDTV_REG_REGLEN_VF] = {
        N848_SDTV_REG_NUM_VF,       // update number of registers    11
        RegIndexVal(0x02, 0x2A),		// 02a02h, 00b04h   output SDTV_RGB type
        RegIndexVal(0x04, 0x0B),
        RegIndexVal(0x08, 0xA8),		// 0a808h, 00609h, 0011ch  adjust TV's Position
        RegIndexVal(0x09, 0x06),
        RegIndexVal(0x1C, 0x01),
        RegIndexVal(0x00, 0x04),		// 00400h, 00003h   disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),		// 0004dh  Y_DELAY = 0 
        RegIndexVal(0x65, 0x82),		// 08265h, 08066h, 08167h  adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66, 0x80),
        RegIndexVal(0x67, 0x81)
};

#define N720X480_SDTV_REG_BUFLEN_VF  (18 * 2 + 1)
#define N720X480_SDTV_REG_NUM_VF  (N720X480_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE N720X480_SDTV_VF [N720X480_SDTV_REG_BUFLEN_VF] = {
        N720X480_SDTV_REG_NUM_VF, // update number of registers    18
        RegIndexVal(0x03, 0x40),		// 04003h  Filter Selection
        RegIndexVal(0x04, 0x10),		// 01004h  Output Mode
        RegIndexVal(0x08, 0x43),		// 04308h, 00709h  adjust TV's Position
        RegIndexVal(0x09, 0x07),
        RegIndexVal(0x0B, 0x00),		// 0000Bh  Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),		// reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),		// 0011Fh  Filter Switch
        RegIndexVal(0x20, 0x2F),		// 02F20h  TV Sync step
        RegIndexVal(0x62, 0x00),		// 00062h  Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),		// register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),		// spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x6F, 0x00),		// NTSC 480p mode- WSS timing
        RegIndexVal(0x70, 0x00),		
        RegIndexVal(0x72, 0x00),		
        RegIndexVal(0x73, 0x00)		
};

#define N640_DOT_REG_BUFLEN_VF  (3 * 2 + 1)
#define N640_DOT_REG_NUM_VF  (N640_DOT_REG_BUFLEN_VF - 1) / 2

 BYTE N640_DotCrawl_VF [N640_DOT_REG_BUFLEN_VF] = {
        N640_DOT_REG_NUM_VF,        // update number of registers  3   
        RegIndexVal(0x11, 0x08),		// 0811h   enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x50),		// 05016h, 07b17h  adjust TV FSCI
        RegIndexVal(0x17, 0x7B)
};

#define N800_DOT_REG_BUFLEN_VF  (3 * 2 + 1)
#define N800_DOT_REG_NUM_VF  (N800_DOT_REG_BUFLEN_VF - 1) /2

 BYTE N800_Dotcrawl_VF  [N800_DOT_REG_BUFLEN_VF] = {
        N800_DOT_REG_NUM_VF,        // update number of registers  3  
        RegIndexVal(0x11, 0x08),		// 0811h   enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xD1),		// 0d116h, 0F617h   adjust TV FSCI
        RegIndexVal(0x17, 0xF6)
};

#define N1024_DOT_REG_BUFLEN_VF  (3 * 2 + 1)
#define N1024_DOT_REG_NUM_VF  (N1024_DOT_REG_BUFLEN_VF - 1) / 2

 BYTE N1024_DotCrawl_VF  [N1024_DOT_REG_BUFLEN_VF] = {
        N1024_DOT_REG_NUM_VF,       // update number of registers    3
        RegIndexVal(0x11, 0x08),		// 0811h  enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x06),		// 00616h, 08417h   adjust TV FSCI
        RegIndexVal(0x17, 0x84)
};

#define N848_DOT_REG_BUFLEN_VF  (3 *  2 + 1)
#define N848_DOT_REG_NUM_VF  (N848_DOT_REG_BUFLEN_VF - 1) /2

 BYTE N848_DotCrawl_VF [N848_DOT_REG_BUFLEN_VF] = {
        N848_DOT_REG_NUM_VF,        // update number of registers  3  
        RegIndexVal(0x11, 0x08),		// 0811h  enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x1C),		// 01c16h, 07d17h  adjust TV FSCI
        RegIndexVal(0x17, 0x7D)
};

#define N720x480_DOT_REG_BUFLEN_VF  (3 * 2 + 1)
#define N720x480_DOT_REG_NUM_VF  (N720x480_DOT_REG_BUFLEN_VF - 1) /2

 BYTE N720x480_DotCrawl_VF [N720x480_DOT_REG_BUFLEN_VF] = {
        N720x480_DOT_REG_NUM_VF,    // update number of registers    3
        RegIndexVal(0x11, 0x08),		// 0811h  enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xE8),		// 0e816h, 0eb17h  adjust TV FSCI
        RegIndexVal(0x17, 0xEB)
};

#define P640_SDTV_REG_BUFLEN_VF  (17 * 2 + 1)
#define P640_SDTV_REG_NUM_VF  (P640_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE P640_SDTV_VF  [P640_SDTV_REG_BUFLEN_VF] = {
        P640_SDTV_REG_NUM_VF,	    // update number of registers    17
        RegIndexVal(0x03, 0x40),		// 04003h  Filter Selection
        RegIndexVal(0x04, 0x13),		// 01304h  Output Mode
        RegIndexVal(0x07, 0x50),		// 05007h, 04308h, 00A09h  adjust TV's Position
        RegIndexVal(0x08, 0x43),
        RegIndexVal(0x09, 0x0A),
        RegIndexVal(0x1A, 0x00),		// reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),		// reserved Additional Register
        RegIndexVal(0x2B, 0x00), 
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),		// 0011Fh  Filter Switch
        RegIndexVal(0x20, 0x1C),		// 01C20h  TV Sync step
        RegIndexVal(0x51, 0x83),		// 08351h, 08356h   TV Timing
        RegIndexVal(0x56, 0x83),
        RegIndexVal(0x62, 0x00)			//  00062h   Adaptive Deflicker Disable
};

#define P800_SDTV_REG_BUFLEN_VF  (18 * 2 + 1)
#define P800_SDTV_REG_NUM_VF  (P800_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE P800_SDTV_VF [P800_SDTV_REG_BUFLEN_VF] = {
        P800_SDTV_REG_NUM_VF,  // update number of registers    18
        RegIndexVal(0x03, 0xC0),		// 0C003h  Filter Selection
        RegIndexVal(0x04, 0x13),		// 01304h  Output Mode
        RegIndexVal(0x07, 0x46),		// 04607h  Start Active Video
        RegIndexVal(0x08, 0x41),		// 04108h, 02409h  adjust TV's Position
        RegIndexVal(0x09, 0x24),
        RegIndexVal(0x10, 0x08),		// 00810h   Hue Adjustment
        RegIndexVal(0x1A, 0x00),		// reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),		// reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),		// 0011Fh  Filter Switch
        RegIndexVal(0x20, 0x1C),		// 01C20h  TV Sync step
        RegIndexVal(0x51, 0x24),		// 02451h, 08956h  TV Timing
        RegIndexVal(0x56, 0x89),
        RegIndexVal(0x62, 0x00)			// 00062h  Adaptive Deflicker Disable
 };

#define P1024_SDTV_REG_BUFLEN_VF  (17 * 2 + 1)
#define P1024_SDTV_REG_NUM_VF  (P1024_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE P1024_SDTV_VF  [P1024_SDTV_REG_BUFLEN_VF] = {
        P1024_SDTV_REG_NUM_VF,      // update number of registers    17
        RegIndexVal(0x03, 0xC0),		// 0C003h  Filter Selection
        RegIndexVal(0x04, 0x13),		// 01304h  Output Mode
        RegIndexVal(0x07, 0x95),		// 09507h  Start Active Video
        RegIndexVal(0x08, 0x4B),		// 04B08h, 01A09h   adjust TV's Position
        RegIndexVal(0x09, 0x1A), 
        RegIndexVal(0x1A, 0x00),		// reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),		//reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x00),		// 0001Fh  Filter Switch
        RegIndexVal(0x51, 0x04),		// 00451h, 00956h, 09E5Ch   TV Timing
        RegIndexVal(0x56, 0x09),
        RegIndexVal(0x5C, 0x9E),
        RegIndexVal(0x62, 0x00)		// 00062h  Adaptive Deflicker Disable
 };

#define P848_SDTV_REG_BUFLEN_VF  (11 * 2 + 1)
#define P848_SDTV_REG_NUM_VF  (P848_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE P848_SDTV_VF  [P848_SDTV_REG_BUFLEN_VF] = {    
        P848_SDTV_REG_NUM_VF,       // update number of registers    11
        RegIndexVal(0x02, 0x2A),		// 02a02h, 00804h  output SDTV_RGB type
        RegIndexVal(0x04, 0x08),
        RegIndexVal(0x08, 0xBC),		// 0bc08h, 01209h, 0011ch   adjust TV's Position
        RegIndexVal(0x09, 0x12),
        RegIndexVal(0x1C, 0x01),
        RegIndexVal(0x00, 0x04),		// 00400h, 00003h  disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),		// 0004dh  Y_DELAY = 0
        RegIndexVal(0x65, 0x82),		// 08265h, 08066h, 08167h        ; adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66, 0x80),
        RegIndexVal(0x67, 0x81)
};

#define P720X576_SDTV_REG_BUFLEN_VF  (14 * 2 + 1)
#define P720X576_SDTV_REG_NUM_VF  (P720X576_SDTV_REG_BUFLEN_VF - 1) /2

 BYTE P720X576_SDTV_VF [P720X576_SDTV_REG_BUFLEN_VF] = {
        P720X576_SDTV_REG_NUM_VF,   // update number of registers    
        RegIndexVal(0x03, 0x40),		// 04003h  Filter Selection
        RegIndexVal(0x04, 0x13),		// 01304h  Output Mode
        RegIndexVal(0x08, 0x43),		// 04308h, 00D09h  adjust TV's Position
        RegIndexVal(0x09, 0x0D),
        RegIndexVal(0x1A, 0x00),		// reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),		// reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),		//  0011Fh  Filter Switch
        RegIndexVal(0x20, 0x1C),		//  01C20h  TV Sync step
        RegIndexVal(0x62, 0x00)		//  00062h  Adaptive Deflicker Disable
 };




//---------------------------------------------------------------------------
//                              Over Scanning
//---------------------------------------------------------------------------
TVTBLDATA_UMA csTVModeOverTbl_1625 [] = {
        { MODE640,     Over_NTSC_640,   Over_PAL_640,       Over_NTSC_CRTC_640,     Over_PAL_CRTC_640 },    // 04 -> 640x480 tv modes
        { MODE800 ,    Over_NTSC_800,   Over_PAL_800,       Over_NTSC_CRTC_800,     Over_PAL_CRTC_800 },    // 05 -> 800x600 tv modes
        { MODE1024,    Over_NTSC_1024,  Over_PAL_1024,      Over_NTSC_CRTC_1024,    Over_PAL_CRTC_1024 },   // 06 -> 1024x768 tv modes
        //{ MODE848,     Over_NTSC_848,   Over_PAL_848,       Over_NTSC_CRTC_848,     Over_PAL_CRTC_848 },    // 07 -> 848x480 tv modes
        { MODE720X480, Over_NTSC_720X480, NULL,             Over_NTSC_CRTC_720X480, NULL },                // 08 -> NTSC 720x480 tv modes
        { MODE720X576, NULL,            Over_PAL_720X576,   NULL,                   Over_PAL_CRTC_720X576}, // 09 -> PAL  720x576 tv modes
        { 0xFF,         NULL, 		    NULL, 	            NULL,				    NULL}	                // end of table
};

//-----------------------Normal scan TV output type Table----------------------------

 TV_FUNCTION_UMA Over_NTSC_640 [] = { 
        // Index addr of table
        { TV_FUNC,         N640_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   N640_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, N640_SDTV_VO},       // output SDTV_YPbPr signal
        { DOTCRAWL_FUNC,   N640_DotCrawl_VO},   // enable dot crawl
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_NTSC_800 [] = {
        //Index addr of table                                                
        { TV_FUNC,         N800_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   N800_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, N800_SDTV_VO},       // output SDTV_YPbPr signal
        { DOTCRAWL_FUNC,   N800_DotCrawl_VO},   // enable dot crawl
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_NTSC_1024 [] = {
        //Index addr of table           
        { TV_FUNC,         N1024_TV_VO},        // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   N1024_SDTV_VO},      // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, N1024_SDTV_VO},      // output SDTV_YPbPr signal
        { DOTCRAWL_FUNC,   N1024_DotCrawl_VO},  // enable dot crawl
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_NTSC_848 [] = {
        //Index addr of table           
        { TV_FUNC,         N848_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   N848_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, N848_SDTV_VO},       // output SDTV_YPbPr signal
        { DOTCRAWL_FUNC,   N848_DotCrawl_VO},   // enable dot crawl
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_NTSC_720X480 [] = {
        //Index addr of table           
        { TV_FUNC,         N720X480_TV_VO},     // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   N720X480_SDTV_VO},   // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, N720X480_SDTV_VO},   // output SDTV_YPbPr signal
        { DOTCRAWL_FUNC,   N720x480_DotCrawl_VO}, // enable dot crawl
        { YCBCR_IN_FUNC,   N720X480_YCbCr_IN_VN}, // input YCbCr signal
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_PAL_640 [] = {
        //Index addr of table  
        { TV_FUNC,         P640_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   P640_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, P640_SDTV_VO},       // output SDTV_YPbPr signal
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_PAL_800 [] = {
        //Index addr of table  
        { TV_FUNC,         P800_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   P800_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, P800_SDTV_VO},       // output SDTV_YPbPr signal
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_PAL_1024 [] = {
        // Index addr of table
        { TV_FUNC,         P1024_TV_VO},        // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   P1024_SDTV_VO},      // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, P1024_SDTV_VO},      // output SDTV_YPbPr signal
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_PAL_848 [] = {
        // Index addr of table
        { TV_FUNC,         P848_TV_VO},         // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   P848_SDTV_VO},       // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, P848_SDTV_VO},       // output SDTV_YPbPr signal
        { 0xFF ,            NULL }              // End of table  
};

 TV_FUNCTION_UMA Over_PAL_720X576 [] = {
        // Index addr of table
        { TV_FUNC,         P720X576_TV_VO},     // Set TV mode (output CVBS and S-VIDEO)
        { RGB_FUNC,        TV_OUT_RGB},         // output RGB signal
        { YCBCR_FUNC,      TV_OUT_YCbCr},       // output YCbCr signal
        { SDTV_RGB_FUNC,   P720X576_SDTV_VO},   // output SDTV_RGB signal
        { SDTV_YPBPR_FUNC, P720X576_SDTV_VO},   // output SDTV_YPbPr signal
        { YCBCR_IN_FUNC,   P720X576_YCbCr_IN_VN},   // input YCbCr signal
        { 0xFF ,            NULL }              // End of table  
};

//-------------------------Over scan level-------------------------------------

 BYTE N640_TV_VO [] = {
        // normal registers     
        0x03,0x00,0x10,0x1F,0x00,    // TV.00-04
        0x00,0x00,0x86,0x1E,0x01,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0xFA,0x21,    // TV.0F-13
        0xC7,0x68,0xD6,0x7B,0xF0,    // TV.14-18
        0x21,0x00,0x50,0x03,0x80,    // TV.19-1D
        0x00,0x10,0x1C,0x2A,0xCA,    // TV.1E-22
        0x77,0x00,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F

        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                      // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x1B,0x81,0x23,0x0C,0x22,    // TV.50-54
        // TV Timing registers
        0x59,0xB5,0x7F,0x23,0x90,    // TV.55-59
        0xD3,0x0D,0x7A,0x16,         // TV.5A-5D
        // TV CRTC
        0x00,0x64,0x80,0x27,0xFF,    // TV.5E-62
        0x1B,0x03,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00         // TV.70-73  
};

 WORD Over_NTSC_CRTC_640  [] = {
        796,                       // H_Total
        640,                       // H_Display_End
        640,                       // H_Blanking_Start
        796,                       // H_Blanking_End
        648,                       // H_Sync_Start
        664,                       // H_Sync_End
        525,                       // V_Total
        480,                       // V_Display_End
        480,                       // V_Blanking_Start
        525,                       // V_Blanking_End
        490,                       // V_Sync_Start
        496                        // V_Sync_End
};

 BYTE N800_TV_VO  [] = {
        // normal registers
        0x03,0x00,0x10,0x90,0x00,    // TV.00-04
        0x00,0x10,0x01,0x1E,0x03,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0xED,0x21,    // TV.0F-13
        0xBC,0x34,0xD6,0x7B,0xF0,    // TV.14-18
        0x21,0x00,0x50,0x03,0x80,    // TV.19-1D
        0x00,0x10,0x1C,0x2A,0xCA,    // TV.1E-22
        0x77,0x00,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                      // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xAF,0x22,0x34,0x91,0x22,    // TV.50-54
        // TV Timing registers
        0x59,0xC6,0x7F,0x23,0x90,    // TV.55-59
        0xD2,0xEE,0x7A,0x06,        // TV.5A-5D
        // TV CRTC
        0x6D,0x06,0xA0,0x29,0xFF,    // TV.5E-62
        0xDF,0x05,                 // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00         // TV.70-73
};
        

 WORD Over_NTSC_CRTC_800 [] = {
        1200,                     // H_Total
        800,                      // H_Display_End
        800,                      // H_Blanking_Start
        1200,                     // H_Blanking_End
        880,                      // H_Sync_Start
        946,                      // H_Sync_End
        658,                      // V_Total
        600,                      // V_Display_End
        600,                      // V_Blanking_Start
        658,                      // V_Blanking_End
        610,                      // V_Sync_Start
        616                       // V_Sync_End
};

 BYTE N1024_TV_VO [] = { 
        // normal registers
        0x03,0x00,0x10,0x9A,0x00,    // TV.00-04
        0x00,0x00,0x48,0x23,0x05,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB0,0x00,0x80,0x2A,0x0D,    // TV.0F-13
        0x28,0x18,0xA1,0x64,0x93,    // TV.14-18
        0x1B,0x00,0x50,0x05,0x80,    // TV.19-1D
        0x00,0x0C,0x17,0xFF,0x37,    // TV.1E-22
        0x77,0x00,                 // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                      // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x5F,0x03,0x44,0x38,0x03,    // TV.50-54
        // TV Timing registers
        0x1F,0x60,0x9C,0x34,0xB3,    // TV.55-59
        0x04,0x2D,0x00,0x58,         // TV.5A-5D
        // TV CRTC
        0x24,0x7F,0xC9,0x29,0xFF,    // TV.5E-62
        0xDF,0x06,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD Over_NTSC_CRTC_1024  [] = {
        1120,                      // H_Total
        1024,                      // H_Display_End
        1024,                      // H_Blanking_Start
        1120,                      // H_Blanking_End
        1032,                      // H_Sync_Start
        1048,                      // H_Sync_End
        825,                       // V_Total
        768,                       // V_Display_End
        768,                       // V_Blanking_Start
        825,                       // V_Blanking_End
        777,                       // V_Sync_Start
        786,                       // V_Sync_End
};

 BYTE N848_TV_VO [] = {
        // normal registers
        0x84,0x00,0x10,0x04,0x03,        // TV.00-04
        0x00,0x20,0x4e,0x9e,0x07,        // TV.05-09
        0x51,0x00,0x50,0x3a,0x3F,        // TV.0A-0E
        0x00,0x00,0x00,0xed,0x23,        // TV.0F-13
        0x08,0x35,0xa1,0x64,0x93,        // TV.14-18
        0x1b,0x00,0x10,0x03,0x80,        // TV.19-1D
        0x00,0x44,0x11,0x0a,0xF0,        // TV.1E-22
        0x73,0x04,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x04,0x00,        // TV.4A-4E
        0x39,                       // TV.4F
              
        // Set Video Timing
        // TV CRTC registers
        0xeF,0x51,0x33,0x25,0x02,        // TV.50-54
        // TV Timing registers
        0x1F,0x47,0x9c,0x74,0xb5,        // TV.55-59
        0x0c,0x3d,0xF1,0x57,            // TV.5A-5D
        // TV CRTC
        0x30,0x0c,0x04,0x00,0x01,        // TV.5E-62
        0x1F,0x04,                   // TV.63-64

        0x00,0x00,0x00,0x00,0x00,        // TV.6B-6F
        0x00,0x00,0x00,0x00     
};        

 BYTE N720X480_TV_VO [] = {
        // normal registers
        0x03,0x00,0x10,0x1F,0x00,    // TV.00-04
        0x00,0x00,0x02,0x10,0x00,    // TV.05-09
        0x7B,0x15,0x50,0x57,0x3F,    // TV.0A-0E
        0xB7,0x00,0x80,0xAD,0x21,    // TV.0F-13
        0x64,0x34,0xD6,0x7B,0xF0,    // TV.14-18
        0x21,0x00,0x50,0x01,0x80,    // TV.19-1D
        0x00,0x10,0x1C,0x08,0xE5,    // TV.1E-22
        0x77,0x02,                  // TV.23-24

        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x4A,                      // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0x1F,0xD2,0x23,0x0C,0x22,    // TV.50-54

        // TV Timing registers
        0x59,0xc0,0x7E,0x23,0x8C,    // TV.55-59
        0xD0,0xF6,0x7C,0x06,         // TV.5A-5D
        // TV CRTC
        0x00,0x34,0x80,0x28,0xFF,    // TV.5E-62
        0x1F,0x03,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,        // TV.6B-6F
        0x00,0x00,0x00,0x00     
};
        

 WORD Over_NTSC_CRTC_720X480 [] = {
        800,                       // H_Total
        720,                       // H_Display_End
        720,                       // H_Blanking_Start
        800,                       // H_Blanking_End
        760,                       // H_Sync_Start
        800,                       // H_Sync_End
        525,                       // V_Total
        480,                       // V_Display_End
        480,                       // V_Blanking_Start
        525,                       // V_Blanking_End
        482,                       // V_Sync_Start
        485                        // V_Sync_End
};

 BYTE P640_TV_VO  [] = {
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,    // TV.00-04
        0x00,0x03,0x4E,0x39,0x31,    // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,    // TV.0A-0E
        0xB7,0x00,0x80,0x0D,0x09,    // TV.0F-13
        0x1A,0x30,0xCB,0x8A,0x09,    // TV.14-18
        0x2A,0x00,0x50,0x03,0x80,    // TV.19-1D
        0x00,0x10,0x17,0x1C,0x2D,    // TV.1E-22
        0x7D,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x51,                      // TV.4F
               
        // Set Video Timing
        // TV CRTC registers
        0xE7,0x87,0x23,0x07,0x22,    // TV.50-54
        // TV Timing registers
        0x5F,0xFF,0x7F,0x23,0x94,    // TV.55-59
        0xD1,0x13,0x9E,0x16,         // TV.5A-5D
        // TV CRTC
        0x7F,0x3A,0x6A,0x27,0xFF,    // TV.5E-62
        0x3F,0x03,                  // TV.63-64        
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};
        
 WORD Over_PAL_CRTC_640 [] = {
        1000,                      // H_Total
        640,                       // H_Display_End
        640,                       // H_Blanking_Start
        1000,                      // H_Blanking_End
        816,                       // H_Sync_Start
        928,                       // H_Sync_End
        520,                       // V_Total
        480,                       // V_Display_End
        480,                       // V_Blanking_Start
        520,                       // V_Blanking_End
        490,                       // V_Sync_Start
        496                        // V_Sync_End
};


 BYTE P800_TV_VO [] = {
        // normal registers
        0x03,0x00,0x10,0x90,0x03,    // TV.00-04
        0x00,0x00,0x46,0x00,0x32,    // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,    // TV.0A-0E
        0xB7,0x00,0x80,0x6C,0x12,    // TV.0F-13
        0x41,0x30,0xCB,0x8A,0x09,    // TV.14-18
        0x2A,0x00,0x50,0x03,0x80,    // TV.19-1D
        0x00,0x10,0x17,0x1C,0x34,    // TV.1E-22
        0x7D,0x02,                 // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,    // TV.4A-4E
        0x51,                      // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xE7,0x87,0x33,0x89,0x22,    // TV.50-54
        // TV Timing registers
        0x5F,0xE0,0x7F,0x23,0x94,    // TV.55-59
        0xD1,0x05,0x85,0x16,         // TV.5A-5D
        // TV CRTC
        0x1E,0x1F,0x85,0xA9,0xFF,    // TV.5E-62
        0x0F,0x04,                  // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};
             
 WORD Over_PAL_CRTC_800 [] = {
        1000,                       // H_Total
        800,                        // H_Display_End
        800,                        // H_Blanking_Start
        1000,                       // H_Blanking_End
        872,                        // H_Sync_Start
        928,                        // H_Sync_End
        650,                        // V_Total
        600,                        // V_Display_End
        600,                        // V_Blanking_Start
        650,                        // V_Blanking_End
        608,                        // V_Sync_Start
        620                         // V_Sync_End
};

 BYTE P1024_TV_VO [] = {
        // normal registers
        0x03,0x00,0x10,0x9A,0x03,     // TV.00-04
        0x00,0x10,0xCF,0x1E,0x37,     // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,     // TV.0A-0E
        0xB0,0x00,0x80,0xE4,0x36,     // TV.0F-13
        0xA7,0x10,0xCB,0x8A,0x09,     // TV.14-18
        0x2A,0x00,0x50,0x03,0x80,     // TV.19-1D
        0x00,0x10,0x1D,0x1C,0xEE,     // TV.1E-22
        0x7D,0x02,                  // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,     // TV.4A-4E
        0x51,                       // TV.4F
               
        // Set Video Timing
        // TV CRTC registers
        0xCF,0x03,0x47,0x42,0x23,     // TV.50-54
        // TV Timing registers
        0x5F,0xBF,0x7F,0x23,0x93,     // TV.55-59
        0xD0,0x08,0x8D,0x16,          // TV.5A-5D
        // TV CRTC
        0x02,0xAB,0xAB,0xAB,0xFF,     // TV.5E-62
        0x6F,0x0A,                   // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};        
        

 WORD Over_PAL_CRTC_1024 [] = {
        2000,                       // H_Total
        1024,                       // H_Display_End
        1024,                       // H_Blanking_Start
        2000,                       // H_Blanking_End
        1504,                       // H_Sync_Start
        1536,                       // H_Sync_End
        835,                        // V_Total
        768,                        // V_Display_End
        768,                        // V_Blanking_Start
        835,                        // V_Blanking_End
        778,                        // V_Sync_Start
        784                         // V_Sync_End        
};

 BYTE P848_TV_VO [] = { 
        // normal registers
        0x84,0x00,0x10,0x04,0x00,     // TV.00-04
        0x00,0x20,0xa5,0xa1,0x38,     // TV.05-09
        0x5e,0x00,0x4d,0x41,0x3F,     // TV.0A-0E
        0x00,0x00,0x00,0xc7,0x1e,     // TV.0F-13
        0x79,0x1c,0xec,0xe5,0x64,     // TV.14-18
        0x22,0x00,0x10,0x03,0x80,     // TV.19-1D
        0x00,0xbb,0x12,0x0c,0x5a,     // TV.1E-22
        0x79,0x0c,                   // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0x00,0x00,0x00,0x04,0x00,     // TV.4A-4E
        0x3a,                       // TV.4F
                
        // Set Video Timing
        // TV CRTC registers
        0xaF,0x4F,0x34,0x25,0x02,     // TV.50-54
        // TV Timing registers
        0x1F,0x4F,0x9b,0x74,0xb7,     // TV.55-59
        0x0a,0x3F,0xF0,0x58,          // TV.5A-5D
        // TV CRTC
        0x85,0x00,0x03,0x00,0x01,     // TV.5E-62
        0x1F,0x04,                   // TV.63-64

        0x00,0x00,0x00,0x00,0x00,     // TV.6B-6F
        0x00,0x00,0x00,0x00           // TV.70-73
};

 BYTE P720X576_TV_VO  [] = {
        // normal registers
        0x03,0x00,0x10,0x1F,0x03,          // TV.00-04
        0x00,0x00,0x39,0x19,0x01,          // TV.05-09
        0x88,0x00,0x55,0x5E,0x3F,          // TV.0A-0E
        0x9E,0x00,0x80,0x04,0x08,          // TV.0F-13
        0x08,0x10,0xCB,0x8A,0x09,          // TV.14-18
        0x2A,0x00,0x50,0x01,0x80,          // TV.19-1D
        0x00,0x10,0x17,0x0C,0x32,          // TV.1E-22
        0x7D,0x02,                     // TV.23-24
        
        // reserved registers
        0x00,0x00,0x00,0x00,0x00,     // TV.25-29
        0x00,0x00,0x00,0x00,0x00,     // TV.2A-2E
        0x00,                       // TV.2F
        
        // Filter registers
        0xC5,0x0F,0x00,0x01,0x10,          // TV.4A-4E
        0x51,                         // TV.4F
              
        // Set Video Timing
        // TV CRTC registers
        0x5F,0xCF,0x23,0x70,0x22,          // TV.50-54
        // TV Timing registers
        0x5F,0xD0,0x7F,0x23,0x92,          // TV.55-59
        0xCE,0x0C,0x8E,0x16,              // TV.5A-5D
        // TV CRTC
        0x00,0x00,0x80,0x20,0xFF,          // TV.5E-62
        0x5F,0x03,                     // TV.63-64
        
        0x00,0x00,0x00,0x00,0x00,    // TV.6B-6F
        0x00,0x00,0x00,0x00          // TV.70-73
};

 WORD Over_PAL_CRTC_720X576 [] = {
        864,                        // H_Total
        720,                        // H_Display_End
        720,                        // H_Blanking_Start
        864,                        // H_Blanking_End
        760,                        // H_Sync_Start
        800,                        // H_Sync_End
        625,                        // V_Total
        576,                        // V_Display_End
        576,                        // V_Blanking_Start
        625,                        // V_Blanking_End
        578,                        // V_Sync_Start
        581                         // V_Sync_End
};

#define N640_SDTV_REG_BUFLEN_VO  (25 * 2 + 1)
#define N640_SDTV_REG_NUM_VO  (N640_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE N640_SDTV_VO [N640_SDTV_REG_BUFLEN_VO] = {
        N640_SDTV_REG_NUM_VO,       // update number of registers 25   
        RegIndexVal(0x03, 0x40),     // 04003h Filter Selection
        RegIndexVal(0x04, 0x10),     // 01004h Output Mode
        RegIndexVal(0x07, 0x84),     // 08407h Start Active Video
        RegIndexVal(0x08, 0x1D),     // 01D08h adjust TV's Position
        RegIndexVal(0x0B, 0x00),     // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1C, 0x00),     // reserved Additional Register
        RegIndexVal(0x1F, 0x01),     // 0011Fh Filter Switch
        RegIndexVal(0x51, 0x83),     // 08351h TV Timing
        RegIndexVal(0x54, 0x02),     // 00254h, 01B55h, 08356h, 07557h  ; TV Timing
        RegIndexVal(0x55, 0x1B),
        RegIndexVal(0x56, 0x83),
        RegIndexVal(0x57, 0x75),
        RegIndexVal(0x59, 0x81),     // 08159h, 0C45Ah, 0005Bh TV Timing
        RegIndexVal(0x5A, 0xC4),
        RegIndexVal(0x5B, 0x00),
        RegIndexVal(0x5C, 0x04),     // 0045Ch, 0005Fh TV Timing
        RegIndexVal(0x5F, 0x00),
        RegIndexVal(0x61, 0x20),     // 02061h Scaling
        RegIndexVal(0x62, 0x00),     // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),      // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),    
        RegIndexVal(0x6F, 0x00),
        RegIndexVal(0x70, 0x00),     
        RegIndexVal(0x72, 0x00),     // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x73, 0x00)
};

#define N800_SDTV_REG_BUFLEN_VO  (23 * 2 + 1)
#define N800_SDTV_REG_NUM_VO  (N800_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE N800_SDTV_VO [N800_SDTV_REG_BUFLEN_VO] = {
        N800_SDTV_REG_NUM_VO,       // update number of registers 23   
        RegIndexVal(0x03, 0xC0),     // 0C003h Filter Selection
        RegIndexVal(0x04, 0x10),     // 01004h Output Mode
        RegIndexVal(0x06, 0x00),     // 00006h, 0FB07h Start Active Video
        RegIndexVal(0x07, 0xFB),
        RegIndexVal(0x08, 0x26),     // 02608h, 00409h adjust TV's Position
        RegIndexVal(0x09, 0x04),
        RegIndexVal(0x0B, 0x00),     // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),     // reserved Additional Register
        RegIndexVal(0x1C, 0x00),     
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),     // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x29),     // 02920h TV Sync step
        RegIndexVal(0x51, 0x27),     // 02751h, 0C856h, 0EB5Bh TV Timing
        RegIndexVal(0x56, 0xC8),
        RegIndexVal(0x5B, 0xEB),
        RegIndexVal(0x62, 0x00),     // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),     // register is for 480i/480p/576i/720p/1080i that meet      
        RegIndexVal(0x6E, 0x00),   
        RegIndexVal(0x6F, 0x00),
        RegIndexVal(0x70, 0x00),          
        RegIndexVal(0x72, 0x00),     // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x73, 0x00)
};

#define N1024_SDTV_REG_BUFLEN_VO  (15 * 2 + 1)
#define N1024_SDTV_REG_NUM_VO  (N1024_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE N1024_SDTV_VO [N1024_SDTV_REG_BUFLEN_VO] = {    
        N1024_SDTV_REG_NUM_VO,      // update number of registers 15   
        RegIndexVal(0x03, 0xC0),     // 0C003h Filter Selection
        RegIndexVal(0x04, 0x10),     // 01004h Output Mode
        RegIndexVal(0x07, 0x47),     // 04707h Start Active Video
        RegIndexVal(0x08, 0x29),     // 02908h, 00009h adjust TV's Position
        RegIndexVal(0x09, 0x00),
        RegIndexVal(0x0B, 0x00),     // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),     // reserved Additional Register
        RegIndexVal(0x1C, 0x00),     
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),    
        RegIndexVal(0x1F, 0x01),     // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x28),     // 02820h TV Sync step
        RegIndexVal(0x51, 0x05),     // 00551h, 06156h TV Timing
        RegIndexVal(0x56, 0x61),
        RegIndexVal(0x62, 0x00)      // 00062h Adaptive Deflicker Disable
};

#define N848_SDTV_REG_BUFLEN_VO  (11 * 2 + 1)
#define N848_SDTV_REG_NUM_VO  (N848_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE N848_SDTV_VO [N848_SDTV_REG_BUFLEN_VO] = {
        N848_SDTV_REG_NUM_VO,       // update number of registers  11  
        RegIndexVal(0x02, 0x2A),     // 02a02h, 00b04h output SDTV_RGB type
        RegIndexVal(0x04, 0x0B),
        RegIndexVal(0x08, 0x97),     // 09708h, 00009h, 0011ch adjust TV's Position
        RegIndexVal(0x09, 0x00),
        RegIndexVal(0x1C, 0x01),
        RegIndexVal(0x00, 0x04),     // 00400h, 00003h disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),     // 0004dh Y_DELAY = 0
        RegIndexVal(0x65, 0x82),     // 08265h, 08066h, 08167h adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66, 0x80),
        RegIndexVal(0x67, 0x81)
};

#define N720X480_SDTV_BUFLEN_NUM_VO  (18 * 2 + 1)
#define N720X480_SDTV_REG_NUM_VO  (N720X480_SDTV_BUFLEN_NUM_VO - 1) /2

 BYTE N720X480_SDTV_VO [N720X480_SDTV_BUFLEN_NUM_VO] = {
        N720X480_SDTV_REG_NUM_VO,   // update number of registers 18   
        RegIndexVal(0x03, 0x40),     // 04003h Filter Selection
        RegIndexVal(0x04, 0x10),     // 01004h Output Mode
        RegIndexVal(0x08, 0x20),     // 02008h, 00009h adjust TV's Position
        RegIndexVal(0x09, 0x00),
        RegIndexVal(0x0B, 0x00),     // 0000Bh Blanking Level set to zero 
        RegIndexVal(0x1A, 0x00),     // reserved Additional Register 
        RegIndexVal(0x1C, 0x00),     
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x1F, 0x01),     // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x2F),     // 02F20h TV Sync step
        RegIndexVal(0x62, 0x00),     // 00062h Adaptive Deflicker Disable
        RegIndexVal(0x6B, 0x00),     // register is for 480i/480p/576i/720p/1080i that meet 
        RegIndexVal(0x6E, 0x00),     // spec of IEC61880/IEC61880-2/ETSI EN 300 294/EIA/CEA 805-A
        RegIndexVal(0x6F, 0x00),     // NTSC 480p mode- WSS timing
        RegIndexVal(0x70, 0x00),     
        RegIndexVal(0x72, 0x00),    
        RegIndexVal(0x73, 0x00)     
};

#define P640_SDTV_REG_BUFLEN_VO  (20 * 2 + 1)
#define P640_SDTV_REG_NUM_VO  (P640_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE P640_SDTV_VO [P640_SDTV_REG_BUFLEN_VO] = { 
        P640_SDTV_REG_NUM_VO,       // update number of registers 20   
        RegIndexVal(0x03, 0x40),     // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),     // 01304h Output Mode
        RegIndexVal(0x07, 0x48),     // 04807h Start Active Video
        RegIndexVal(0x09, 0x64),     // 06409h adjust TV's Position 
        RegIndexVal(0x1C, 0x00),     // reserved Additional Register
        RegIndexVal(0x1F, 0x01),     // 0011Fh Filter Switch
        RegIndexVal(0x54, 0x02),     // 00254h, 0FF55h, 0A056h, 07057h TV Timing
        RegIndexVal(0x55, 0xFF),
        RegIndexVal(0x56, 0xA0),
        RegIndexVal(0x57, 0x70),
        RegIndexVal(0x58, 0x22),     // 02258h, 08359h, 0B95Ah, 0D35Bh  ; TV Timing
        RegIndexVal(0x59, 0x83),
        RegIndexVal(0x5A, 0xB9),
        RegIndexVal(0x5B, 0xD3),
        RegIndexVal(0x5C, 0xC0),     // 0C05Ch, 0055Dh, 07E5Eh, 0005Fh  ; TV Timing
        RegIndexVal(0x5D, 0x05),
        RegIndexVal(0x5E, 0x7E),
        RegIndexVal(0x5F, 0x00),
        RegIndexVal(0x61, 0x20),     // 02061h Scaling
        RegIndexVal(0x62, 0x00)      // 00062h Adaptive Deflicker Disable
};

#define P800_SDTV_REG_BUFLEN_VO  (13 * 2 + 1)
#define P800_SDTV_REG_NUM_VO  (P800_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE P800_SDTV_VO [P800_SDTV_REG_BUFLEN_VO] = {    
        P800_SDTV_REG_NUM_VO,       // update number of registers 13   
        RegIndexVal(0x03, 0xC0),     // 0C003h Filter Selection
        RegIndexVal(0x04, 0x13),     // 01304h Output Mode
        RegIndexVal(0x09, 0x65),     // 06509h adjust TV's Position 
        RegIndexVal(0x1A, 0x00),     // reserved Additional Register
        RegIndexVal(0x1C, 0x00),     
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),     // reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),      // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x1C),      // 01C20h TV Sync step
        RegIndexVal(0x62, 0x00)       // 00062h Adaptive Deflicker Disable
};

#define P1024_SDTV_REG_BUFLEN_VO  (13 * 2 + 1)
#define P1024_SDTV_REG_NUM_VO  (P1024_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE P1024_SDTV_VO [P1024_SDTV_REG_BUFLEN_VO] = {
        P1024_SDTV_REG_NUM_VO,       // update number of registers 13   
        RegIndexVal(0x03, 0xC0),      // 0C003h Filter Selection
        RegIndexVal(0x04, 0x13),      // 01304h Output Mode
        RegIndexVal(0x07, 0xCC),      // 0CC07h Start Active Video
        RegIndexVal(0x08, 0x24),      // 02408h, 06E09h adjust TV's Position
        RegIndexVal(0x09, 0x6E),
        RegIndexVal(0x1A, 0x00),      // reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),
        RegIndexVal(0x1F, 0x01),       // 0011Fh Filter Switch
        RegIndexVal(0x51, 0x06),       // 00651h, 0C156h TV Timing
        RegIndexVal(0x56, 0xC1),
        RegIndexVal(0x62, 0x00)         // 00062h Adaptive Deflicker Disable
};

#define P848_SDTV_REG_BUFLEN_VO  (11 * 2 + 1)
#define P848_SDTV_REG_NUM_VO  (P848_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE P848_SDTV_VO [P848_SDTV_REG_BUFLEN_VO] = {   
        P848_SDTV_REG_NUM_VO,        // update number of registers 11   
        RegIndexVal(0x02, 0x2A),      // 02a02h, 00804h output SDTV_RGB type
        RegIndexVal(0x04, 0x08),
        RegIndexVal(0x08, 0x92),      // 09208h, 00309h, 0001ch adjust TV's Position
        RegIndexVal(0x09, 0x03),
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x00, 0x04),      // 00400h, 00003h disable de-flicker function
        RegIndexVal(0x03, 0x00),
        RegIndexVal(0x4D, 0x00),      // 0004dh  Y_DELAY = 0 
        RegIndexVal(0x65, 0x82),      // 08265h, 08066h, 08167h  adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66, 0x80),
        RegIndexVal(0x67, 0x81)
};

#define P720X576_SDTV_REG_BUFLEN_VO  (13 * 2 + 1)
#define P720X576_SDTV_REG_NUM_VO  (P720X576_SDTV_REG_BUFLEN_VO - 1) /2

 BYTE P720X576_SDTV_VO [P720X576_SDTV_REG_BUFLEN_VO] = {
        P720X576_SDTV_REG_NUM_VO,    // update number of registers 13   
        RegIndexVal(0x03, 0x40),      // 04003h Filter Selection
        RegIndexVal(0x04, 0x13),      // 01304h Output Mode
        RegIndexVal(0x09, 0x03),      // 00309h adjust TV's Position
        RegIndexVal(0x1A, 0x00),      // reserved Additional Register
        RegIndexVal(0x1C, 0x00),
        RegIndexVal(0x28, 0x00),
        RegIndexVal(0x29, 0x00),
        RegIndexVal(0x2A, 0x00),      // reserved Additional Register
        RegIndexVal(0x2B, 0x00),
        RegIndexVal(0x2C, 0x00),
        RegIndexVal(0x1F, 0x01),      // 0011Fh Filter Switch
        RegIndexVal(0x20, 0x1C),      // 01C20h TV Sync step
        RegIndexVal(0x62, 0x00)       // 00062h Adaptive Deflicker Disable
};

#define N640_DOT_REG_BUFLEN_VO  (3 * 2 + 1)
#define N640_DOT_REG_NUM_VO  (N640_DOT_REG_BUFLEN_VO - 1) /2

 BYTE N640_DotCrawl_VO [N640_DOT_REG_BUFLEN_VO] = {
        N640_DOT_REG_NUM_VO,         // update number of registers 3   
        RegIndexVal(0x11, 0x08),      // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xE5),      // 0e516h, 0a017h adjust TV FSCI
        RegIndexVal(0x17, 0xA0)
};

#define N800_DOT_REG_BUFLEN_VO  (3 * 2 + 1)
#define N800_DOT_REG_NUM_VO  (N800_DOT_REG_BUFLEN_VO - 1) /2

 BYTE N800_DotCrawl_VO [N800_DOT_REG_BUFLEN_VO] = {
        N800_DOT_REG_NUM_VO,         // update number of registers 3   
        RegIndexVal(0x11, 0x08),      // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0xA1),      // 0a116h, 05917h adjust TV FSCI
        RegIndexVal(0x17, 0x59)
};

#define N1024_DOT_REG_BUFLEN_VO  (3 * 2 + 1)
#define N1024_DOT_REG_NUM_VO  (N1024_DOT_REG_BUFLEN_VO - 1) /2

 BYTE N1024_DotCrawl_VO [N1024_DOT_REG_BUFLEN_VO] = {   
        N1024_DOT_REG_NUM_VO,         // update number of registers  3  
        RegIndexVal(0x11, 0x08),       // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x11),       // 01116h, 0e217h adjust TV FSCI
        RegIndexVal(0x17, 0xE2)
};

#define N848_DOT_REG_BUFLEN_VO  (3 * 2 + 1)
#define N848_DOT_REG_NUM_VO  (N848_DOT_REG_BUFLEN_VO - 1) /2

 BYTE N848_DotCrawl_VO [N848_DOT_REG_BUFLEN_VO] = {
        N848_DOT_REG_NUM_VO,          // update number of registers  3  
        RegIndexVal(0x11, 0x08),       // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x67),       // 06716h, 03017h adjust TV FSCI
        RegIndexVal(0x17, 0x30)
};

#define N720x480_DOT_REG_BUFLEN_VO  (3 * 2 + 1)
#define N720x480_DOT_REG_NUM_VO  (N848_DOT_REG_BUFLEN_VO - 1) /2

 BYTE N720x480_DotCrawl_VO [N848_DOT_REG_BUFLEN_VO] = {
        N720x480_DOT_REG_NUM_VO,     // update number of registers  3  
        RegIndexVal(0x11, 0x08),      // 0811h enable DotCrawl(only update TV.11=>BIT3)
        RegIndexVal(0x16, 0x1E),      // 01e16h, 05c17h adjust TV FSCI
        RegIndexVal(0x17, 0x5C)
};

#define P720X576_YCbCr_IN_REG_BUFLEN_VN  (3 * 2 + 1)
#define P720X576_YCbCr_IN_REG_NUM_VN  (P720X576_YCbCr_IN_REG_BUFLEN_VN - 1) /2

 BYTE P720X576_YCbCr_IN_VN [P720X576_YCbCr_IN_REG_BUFLEN_VN] = {
        P720X576_YCbCr_IN_REG_NUM_VN, // update number of registers 3
        RegIndexVal(0x00, 0x3A),       // 03A00h Input Format Selection
        RegIndexVal(0x03, 0x10),       // 01003h DeFlicker Disable
        RegIndexVal(0x4C, 0x08)        // 0084Ch Undershoot check
};


//-------------------------shared TV table-------------------------
#define TV_OUT_RGBBUFLEN   (8*2 + 1)
#define TV_OUT_RGBREGNUM   (TV_OUT_RGBBUFLEN - 1)  / 2  

#define TV_OUT_YCbCrBUFLEN   (5*2 + 1)
#define TV_OUT_YCbCrREGNUM   (TV_OUT_YCbCrBUFLEN - 1)  / 2  

 BYTE TV_OUT_RGB  [TV_OUT_RGBBUFLEN] = {
        TV_OUT_RGBREGNUM,               // update number of registers 8    
        RegIndexVal(0x02,   0x12), 	    // 01202h  SYNC on G
        RegIndexVal(0x23,   0x7E),	    // 07E23h  Blank Level
        RegIndexVal(0x4A,   0x85), 	    // 0854Ah, 00A4Bh  DAC Selection
        RegIndexVal(0x4B,   0x0A), 
        RegIndexVal(0x4E,   0x00),	    // 0004Eh  YUV Delay Control
        RegIndexVal(0x65,   0x55),	    // 05565h, 03766h, 05C67h      ; adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66,   0x37),	
        RegIndexVal(0x67,   0x5C) 
};


 BYTE TV_OUT_YCbCr [TV_OUT_YCbCrBUFLEN] =   {
        TV_OUT_YCbCrREGNUM,             // update number of registers  5
        RegIndexVal(0x23,  0x7E),        // 07E23h    Blank Level
        RegIndexVal(0x4E,  0x00),        // 0004Eh   YUV Delay Control
        RegIndexVal(0x65,  0x55),        // 05565h, 05466h, 05667h      ; adjust SDTV_RGB Amplitude factor
        RegIndexVal(0x66,  0x54),
        RegIndexVal(0x67,  0x56)
};

