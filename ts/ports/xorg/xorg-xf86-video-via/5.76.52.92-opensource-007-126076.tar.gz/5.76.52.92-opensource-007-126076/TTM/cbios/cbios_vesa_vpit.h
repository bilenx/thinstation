/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_sub_func.h"

//-----------------------------------------------------------------------
// Generic mode support AND ENABLE
//      1. MODE640x480_SUPPORT         =       TRUE
//      2. MODE800x600_SUPPORT         =       TRUE
//      3. MODE1024x768_SUPPORT        =       TRUE
//      4. MODE1280x720_SUPPORT        =       TRUE
//      5. MODE1280x768_SUPPORT        =       TRUE
//      6. MODE1280x800_SUPPORT        =       TRUE
//      7. MODE1280x960_SUPPORT        =       TRUE
//      8. MODE1280x1024_SUPPORT       =       TRUE
//      9. MODE1360X768_SUPPORT        =       TRUE
//     10. MODE1440X900_SUPPORT        =       TRUE
//     11. MODE1400X1050_SUPPORT       =       TRUE
//     12. MODE1600x1200_SUPPORT       =       TRUE
//     13. MODE1680x1050_SUPPORT       =       TRUE
//     14. MODE1920x1080_SUPPORT       =       TRUE
//     15. MODE1920X1200_SUPPORT       =       TRUE
//----------------------------------------------------------------------
#define DCLK_25_2M      0x8B9083    // 25_2Mhz
#define DCLK_27M        0x959083    // 27Mhz
#define DCLK_27_07M     0x771002    // 27.07Mhz
#define DCLK_31_5M      0xAE1003    // 31.5Mhz
#define DCLK_36M        0xC81003    // 36Mhz
#define DCLK_40M        0x6E0C03    // 40Mhz
#define DCLK_49_5M      0x880C03    // 49.5Mhz
#define DCLK_50M        0x8A0C03    // 50Mhz
#define DCLK_54M        0x958C83    // 54Mhz
#define DCLK_56_25M     0x9B0C03    // 56.25Mhz
#define DCLK_62M        0xAC0C03    // 62Mhz
#define DCLK_65M        0xB40C03    // 65Mhz
#define DCLK_72_3M      0xC88C83    // 72.3M
#define DCLK_72_78M     0xCA0C03    // 72.784Mhz
#define DCLK_73_38M     0xCB0C03    // 73.380Mhz
#define DCLK_74_27M     0xA48C82    // 74.275558MHz
#define DCLK_75M        0xD00C03    // 75Mhz
#define DCLK_78_75M     0x6C0803    // 78.75Mhz
#define DCLK_83_5M      0x448881    // 83.527Mhz
#define DCLK_85_91M     0x760803    // 85.909Mhz
#define DCLK_94_5M      0x820803    // 94.5Mhz
#define DCLK_79_47M     0x6D0803    // 79.466Mhz
#define DCLK_102_91M    0x710802    // 102.912Mhz
#define DCLK_106_47M    0x750802    // 106.491Mhz
#define DCLK_107M       0x940803    // 106.928Mhz
#define DCLK_108M       0x958883    // 108Mhz
#define DCLK_108_8M     0x960803    // 108.836Mhz
#define DCLK_117_5M     0xA20803    // 117.409Mhz
#define DCLK_121_70M    0x420800    // 121.704Mhz
#define DCLK_122_9M     0xAA0803    // 122.898Mhz
#define DCLK_135M       0xBB0803    // 135Mhz
#define DCLK_136_74M    0xBD0803    // 136.73Mhz
#define DCLK_146_76M    0xCC0803    // 146.76Mhz
#define DCLK_148_5M     0xA48882    // 148.551Mhz
#define DCLK_156M       0x558402    // 156MHz
#define DCLK_156_8M     0x6C0403    // 156.867Mhz
#define DCLK_157_5M     0x6C0403    // 157.5Mhz
#define DCLK_162M       0x6F0403    // 162Mhz
#define DCLK_173M       0x770403    // 173Mhz
#define DCLK_175M       0x780403    // 175Mhz
#define DCLK_178_8M     0x7B0403    // 178.8Mhz
#define DCLK_187_568M   0x810403    // 187.568Mhz
#define DCLK_189M       0x820403    // 189Mhz
#define DCLK_193M       0x850403    // 193Mhz
#define DCLK_202_5M     0x8C0403    // 202.5Mhz
#define DCLK_214_772M   0x940403    // 214.772Mhz
#define DCLK_229_5M     0x9F0403    // 229.5Mhz
#define DCLK_245_198M   0x870402    // 245.198Mhz
#define DCLK_281_590M   0x740401    // 281.59Mhz

#define DCLK_25_2M_409      0x8D9085    // 25_2Mhz
#define DCLK_27M_409        0x979085    // 27Mhz
#define DCLK_27_07M_409     0x791004    // 27.07Mhz
#define DCLK_31_5M_409      0xB01005    // 31.5Mhz
#define DCLK_36M_409        0xCA1005    // 36Mhz
#define DCLK_40M_409        0x700C05    // 40Mhz
#define DCLK_49_5M_409      0x8A0C05    // 49.5Mhz
#define DCLK_50M_409        0x8C0C05    // 50Mhz
#define DCLK_54M_409        0x978C85    // 54Mhz
#define DCLK_56_25M_409     0x9D0C05    // 56.25Mhz
#define DCLK_62M_409        0xAE0C05    // 62Mhz
#define DCLK_65M_409        0xB60C05    // 65Mhz
#define DCLK_72_3M_409      0xCA8C85    // 72.3M
#define DCLK_72_78M_409     0xCC0C05    // 72.784Mhz
#define DCLK_73_38M_409     0xCD0C05    // 73.380Mhz
#define DCLK_74_27M_409     0xA68C84    // 74.275558MHz
#define DCLK_75M_409        0xD20C05    // 75Mhz
#define DCLK_78_75M_409     0x6E0805    // 78.75Mhz
#define DCLK_83_5M_409      0x468883    // 83.527Mhz
#define DCLK_85_91M_409     0x780805    // 85.909Mhz
#define DCLK_94_5M_409      0x840805    // 94.5Mhz
#define DCLK_79_47M_409     0x6F0805    // 79.466Mhz
#define DCLK_102_91M_409    0x730804    // 102.912Mhz
#define DCLK_106_47M_409    0x770804    // 106.491Mhz
#define DCLK_107M_409       0x960805    // 106.928Mhz
#define DCLK_108M_409       0x978885    // 108Mhz
#define DCLK_108_8M_409     0x980805    // 108.836Mhz
#define DCLK_117_5M_409     0xA40805    // 117.409Mhz
#define DCLK_121_70M_409    0x440802    // 121.704Mhz
#define DCLK_122_9M_409     0xAC0805    // 122.898Mhz
#define DCLK_135M_409       0xBD0805    // 135Mhz
#define DCLK_136_74M_409    0xBF0805    // 136.73Mhz
#define DCLK_146_76M_409    0xCE0805    // 146.76Mhz
#define DCLK_148_5M_409     0xA68884    // 148.551Mhz
#define DCLK_156M_409       0x578404    // 156MHz
#define DCLK_156_8M_409     0x6E0405    // 156.867Mhz
#define DCLK_157_5M_409     0x6E0405    // 157.5Mhz
#define DCLK_162M_409       0x710405    // 162Mhz
#define DCLK_173M_409       0x790405    // 173Mhz
#define DCLK_175M_409       0x7A0405    // 175Mhz
#define DCLK_178_8M_409     0x7D0405    // 178.8Mhz
#define DCLK_187_568M_409   0x830405    // 187.568Mhz
#define DCLK_189M_409       0x840405    // 189Mhz
#define DCLK_193M_409       0x870405    // 193Mhz
#define DCLK_202_5M_409     0x8E0405    // 202.5Mhz
#define DCLK_214_772M_409   0x960405    // 214.772Mhz
#define DCLK_229_5M_409     0xA10405    // 229.5Mhz
#define DCLK_245_198M_409   0x890404    // 245.198Mhz
#define DCLK_281_590M_409   0x760403    // 281.59Mhz

#define CBIOS_GENRIC_MODESUPPORT_NUM  15

extern VESA_INFO_CBIOS MODE_TABLE_CBIOS[CBIOS_GENRIC_MODESUPPORT_NUM];  

#define CBIOS_CEA_MODESUPPORT_NUM  5

extern CEA_INFO_CBIOS CEA_MODE_TABLE_CBIOS[CBIOS_CEA_MODESUPPORT_NUM]; 

#define CBIOS_DMT_MODESUPPORT_NUM     4

extern VESA_INFO_CBIOS VESA_DMT_TABLE[CBIOS_DMT_MODESUPPORT_NUM];
extern VESA_INFO_CBIOS VESA_DMT_TABLE_409[CBIOS_DMT_MODESUPPORT_NUM];


