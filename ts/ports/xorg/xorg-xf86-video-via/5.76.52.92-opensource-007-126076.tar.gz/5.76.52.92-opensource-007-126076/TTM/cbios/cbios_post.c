/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "cbios_platform.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"
#include "cbios_cea_timing.h"


/*
 * Programming info contained in this module about chips can be found at:
 *   Chrontel 7305 : http://www.chrontel.com/pdf/7305ds.pdf
 *   Chrontel 7301 : http://www.chrontel.com/pdf/7301ds.pdf
 *   silicon 164 : http://www.siliconimage.com/docs/SiI-DS-0021-E-164.pdf
 *   TI tfp410 : http://www.ti.com/lit/ds/symlink/tfp410.pdf
 *   ADI ad9389b : http://www.analog.com/static/imported-files/data_sheets/AD9389B.pdf
 *                 http://ez.analog.com/servlet/JiveServlet/download/1741-8-10790/AD9889B%20Programming%20Guide%20RevB.pdf
 *   EDID info : http://en.wikipedia.org/wiki/Extended_display_identification_data
 */

//end of code for read VCP info from VBIOS image in system direcotry
/////////////////////////////////////////////////////////////////////////////

#define VBE_MAX_VGA_MODE                 0x0013

CBIOS_STATUS
CBiosInt10_UMA( PVOID pvcbe,
               PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    PCBIOS_EXTENSION pcbe = pvcbe;
    DWORD   Eax_Entry = biosArguments->Eax;    
    cbDbgPrint(1,
        "CBiosInt10: (Entry)  EAX=%08X EBX=%08X ECX=%08X EDX=%08X ESI=%08X EDI=%08X\n",
        biosArguments->Eax,biosArguments->Ebx,biosArguments->Ecx,
        biosArguments->Edx,biosArguments->Esi,biosArguments->Edi);

    //Standard VGA mode, not supported, turn off screen avoid garbage!
    if((biosArguments->Eax & 0x0FFFF) <= VBE_MAX_VGA_MODE)
    {
        // for std mode just turn off IGA1 screen
        SetIGA1screenOnOff(pcbe, OFF);
        cbDbgPrint(0, "CBiosInt10: Failed in set VGA mode, we don't support them !\n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return CBIOS_OK;
    }                        

    if((biosArguments->Eax & 0x0FF00) != 0x4F00)
    {
        cbDbgPrint(0, "CBiosInt10: Invalid Parameter! \n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return CBIOS_OK;
    }
    
    switch (biosArguments->Eax&0x0FFFF)
    {
    /*
    case 0x4F01:
            VBE_4F01_GetModeInfo_UMA(pcbe, biosArguments);
    case 0x4F02:
            VBE_4F02_SetMode_UMA(pcbe,biosArguments);
        break;

    case 0x4F10:
        switch (biosArguments->Ebx&0x000FF)
        {
        case 0x00:
            VBE_4F10_0000_ReportPowerCapability_UMA(pcbe,biosArguments);
            break;

        case 0x01:
            VBE_4F10_0001_SetDisplayPowerState_UMA(pcbe,biosArguments);
            break;

        case 0x02:
            VBE_4F10_0002_GetDisplayPowerState_UMA(pcbe,biosArguments);
            break;

        default:
            biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
            break;
        }
        break;
    */

    // S3 fucntion
    case S3_EXTBIOS_INFO:
        switch (biosArguments->Ebx&0x000FF)
        {
        // Query Chip Information
        case 0x00:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_VBE_INFO:
                VBE_4F14_0000_QueryChipInfo_UMA(pcbe,biosArguments);
                break;

            case UMA_GET_BIOS_INFO:
                VBE_4F14_0100_GetBIOSInfo_csr(pcbe,biosArguments);
                break;
                
            case UMA_GET_MISC_INFO:
                VBE_4F14_0200_GetMiscInfo_csr(pcbe,biosArguments);
                break;
                
            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        /*
        // Refresh Rate Control
        case 0x01:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_SET_REFRESH:
                    VBE_4F14_0001_SetDisplayDeviceRefreshRate_UMA(pcbe,biosArguments);
                break;

            case S3_GET_REFRESH:
                    VBE_4F14_0101_GetDisplayDeviceRefreshRate_UMA(pcbe,biosArguments);
                break;

            case S3_QUERY_REFRESH:
                    VBE_4F14_0201_QueryRefreshRates_UMA(pcbe,biosArguments);
                break;

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        // Mode Information
        case 0x02:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_QUERY_MODELIST:
                VBE_4F14_0202_QueryExtendedModeList_UMA(pcbe,biosArguments);
                break;

            case S3_GET_EXT_MODEINFO:
                VBE_4F14_0302_GetExtendedModeInfo_UMA(pcbe,biosArguments);
                break;

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;
        */

        // Display Devices Control
        case 0x03:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            /*
            case S3_SET_ACTIVE_DISP:
                VBE_4F14_0003_SetActiveDisplayDevice_UMA(pcbe,biosArguments);
                break;
                
            case S3_GET_ACTIVE_DISP:
                    VBE_4F14_0103_GetActiveDisplayDevice_UMA(pcbe,biosArguments);
                break;

            case S3_QUERY_DISPLAY_DEVICE:
                    VBE_4F14_0203_QueryDisplayDeviceStatus_UMA(pcbe,biosArguments);
                break;

            case S3_SET_DEVICE_POWER_STATE:
                VBE_4F14_0403_SetDevicePowerState_UMA(pcbe,biosArguments);
                break;

            case S3_SET_EXT_DISPLAY:          
                    VBE_4F14_8003_AltSetActiveDisplayDevice_UMA(pcbe,biosArguments);
                break;
            */

            case S3_GET_CMOS_DISPLAY:
                VBE_4F14_8303_QuerySysBIOSDisplayDeviceConfig_UMA(pcbe,biosArguments);
                break;    

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        /*
        // Display Devices Detection
        case 0x04:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_QUERY_ATTACHED:
                VBE_4F14_0004_GetAttachedDisplayDevices_UMA(pcbe,biosArguments);
                break;

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        // Clock Control
        case 0x05:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_SET_CLOCKS:
                VBE_4F14_0005_SetClock_UMA(pcbe,biosArguments);
                break;

            case S3_GET_CLOCKS:
                VBE_4F14_0105_GetClock_UMA(pcbe,biosArguments);
                break;

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        // Flat Panel Control
        case 0x06:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_GET_FLATP_INFO:
                VBE_4F14_0006_GetFlatPanelInfo_UMA(pcbe,biosArguments);
                break;

            case S3_SET_CTREXP_EX:
                VBE_4F14_0306_AltSetFlatPanelExpansionCenteringState_UMA(pcbe,biosArguments);
                break;

            case S3_GET_CTREXP_EX:
                VBE_4F14_0406_AltGetFlatPanelExpansionCenteringState_UMA(pcbe,biosArguments);
                break;

            case S3_GET_SCALING_FACTOR:
                VBE_4F14_0506_GetScalingFactorInfo_UMA(pcbe,biosArguments);
                break;    

            case S3_GET_DISPLAY_DEVICE_INFO:
                VBE_4F14_0806_GetDisplayDeviceInfo_UMA(pcbe,biosArguments);
                break;

            case S3_GET_LCD_INFO:
                VBE_4F14_8106_GetFlatPanelID_UMA(pcbe,biosArguments);
                break;

            case 0x8406:
                VBE_4F14_8406_GetSysBIOSExpansiobSetting(pcbe,biosArguments);
                break;    

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;
        */

        // TV/HDTV Control
        case 0x07:
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case S3_SET_TV_CONFIG:
                VBE_4F14_0007_SetTVConfig_UMA(pcbe,biosArguments);
                break;

            case S3_GET_TV_CONFIG:
                VBE_4F14_0107_GetTVConfig_UMA(pcbe,biosArguments);
                break;

            case S3_GET_TV_SUPPORT:
                VBE_4F14_0207_GetSupportedTVType_UMA(pcbe,biosArguments);
                break;

            case S3_TV_CONTRAST_CONTROL:
                VBE_4F14_0307_ContrastControl_UMA(pcbe,biosArguments);
                break;
                
            case S3_TV_SATURATION_CONTROL:
                VBE_4F14_0407_SaturationControl_UMA(pcbe,biosArguments);
                break;

            case S3_TV_HUE_CONTROL:
                VBE_4F14_0507_HueControl_UMA(pcbe, biosArguments);
                break;
                
            case S3_TV_BRIGHTNESS_CONTROL:
                VBE_4F14_0607_BrightnessControl_UMA(pcbe, biosArguments);
                break;
                
            case S3_TV_FFILTER_CONTROL:
                VBE_4F14_0707_FlickerFilterControl_UMA(pcbe, biosArguments);
                break;

            case S3_TV_POSITION_CONTROL:
                VBE_4F14_0B07_PositionControl_UMA(pcbe, biosArguments);
                break;
                
            case S3_GET_QUERY_TV_CONFIG:
                VBE_4F14_8107_GetTVHDTVConfigFromSysBIOS_UMA(pcbe,biosArguments);
                break;

            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        /*
        case 0x0A:  // Miscellaneous Control
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case 0x000A:
                VBE_4F14_000A_SystemResumeEventNotification(pcbe,biosArguments);
                break;

            case 0x020A:
                VBE_4F14_020A_DeviceControl(pcbe,biosArguments);
                break;

            case 0x090A:
                VBE_4F14_090A_Set64BitOSID(pcbe,biosArguments);
                break;
                
            case 0x0A0A:
                VBE_4F14_0A0A_HotkeyRotationNotify(pcbe,biosArguments);
                break;
                
            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;   
            
        case 0x0B:  // INT15 HOOK
            switch (biosArguments->Ebx&0x0FFFF)
            {
            case 0x000B:
                VBE_4F14_000B_GetSupportedUMASizeRange(pcbe,biosArguments);
                break;
        
            case 0x010B:
                VBE_4F14_010B_SetUMASize(pcbe,biosArguments);
                break;
        
            case 0x020B:
                VBE_4F14_020B_GetUMASize(pcbe,biosArguments);
                break;
                
            case 0x030B:
                VBE_4F14_030B_SetMISCSWOptions(pcbe,biosArguments);
                break;

            case 0x050B:
                VBE_4F14_050B_GetMISCSWOptions(pcbe,biosArguments);
                break;   

            case 0x060B:
                VBE_4F14_060B_GetDisplayRotationOrientation(pcbe,biosArguments);
                break;    
                
            default:
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
                break;
            }
            break;

        case S3_MINIPOST: // Initialize VGA
            //Harrison, need add post parameters
            VBE_4F14_000C_InitializeVGA(pcbe,biosArguments);
            //CBiosPost_CSR(pcbe, NULL);
            break;
        */

        case S3_GET_UMAFB_BASE: // Get the Starting Addr of FB                
            VBE_4F14_000D_GetStartAddressOfFB(pcbe,biosArguments);
            break;    

        /*
        case 0x0E: // Notify System BIOS to check Non-Posted Memory Range                
            VBE_4F14_000E_NotifySysBIOS2CheckNonPostedMemRange(pcbe,biosArguments);
            break;  
        */
            
        default:
            biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
            break;
        }
        break;

    default:
        biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
        break;
    }

   
    if (biosArguments->Eax == VBE_STATUS_NOT_SUPPORTED)
    {
        cbDbgPrint(0, "CBiosInt10: function was not implemented! \n");
        cbDbgPrint(0, "            EAX=%08X EBX=%08X ECX=%08X EDX=%08X ESI=%08X EDI=%08X\n",
            Eax_Entry ,biosArguments->Ebx, biosArguments->Ecx,
            biosArguments->Edx, biosArguments->Esi, biosArguments->Edi);
    }
    
    cbDbgPrint(1,
        "CBiosInt10: (Exit )  EAX=%08X EBX=%08X ECX=%08X EDX=%08X ESI=%08X EDI=%08X\n",
        biosArguments->Eax,biosArguments->Ebx,biosArguments->Ecx,
        biosArguments->Edx,biosArguments->Esi,biosArguments->Edi);

    return CBIOS_OK;;
}

void cbChipEnable_UMA(PCBIOS_EXTENSION pcbe)
{
    UCHAR   Misc;

    /* Wakeup chip, 3C3 bit 0=1 */
    WriteUchar(CB_VIDEO_SUBSYSTEM_ENABLE_REG, 0x1);

    /* 3C2.0 = 1, Set base to 3Dx */
    Misc = ReadUchar((PUCHAR)CB_MISC_OUTPUT_READ_REG);
    Misc |= SEL_IOA_COLOR + ENABLE_VIDEO_RAM;
    WriteUchar(CB_MISC_OUTPUT_WRITE_REG, Misc);

    /* Unlock extended I/O registers */
    cbUnlockExtIO_UMA(pcbe);

    /* Enable PCI power management control
        * Defualt to set DAC to off when chip is just initailized */
    cbWriteRegBits(pcbe, CR_36, 0x31, 0x31);

}

LONG MemCmp(char* pStr1, char* pStr2, ULONG Len)
{
    ULONG Idx = 0;
    for (Idx = 0; Idx < Len; Idx++)
    {
        if (pStr1[Idx] == pStr2[Idx])
        {
            continue;
        }

        return 1;
    }
    return 0;
}


/*-------------------------------------------------------------------------
* cbGetVCPInfo_UMA
* This function gets VCP structure address from VBIOS romimage. VCP structure
* is proceded by string 'PMID', after find 'PMID' we need to test VCP checksum
*
* IN :
*  NONE
* OUT :
* function status
*-------------------------------------------------------------------------*/
BOOL cbGetVCPInfo_UMA(
    IN PBYTE pRomData,
    INOUT PVCPInfo* ppVCPInfo)
{
    ULONG i;
    PVCPInfo pVCPInfo = NULL;
    
    if (!pRomData || !ppVCPInfo) {
        ASSERT(FALSE);
        return FALSE;
    }
    
    /* find the occurrence of string "PMID" in RomImage]
        * VCP structure should be preceded by PMID info and within ROM image */
    for (i = 0; i < (ROM_SCAN_SIZE - sizeof(PMID_Info) - sizeof(VCPInfo)); i++) {
        if (0 == MemCmp((pRomData + i), "PMID", 4)) {
            /* get VCP pointer */
            pVCPInfo = (PVCPInfo)(pRomData + i + sizeof(PMID_Info));
            /* check VCP is valid or not
                     * VBIOS VCP main version must <= CBIOS VCP main version
                     * VBIOC VCP check sum must right with VBIOS VCP buffer length */
            if (GET_VCPVERSION(pVCPInfo->version) > GET_VCPVERSION(VCP_VERSION) ||
                (cbGetCheckSum((BYTE*)pVCPInfo, pVCPInfo->length) != 0)) {
                /* fail to get VCP */
                pVCPInfo = NULL;
            }
            break;
        }
    }

    if (pVCPInfo != NULL) {
        *ppVCPInfo = pVCPInfo;
        return TRUE;
    } else {
        /* cbDbgPrint(1, "VCP error please check rom image!\n"); */
        return FALSE;
    }
}

void cbUnlockExtIO_UMA(PCBIOS_EXTENSION pcbe)
{
    // unLock extended I/O registers
    cbWriteRegByte(pcbe, SR_10, 0x01);
}

//**********************************************************************
// VBE_4F14_0000_QueryChipInfo_CSR - Query Chip Information
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//        EBX - Bit[31:28] =  Core Base Version
//              Bit[27]    =  0: Laptop BIOS; 1: Desktop BIOS
//              Bit[26]    =  0: built from trunk; 1: built from branch
//              Bit[25:24] =  Reserved
//              Bit[23:16] =  Product ID
//              Bit[15:8]  =  Major BIOS Version Number
//              Bit[7:0]   =  Minor BIOS Version Number
//         CX - Bit[15:8]  =  Type of External TV Encoder
//                  00     =  None
//                  01     =  VT1621
//                  02     =  VT1622
//                  03     =  CH7009
//                  04     =  CH7017
//                  05     =  SAA7108AE
//                  06     =  CH7005
//                  07     =  VT1622A
//                  08     =  VT1623
//                  09     =  FS453
//                  10     =  FS454
//                  11     =  CX875 (ADD)
//                  12     =  CX875A (AMR)
//                  13     =  VT3271
//                  14     =  VT1625 (ADD)
//                  15     =  VT1625A (AMR)
//              Bit[7:0]   =  TV Encoder Address
//        EDI - Bit[31:24] =  Process ID
//              Bit[23:16] =  Revision ID
//              Bit[15:0]  =  PCI Device ID
//        ESI - Bit[31]    =  1: Bus Master Supported; 0: Bus Master Supported
//              Bit[30:23] =  Reserved
//              Bit[22]    =  CRT2 dsiplay (2nd CRT) support
//              Bit[21]    =  DVI Display Supported
//              Bit[20]    =  DVI2 Display Supported
//              Bit[19]    =  LCD2 Display Supported
//              Bit[18]    =  TV Display Supported
//              Bit[17]    =  LCD Display Supported
//              Bit[16]    =  CRT Display Supported
//              Bit[15:0]  =  Installed Video Memory in number of 64K block
//**********************************************************************
VOID VBE_4F14_0000_QueryChipInfo_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    cbQueryChipInfo_UMA(pcbe, biosArguments);
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
}

//**********************************************************************
// VBE_4F14_0100_GetBIOSInfo_CSR - Get BIOS Information
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         BX - BIOS Release Date:YY(ASCII)
//         CX - BIOS Release Date:MM(ASCII)
//         DX - BIOS Release Date:DD(ASCII)
//         SI - Bit[15:8]  =  Type of External TV Encoder
//                  00     =  None
//                  11     =  VT1621
//                  12     =  VT1622
//                  13     =  VT1622A
//                  14     =  VT1623
//                  15     =  VT3271
//                  16     =  VT1625 (ADD)
//                  17     =  VT1625A (AMR)
//                  21     =  CH7009
//                  22     =  CH7017
//                  23     =  CH7005
//                  31     =  SAA7108AE
//                  41     =  FS453
//                  42     =  FS454
//                  51     =  CX875 (ADD)
//                  52     =  CX875A (AMR)
//              Bit[7:0]   =  LVDS / TMDS Transmitter for Digital Interface
//              Bit[7:4]   =  DI1
//                  00     =  None
//                  01     =  VT3191
//                  02     =  TTL_PANEL
//                  05     =  ITE6610
//                  07     =  TTL Type ( None Transmitter )
//                  09     =  VT3192
//                  0A     =  SIL9022
//                  0B     =  Sil164
//                  0C     =  Sil168
//                  0F     =  Hardwired Transmitter
//              Bit[3:0]   =  Pixel depth of mode
//                  00     =  None
//                  01     =  VT3191
//                  02     =  TTL_PANEL
//                  07     =  TTL Type ( None Transmitter )
//                  09     =  VT3192
//                  0A     =  VT3193
//                  0B     =  Sil164
//                  0C     =  Sil168
//                  0F     =  Hardwired Transmitter
//**********************************************************************
VOID VBE_4F14_0100_GetBIOSInfo_csr(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    cbGetBIOSInfo_UMA(pcbe, biosArguments);
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
}

//**********************************************************************
// VBE_4F14_0200_GetMiscInfo_csr - get Misc. Information
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     EDI  MISC3
//     EDX  MISC2
//     ECX 
//          Bit [31:4]: Reserved 
//          Bit [3]:    Restore ScatchPad  before mini post
//                      0: FALSE
//                      1: TRUE
//          Bit [2]:    Validate modes support control
//                      0: Generic case
//                      1: Skip ValidateSupportMode control
//                      (mode control by vBIOS; driver don't care)
//          Bit [1]:    Device definition length
//                      0: BYTE
//                      1: WORD
//          Bit [0]:    Device definition length
//                      0: Old definition
//                      1:  S3 definition
//*********************************************************************
VOID VBE_4F14_0200_GetMiscInfo_csr(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    cbgetMiscInfo_UMA(pcbe, biosArguments);
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
}

//**********************************************************************
// VBE_4F14_8303_QuerySysBIOSDisplayDeviceConfig_UMA - get CMOS boot up dev
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     ax  = VBE return status
//     Ecx = Display Device DWORD
//*********************************************************************
VOID VBE_4F14_8303_QuerySysBIOSDisplayDeviceConfig_UMA(PCBIOS_EXTENSION pcbe,
                                PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    DWORD dwTemp = 0;
    if (pcbe->SysBiosInfoValid)
    {
        biosArguments->Ecx = pcbe->SysBiosInfo.BootUpDev;
        // CRT2 bit definition need transfer
        if (biosArguments->Ecx & BIT7)
        {
            biosArguments->Ecx &= ~BIT7;    // remove system bios CRT2 bit
            biosArguments->Ecx |= S3_CRT2;  // add S3 definition CRT2 bit
        }
        // DP2 bit definition need transfer
        if(biosArguments->Ecx & BIT14)
        {
            biosArguments->Ecx &= ~BIT14;    // remove system bios DP2 bit
            biosArguments->Ecx |= S3_DP2;    // add S3 definition DP2 bit
        }
        if ((pcbe->SupportDevices & (S3_DVI + S3_DVI2)) == S3_DVI2)
        {
            // sync DVI to DVI2 from SysBIOS settings
            if (biosArguments->Ecx & S3_DVI)
            {
                biosArguments->Ecx &= ~S3_DVI;
                biosArguments->Ecx |= S3_DVI2;
            }
        }
        if ((pcbe->SupportDevices & (S3_LCD + S3_LCD2)) == S3_LCD2)
        {
            // sync LCD to LCD2 from SysBIOS settings
            if (biosArguments->Ecx & S3_LCD)
            {
                biosArguments->Ecx &= ~S3_LCD;
                biosArguments->Ecx |= S3_LCD2;
            }
        }

        if(pcbe->pVCPInfo->version >= VCP1_8)
        {
            ;    
        }
        else if((pcbe->ChipCaps.InternalDP_Support == TRUE) && (pcbe->pVCPInfo->version >= VCP1_6) && !(pcbe->pVCPInfo->miscConfigure3 & BIT6)) // old definition: BIT6 is DP_LAYOUT_CONNECTOR. VCP1.8 later, it is removed
        {
            if(pcbe->pVCPInfo->BIOSSupportDev & S3_HDMI)
            {
                dwTemp = biosArguments->Ecx & (S3_HDMI + S3_HDMI2);
                biosArguments->Ecx &= ~(S3_HDMI + S3_HDMI2);
                biosArguments->Ecx |= (dwTemp & S3_HDMI) ? S3_HDMI2 : 0;
                biosArguments->Ecx |= (dwTemp & S3_HDMI2) ? S3_HDMI : 0;
            }

            if(pcbe->pVCPInfo->BIOSSupportDev & S3_DVI)
            {
                dwTemp = biosArguments->Ecx & (S3_DVI + S3_DVI2);
                biosArguments->Ecx &= ~(S3_DVI + S3_DVI2);
                biosArguments->Ecx |= (dwTemp & S3_DVI) ? S3_DVI2 : 0;
                biosArguments->Ecx |= (dwTemp & S3_DVI2) ? S3_DVI : 0;
            }
        }

        biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
    }
    else
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
}

VOID VBE_4F14_000D_GetStartAddressOfFB(PCBIOS_EXTENSION pcbe,
               PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{               
    DWORD StartAddr = 0;

    switch(pcbe->PCIDeviceID)
    {
        // only K8 platform need this feature
        case PCI_ID_VT3336:
            if(pcbe->SysBiosInfoValid)
            {
                StartAddr = pcbe->SysBiosInfo.FBStartingAddr;
                biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
            }
            else
            {
                biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED; 
            }
            break;
        case PCI_ID_VT3353:
        case PCI_ID_VT3409P:
        case PCI_ID_VT3410:
            StartAddr = (DWORD)cbReadRegByte(pcbe, SR_6E);
            StartAddr = (StartAddr << 8) | cbReadRegByte(pcbe, SR_6D);
            StartAddr <<= 21;
            biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
            break;
        default:
            biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED; 
            break;
    }
    // put add back to register
    biosArguments->Edx = StartAddr & 0xFFFF;
    biosArguments->Ecx = (StartAddr & 0xFFFF0000)>>16;
}

//**********************************************************************
// VBE_4F14_0107_GetTVConfig_UMA - Get TV Configuration
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CL - TV Configuration Type
//              [7:5]    = TV Contraction Level   000 - VGA BIOS default (No Implement)
//              [4:3:2]  = TV Type
//                         000 - NTSC
//                         001 - PAL
//                         010 - PALM
//                         011 - PALN
//                         100 - PALNc
//              [1:0]    = Reserved
//         CH - TV Configuration Type 2
//              Bit[7]      =  Enable De-Dot Crawl
//                             TV Output Connector
//              Bit[6]      =  S-VIDEO 1 (Y/C)
//              Bit[5]      =  SDTV_YPbPr
//              Bit[4]      =  SDTV_RGB
//              Bit[3]      =  YCbCr
//              Bit[2]      =  RGB
//              Bit[1]      =  S-VIDEO 0 (Y/C)
//              Bit[0]      =  CVBS
//**********************************************************************
VOID VBE_4F14_0107_GetTVConfig_UMA(PCBIOS_EXTENSION pcbe,
                              PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    // assume supported and sucess
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    if(pcbe->SupportDevices & HDTV)
    {
        if(pcbe->sPad_11.HDTVOutputType) // 0:RGB, 1:Pr/Y/Pb 
            biosArguments->Ecx |= BIT27;
        else
            biosArguments->Ecx |= BIT26;

        biosArguments->Ecx |= ((ULONG)pcbe->sPad_11.HDTV_Type << 16);
    }

    // TV Output Connector
    biosArguments->Ecx |= ((WORD)pcbe->sPad_7.TVOutType << 8);

    // Dot Crawl?
    if(pcbe->sPad_5.enableDotCrawl)
        biosArguments->Ecx |= BIT15;

    // TV Contraction Level
    biosArguments->Ecx |= (pcbe->sPad_5.TV_Contraction << 5);

    // TV Type
    biosArguments->Ecx |= (pcbe->sPad_8.TV_Type << 2);

    // TV Encoder Input Mode
    biosArguments->Ecx |= pcbe->sPad_5.TVInputMode;
}

//**********************************************************************
// VBE_4F14_0007_SetTVConfig_UMA - Set TV Configuration
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CL - TV Configuration Type
//              [7:5]    = TV Contraction Level   000 - VGA BIOS default
//              [4:3:2]  = TV Type
//                         000 - NTSC
//                         001 - PAL
//                         010 - PALM
//                         011 - PALN
//                         100 - PALNc
//              [1]      = Reserved
//              [0]      = TV Input Format
//                         0 - RGB Input
//                         1 - YCbCr Input
//         CH - TV Configuration Type 2
//              Bit[7]      =  Enable De-Dot Crawl
//                             TV Output Connector
//              Bit[6]      =  S-VIDEO 1 (Y/C)
//              Bit[5]      =  SDTV_YPbPr
//              Bit[4]      =  SDTV_RGB
//              Bit[3]      =  YCbCr
//              Bit[2]      =  RGB
//              Bit[1]      =  S-VIDEO 0 (Y/C)
//              Bit[0]      =  CVBS
//         DL - TV Configuration Masking Byte 1
//         DH - TV Configuration Masking Byte 2
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//**********************************************************************

VOID VBE_4F14_0007_SetTVConfig_UMA(PCBIOS_EXTENSION pcbe,
                          PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG OldConfig, NewConfig, ConfigMask = biosArguments->Edx;
    PTV_FUNCTION_VCP pTVFunc = NULL;
    PTV_FUNCTION_UMA pTVFunc_CBIOS = NULL;
    BYTE *pHDTVPatch = NULL;
    DWORD dispDev;
    BOOL isHDTVTypeChanged = FALSE, isTVTypeChanged = FALSE; 
    I2C_CONTROL_UMA i2c;  
    ULONG encodertype;
    DWORD H_Res;
    DWORD V_Res;
    i2c.Flags = 0;
    
    // assume supported and sucess
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    NewConfig = biosArguments->Ecx;
    biosArguments->Ecx = 0;
    VBE_4F14_0107_GetTVConfig_UMA(pcbe, biosArguments);
    OldConfig= biosArguments->Ecx;
    
    if((NewConfig & ConfigMask) == (OldConfig & ConfigMask))
        return;

    //**************************************************************
    // 1. Update TV/ HDTV scratch pad Info
    //**************************************************************
    if (pcbe->SupportDevices & HDTV)
    {
        if (BIT27 & (NewConfig & ConfigMask))
        {
            pcbe->sPad_11.HDTVOutputType = 1;
        }
        else if (BIT26 & (NewConfig & ConfigMask))
        {
            pcbe->sPad_11.HDTVOutputType = 0;
        }
                   
        if (ConfigMask & (BIT16+BIT17+BIT18))
        {
            // if HDTV type(720P / 1080I) has been modified 
            if (pcbe->sPad_11.HDTV_Type != (BYTE)((NewConfig & (BIT16+BIT17+BIT18)) >> 16))
            {
                pcbe->sPad_11.HDTV_Type = (BYTE)((NewConfig & (BIT16+BIT17+BIT18)) >> 16);
                isHDTVTypeChanged = TRUE;
            }
        }
        // update hardware registers, HDTV type sPad_11[2:0]
        // update hardware registers, HDTV output type sPad_11[3]
        cbWriteRegBits(pcbe, CR_3C, BIT0+BIT1+BIT2+BIT3, STRUCT_BYTE(pcbe->sPad_11, 0));
        
    }

    if(ConfigMask & BIT15)
    {
        pcbe->sPad_5.enableDotCrawl = (BYTE)((NewConfig & BIT15) >> 15);
    }
    
    if(ConfigMask & BIT0)
    {
        pcbe->sPad_5.TVInputMode = (BYTE)(NewConfig & BIT0);
    }
    
    if(ConfigMask & (BIT5+BIT6+BIT7))
    {
        pcbe->sPad_5.TV_Contraction = (BYTE)((NewConfig & (BIT5+BIT6+BIT7)) >> 5);
    }
    // update hardware registers, TV dot crawl sPad_5[7]
    // update hardware registers, TV input type sPad_5[6] 
    // Write scratch pad,so update hardware registers too
    cbWriteRegBits(pcbe, CR_4B, BIT0+BIT1+BIT2+BIT6+BIT7, STRUCT_BYTE(pcbe->sPad_5, 0));

    if(ConfigMask & 0x7F00)
    {
        pcbe->sPad_7.TVOutType = (BYTE)((NewConfig & 0x7F00) >> 8);
    }
    //Write scratch pad,so update hardware registers too
    cbWriteRegBits(pcbe, CR_4D, BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT6, STRUCT_BYTE(pcbe->sPad_7, 0));

    if(ConfigMask & (BIT2+BIT3+BIT4))
    {
        // if TV type(PAL /NTSC) has been modified 
        if (pcbe->sPad_8.TV_Type != (BYTE)((NewConfig & (BIT2+BIT3+BIT4)) >> 2))
        {
            pcbe->sPad_8.TV_Type = (BYTE)((NewConfig & (BIT2+BIT3+BIT4)) >> 2);
            //Write scratch pad,so update hardware registers too
            cbWriteRegBits(pcbe, CR_4E, BIT0+BIT1+BIT2+BIT3, STRUCT_BYTE(pcbe->sPad_8, 0));
            isTVTypeChanged = TRUE;
        }
    }    

    // if HDTV type(720P / 1080I) has been modified 
    // if TV type(PAL /NTSC) has been modified 
    // we just modify scratch pad & return
    if (isHDTVTypeChanged == TRUE || isTVTypeChanged == TRUE)
    {
        return;
    }

    //**********************************************************************
    // 2. Get TV register table from VBIOS or CBIOS table
    // get current TV on display state
    // we don't care TV+HDTV, TV2 case
    //**********************************************************************
    if (pcbe->IGA1Info.dispDev & S3_TV)
    {
        // TV on IGA1
        if (!cbGetVBIOSTVEncoderTimingTable(pcbe, (WORD)(pcbe->IGA1Info.TargetHRes), (WORD)(pcbe->IGA1Info.TargetVRes), &pTVFunc))
        {
            // fetch tv table from CBIOS table
            pTVFunc = NULL;
            if (!cbGetCBIOSTVEncoderTimingTable(pcbe, 
                                                (WORD)(pcbe->IGA1Info.TargetHRes),
                                                (WORD)(pcbe->IGA1Info.TargetVRes),
                                                &pTVFunc_CBIOS))
            {
                // according to spec . if there is no Mode on IGA 
                // we just update scratch pad & return success
                biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
                return;
            }
        }
        dispDev = S3_TV;
        H_Res = pcbe->IGA1Info.TargetHRes;
        V_Res = pcbe->IGA1Info.TargetVRes;
    }
    else if (pcbe->IGA2Info.dispDev & S3_TV)
    {
        // TV on IGA2
        if (!cbGetVBIOSTVEncoderTimingTable(pcbe, (WORD)(pcbe->IGA2Info.TargetHRes), (WORD)(pcbe->IGA2Info.TargetVRes), &pTVFunc))
        {   
            // fetch tv table from CBIOS table
            pTVFunc = NULL;
            if (!cbGetCBIOSTVEncoderTimingTable(pcbe, 
                                                (WORD)(pcbe->IGA2Info.TargetHRes),
                                                (WORD)(pcbe->IGA2Info.TargetVRes), 
                                                &pTVFunc_CBIOS))
            {
                // according to spec . if there is no Mode on IGA 
                // we just update scratch pad & return success
                biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
                return;
            }                        
       }
       dispDev = S3_TV;
       H_Res = pcbe->IGA2Info.TargetHRes;
       V_Res = pcbe->IGA2Info.TargetVRes;
    }
    else if (pcbe->IGA1Info.dispDev & S3_HDTV)
    {
        // HDTV on IGA1
        if (!cbGetVBIOSHDTVEncoderTimingTable(pcbe, (WORD)(pcbe->IGA1Info.TargetHRes), (WORD)(pcbe->IGA1Info.TargetVRes), &pTVFunc, &pHDTVPatch))
        {
            // according to spec . if there is no Mode on IGA 
            // we just update scratch pad & return success
            biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
            return;
        }
        dispDev = S3_HDTV;
        H_Res = pcbe->IGA1Info.TargetHRes;
        V_Res = pcbe->IGA1Info.TargetVRes;
    }
    else if (pcbe->IGA2Info.dispDev & S3_HDTV)
    {
        // HDTV on IGA2
        if (!cbGetVBIOSHDTVEncoderTimingTable(pcbe, (WORD)(pcbe->IGA2Info.TargetHRes), (WORD)(pcbe->IGA2Info.TargetVRes), &pTVFunc, &pHDTVPatch))
        {
            // according to spec . if there is no Mode on IGA 
            // we just update scratch pad & return success
            biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
            return;
        }
        dispDev = S3_HDTV;
        H_Res = pcbe->IGA2Info.TargetHRes;
        V_Res = pcbe->IGA2Info.TargetVRes;
    }
    else
    {
        // TV/HDTV not attached to any IGA
        // according to our spec. if there
        // is no TV configed to IGA , we just update the scratch pad
        biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
        return;
    }

    // Get TV encoder type
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) ==FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }

    // close TV DAC
    cbSetTVDACState(pcbe, ALL_DAC_OFF);

    if (dispDev == S3_TV)
    {
        cbGetDII2Csetting(pcbe, &i2c, S3_TV);       // Get I2C port info of TV. 
        if (pTVFunc != NULL)
        {
            // load TV encoder register here
            // default TV table TV_FUNC
            cbFillTVFunctionRegs(pcbe, pTVFunc, TV_FUNC);
            // function for TV table
            cbPatchTVFunctions(pcbe, pTVFunc);
            switch (encodertype)
            {
            case VT1625_6:
            case VT1625A_6A:
                cbTV1625Reset_UMA(pcbe, &i2c);
                break;
            case IN_TV:
            {
                GFXTimingTable pTimingTbl;
                cbGetVBIOSTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, &pTimingTbl);
                if ( cbIsNativeTVTiming(pcbe, pTimingTbl.HDisEnd, pTimingTbl.VDisEnd, S3_TV) )
                {
                    // function for bypass mode
                    cbPatchforBypassMode(pcbe, pTimingTbl.HDisEnd, pTimingTbl.VDisEnd, S3_TV);
                }
                else //not bypass mode
                {
                    InTV_Write_Byte_UMA(pcbe, 0x02, 0x41);  // don't bypass
                    InTV_Write_Byte_UMA(pcbe, 0x03, 0x80);  // SD enable
                }
                break;
            }    
            default:
               cbDbgPrint(1, "Can not support the TV encoder type!\n");
               break;
            }
            // update TV parameters for utility to adjust TV output quality
            cbUpdateTVparameter(pcbe);
        }
        else if (pTVFunc_CBIOS != NULL)
        {
            // load TV encoder register here
            // default TV table TV_FUNC
            cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, TV_FUNC);
            // function for TV table
            cbPatchTVFunctions_CBIOS(pcbe, pTVFunc_CBIOS);
            cbTV1625Reset_UMA(pcbe, &i2c);
            // update TV parameters for utility to adjust TV output quality
            cbUpdateTVparameter(pcbe);
        }
        else
        {
            biosArguments->Eax = VBE_STATUS_FAILED;
            return;
        }
    }
    else if (dispDev == S3_HDTV)
    {
        cbGetDII2Csetting(pcbe, &i2c, S3_HDTV);       // Get I2C port info of HDTV. 
        // load HDTV encoder register here
        // default HDTV table TV_FUNC
        cbFillTVFunctionRegs(pcbe, pTVFunc, TV_FUNC);
        // function for HDTV table
        cbPatchHDTVFunctions(pcbe, pHDTVPatch);
        switch (encodertype)
        {
        case VT1625_6:
        case VT1625A_6A:
            cbTV1625Reset_UMA(pcbe, &i2c);
            break;
        case IN_TV:
        {
            GFXTimingTable pTimingTbl;
            cbGetVBIOSHDTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, &pTimingTbl);
            if ( cbIsNativeTVTiming(pcbe, pTimingTbl.HDisEnd, pTimingTbl.VDisEnd, S3_HDTV) )
            {
                // function for bypass mode
                cbPatchforBypassMode(pcbe, pTimingTbl.HDisEnd, pTimingTbl.VDisEnd, S3_HDTV);
            }
            else //not bypass mode
            {
                InTV_Write_Byte_UMA(pcbe, 0x02, 0x41);       // don't bypass
                InTV_Write_Byte_UMA(pcbe, 0x03, 0x80);       // SD enable
                InTV_Write_Bits_UMA(pcbe, 0x3B, 0x01, BIT0); // async mode enable
            }
            break;
        }    
        default:
           cbDbgPrint(1, "Can not support the TV encoder type!\n");
           break;
        }
        // update TV / HDTV parameters for utility to adjust HDTV output quality
        cbUpdateTVparameter(pcbe);
    }

    //******************************************************************
    // 3. when change TV output type we need to reset TV DAC 
    // so that after 07 called TV can light immediately after set
    // TV /HDTV configuration
    // since adjust TV / HDTV signal type need to reload GFX timing
    // AND this is not loaded here. since it will cause screen flicker
    // driver need to call screen off before this interface
    //******************************************************************
    if (dispDev == S3_TV 
      && pcbe->devicepowerstate[TVbit] == S3PM_ON)
    {
        // sets TV DAC powerstate according to TV output type
        cbSetTVDACState(pcbe, SET_DAC_ACCORDING_TVOutType);
    }
    else if (dispDev == S3_HDTV 
           && pcbe->devicepowerstate[HDTVbit] == S3PM_ON)
    {
        // sets HDTV DAC powerstate according to HDTV output type
        cbSetTVDACState(pcbe, SET_DAC_ACCORDING_HDTVOutType);
    }
    
}

//**********************************************************************
// VBE_4F14_0207_GetSupportedTVType_UMA - Get Supported TV Types
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//        ECX - Support TV Type
//              Bit[31:30]  =  Reserved
//              Bit[29]     =  HDTV 1080P
//              Bit[28]     =  HDTV 1080I
//              Bit[27]     =  HDTV 720P
//              Bit[26]     =  HDTV 576P
//              Bit[25]     =  HDTV 480P
//              Bit[24]     =  SDTV 625I
//              Bit[23]     =  SDTV 525I
//              Bit[22]     =  S-Video2
//              Bit[21]     =  SDTV-YPbPr
//              Bit[20]     =  SDTV-RGB
//              Bit[19]     =  YCbCr
//              Bit[18]     =  RGB(SCART)
//              Bit[17]     =  S-Video1
//              Bit[16]     =  Composite
//              Bit[15:13]  =  Reserved
//              Bit[12]     =  PAL Nc
//              Bit[11]     =  PAL N
//              Bit[10]     =  PAL K1
//              Bit[9]      =  PAL K
//              Bit[8]      =  PAL I
//              Bit[7]      =  PAL H
//              Bit[6]      =  PAL G
//              Bit[5]      =  PAL D
//              Bit[4]      =  PAL B
//              Bit[3]      =  PAL M
//              Bit[2]      =  NTSC Japan
//              Bit[1]      =  PAL
//              Bit[0]      =  NTSC U.S / NTSC M
//**********************************************************************
VOID VBE_4F14_0207_GetSupportedTVType_UMA(PCBIOS_EXTENSION pcbe,
                                 PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG encodertype;
    
    biosArguments->Ecx = cbGetTVLayout(pcbe, pcbe->SysBiosInfo.TVLayOut) << 16;

    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
        return;
    }
        
    // get support TV Capbility
    switch (encodertype)
    {
    case VT1621:
    case VT1622:
        biosArguments->Ecx |= BIT0 + BIT1 + BIT2 + BIT4 + BIT5 + BIT6 + BIT7
                            + BIT8 + BIT9 + BIT10;
        break;

    case VT1622A:
    case VT1623_3A:
        biosArguments->Ecx |= BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6
                            + BIT7 + BIT8 + BIT9 + BIT10 + BIT11 + BIT12;
        break;

    case VT1625_6:
    case VT1625A_6A:
        /* do not support HDTV 480P and 576P
        if (biosArguments->Ecx & (BIT20 + BIT21))
        {
            biosArguments->Ecx |= BIT25 + BIT26;
        }*/
        biosArguments->Ecx |= BIT0 + BIT1 + BIT2 + BIT4 + BIT5 + BIT6 + BIT7
                            + BIT8 + BIT9 + BIT10 + BIT27 + BIT28;
        break;

    case VT2325:
        biosArguments->Ecx |= BIT0 + BIT1 + BIT2 + BIT4 + BIT5 + BIT6 + BIT7
                            + BIT8 + BIT9 + BIT10 + BIT25 + BIT26 + BIT27 + BIT28;
        break;

    case IN_TV:
        biosArguments->Ecx |= BIT0 + BIT1 + BIT2 + BIT11 + BIT12 + BIT16 + BIT17
                            + BIT18 + BIT19 + BIT20 + BIT21 + BIT25 + BIT27 + BIT28;
        break;

    default:
        biosArguments->Eax = VBE_STATUS_NOT_SUPPORTED;
        return;
    }

    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
}


//**********************************************************************
// VBE_4F14_0307_ContrastControl_UMA - TV/HDTV Contrast Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//         CX - Contrast level*
//        
//         DL - The sub-functions of contrast control
//              0       = Set contrast level
//              1       = Get contrast level
//              2       = Reset contrast level to BIOS default
//              3       = Max. supported contrast level
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CX - Contrast Level**
// *  it is recommended to get the number of Levels with DL=3 (max. supported contrast level).
// ** No value returned for "set contrast level" or invalid function calls.
//**********************************************************************
VOID VBE_4F14_0307_ContrastControl_UMA(PCBIOS_EXTENSION pcbe,
                                        PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG ulFun = biosArguments->Edx & 0xFF;
    ULONG conlevel;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }

    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    // if TV / HDTV haven't config to IGAs 
    // Can not set / get contrast value
    if ((ulFun != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & (S3_TV | S3_HDTV)) == 0))
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }

    switch(ulFun)
    {
    //Set contrast level
    case S3_TV_FN_SET_UMA:
        if (encodertype == IN_TV)
        {
            conlevel = biosArguments->Ecx & 0x1FF;
        }
        else //1625
        {
            conlevel = biosArguments->Ecx & 0xFF;
        }
        status = cbSetContrastControl_UMA(pcbe, conlevel);
        break;

    //Get contrast level
    case S3_TV_FN_GET_UMA:
        biosArguments->Ecx = pcbe->tvparameter.CurContrast;
        break;

    //Reset contrast level to BIOS default
    case S3_TV_FN_SET_DEFAULT_UMA:
        conlevel = pcbe->tvparameter.DefaultContrast;
        status =  cbSetContrastControl_UMA(pcbe, conlevel);
        biosArguments->Ecx = pcbe->tvparameter.CurContrast;
        break;

    //Max. supported contrast level
    case S3_TV_FN_QUERY_MAX_RANGE_UMA:
        status = cbGetMaxContrast_UMA(pcbe, &biosArguments->Ecx);
        break;
            
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
    
}

//**********************************************************************
// VBE_4F14_0407_SaturationControl_UMA - TV/HDTV Saturation Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//         CL - Saturation level
//        
//         DL - The sub-functions of Saturation control
//              0       = Set Saturation level
//              1       = Get Saturation level
//              2       = Reset Saturation level to BIOS default
//              3       = Max. supported Saturation level
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CL - Saturation Level*
// *No value returned for "set contrast level" or invalid function calls.
//**********************************************************************
VOID VBE_4F14_0407_SaturationControl_UMA(PCBIOS_EXTENSION pcbe,
                                         PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG ulFun = biosArguments->Edx & 0xFF;
    ULONG satlevel;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }

    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    // if TV / HDTV haven't config to IGAs 
    // Can not set / get saturation value
    if ((ulFun != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & (S3_TV | S3_HDTV)) == 0))
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }
    
    switch(ulFun)
    {
    //Set Saturation level
    case S3_TV_FN_SET_UMA:
        if (encodertype == IN_TV)
        {
            satlevel = biosArguments->Ecx & 0x1FF;
        }
        else //1625
        {
            satlevel = biosArguments->Ecx & 0xFF;
        }
        status = cbSetSaturationControl_UMA(pcbe, satlevel);
        break;

    //Get Saturation level
    case S3_TV_FN_GET_UMA:
        biosArguments->Ecx = pcbe->tvparameter.CurSaturation;
        break;

    //Reset Saturation level to BIOS default
    case S3_TV_FN_SET_DEFAULT_UMA:
        satlevel = pcbe->tvparameter.DefaultSaturation;
        status =  cbSetSaturationControl_UMA(pcbe, satlevel);
        biosArguments->Ecx = pcbe->tvparameter.CurSaturation;
        break;

    //Max. supported Saturation level
    case S3_TV_FN_QUERY_MAX_RANGE_UMA:
        status = cbGetMaxSaturation_UMA(pcbe, &biosArguments->Ecx);
        break;
            
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }

}


//**********************************************************************
// VBE_4F14_0507_HueControl_UMA - TV/HDTV Hue Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//         CX - Hue level
//        
//         DL - The sub-functions of Hue control
//              0       = Set Hue level
//              1       = Get Hue level
//              2       = Reset Hue level to BIOS default
//              3       = Max. supported Hue level
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CX - Hue Level*
// *No value returned for "set contrast level" or invalid function calls.
//**********************************************************************
VOID VBE_4F14_0507_HueControl_UMA(PCBIOS_EXTENSION pcbe,
                                  PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG ulFun = biosArguments->Edx & 0xFF;
    ULONG hue_angle;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 

    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    // if TV / HDTV haven't config to IGAs 
    // Can not set / get hue value
    if ((ulFun != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & (S3_TV | S3_HDTV)) == 0))
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }
    
    switch(ulFun)
    {
    //Set Hue level in CX
    case S3_TV_FN_SET_UMA:
        hue_angle = biosArguments->Ecx & 0xFFFF;
        status = cbSetHueControl_UMA(pcbe, hue_angle);
        break;

    //Get Hue level
    case S3_TV_FN_GET_UMA:
        biosArguments->Ecx = pcbe->tvparameter.CurHueAngle;
        break;

    //Reset Hue angle to BIOS default
    case S3_TV_FN_SET_DEFAULT_UMA:
        hue_angle = pcbe->tvparameter.DefaultHueAngle;
        status =  cbSetHueControl_UMA(pcbe, hue_angle);
        biosArguments->Ecx = pcbe->tvparameter.CurHueAngle;
        break;

    //Max. supported Hue level
    case S3_TV_FN_QUERY_MAX_RANGE_UMA:
        status = cbGetMaxHue_UMA(pcbe, &biosArguments->Ecx);
        break;
            
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
  
}


//**********************************************************************
// VBE_4F14_0607_HueControl_UMA - TV/HDTV Brightness Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//         CX - Brightness level
//        
//         DL - The sub-functions of Hue control
//              0       = Set Brightness level
//              1       = Get Brightness level
//              2       = Reset Brightness level to BIOS default
//              3       = Max. supported Brightness level
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//         CX - Brightness Level*
// *No value returned for "set Brightness level" or invalid function calls.
//**********************************************************************
VOID VBE_4F14_0607_BrightnessControl_UMA(PCBIOS_EXTENSION pcbe,
                                  PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG ulFun = biosArguments->Edx & 0xFF;
    ULONG brigtnesslevel;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 

    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    // if TV / HDTV haven't config to IGAs 
    // Can not set / get brightness value
    if ((ulFun != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & (S3_TV | S3_HDTV)) == 0))
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }
    
    switch(ulFun)
    {
    //Set Brightness level in CX
    case S3_TV_FN_SET_UMA:
        brigtnesslevel = biosArguments->Ecx & 0xFF;
        status = cbSetBrightnessControl_UMA(pcbe, brigtnesslevel);
        break;

    //Get Brightness level
    case S3_TV_FN_GET_UMA:
        biosArguments->Ecx = pcbe->tvparameter.CurBrightness;
        break;

    //Reset Brightness level to BIOS default
    case S3_TV_FN_SET_DEFAULT_UMA:
        brigtnesslevel = pcbe->tvparameter.DefaultBrightness;
        status =  cbSetBrightnessControl_UMA(pcbe, brigtnesslevel);
        biosArguments->Ecx = pcbe->tvparameter.CurBrightness;
        break;

    //Max. supported Brightness level
    case S3_TV_FN_QUERY_MAX_RANGE_UMA:
        status = cbGetMaxBrightness_UMA(pcbe, &biosArguments->Ecx);
        break;
            
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
  
}

//**********************************************************************
// VBE_4F14_0707_FilterControl_UMA - TV deflicker filter Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//        CX
//         0 = Enable Normal flicker filter disable Adaptive flicker filter
//         1 = Disable Normal flicker filter enable Adaptive flicker filter
//        DL    
//         0 = Set flicker filter state
//         1 = Query current flicker filter status
//         2 = Reset flicker fliter default status
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//        CX    
//         0 = Enable Normal flicker filter disable Adaptive flicker filter
//         1 = Disable Normal flicker filter enable Adaptive flicker filter
// *No value returned for "set flicker filter status" or invalid function calls.
//**********************************************************************
VOID VBE_4F14_0707_FlickerFilterControl_UMA(PCBIOS_EXTENSION pcbe,
                                  PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    ULONG ulFun = biosArguments->Edx & 0xFF;
    CBIOS_STATUS status = CBIOS_OK;
    ULONG flickerfilterstatus = biosArguments->Ecx & 0xFF;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 

    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    // if TV / HDTV haven't config to IGAs 
    // Can not set / get flicker filter value
    if ((dispDev & (S3_TV | S3_HDTV)) == 0)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }
    
    switch(ulFun)
    {
    // set flicker filter status
    case S3_TV_FN_SET_UMA:
        if (flickerfilterstatus == ENABLE_NORM_FLICKERFILTER)
        {
            // enable normal flicker filter disable adaptive flicker filter
            status = cbEnableNormFlickerFilter_UMA(pcbe);
        }
        else if (flickerfilterstatus == ENABLE_ADAPTIVE_FLICKERFILTER)
        {
            // disable normal flicker filter enable adaptive flicker filter
            status = cbEnableAdaptiveFlickerFilter_UMA(pcbe);
        }
        break;
    
    // query current flicker filter status 
    case S3_TV_FN_GET_UMA:
        biosArguments->Ecx = pcbe->tvparameter.CurDeflickerFliterStatus;
        break;
            
    // set to defualt flicker filter status 
    case S3_TV_FN_SET_DEFAULT_UMA:
        if (pcbe->tvparameter.DefaultDeflickerFliterStatus == ENABLE_NORM_FLICKERFILTER)
        {
            status = cbEnableNormFlickerFilter_UMA(pcbe);
        }
        else if (pcbe->tvparameter.DefaultDeflickerFliterStatus == ENABLE_ADAPTIVE_FLICKERFILTER)
        {
            status = cbEnableAdaptiveFlickerFilter_UMA(pcbe);
        }
        biosArguments->Ecx = pcbe->tvparameter.DefaultDeflickerFliterStatus;
        break;

  
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
}

//**********************************************************************
// VBE_4F14_0B07_PositionControl_UMA - TV Position Control
//
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//        ECX - Position Adjustment Level
//              [15:00] = The Horizontal Position Adjustment Level
//              [31:16] = The Vertical Position Adjustment Level
//         DL - The sub-functions of contraction control
//              0       = Set position adjustment
//              1       = Get Current position adjustment
//              2       = Reset position adjustment to default 
//              3       = Query the max. range of position level
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//        ECX - Contraction Level
//              [15:00]  = The Horizontal Position Adjustment level
//              [31:16]  = The Vertical Position Adjustment level
//**********************************************************************
#define H_POSITION_MASK     0x0000FFFF
#define V_POSITION_MASK     0xFFFF0000

VOID VBE_4F14_0B07_PositionControl_UMA(PCBIOS_EXTENSION pcbe,
                                   PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{
    CBIOS_STATUS status = CBIOS_OK;
    BYTE CtlFunc = (BYTE)(biosArguments->Edx) & 0xF; // get DL
    ULONG HPositionAdj, VPositionAdj;
    ULONG HPositionMax, VPositionMax;
    ULONG defualtHPositionAdj, defualtVPositionAdj;
    ULONG dispDev = pcbe->IGA1Info.dispDev | pcbe->IGA2Info.dispDev; 
    ULONG encodertype;
    
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }
    
    //default return success
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;
    
    // if TV / HDTV haven't config to IGAs 
    // Can not set / get position value
    if ((CtlFunc != S3_TV_FN_QUERY_MAX_RANGE_UMA) && 
        ((dispDev & (S3_TV | S3_HDTV)) == 0))
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
        return;
    }

    switch(CtlFunc)
    {
    // Set position adjustment level
    case S3_TV_FN_SET_UMA:
        HPositionAdj = biosArguments->Ecx & H_POSITION_MASK;
        VPositionAdj = biosArguments->Ecx & V_POSITION_MASK;
        VPositionAdj >>= 16;
        status = cbSetPositionControl_UMA(pcbe, HPositionAdj, VPositionAdj);
        break;

    // Get Current position adjustment level
    case S3_TV_FN_GET_UMA:
        status = cbGetPositionControl_UMA(pcbe, &HPositionAdj, &VPositionAdj);

        HPositionAdj &= H_POSITION_MASK;
        VPositionAdj = (VPositionAdj << 16) & V_POSITION_MASK;
        biosArguments->Ecx = VPositionAdj | HPositionAdj;
        break;

    // Reset position adjustment level to default
    case S3_TV_FN_SET_DEFAULT_UMA:
        status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);
        if (encodertype == VT1625_6 || encodertype == VT1625A_6A)
        {
            // Caution! Now we just handle H right side limit & V downwards limit
            // for H left side limit & V upwards limit do not handle since we haven't 
            // see such limitation case
            if ((LONG)pcbe->tvparameter.DefaultHPosition >= ((LONG)(HPositionMax >> 1) - 1))
            {
                // if there is enough room for us to adjust H position
                // then keep default H position as middle value
                // rightmost =< 0_________________defualt______________MAX <= leftmost
                defualtHPositionAdj =  (HPositionMax>>1);
            }
            else
            {
                // else keep RegValue == 0 as H position adjust level Max
                // rightmost =< 0___________________________defualt____MAX = leftmost
                defualtHPositionAdj = HPositionMax - pcbe->tvparameter.DefaultHPosition;
            }
    
            
            if ((LONG)pcbe->tvparameter.DefaultVPosition >= ((LONG)(VPositionMax >> 1) - 1))
            {
                // if there is enough room for us to adjust V position
                // then keep default V position as middle value
                // Bottommost =< 0_________________defualt______________MAX <= upmost
                defualtVPositionAdj = (VPositionMax>>1);
            }
            else
            {
                // else keep RegValue == 0 as V position adjust level 0
                // Bottommost =< 0___________________________defualt____MAX = upmost
                defualtVPositionAdj = pcbe->tvparameter.DefaultVPosition;
            }
        }
        else // default for IN_TV and other
        {
            defualtHPositionAdj = pcbe->tvparameter.DefaultHPosition;
            defualtVPositionAdj = pcbe->tvparameter.DefaultVPosition;
        }
        status = cbSetPositionControl_UMA(pcbe, defualtHPositionAdj, defualtVPositionAdj);
        status = cbGetPositionControl_UMA(pcbe, &HPositionAdj, &VPositionAdj);

        HPositionAdj &= H_POSITION_MASK;
        VPositionAdj = (VPositionAdj << 16) & V_POSITION_MASK;
        biosArguments->Ecx = VPositionAdj | HPositionAdj;
        break;
        
    // Query the max. range of position level
    case S3_TV_FN_QUERY_MAX_RANGE_UMA:
        status = cbGetTVPositionMaxRange_UMA(pcbe, &HPositionMax, &VPositionMax);

        HPositionMax &= H_POSITION_MASK;
        VPositionMax = (VPositionMax << 16) & V_POSITION_MASK;
        biosArguments->Ecx = VPositionMax | HPositionMax;
        break;
            
    default:
        biosArguments->Eax = VBE_STATUS_FAILED;
        break;
    }
    
    if(status != CBIOS_OK)
    {
        biosArguments->Eax = VBE_STATUS_FAILED;
    }
  

}

//**********************************************************************
// VBE_4F14_8107_GetTVHDTVConfigFromSysBIOS_UMA - TV Contraction Control
//
//        Processing:
//          This procedure can get TV Configuration.
// Entry:
//     PCBIOS_EXTENSION
//     PVIDEO_X86_BIOS_ARGUMENTS
//          cx = 00h Get TV configuratiion from the system BIOS
//             = 01h Query the TV connection output support combinations configuration
//
// Exit:
//     PVIDEO_X86_BIOS_ARGUMENTS
//         AX - VBE support code
//              0x004F = VBE success
//              0x014F = VBE fail
//              0x0000 = VBE not support
//
//         When cx = 0,
//           ax = VBE return status
//           cl = TV Configuration Type
//              = Bit[7]      0 = TV Hardware Supported, 1 = No Support   (No Implement)
//              = Bit[6]      Force 8-dot text mode                       (No Implement)
//              = Bit[5]      Force Panning on TV                         (No Implement)
//              = Bit[4:3:2]  TV Type
//                            000 - NTSC
//                            001 - PAL / PAL B / PAL G / PAL H
//                            010 - PAL M
//                            011 - PAL N
//                            100 - PAL Nc
//                            101 - PAL I
//                            110 - PAL D
//                            111 - NTSC Japan
//              = Bit[1:0]    Reserved
//
//           ch = TV Configuration Type 2
//              = Bit[7]      Enable De-Dot Crawl
//                            TV Output Connector
//              = Bit[6]      S-VIDEO 1 (Y/C)
//              = Bit[5]      C_SDTVYPbPr
//              = Bit[4]      C_SDTVRGB
//              = Bit[3]      YCbCr
//              = Bit[2]      RGB
//              = Bit[1]      S-VIDEO 0 (Y/C)
//              = Bit[0]      CVBS
//           ecx[18:16] = HDTV configuration byte 1
//              = 000         SDTV 525I (SDTV 480I, NTSC)
//              = 001         SDTV 625I (SDTV 576I, PAL)
//              = 010         HDTV 480P (HDTV 525P, NTSC)
//              = 011         HDTV 576P (HDTV 625P, PAL)
//              = 100         HDTV 720P
//              = 101         HDTV 1080I
//              = 110         HDTV 1080P
//           ecx[31:24] = HDTV configuration byte 2
//              = Bit[2]      RGB
//              = Bit[3]      YPBPR
//
//         When cx = 1,
//           ax = VBE return status
//           di = Support TV / HDTV layout Type Combination.
//              = Bit0        CVBS
//              = Bit1        SVideo1
//              = Bit2        RGB
//              = Bit3        YCbCr
//              = Bit4        SDTVRGB
//              = Bit5        SDTVYPbPr
//              = Bit6        CVBS+SVideo1
//              = Bit7        CVBS+RGB
//              = Bit8        CVBS+YCbCr
//           edi[23:16] = Support HDTV Type Combination
//                      = BIT2   RGB
//                      = BIT3   YPBPR
//**********************************************************************
VOID VBE_4F14_8107_GetTVHDTVConfigFromSysBIOS_UMA(PCBIOS_EXTENSION pcbe,
               PVIDEO_X86_BIOS_ARGUMENTS biosArguments)
{         
    BYTE TVConType,TempByte;
    WORD TVLayout;
    VIDEO_X86_BIOS_ARGUMENTS biosArgumentTVCap;
    biosArguments->Eax = VBE_STATUS_SUCCESSFUL;

    switch (biosArguments->Ecx)
    {
    case 0: // Get TV configuratiion from the shadowed CMOS data area
        {   
            if (pcbe->SysBiosInfoValid == FALSE)
            {
                biosArguments->Eax = VBE_STATUS_FAILED;
                cbDbgPrint(1, "System bios shadow error. We can not get CMOS setting!\n");
                return;
            }
            biosArguments->Ecx = 0;
            if(pcbe->SupportDevices & S3_HDTV)
            {
                // ECX bit[26] : RGB , bit[27] : Y/Pb/Pr
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & (BIT26+BIT27));
                // ECX bit[16:19] : HDTV type 
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & (BIT16+BIT17+BIT18+BIT19));
            }

            if(pcbe->SupportDevices & (S3_TV | S3_TV2))
            {
                // ECX bit[8:14] : TV Output Connector 
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & 0x7f00);

                // ECX bit[15] : Dot Crawl
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & BIT15);

                // ECX bit[5:7] : TV Contraction Level
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & (BIT5+BIT6+BIT7));

                // ECX bit[2:4] : TV Type
                biosArguments->Ecx |= (pcbe->SysBiosInfo.HDTV_TV_Config & (BIT2+BIT3+BIT4));

                // ECX bit[0] : TV Encoder Input Mode
                biosArguments->Ecx |= pcbe->SysBiosInfo.HDTV_TV_Config & BIT0;
            }
            //vlidation the TV connector type in TV layout
            TVConType=(BYTE)((biosArguments->Ecx & 0x7f00)>>8);
            TVLayout=(WORD)(cbGetTVLayout(pcbe, pcbe->SysBiosInfo.TVLayOut));
            cbLimitTVConTypeInLayout(&TVConType, TVLayout);
            biosArguments->Ecx &=0xFFFF80FF;
            biosArguments->Ecx |=(TVConType<<8);
            //here no need to check HDTV, for HDTV layout is support all connection type

            //validation the TV Type
            biosArgumentTVCap.Eax=0x4f14;
            biosArgumentTVCap.Ebx=0x0207;
            VBE_4F14_0207_GetSupportedTVType_UMA(pcbe, &biosArgumentTVCap);
            if(biosArgumentTVCap.Eax==VBE_STATUS_SUCCESSFUL)
            {
                TempByte=(BYTE)((biosArguments->Ecx & (BIT2+BIT3+BIT4))>>2);
                cbLimitTVType(&TempByte, (WORD)(biosArgumentTVCap.Ecx & 0x1FFF));
                biosArguments->Ecx =(biosArguments->Ecx&~(BIT2+BIT3+BIT4)) | ((TempByte<<2)&(BIT2+BIT3+BIT4));

                TempByte=(BYTE)((biosArguments->Ecx & (BIT16+BIT17+BIT18))>>16);
                cbLimitHDTVType(&TempByte, (BYTE)((biosArgumentTVCap.Ecx>>23) & 0x7F));
                biosArguments->Ecx =(biosArguments->Ecx&~(BIT16+BIT17+BIT18)) | ((((DWORD)(TempByte))<<16)&(BIT16+BIT17+BIT18));
            }
        }
        break;

    case 1: // Query the TV / HDTV connection output support combinations configuration
        {
            if(pcbe->SupportDevices & (S3_TV | S3_TV2))
            {
                //if SysBiosInfo version is 1(old version), pcbe->SysBiosInfo.TVLayOut must be 0
                biosArguments->Edi = cbGetTVLayout(pcbe, pcbe->SysBiosInfo.TVLayOut);
            }
            if (pcbe->SupportDevices & S3_HDTV)
            {
                // HDTV default support all connection type
                biosArguments->Edi |= (BIT18+BIT19);
            }
        }
        break;
        
    }
}

/*=============================================================================
* below is new sub functions
* =============================================================================
* -------------------------------------------------------------------
* ----------Init CBIOS new interface information in pcbe -------------
* -------------------------------------------------------------------
* -----------------------------------------------------------------
* cbCBIOSInfoInit
* This function initalized cbios new interface information stored
* in pcbe.Since pcbe info stored in memeory , below is the policy
*     1. scratchpad info in pcbe 
*     2. IGA info
*     3. Device power state  
*     4. Digital Port (OSstart / POST)
*     5. TV encoder I2C
*     6. device timing policy init
*     7. FIFO aid setting
*     IN :
*         InitializationEvent
*     OUT : 
*          CBIOS_STATUS 
* -----------------------------------------------------------------*/
CBIOS_STATUS cbCBIOSInfoInit(
    PCBIOS_EXTENSION pcbe,
    IN UINT32 InitializationEvent)
{
    CBIOS_STATUS status = CBIOS_OK;
    BYTE EdidBuffer[EDID1_X_BLOCKSIZE];
    CBIOS_PARAM_GET_EDID CBParamGetEdid;
    PCBIOS_DEV_EDID pEDID;
    /* get default power now condition from VBIOS
        * need to check MAMM case */
    if(cbReadRegByte(pcbe, CR_42) & 0x80)
    {
        pcbe->IGA1Info.PowerNowCondition = VB_FIFO;
    }
    else
    {
        pcbe->IGA1Info.PowerNowCondition = VB_ONLY;
    }
    if(cbReadRegByte(pcbe, CR_9E) & 0x80)
    {
        pcbe->IGA2Info.PowerNowCondition = VB_FIFO;
    }
    else
    {
        pcbe->IGA2Info.PowerNowCondition = VB_ONLY;
    }

    /* cbios chip caps init should be done first */
    cbCbiosChipCapsInit(pcbe);

    //----------------------------------------------------
    //--- save HW scracth pad value to pcbe info after finish init all necessary caps or information
    //--- must init before get sysbios info for MAMM case
    //----------------------------------------------------
    CBiosSyncCBiosExtensionFromHWReg(pcbe);    

    //----------------------------------------------------
    //---init scratchpad value stored in pcbe 
    //--- 1. OSstart & S4 need 
    //--- 2. MAMM secondary need to init HW first
    //--- 3. Here we do not care about if MAMM or not, just use pcbe->SysBiosInfo to init Scratch pad,
    //       We do not use the result of vbios initialization, unless the SysBiosInfo is invalid.
    //----------------------------------------------------
    if( !cbGetSysBiosInfo(pcbe) )
    {
        //system bios info invalid and we are sencondary adapter, return fail
        cbDbgPrint(0, "Not support shadow VBIOS! \n");
    }

    //----------------------------------------------------	
    //--- set IGA upscaler caps
    //----------------------------------------------------
    pcbe->IGA1Info.IGAUpScalerCaps = CENTER_SUPPORTED | UPSCALER_KEEP_ASPECT_RATIO;
    pcbe->IGA2Info.IGAUpScalerCaps = CENTER_SUPPORTED | UPSCALER_SUPPORTED | UPSCALER_KEEP_ASPECT_RATIO;
    if(pcbe->ChipCaps.IGA1_Support_Upscale)
    {
        pcbe->IGA1Info.IGAUpScalerCaps = CENTER_SUPPORTED | UPSCALER_SUPPORTED | UPSCALER_KEEP_ASPECT_RATIO;
    }
    // VT3336 desktop IGA2 do not have upscaler
    // so we use VBIOS version[27:26] to decide if it is VT3336 desktop chipset
    if( pcbe->PCIDeviceID == PCI_ID_VT3336 
    && (pcbe->RomData[VBIOS_VERSION_OFFSET] & (BIT2 + BIT3)) == DESKTOPBIOS)
    {
        pcbe->IGA2Info.IGAUpScalerCaps = CENTER_SUPPORTED | UPSCALER_KEEP_ASPECT_RATIO;
    }

    //---------------------------------------------------
    //  4. Digital Port (OSstart / POST)
    //--- initialize DI port info in pcbe
    //--- OSstart / POST needs to init DI port info in pcbe
    //---------------------------------------------------
    if (InitializationEvent == OSstart || InitializationEvent == POST)
    {
        status = cbDIInfoInit(pcbe);
    }

    //--------------------------------------------------
    //--- init Current hardware support device
    //--- This need to be done after TX / TV encoder senser
    //--- done in DI port init
    //--- pcbe->SupportDevices
    //--------------------------------------------------
    if (status == CBIOS_OK)
    {
        status = cbInitHWSupportdevice(pcbe);
    }
    
    //--------------------------------------------------
    //  5. TV encoder I2C
    //--------------------------------------------------
    // default TV I2C
    pcbe->TVI2CPort = 0x31;
    pcbe->TVI2CSubAddr = 0x40;
    // TV I2C info from VCP
    if (NULL != pcbe->pVCPInfo)
    {
        if (0 != pcbe->pVCPInfo->TV_TBL)
        {
            PTVI2CTBLDATA pTV = (PTVI2CTBLDATA)(pcbe->RomData + pcbe->pVCPInfo->TV_TBL);
            if (pTV->TVI2CPORT != 0xFF)
            {
                // get TV I2C info from VBIOS
                pcbe->TVI2CPort = pTV->TVI2CPORT;
                pcbe->TVI2CSubAddr = pTV->TVSlaveAddr;
            }
        }
    }
    
    //--------------------------------------------------
    //  6. device timing policy init
    //--------------------------------------------------
    //  here we will init all device timing type for all device 
    //  within or without hardware supported device for performace issue
    if (InitializationEvent == OSstart || InitializationEvent == POST)
    {
        // CRT / CRT2 default using VESAVPIT timing type
        pcbe->devicetimingtype[CRTbit ]  = VESAVPIT_TIMING_TYPE;
        pcbe->devicetimingtype[CRT2bit]  = VESAVPIT_TIMING_TYPE;
        // LCD / LCD2 default using non device scaler timing type
        pcbe->devicetimingtype[LCDbit ]  = EDID_DISABLEDEVSCALING_TIMING_TYPE;
        pcbe->devicetimingtype[LCD2bit]  = EDID_DISABLEDEVSCALING_TIMING_TYPE;
        // TV supports TV timing type
        pcbe->devicetimingtype[TVbit  ]  = TV_TIMING_TYPE;
        // HDTV supports HDTV timing type
        pcbe->devicetimingtype[HDTVbit]  = HDTV_TIMING_TYPE;
        // DVI / DVI2 default using EDID timing type
        pcbe->devicetimingtype[DVIbit ]  = EDID_ENABLEDEVSCALING_TIMING_TYPE;
        pcbe->devicetimingtype[DVI2bit]  = EDID_ENABLEDEVSCALING_TIMING_TYPE;
        // HDMI default using EDID timing type
        pcbe->devicetimingtype[HDMIbit] = EDID_ENABLEDEVSCALING_TIMING_TYPE;
    }

    //----------------------------------------------------
    //   7. for Non hot plug device(LCD / LCD2) we need to init EDID block
    //      by CBIOS itself
    //      now we support EDID1_X first 128 block parse
    //---------------------------------------------------
    CBParamGetEdid.EdidBuffer = EdidBuffer;
    CBParamGetEdid.EdidBufferLen = EDID1_X_BLOCKSIZE;
    if (pcbe->SupportDevices & S3_LCD)
    {
        CBParamGetEdid.DisplayDeviceDWord = S3_LCD;
        CBParamGetEdid.type = EDID_DIGITAL;
        if(cbGetEDID_UMA(pcbe, &CBParamGetEdid))
        {                        
            pEDID = &( pcbe->devEDID[cbGetLowestBitPos(S3_LCD)] );
            cbUpdateLCD_panel_ID(pcbe, &(pEDID->EDIDInfo), S3_LCD);
        }
    }

    if (pcbe->SupportDevices & S3_LCD2)
    {
        CBParamGetEdid.DisplayDeviceDWord = S3_LCD2; 
        CBParamGetEdid.type = EDID_DIGITAL;
        if(cbGetEDID_UMA(pcbe, &CBParamGetEdid))
        {                        
            pEDID = &( pcbe->devEDID[cbGetLowestBitPos(S3_LCD2)] );
            cbUpdateLCD_panel_ID(pcbe, &(pEDID->EDIDInfo), S3_LCD2);
        }
        
    }

    //--------------------------------------------------
    //  8. FIFO aid setting
    //--------------------------------------------------
    // init FIFO aid setting
    // CBIOS default
    switch (pcbe->PCIDeviceID)
    {
    case PCI_ID_VT3336:
    case PCI_ID_VT3382:
        pcbe->FIFO_Info.VGA_IGA1_Depth          = 80+16;
        pcbe->FIFO_Info.VGA_IGA1_Normal_TH      = 40;
        pcbe->FIFO_Info.VGA_IGA1_Fetch_CNT      = 80+4;
        pcbe->FIFO_Info.VGA_IGA1_Expire_N       = 20;

        pcbe->FIFO_Info.TEXT_IGA1_Depth         = 132+16;
        pcbe->FIFO_Info.TEXT_IGA1_Normal_TH     = 66;
        pcbe->FIFO_Info.TEXT_IGA1_Urgent_TH     = 30;
        pcbe->FIFO_Info.TEXT_IGA1_Fetch_CNT     = 132+4;
        pcbe->FIFO_Info.TEXT_IGA1_Expire_N      = 33;

        pcbe->FIFO_Info.ExtVGA_IGA1_Expire_N    = 20;

        pcbe->FIFO_Info.ExtGFX_IGA1_Depth       = 360/2-1;
        pcbe->FIFO_Info.ExtGFX_IGA1_Normal_TH   = 328/4;
        pcbe->FIFO_Info.ExtGFX_IGA1_Urgent_TH   = 296/4;    
        pcbe->FIFO_Info.ExtGFX_IGA1_Expire_N    = 124/4;

        pcbe->FIFO_Info.ExtGFX_IGA2_Depth       = 360/8-1;
        pcbe->FIFO_Info.ExtGFX_IGA2_Normal_TH   = 328/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Urgent_TH   = 296/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Expire_N    = 124/4;
        break;
    case PCI_ID_VT3364:
    case PCI_ID_VT3293:
    case PCI_ID_VT3353:
    case PCI_ID_VT3394_3405:
    case PCI_ID_VT3409:
        pcbe->FIFO_Info.VGA_IGA1_Depth          = 31;
        pcbe->FIFO_Info.VGA_IGA1_Normal_TH      = 12;
        pcbe->FIFO_Info.VGA_IGA1_Fetch_CNT      = 80+4;
        pcbe->FIFO_Info.VGA_IGA1_Expire_N       = 20;

        pcbe->FIFO_Info.TEXT_IGA1_Depth         = 31;
        pcbe->FIFO_Info.TEXT_IGA1_Normal_TH     = 12;
        pcbe->FIFO_Info.TEXT_IGA1_Urgent_TH     = 4;
        pcbe->FIFO_Info.TEXT_IGA1_Fetch_CNT     = 132+4;
        pcbe->FIFO_Info.TEXT_IGA1_Expire_N      = 33;

        pcbe->FIFO_Info.ExtVGA_IGA1_Expire_N    = 20;

        pcbe->FIFO_Info.ExtGFX_IGA1_Depth       = 96/2-1;
        pcbe->FIFO_Info.ExtGFX_IGA1_Normal_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA1_Urgent_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA1_Expire_N    = 32/4;

        pcbe->FIFO_Info.ExtGFX_IGA2_Depth       = 96/8-1;
        pcbe->FIFO_Info.ExtGFX_IGA2_Normal_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Urgent_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Expire_N    = 32/4;
        break;
    case PCI_ID_VT3409P:
    case PCI_ID_VT3410:
        pcbe->FIFO_Info.VGA_IGA1_Depth          = 31;
        pcbe->FIFO_Info.VGA_IGA1_Normal_TH      = 12;
        pcbe->FIFO_Info.VGA_IGA1_Fetch_CNT      = 80+4;
        pcbe->FIFO_Info.VGA_IGA1_Expire_N       = 20;

        pcbe->FIFO_Info.TEXT_IGA1_Depth         = 31;
        pcbe->FIFO_Info.TEXT_IGA1_Normal_TH     = 12;
        pcbe->FIFO_Info.TEXT_IGA1_Urgent_TH     = 4;
        pcbe->FIFO_Info.TEXT_IGA1_Fetch_CNT     = 132+4;
        pcbe->FIFO_Info.TEXT_IGA1_Expire_N      = 33;

        pcbe->FIFO_Info.ExtVGA_IGA1_Expire_N    = 20;

        pcbe->FIFO_Info.ExtGFX_IGA1_Depth       = 200/2-1;
        pcbe->FIFO_Info.ExtGFX_IGA1_Normal_TH   = 160/4;
        pcbe->FIFO_Info.ExtGFX_IGA1_Urgent_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA1_Expire_N    = 80/4;

        pcbe->FIFO_Info.ExtGFX_IGA2_Depth       = 200/8-1;
        pcbe->FIFO_Info.ExtGFX_IGA2_Normal_TH   = 160/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Urgent_TH   = 76/4;
        pcbe->FIFO_Info.ExtGFX_IGA2_Expire_N    = 80/4;
        break;
    default:
        break;
    }
    if (pcbe->pVCPInfo != NULL)
    {
        if (pcbe->pVCPInfo->version >= VCP1_1)
        {
            // if VCP 1.1, load FIFO setting from VBIOS
            PFIFOPatchSetting pFIFOSetting =
                (PFIFOPatchSetting)(pcbe->RomData + pcbe->pVCPInfo->FIFOSetting);
            pcbe->FIFO_Info = *pFIFOSetting;
        }
    }
    
    // Init S1 power saving registers
    if(pcbe->ChipCaps.S1_power_saving_sup)
    {
        pcbe->S1SavingRegs.PS_REG_SR19 = cbReadRegByte(pcbe, SR_19);
        pcbe->S1SavingRegs.PS_REG_SR1B = cbReadRegByte(pcbe, SR_1B);
        pcbe->S1SavingRegs.PS_REG_SR2D = cbReadRegByte(pcbe, SR_2D);
        pcbe->S1SavingRegs.PS_REG_SR2E = cbReadRegByte(pcbe, SR_2E);
        pcbe->S1SavingRegs.PS_REG_SR3F = cbReadRegByte(pcbe, SR_3F);
        pcbe->S1SavingRegs.PS_REG_CR92 = cbReadRegByte(pcbe, CR_92);
    }

    // Get ECK and VDCK PLL register, and save to pcbe
    if (InitializationEvent == OSstart)
    {
        pcbe->ECK_Freq = pcbe->VDCK_Freq = 0;
        pcbe->ECK_Freq = ((DWORD)cbReadRegByte(pcbe, SR_47)<<16) | ((DWORD)cbReadRegByte(pcbe, SR_48)<<8)|
                         (DWORD)cbReadRegByte(pcbe, SR_49);
        pcbe->VDCK_Freq = ((DWORD)cbReadRegByte(pcbe, SR_C0)<<16) | ((DWORD)cbReadRegByte(pcbe, SR_C1)<<8)|
                         (DWORD)cbReadRegByte(pcbe, SR_C2);
    }

    return status;
}

//-----------------------------------------------------------------
// cbInitHWSupportdevice
//    This function initalized hardware really support device combination
//  It comes from (VBIOS support device ability) AND (Current Hardware support
//  Ability(TX, Encoder)). The function relys on DIport info stored in 
//  pcbe.
//   IN :
//      NONE
//   OUT : 
//      CBIOS_STATUS 
//-----------------------------------------------------------------
CBIOS_STATUS cbInitHWSupportdevice(PCBIOS_EXTENSION pcbe)
{
    int i;
    ULONG encodertype;
    
    pcbe->SupportDevices  = 0;
    pcbe->SupportDevices |= S3_CRT;      // Default CRT support, for VCP = NULL case to light on CRT
   
    // if pVCPInfo == NULL only support CRT 
    if (pcbe->pVCPInfo == NULL)
    {
        return CBIOS_OK;
    }
    // device can be supported (init / sense /power manangement) 
    // only if it is configued to one IGA port and TX / Encoder
    // which device connects to really exist
    for (i = 0; i < DigitalPortNUM; i++)
    {
        if (pcbe->DIPort[i].PortInfo.TXType != 0)
        {
            pcbe->SupportDevices |= pcbe->DIPort[i].PortInfo.device;
        }

        // TV / HDTV share one DIport when VT1625 or initernal TV encoder
        // is really on the DIport
        // Since internal TV & CRT share the CRT_PORT,so we change == to &
        if (pcbe->DIPort[i].PortInfo.device & S3_TV)
        {
            cbGetDIEncodertype(pcbe, &encodertype, S3_TV);
            if (encodertype == VT1625A_6A ||
                encodertype == VT1625_6 ||
                encodertype == IN_TV)
            {
                pcbe->SupportDevices |= S3_HDTV;  
            }
        }
    }

    //If CRT attached on, remove CRT support from supported device
    if(pcbe->pVCPInfo->version >= VCP1_4 && pcbe->pVCPInfo->Always_On_Device & CRT_ATTACHED_ON)
    {
        pcbe->SupportDevices &= ~S3_CRT;     // Remove CRT support
    }

    if (pcbe->pVCPInfo->version >= VCP1_2)
    {
        // CRT2 force on 
        if (pcbe->pVCPInfo->miscConfigure2 & BIT0)
        {
            pcbe->SupportDevices |= S3_CRT2;
        }
    }
    return CBIOS_OK;
}

//-----------------------------------------------------------------
// cbDIInfoInit
//      This function initalized cbios new interface information about
//  Digital Port stored in pcbe
//   IN :
//   OUT : 
//       CBIOS_STATUS 
//-----------------------------------------------------------------
CBIOS_STATUS cbDIInfoInit(PCBIOS_EXTENSION pcbe)
{
    PDIPortInfo pDIPortInfo;
    PDigitalPortInfo PDIPort = pcbe->DIPort;

    // when VCP is null we only support CRT 
    // so need not to init DI port info data structure
    if (pcbe->pVCPInfo != NULL)
    {   
        pDIPortInfo = &pcbe->pVCPInfo->DI_DVP0;
        //DVP0 init
        PDIPort[0].DIType = DVP0;
        if (FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[0], &PDIPort[0].PortInfo))
        {
            // memory set DIport info data structure
            memset(&PDIPort[0].PortInfo, 0, sizeof(DIPortInfo));
        }
        
        //DVP1 init
        PDIPort[1].DIType = DVP1;
        if ( FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[1], &PDIPort[1].PortInfo) )
        {
            // memory set DIport info data structure
            memset(&PDIPort[1].PortInfo, 0, sizeof(DIPortInfo));
        }
        
        //DFPH init
        PDIPort[2].DIType = DFP_HIGH;
        if (FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[2], &PDIPort[2].PortInfo))
        {
            // memory set DIport info data structure
            memset(&PDIPort[2].PortInfo, 0, sizeof(DIPortInfo));
        }       
        
        //DFPL init
        PDIPort[3].DIType = DFP_LOW;
        if ( FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[3], &PDIPort[3].PortInfo) )
        {       
            // memory set DIport info data structure
            memset(&PDIPort[3].PortInfo, 0, sizeof(DIPortInfo));
        }
        
        //DFP  init
        PDIPort[4].DIType = DFP_FULL;
        if (FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[4], &PDIPort[4].PortInfo))
        {
            // memory set DIport info data structure
            memset(&PDIPort[4].PortInfo, 0, sizeof(DIPortInfo));
        }
        
        PDIPort[5].DIType = CRT_PORT;
        if (pcbe->pVCPInfo->miscConfigure & INTERNAL_TV_SUPPORT)  //if internal TV support
        {
            PDIPort[5].PortInfo.device = S3_TV | S3_CRT; //attach CRT & InTV both on CRT_PORT
            PDIPort[5].PortInfo.TXType = IN_TV;
        }
        else  //CRT
        {
            PDIPort[5].PortInfo.device = S3_CRT;
            PDIPort[5].PortInfo.TXType = 0x00;
            if(pcbe->pVCPInfo->version >= VCP1_6)
            {
                PDIPort[5].PortInfo.DIPORTMISC = pcbe->pVCPInfo->CRT_PORT_MISC;
            } 
            else //default layout
            {                 
                PDIPort[5].PortInfo.DIPORTMISC |= USING_TMDS_HPD_INTERRUPT;
            }
        }
        // for CRT only DDC port 26h
        PDIPort[5].PortInfo.I2CPort = 0x26;
        PDIPort[5].PortInfo.DDCPort = 0x26;

        // no TX connect in CRT so set slave addr to 0x00
        PDIPort[5].PortInfo.I2CSubAddr = 0x00;
        
        // CRT HSYNC Adjust value default value 0x06
        // refer Mode_XRegs table
        PDIPort[5].PortInfo.DPASetting[0] = 0x06;
        PDIPort[5].PortInfo.DPASetting[1] = 0x06;
        PDIPort[5].PortInfo.DPASetting[2] = 0x06;
        PDIPort[5].PortInfo.DPASetting[3] = 0x06;
        PDIPort[5].PortInfo.DPASetting[4] = 0x06;
        PDIPort[5].PortInfo.DPASetting[5] = 0x06;

        if(pcbe->pVCPInfo->version >= VCP1_8)
        {
            pDIPortInfo = &pcbe->pVCPInfo->DI_DPPHY;

            //DPPHY  init
            PDIPort[6].DIType = DPPHY;
            if (FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[0], &PDIPort[6].PortInfo))
            {
                // memory set DIport info data structure
                memset(&PDIPort[6].PortInfo, 0, sizeof(DIPortInfo));
            }
            if(pcbe->ChipCaps.DP_FOR_410_A0_A1)
                PDIPort[6].PortInfo.DIPORTMISC = 0; // hardcode for A0/A1

            //DPMUX  init
            PDIPort[7].DIType = DPMUX;
            if (FALSE == cbInitDigitalPortInfo(pcbe, &pDIPortInfo[1], &PDIPort[7].PortInfo))
            {
                // memory set DIport info data structure
                memset(&PDIPort[7].PortInfo, 0, sizeof(DIPortInfo));
            }
            if(pcbe->ChipCaps.DP_FOR_410_A0_A1)
                PDIPort[7].PortInfo.DIPORTMISC = 0; // hardcode for A0/A1
        }
        else
        {
            if(pcbe->pVCPInfo->BIOSSupportDev & S3_DP)
            {
                // DIPort 6, for DP support
                PDIPort[6].PortInfo.device = S3_DP;
                // pcbe->pVCPInfo->BIOSSupportDev will only report external HDMI
                if(!(pcbe->pVCPInfo->BIOSSupportDev & S3_HDMI))
                    PDIPort[6].PortInfo.device |= S3_HDMI;
                else
                    PDIPort[6].PortInfo.device |= S3_HDMI2;
                // pcbe->pVCPInfo->BIOSSupportDev will only report external DVI
                if(!(pcbe->pVCPInfo->BIOSSupportDev & S3_DVI))
                    PDIPort[6].PortInfo.device |= S3_DVI;
                else
                    PDIPort[6].PortInfo.device |= S3_DVI2;
                PDIPort[6].PortInfo.TXType = INTERNAL_DP;
                PDIPort[6].PortInfo.DIPORTMISC |= 0;//USING_DP_HPD_INTERRUPT + USING_HDAUDIO_INTERRUPT;
                // DP
                PDIPort[6].PortInfo.I2CPort = 0x00;
                PDIPort[6].PortInfo.DDCPort = 0x00;
                PDIPort[6].PortInfo.I2CSubAddr = 0x00;
                
                PDIPort[6].PortInfo.DPASetting[0] = 0x00;
                PDIPort[6].PortInfo.DPASetting[1] = 0x00;
                PDIPort[6].PortInfo.DPASetting[2] = 0x00;
                PDIPort[6].PortInfo.DPASetting[3] = 0x00;
                PDIPort[6].PortInfo.DPASetting[4] = 0x00;
                PDIPort[6].PortInfo.DPASetting[5] = 0x00;
            }
            else
            {
                // DIPort 6, for DP support
                PDIPort[6].PortInfo.device = 0;
                PDIPort[6].PortInfo.TXType = 0;   // TX_NONE
                PDIPort[6].PortInfo.DIPORTMISC = 0;
                // DP
                PDIPort[6].PortInfo.I2CPort = 0x00;
                PDIPort[6].PortInfo.DDCPort = 0x00;
                PDIPort[6].PortInfo.I2CSubAddr = 0x00;
                
                PDIPort[6].PortInfo.DPASetting[0] = 0x00;
                PDIPort[6].PortInfo.DPASetting[1] = 0x00;
                PDIPort[6].PortInfo.DPASetting[2] = 0x00;
                PDIPort[6].PortInfo.DPASetting[3] = 0x00;
                PDIPort[6].PortInfo.DPASetting[4] = 0x00;
                PDIPort[6].PortInfo.DPASetting[5] = 0x00;
            } 
            if(pcbe->pVCPInfo->BIOSSupportDev & S3_DP2)
            {
                // DIPort 7, for DP2 support
                PDIPort[7].PortInfo.device = S3_DP2;
                PDIPort[7].PortInfo.TXType = INTERNAL_DP;
                PDIPort[7].PortInfo.DIPORTMISC |= 0;//USING_DP2_HPD_INTERRUPT;
                // DP2
                PDIPort[7].PortInfo.I2CPort = 0x00;
                PDIPort[7].PortInfo.DDCPort = 0x00;
                PDIPort[7].PortInfo.I2CSubAddr = 0x00;
                
                PDIPort[7].PortInfo.DPASetting[0] = 0x00;
                PDIPort[7].PortInfo.DPASetting[1] = 0x00;
                PDIPort[7].PortInfo.DPASetting[2] = 0x00;
                PDIPort[7].PortInfo.DPASetting[3] = 0x00;
                PDIPort[7].PortInfo.DPASetting[4] = 0x00;
                PDIPort[7].PortInfo.DPASetting[5] = 0x00;
            }
            else
            {
                PDIPort[7].PortInfo.device = 0;
                PDIPort[7].PortInfo.TXType = 0;   // TX_NONE
                PDIPort[7].PortInfo.DIPORTMISC = 0;
                // DP2
                PDIPort[7].PortInfo.I2CPort = 0x00;
                PDIPort[7].PortInfo.DDCPort = 0x00;
                PDIPort[7].PortInfo.I2CSubAddr = 0x00;
                
                PDIPort[7].PortInfo.DPASetting[0] = 0x00;
                PDIPort[7].PortInfo.DPASetting[1] = 0x00;
                PDIPort[7].PortInfo.DPASetting[2] = 0x00;
                PDIPort[7].PortInfo.DPASetting[3] = 0x00;
                PDIPort[7].PortInfo.DPASetting[4] = 0x00;
                PDIPort[7].PortInfo.DPASetting[5] = 0x00;
            }
        }
    }
    else //pcbe->pVCPInfo = NULL
    {
        // CRT Port init (CRT always support even VCP is null) 
        // althought CRT have't connect to one DI port we assume it connect 
        // to a presudo DI port so that device configuration will be more clear
        PDIPort[5].PortInfo.device = S3_CRT;
    
        // for CRT only DDC port 26h
        PDIPort[5].PortInfo.I2CPort = 0x26;
        PDIPort[5].PortInfo.DDCPort = 0x26;

        // no TX connect in CRT so set slave addr to 0x00
        PDIPort[5].PortInfo.TXType = 0x00;
        PDIPort[5].PortInfo.I2CSubAddr = 0x00;
        
        // CRT HSYNC Adjust value default value 0x06
        // refer Mode_XRegs table
        PDIPort[5].PortInfo.DPASetting[0] = 0x06;
        PDIPort[5].PortInfo.DPASetting[1] = 0x06;
        PDIPort[5].PortInfo.DPASetting[2] = 0x06;
        PDIPort[5].PortInfo.DPASetting[3] = 0x06;
        PDIPort[5].PortInfo.DPASetting[4] = 0x06;
        PDIPort[5].PortInfo.DPASetting[5] = 0x06;
        
        PDIPort[5].DIType = CRT_PORT;
    }
    return CBIOS_OK;
}

//-----------------------------------------------------------------
// cbInitDigitalPortInfo
//     init des digital port info structure using src .
//     TX type must be set after TX senser process, not simply from src 
//     now, add real TX sensor process, not read from scratch pad(init by VBIOS)
//   IN :
//      src : source port info addr
//      des : destination port info addr
//   OUT : 
//       BOOL 
//-----------------------------------------------------------------
BOOL cbInitDigitalPortInfo(
        PCBIOS_EXTENSION pcbe,
        IN  PDIPortInfo src,
        INOUT PDIPortInfo dst)
{
    BOOL TXstatus = TRUE;
    I2C_CONTROL_UMA i2c;
    DWORD TransDev = src->device;
    i2c.Flags = 0;
    
    if (NULL == src || NULL == dst)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    // TransDev may have two devices, here filter out unsupported devices
    TransDev &= pcbe->pVCPInfo->BIOSSupportDev;
    if(0 == TransDev)
    {
        return FALSE;
    }
    
    // For 324, we should translate word define device to s3 define here first.
    if ( (pcbe->pVCPInfo->version >= VCP1_5) && 
         (pcbe->ChipCaps.S3_device_define_for_324) )
    {
        cbTranslateWordDefineToS3Define(pcbe, &TransDev);
    }
    // no TX in DI port just set dst memory & return
    if(TransDev != 0 && src->TXType == TX_NONE)
    {   
        // memory set DIport info data structure
        dst->TXType = TX_NONE;
        dst->I2CSubAddr = 0x00;
        dst->device = TransDev;
        dst->I2CPort = src->I2CPort;
        dst->DDCPort = src->DDCPort;
        dst->DPASetting[0] = src->DPASetting[0];
        dst->DPASetting[1] = src->DPASetting[1];
        dst->DPASetting[2] = src->DPASetting[2];
        dst->DPASetting[3] = src->DPASetting[3];
        dst->DPASetting[4] = src->DPASetting[4];
        dst->DPASetting[5] = src->DPASetting[5];
        return TRUE;
    }

    switch(TransDev)
    {
    //*******************************************************************
    //**************       device Encoder sense         *****************
    //*******************************************************************
    case S3_TV:
    case S3_TV2:
    case S3_CRT2:
    case S3_TV+S3_CRT2: //VT1625 support TV and CRT2 at the same time
        // Internal TV has no I2C access attribute
        if( src->TXType == IN_TV )
        {
            dst->TXType = src->TXType;
            dst->I2CSubAddr = 0;
            dst->I2CPort = 0;
            break;
        }
        // if DI support TV /TV2/ HDTV(same as TV) 
        // just use VCP configure
        // TV default I2C port SR31 
        i2c.I2cPort = (src->I2CPort != 0) ? src->I2CPort : 0x31;

        // VT1622/VT1625_26 sub address are all 0x40
        i2c.SlaveAddr = (src->I2CSubAddr != 0) ? src->I2CSubAddr : 0x40;

        // VT1622/VT1625_26 Version ID reg1B
        i2c.RegIndex = 0x1B ;         
        i2c.IndexData = 0;
        I2C_Read_Byte_INV(pcbe, &i2c);

        // VT1625 also used as CRT2 encoder
        // don't do Encoder check for special issue that force CRT2 always on!
         if (((i2c.IndexData == VT1625_5A_ID) && 
             (src->TXType == VT1625_6 || src->TXType == VT1625A_6A || src->TXType == CRT2Encoder)) 
          || ((pcbe->pVCPInfo->miscConfigure2 & FORCE_CRT2_LIGHTON) && (src->TXType == CRT2Encoder)))
        {
            dst->TXType = src->TXType;
            dst->I2CSubAddr = i2c.SlaveAddr;
            dst->I2CPort = i2c.I2cPort;
        }
        else if ((i2c.IndexData == VT1622A_3_ID) && 
        (src->TXType == VT1622A || src->TXType == VT1623_3A))
        {
            dst->TXType = VT1622A;
            dst->I2CSubAddr = i2c.SlaveAddr;
            dst->I2CPort = i2c.I2cPort;
        }
        else if(i2c.IndexData == VT1622_ID && src->TXType == VT1622)
        {
            dst->TXType = VT1622;
            dst->I2CSubAddr = i2c.SlaveAddr;
            dst->I2CPort = i2c.I2cPort;
        }
        else
        {
            TXstatus = FALSE;
        }
        break;
    
    //*******************************************************************
    //**************       device Transmiter sense       ****************
    //*******************************************************************
    case S3_LCD:
    case S3_DVI2:
    case S3_DVI:
    case S3_LCD2:
    case S3_DVI+S3_CRT2:
	case S3_DVI2+S3_CRT2:
        // TX do not need to do sense job 
        if(src->TXType == IN_TMDS  ||
           src->TXType == HARDWIRED_LVDS ||
           src->TXType == IN_LVDS1 ||
           src->TXType == IN_LVDS2 ||
           src->TXType == TTL_PANEL ||
           src->TXType == INTERNAL_DP)
        {
            dst->TXType = src->TXType; // if use Internal or Non-sensible TX, no need to sense

            // for DCON, need to control it by I2CPort and I2CSubAddr
            if((pcbe->pVCPInfo->version >= VCP1_7) && (pcbe->pVCPInfo->miscConfigure3 & SW_CTRL_DCON_PANEL))
            {
                dst->I2CPort = src->I2CPort;
                dst->I2CSubAddr = src->I2CSubAddr;
            }
        }
        else
        {
            // TX need to do sense job 
            //I2C sensible TX
            PTXTABLEDATA pTxTbl = NULL; 
            // get TX table offset
            if (TransDev & (S3_LCD | S3_DVI2) && (pcbe->pVCPInfo->TX_LCD_DVI2_TBL != 0))
            {
                pTxTbl = (PTXTABLEDATA)(pcbe->RomData + pcbe->pVCPInfo->TX_LCD_DVI2_TBL);
            }
            else if (TransDev & (S3_LCD2 | S3_DVI) && (pcbe->pVCPInfo->TX_DVI_LCD2_TBL != 0))
            {
                pTxTbl = (PTXTABLEDATA)(pcbe->RomData + pcbe->pVCPInfo->TX_DVI_LCD2_TBL);
            }
            else
            {
                TXstatus = FALSE;
            }
            if(TXstatus == TRUE)
            {
                // check TX exist according to DI port TX type
                if (!cbGetExistTXInfo(pcbe, dst, src, pTxTbl))
                {
                    // can't sense right TX
                    if(TransDev & (S3_LCD | S3_LCD2))
                    {
                        // TTL type TX can use AUTO_SENSE TX type go here
                        dst->TXType = HARDWIRED_LVDS;
                        for (; pTxTbl->TXDI != 0xFF; pTxTbl++)
                        {
                            if (pTxTbl->TXDI == VT1636)
                            {
                                // this VBIOS support VT1636 but TX not exists
                                // not report LCD support
                                TXstatus = FALSE;
                                dst->TXType = TX_NONE;
                                break;
                            }
                        }
                    }
                    else
                    {
                        TXstatus = FALSE; // No TX detected
                    }
                }
            }
        } // if src->TXType
        break;
        
    case S3_HDMI:
    case S3_HDMI2:
        if (pcbe->pVCPInfo->version >= VCP1_3)
        {
            // TX do not need to do sense job 
            if(src->TXType == INTERNAL_DP)
            {
                dst->TXType = src->TXType; // if use Internal or Non-sensible TX, no need to sense
            }
            else
            {
                PTXTABLEDATA pTxTbl = NULL;
                // get TX table offset
                if (pcbe->pVCPInfo->TX_HDMI_TBL != 0)
                {
                    pTxTbl = (PTXTABLEDATA)(pcbe->RomData + pcbe->pVCPInfo->TX_HDMI_TBL);
                }
                else
                {
                    TXstatus = FALSE; // No TX detected
                }
                if(TXstatus == TRUE)
                {
                    if(cbCheckHDMITXExist(pcbe, src->TXType, &pTxTbl))
                    {
                        dst->TXType     = pTxTbl->TXDI; // HDMI TX
                        dst->I2CPort    = pTxTbl->TXI2CPORT;
                        dst->I2CSubAddr = pTxTbl->TXSLVADDR;

                        if(dst->TXType == HDMI_AD9389B) //means DVI+HDMI support
                        {
                            //translate HDMI_AD9389B in vbios to AD9389 in cbios
                            dst->TXType = AD9389B;                            
                        }
                        if((src->I2CPort != 0) && (dst->I2CPort != src->I2CPort))
                        {
                            cbDbgPrint(1, "Internal error: TX I2C PORT define mismatch in VCP info !\n");
                        }
                    }
                    else
                    {
                        TXstatus = FALSE; // No TX detected
                    }
                }
            }
        }
        break;
        
    case S3_HDMI+S3_DVI:  //AD9389 can support DVI+HDMI at the same Digital port,so we need add this case
    case S3_HDMI+S3_DVI2:
    case S3_HDMI2+S3_DVI2:
        // TX do not need to do sense job 
        if(src->TXType == IN_TMDS  ||
           src->TXType == INTERNAL_DP)
        {
            dst->TXType = src->TXType; // if use Internal or Non-sensible TX, no need to sense
        }
        else
        {
            PTXTABLEDATA pTxTbl = NULL;
            // get TX table offset
            if (TransDev & S3_DVI2 && (pcbe->pVCPInfo->TX_LCD_DVI2_TBL != 0))
            {
                pTxTbl = (PTXTABLEDATA)(pcbe->RomData + pcbe->pVCPInfo->TX_LCD_DVI2_TBL);
            }
            else if (TransDev & S3_DVI && (pcbe->pVCPInfo->TX_DVI_LCD2_TBL != 0))
            {
                pTxTbl = (PTXTABLEDATA)(pcbe->RomData + pcbe->pVCPInfo->TX_DVI_LCD2_TBL);
            }
            else
            {
                TXstatus = FALSE;
            }
            if(TXstatus == TRUE)
            {
                if (cbGetExistTXInfo(pcbe, dst, src, pTxTbl))
                {
                    if(dst->TXType == HDMI_AD9389B) //means DVI+HDMI support
                    {
                        //translate HDMI_AD9389B in vbios to AD9389 in cbios
                        dst->TXType = AD9389B;
                    }                    
                    if((src->I2CPort != 0) && (dst->I2CPort != src->I2CPort))
                    {
                        cbDbgPrint(1, "Internal error: TX I2C PORT define mismatch in VCP info !\n");
                    }
                }
                else
                {
                    TXstatus = FALSE; // No TX detected
                }
            }
        }
        break;
    case S3_DP:
    case S3_DP2:
    case S3_DP+S3_HDMI+S3_DVI:
        if(src->TXType == INTERNAL_DP  ||
           src->TXType == INTERNAL_DP2)
        {
            dst->TXType = src->TXType;
        }
        else
        {
            TXstatus = FALSE; // No TX detected
        }
        break;		
    // VCP set device to zero when  this Digital port not support device 
    
    case 0:
    default:
        TXstatus = FALSE; // No TX detected
        cbDbgPrint(1, "error device type supported by digital port!\n");
        return FALSE;
    }

    if(TXstatus == TRUE)
    {
        // ------------ DPA info --------------
        dst->DPASetting[0] = src->DPASetting[0];
        dst->DPASetting[1] = src->DPASetting[1];
        dst->DPASetting[2] = src->DPASetting[2];
        dst->DPASetting[3] = src->DPASetting[3];
        dst->DPASetting[4] = src->DPASetting[4];
        dst->DPASetting[5] = src->DPASetting[5];

        dst->device  = TransDev;

        //-------- for DDC port ---------
        if(src->DDCPort != 0)
        {
            dst->DDCPort = src->DDCPort;
        }
        else
        {
            // old VCP DDC Port = 0 case
            // we may use I2C port      
            dst->DDCPort = dst->I2CPort;
        }

        // now there maybe LCD DDC port equals to DVI DDC port case 
        // we will set LCD / LCD2 DDC port to zero when no SPWG flag enable in VBIOS
        if (dst->device & (S3_LCD + S3_LCD2) && (pcbe->pVCPInfo->version >= VCP1_2))
         {
             // spwg support, 1---Not support spwg
             // Considering old vbios's MISC2[12] always equals 0, So if old customer enable SPWG in the old way, CBIOS can not know
             // To cover this we use inversed logic here, then for old vbios, we assume always SPWG first
             if(pcbe->pVCPInfo->miscConfigure2 & SPWG_LCD_NOT_Support)
             {
                 //SPWG not enabled, set LCD/LCD2 DDC port to zero
                 dst->DDCPort = 0;
             }
         }

        // --------- DI port MISC info---------------
        dst->DIPORTMISC = src->DIPORTMISC;

        // for old vcp do not set hotplug bit
        // Report the default hotplug setting to driver, this was ported from driver's code
        if (pcbe->pVCPInfo->version < VCP1_6)
        {
            if(dst->device & (S3_HDMI+S3_DVI))
            {
                if(pcbe->PCIDeviceID == PCI_ID_VT3336 || pcbe->PCIDeviceID == PCI_ID_VT3364)
                {
                    //336,364 HDMI/DVI use INT1
                    dst->DIPORTMISC = USING_TMDS_HPD_INTERRUPT;
                }
                else if(pcbe->PCIDeviceID == PCI_ID_VT3324)
                {
                    //324 HDMI use INT1, DVI use INT0
                    //HDMI+DVI case assume same with HDMI
                    if(dst->device & S3_HDMI)
                    {
                        dst->DIPORTMISC = USING_TMDS_HPD_INTERRUPT;
                    }
                    else
                    {
                        dst->DIPORTMISC = USING_LVDS_HPD_INTERRUPT;
                    }
                }
                else
                {
                    //353 HDMI/DVI use INT0, set later chips as 353 too.
                    dst->DIPORTMISC = USING_LVDS_HPD_INTERRUPT;
                }
            }
        }
                        
        //-------- update to scratch pad --------
        if((pcbe->pVCPInfo->version >= VCP1_8) && (pcbe->pVCPInfo->miscConfigure3 & NEW_DIPOPRT_TX_SCRATCHPAD))
        {
            DI_TYPE DIType = (DI_TYPE)*((DI_TYPE *)dst - sizeof(DI_TYPE));
            if((DIType == DVP1) && (dst->device & (S3_LCD+S3_LCD2+S3_DVI+S3_DVI2+S3_HDMI+S3_HDMI2)))
            {
                pcbe->sPad_3.Tx = dst->TXType;
                cbWriteRegByte(pcbe, CR_3E, STRUCT_BYTE(pcbe->sPad_3, 0));
            }
            else if(dst->device & (S3_TV+S3_TV2))
            {
                pcbe->sPad_8.bTVAttached = 1;
                cbWriteRegBits(pcbe, CR_4E, BIT6, STRUCT_BYTE(pcbe->sPad_8, 0));
            }
        }
        else
        {        
            if(dst->device & (S3_LCD+S3_DVI2))
            {
                pcbe->sPad_3.Tx1 = dst->TXType;
                cbWriteRegBits(pcbe, CR_3E, BIT7+BIT6+BIT5+BIT4, STRUCT_BYTE(pcbe->sPad_3, 0));
            }
            else if(dst->device & (S3_DVI+S3_LCD2))
            {
                if(pcbe->sPad_3.Tx0 != TX_NONE)
                {
                    if(!(dst->TXType == HARDWIRED_LVDS ||
                         dst->TXType == IN_LVDS2 ||
                         dst->TXType == TTL_PANEL ||
                         dst->TXType == IN_TMDS))
                    {
                        pcbe->sPad_3.Tx0 = dst->TXType;
                        cbWriteRegBits(pcbe, CR_3E, BIT3+BIT2+BIT1+BIT0, STRUCT_BYTE(pcbe->sPad_3, 0));
                    }
                }
                else
                {
                    pcbe->sPad_3.Tx0 = dst->TXType;
                    cbWriteRegBits(pcbe, CR_3E, BIT3+BIT2+BIT1+BIT0, STRUCT_BYTE(pcbe->sPad_3, 0));
                }
            }
            else if(dst->device & (S3_TV+S3_TV2))
            {
                pcbe->sPad_8.bTVAttached = 1;
                cbWriteRegBits(pcbe, CR_4E, BIT6, STRUCT_BYTE(pcbe->sPad_8, 0));
            }
        }

        //--------------------------------------------------
        //  HDMI Duplicated mode PLL MRN update
        //--------------------------------------------------
        // AD9889 will double pixels automatically with duplicated modes.
        // so we have to divide our Pixel clock by 2.
        if (AD9389B == dst->TXType)
        {
            DWORD i;
            for (i=0; i<CEA_DUPLICATED_MODE_NUM; i++)
            {
                DWORD modeNo = CEA_DUPLICATED_MODE[i] - 1;
                // PLL MRN in CEA timing table is 353 format, so use_409_formula is false
                CEA861_FormatTimingTbl[modeNo].PLL_MRN = cbGetMRN_UMA(FALSE, CEA861_FormatTimingTbl[modeNo].PLL_SEED/2);
            }
        }

    }

    return TXstatus;
}


//-----------------------------------------------------------------
// cbGetExistTXInfo
//      This function will check if a sensiable TX is plugged in
//      Here we only check sensiable TX, Non sensiable TX should be 
//      processed before calling this function.
//   IN
//      pVCP_DIPort:    DIPort info in VCP
//      pTxTbl:         LCD_DVI_TX_TYPE table from VCP
//   OUT
//      pCBE_DIPort:    DIPort info in pcbe need to fill
//-----------------------------------------------------------------
BOOL cbGetExistTXInfo(PCBIOS_EXTENSION pcbe,
    OUT PDIPortInfo pCBE_DIPort,
    IN PDIPortInfo pVCP_DIPort,
    IN PTXTABLEDATA pTxTbl)
{
    I2C_CONTROL_UMA i2c;
    BYTE CurrentSSCStatus = 0;
    LCD_DVI_TX_TYPE TXType = pVCP_DIPort->TXType;
    i2c.Flags = 0;
    
    if (!pTxTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    /*******************************************************************
    //if TXType == TX_NONE||IN_TMDS||HARDWIRED_LVDS||IN_LVDS1||IN_LVDS2
    //search in pTxTbl will also return NULL so do not special check it
    *******************************************************************/
    
    // if we have known the TX type we want to sense, then just sense it directly,
    // do not need to scan and sense all the TX in table pTxTbl
    // it will save us many time, because I2C operation is very slow
    CurrentSSCStatus = cbReadRegByte(pcbe, SR_1E) & BIT3;
    for(; pTxTbl->TXDI != 0xFF; pTxTbl++)
    {
        if((pTxTbl->TXI2CPORT == 0x2c) && (CurrentSSCStatus != 0))
        {
            // if Current Spread Spectrum Control enabled,
            // then skip use of GPIO 2c port to sensor
            // because GPIO 2c port will be used as SSC I/O port
            cbDbgPrint(1, "Function: cbCheckTXExist, Can not sensor TX with GPIO 2C Port when it is used as SSC I/O. ! \n");
            continue;
        }
        
        if (TXType == TX_AUTO_DETECT || TXType == pTxTbl->TXDI || TXType == CH7305_VT1636)
        {
            // if DI port I2C config available in VCP, use it first
            // for customer can use BIOSWE to change it
            i2c.I2cPort   = (pVCP_DIPort->I2CPort != 0) ? pVCP_DIPort->I2CPort : pTxTbl->TXI2CPORT;
            i2c.SlaveAddr = pTxTbl->TXSLVADDR;
            i2c.RegIndex  = pTxTbl->TXDIDOFST;
            I2C_Read_Byte_INV(pcbe, &i2c);
            if(TXType == AD9389B) //special case used for DVI+HDMI
            {
                if(i2c.IndexData == 0x7E || i2c.IndexData == 0xA0)
                {
                    // sensed right TX
                    pCBE_DIPort->TXType     = pTxTbl->TXDI;
                    pCBE_DIPort->I2CPort    = i2c.I2cPort;
                    pCBE_DIPort->I2CSubAddr = i2c.SlaveAddr;
                    return TRUE;
                }
            }            
            else
            {
                if(i2c.IndexData == pTxTbl->TXDEVID)
                {
                    // sensed right TX
                    pCBE_DIPort->TXType     = pTxTbl->TXDI;
                    pCBE_DIPort->I2CPort    = i2c.I2cPort;
                    pCBE_DIPort->I2CSubAddr = i2c.SlaveAddr;
                    return TRUE;
                }
            }
        }
    } // for pTxTbl

    return FALSE;
}

//-----------------------------------------------------------------
// cbCheckTXExist
//      This function will check if a sensiable TX is plugged in
//      Here we only check sensiable TX, Non sensiable TX should be 
//      processed before calling this function.
//   IN     :
//      TXType: TX type need to sense
//      pTxTbl: HDMI_TX_TYPE table from VCP
//   Return : 
//      BOOLEAN
//-----------------------------------------------------------------
BOOL cbCheckHDMITXExist(
        PCBIOS_EXTENSION pcbe, 
        IN HDMI_TX_TYPE TXType, 
        INOUT PTXTABLEDATA *pTxTbl)
{
    BOOL status = FALSE;
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;
    
    if(*pTxTbl== NULL         ||
        TXType == HDMI_TX_NONE)
    {
        cbDbgPrint(1, "Function: cbCheckTXExistError, TX table is NULL or TX Type is NON-Sensible! \n");
        return FALSE;
    }
    // if we have known the TX type we want to sense, then just sense it directly,
    // do not need to scan and sense all the TX in table pTxTbl
    // it will save us many time, because I2C operation is very slow
    if(TXType == HDMI_AD9389B)
    {
        if((*pTxTbl)->TXDI == HDMI_AD9389B)
        {
            i2c.I2cPort   = (*pTxTbl)->TXI2CPORT;
            i2c.SlaveAddr = (*pTxTbl)->TXSLVADDR;
            i2c.RegIndex  = (*pTxTbl)->TXDIDOFST;
            if(I2C_Read_Byte_INV(pcbe, &i2c)) //We do not compare Device ID at TX
                status = TRUE;
        }
    }
    return status;
}

//-----------------------------------------------------------------
// cbGetTXSubAddr
//      This function returns subAddress of the given TX type 
//   IN :
//      TXType : 
//   OUT : 
//      subAddr
//      CBIOS_STATUS 
//-----------------------------------------------------------------
CBIOS_STATUS cbGetTXSubAddr(
        PCBIOS_EXTENSION pcbe, 
        IN LCD_DVI_TX_TYPE TXType, 
        OUT PBYTE subAddr)
{
    int i;
    //---------------------------------------TXType, SubAddr
    static TxTypeToSubAddr subAddrTbl[18] = {{TX_NONE, 0x00}, // No transmitter and without LCD function
                                             {VT3191,  0x70},
                                             {TTL_PANEL,  0x00}, 
                                             {VT1636,  0x80},
                                             {SII170B, 0x70}, 
                                             {ITE6610, 0x98}, // ITE6610 (DVI+HDMI)
                                             {IN_TMDS, 0x00}, // Internal TMDS
                                             {HARDWIRED_LVDS,0x00}, // TTL_LCD (or no transmitter but with LCD function)
                                             {VT3192,  0x10},
                                             {SIL9022,  0x72},
                                             {SII164,  0x70},
                                             {SII168,  0x70},
                                             {IN_LVDS1,  0x10}, // or Sil170B  ??
                                             {IN_LVDS2,  0x00},
                                             {AD9389B,  0x72},
                                             {CH7301,   0xEA},
											 {TFP410,  0x70},
											 {CH7305_VT1636,  0xEA}};
    if (!subAddr)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }
  
    *subAddr = 0x00;
  
    for (i = 0; i < sizeof (subAddrTbl) / sizeof (TxTypeToSubAddr); i++)
    {
        if (subAddrTbl[i].TXType == TXType)
        {
            break;
        }
    }
    
    // do not find the TX type
    if (i >= sizeof (subAddrTbl) / sizeof (TxTypeToSubAddr))
    {
        cbDbgPrint(1, "Error TX Type!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    *subAddr = subAddrTbl[i].subAddr;
    return CBIOS_OK;
}

//-----------------------------------------------------------------------
// cbGetDeviceDDCPort
//      This function gets device related DDC port info
//   IN :
//      device : 
//   OUT : 
//      pi2c : i2c info returned
//      BOOL 
//-----------------------------------------------------------------------
BOOL cbGetDeviceDDCPort(
        PCBIOS_EXTENSION pcbe, 
        OUT PI2C_CONTROL_UMA pi2c, 
        IN DWORD device)
{
    PDigitalPortInfo pDIportinfo = NULL;
    BOOL status = TRUE;
    
    // Now only support LCD & DVI
    if (!pi2c)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
        
    // only CRT / LCD / DVI / DVI2 / HDMI / HDMI2 / CRT2(CH7301) has DDC port
    if(device & (S3_CRT + S3_LCD + S3_LCD2 + S3_DVI + S3_DVI2 + S3_HDMI + S3_HDMI2 + S3_CRT2))
    {
        if(device == S3_CRT2)
        {
            ULONG encodertype = 0;
            
            // get CRT2 associated TxType
            if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
            {
                cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
                return FALSE;
            }

            if(encodertype != CH7301)
            {
                cbDbgPrint(1, "CRT2 has no related DDC port!\n");
                status = FALSE;
                
                return status;
            }
        }
        
        if (cbGetDIPortInfo(pcbe, &pDIportinfo, device) == TRUE)
        {
            pi2c->I2cPort = pDIportinfo->PortInfo.DDCPort;
        }
        else
        {
            cbDbgPrint(1, "Can not find device related DDC port!\n");
            status = FALSE;
        }
    }
    else //TV, HDTV
    {
        cbDbgPrint(1, "TV HDTV has no related DDC port!\n");
        status = FALSE;
    }
    
    return status;
}

//-----------------------------------------------------------------------
// cbGetDIPortInfo
//      This function returns pointers to DIport info in pcbe which is 
//  assigned for the given device (CRT has no digital port), So assume 
//  CRT also connect to a pseudo digital port without TX on it.
//      For HDTV device we uses TV type instead since they share the same 
//  digital port.
//   IN :
//      device : 
//   OUT : 
//      pDIportinfo : DI port info special to the given device
//      BOOL 
//-----------------------------------------------------------------------
BOOL cbGetDIPortInfo(
    PCBIOS_EXTENSION pcbe, 
    OUT PDigitalPortInfo *ppDIportinfo,
    IN DWORD device)
{
    PDigitalPortInfo PDIPort = pcbe->DIPort;
    BOOL status = TRUE;
    int i;

    if(ppDIportinfo == NULL)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // HDTV use TV port info
    if (device == S3_HDTV)
    {
        device = S3_TV; 
    }
    
    // find which digital port of the 6 support this device
    for (i = 0; i < DigitalPortNUM; i++)
    {
        if (PDIPort[i].PortInfo.device != 0 && 
            (device & PDIPort[i].PortInfo.device))
        {
           *ppDIportinfo = &PDIPort[i];
           break;
        }
    }

    if (i >= DigitalPortNUM)
    {
        cbDbgPrint(1, "No DI port assigned to this device!\n");
        status = FALSE;
    }
    else
    {
        //if VT1625 support CRT2 and TV at a same vbios, TX type in Diport is VT1625
        //here need to change the TX type
        if( (device == S3_CRT2)
            && ((PDIPort[i].PortInfo.device==S3_CRT2+S3_TV)||(PDIPort[i].PortInfo.device==S3_CRT2))
            && ((PDIPort[i].PortInfo.TXType==VT1625_6)||(PDIPort[i].PortInfo.TXType==VT1625A_6A))
          )
        {
            pcbe->TempDiPort=PDIPort[i];
            *ppDIportinfo=&(pcbe->TempDiPort);
            pcbe->TempDiPort.PortInfo.TXType=CRT2Encoder;
        }
    }

    return status;
}

//-----------------------------------------------------------------------
// cbGetDII2Csetting
//      This function returns I2C info of the digital port(serial port/
//  associated TX subaddr), since digital port 
//  is fixed to device, so pass device bit as parameter 
//   IN :
//      device : 
//   OUT : 
//      pi2c : I2C info
//      CBIOS_STATUS 
//-----------------------------------------------------------------------
BOOL cbGetDII2Csetting(
        PCBIOS_EXTENSION pcbe, 
        OUT PI2C_CONTROL_UMA pi2c, 
        IN DWORD device)
{
    PDigitalPortInfo PDIPort = NULL;
    
    if (!pi2c)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    //defualt set I2C port to 0x00
    pi2c->I2cPort = 0x00;
    
    // find which digital port of the 6 supported DI port for this device
    // assume CRT also connect to a pseudo digital port without TX on it
    // its I2C port is SR26 which is used for DDC
    if (cbGetDIPortInfo(pcbe, &PDIPort, device) == TRUE)
    {
        // serial port associate with DI 
        pi2c->I2cPort = PDIPort->PortInfo.I2CPort; 
        // subAddr of the TX / TV encoder on DI
        // if no DI just 0x00
        pi2c->SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
    }
    else
    {
        cbDbgPrint(1, "No Digital port assigned to current device\n");
        return FALSE;
    }

    return TRUE;
}

//-----------------------------------------------------------------------
// cbGetDITXtype
//      This function returns device associated TX info from  digital port
//  info block, since digital port is fixed to device, so pass device bit 
//  as parameter 
//   IN :
//      device : S3_LCD | S3_LCD2 | S3_DVI | S3_DVI2 | S3_HDMI | S3_HDMI2 | S3_DP | S3_DP2
//   OUT : 
//      ptxtype : tx type
//      function status 
//-----------------------------------------------------------------------
BOOL cbGetDITXtype(
        PCBIOS_EXTENSION pcbe, 
        OUT PBYTE ptxtype,
        IN DWORD device)
{
    BOOL status = FALSE;
    PDigitalPortInfo PDIPort = NULL;
    
    if (!ptxtype)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if ( ((device & (S3_LCD | S3_LCD2 | S3_DVI | S3_DVI2 | S3_HDMI | S3_HDMI2 | S3_DP | S3_DP2)) == 0) ||
         MORE_THAN_1BIT(device))
    {
        cbDbgPrint(0, "Invalid device or More than one device to enable!\n");
        *ptxtype = 0;
        ASSERT(FALSE);
        return FALSE;
    }
    
    // find which digital port of the 6 supported DI port for this device
    // assume CRT also connect to a pseudo digital port without TX on it
    status = cbGetDIPortInfo(pcbe, &PDIPort, device);
    if (status == TRUE)
    {
        // return TX type associated with device 
        *ptxtype = PDIPort->PortInfo.TXType; 
    }
    
    return status;
}

//-----------------------------------------------------------------------
// cbGetDIEncodertype
//      This function returns device associated TV encoder type info 
//  from  digital port info block, since digital port is fixed to device, 
//  so pass device bit as parameter 
//   IN :
//      device : S3_TV | S3_HDTV | S3_TV2 | S3_CRT2
//   OUT : 
//      pEncodertype : tx type
//      function status 
//-----------------------------------------------------------------------
BOOL cbGetDIEncodertype(
        PCBIOS_EXTENSION pcbe, 
        OUT PULONG pEncodertype,
        IN DWORD device)
{
    BOOL status = FALSE;
    PDigitalPortInfo PDIPort = NULL; //Initialize to NULL to prevent unexpected read/write errors
    
    if (!pEncodertype)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (((device & (S3_TV | S3_HDTV | S3_TV2 | S3_CRT2)) == 0) ||
         MORE_THAN_1BIT(device))
    {
        cbDbgPrint(0, "Invalid device or More than one device to enable! %x\n", device);
        *pEncodertype = 0;
        ASSERT(FALSE);
        return FALSE;
    }
    
    //Status ok and we actually get a DI port info
    status = cbGetDIPortInfo(pcbe, &PDIPort, device);
    if (status == TRUE) 
    {
        // return TX type associated with device 
        *pEncodertype = PDIPort->PortInfo.TXType; 
    }
    
    return status;
}

/**********************************************************************
*  CbPosRegInit_UMA 
*     This function initialize all register when post. Including
*      1. GFX register init
*      2. TX register init
*  IN :
*      NONE
*  OUT :
*      CBIOS_STATUS
***********************************************************************/
CBIOS_STATUS CbPostRegInit_UMA(PCBIOS_EXTENSION pcbe, IN BOOL bNeedLoadDefECK)
{
    WORD OffsetInitTbl;
    CBIOS_STATUS status = CBIOS_OK;
    
    /*---------------------------------------
        * 1. Initialize GFX registers
        *--------------------------------------- */
    if ((NULL != pcbe->pVCPInfo) && (0 != pcbe->pVCPInfo->xRInitTbl)) {
        OffsetInitTbl = pcbe->pVCPInfo->xRInitTbl;
        cbLoadVBIOSInitTable_UMA(pcbe,((PVBINITTBL)(pcbe->RomData + OffsetInitTbl)));

        /* initial xRBitsInitTbl from VCP1.1 */
        if(pcbe->pVCPInfo->version >= VCP1_1) {   
            OffsetInitTbl = pcbe->pVCPInfo->xRBitsInitTbl;
            cbLoadVBIOSInitBitTable_UMA(pcbe, ((PVBBitINITTBL)(pcbe->RomData + OffsetInitTbl)));
        }
        if (pcbe->ChipCaps.ALWAYS_ON_CR_CLOCK_AFTER_S3) {
            cbWriteRegBits(pcbe, SR_3F, 0xC0, 0x80); /* CR clock always on,only for 336&364 */
        }
        cbWriteRegByte(pcbe, CR_42, 0x00); /* IGA1 power now active in vblank */
        cbWriteRegBits(pcbe, CR_9E, BIT7, 0x80); /* IGA2 power now active while display FIFO almost full */
        SetIGA1screenOnOff(pcbe, OFF);/* IGA1 fetch data off */
        SetIGA2screenOnOff(pcbe, OFF);/* IGA2 fetch data off */
    } else {
        cbInitExtRegs(pcbe);
    }

    /*------------------------------------------
        * 2. special  for some extended reg bits
        *------------------------------------------ */
    cbInitExtRegsBits(pcbe);

    /*------------------------------------------
        * 3. load LCD related ext Reg table
        *------------------------------------------ */
    if(pcbe->SupportDevices & (S3_LCD+S3_LCD2)) {
        cbLoadInitLCDTable(pcbe);
    }

    /*-----------------------------------------
        * 4. set Engine clock, if MAMM secondary, we will get ECK by MCK
        * otherwise, we just restore ECK value before S3
        *----------------------------------------- */
    if (bNeedLoadDefECK) {
        /* POST or VISTA boot up go to sleep case */
        cbLoadDefaultEClk(pcbe);
        /* Get ECK PLL register, and save to pcbe */
        pcbe->ECK_Freq = ((DWORD)cbReadRegByte(pcbe, SR_47)<<16) | ((DWORD)cbReadRegByte(pcbe, SR_48)<<8)|
                         (DWORD)cbReadRegByte(pcbe, SR_49);
        cbLoadDefaultVDClk(pcbe);
        /* Get VDCK PLL register, and save to pcbe */
        pcbe->VDCK_Freq = ((DWORD)cbReadRegByte(pcbe, SR_C0)<<16) | ((DWORD)cbReadRegByte(pcbe, SR_C1)<<8)|
                         (DWORD)cbReadRegByte(pcbe, SR_C2);
    } else {
        /* S3 case */
        /* restore ECK value */
        cbSetECLK_UMA(pcbe, pcbe->ECK_Freq);
        /* restore VDCK value */
        cbSetVDCLK_UMA(pcbe, pcbe->VDCK_Freq);
        /* load a default VCK & LCK */
        if (pcbe->ChipCaps.FOR_409_S3_RESUME_PLL) {
            cbSetPixelCLK_UMA(pcbe, DCLK_25_2M_409, IGA1);
            cbSetPixelCLK_UMA(pcbe, DCLK_25_2M_409, IGA2);
        }
    }
    
    return status;
}
VOID cbLoadRegTbl(PCBIOS_EXTENSION pcbe,
        INOUT PVBINITTBL *ppRegTable)
{
    while((*ppRegTable)->group != 0xFF)
    {
        switch ((*ppRegTable)->group)
        {
        case ZCR:
            cbWriteRegByte(pcbe, (*ppRegTable)->index, (UCHAR)((*ppRegTable)->data));
            break;

        case ZSR:
            cbWriteRegByte(pcbe, (0x100 | (*ppRegTable)->index), (UCHAR)((*ppRegTable)->data));
            break;

        default:
            cbDbgPrint(0, "Not implement init group\n");
            break;
        }
        (*ppRegTable)++;
    }
}
//-----------------------------------------------------------------
//  cbLoadVBIOSInitTable_UMA
//      This function inits all VBINITTBL type register table
//  IN :
//      pRegTable : regiter described to init
//  OUT :
//      NONE
//-----------------------------------------------------------------
VOID cbLoadVBIOSInitTable_UMA(
        PCBIOS_EXTENSION pcbe,
        IN PVBINITTBL pRegTable)
{
    cbDbgPrint(0, "cbLoadVBIOSInitTable_UMA: Loadtable called\n");

    cbLoadRegTbl(pcbe, &pRegTable);
}

//*****************************************************************************
//
//  cbLoadVBIOSInitBitTable_UMA
//
//  called by CBiosMiniPost_UMA to initial xRBitsInitTbl from VCP1.1
//
//  Parameters:     PCBIOS_EXTENSION pcbe
//                  xRBitsInitTbl address
//
//  Return Value:   none
//
//*****************************************************************************
VOID cbLoadVBIOSInitBitTable_UMA(PCBIOS_EXTENSION pcbe,
                     IN PVBBitINITTBL pBitRegTable)
{
    cbDbgPrint(0, "cbLoadVBIOSInitBitTable_UMA: Load init Bit table called\n");

    while(pBitRegTable->group != 0xFF)
    {
        cbWriteRegBits(pcbe, (pBitRegTable->group<<8) + pBitRegTable->index, pBitRegTable->mask, pBitRegTable->data);
        pBitRegTable++;
    }
}


/*-----------------------------------------------------------------
*  cbLoadDefaultEClk
*      This function will set the default engine clock. Default engine
*  clock is provided in VCP.
*  IN :
*      NONE
*  OUT :
*      NONE
*---------------------------------------------------------------- */
#define PLL_166MHz  0x720403
#define PLL_185MHz  0x7F0403
#define PLL_200MHz  0x8A8483
#define PLL_250MHz  0xAD0403
#define PLL_409_250MHz  0xA18483
#define PLL_275MHz  0xBF0403

VOID cbLoadDefaultEClk(PCBIOS_EXTENSION pcbe)
{
    BYTE vSR12;
    ULONG pMClk = 0;
    ULONG pEClk = 0;
    CBIOS_STATUS GETMCLK_OK = CBIOS_OK;
    CBIOS_STATUS GETECLK_OK = CBIOS_OK;

    /* defualt ECLK for 336 & 364: DDR400 (250MHz) */
    DWORD vPLL = PLL_250MHz;

    if (pcbe->ChipCaps.PLL_USE_409_FORMULA) {
        vPLL = PLL_409_250MHz;
    }
    
    if (NULL != pcbe->pVCPInfo) {
        if (pcbe->pVCPInfo->version >= VCP1_1) {
            WORD ECLKTbl = pcbe->pVCPInfo->ECLKTbl;
            vPLL =  *(pcbe->RomData + ECLKTbl); /* SR47, ECLK[23:16] */
            vPLL <<= 8;  /* SR48, ECLK[15:8] */
            vPLL |= *(pcbe->RomData + ECLKTbl + 1);
            vPLL <<= 8;  /* SR49, ECLK[7:0] */
            vPLL |= *(pcbe->RomData + ECLKTbl + 2); 
        }
    }

    /* for customer support modify ECLK
         * begin from 353 */
    if (pcbe->ChipCaps.GET_ECK_DEPENDON_SYSINFO) {
        /* for 353 and later chips */
        if (pcbe->SysBiosInfoValid) {
            PSYSBIOSInfo pSysInfo = &pcbe->SysBiosInfo;
            DWORD ECKID = pSysInfo->EngineClockModify;
            if(ECKID & BIT31) {
                ECKID &= ~BIT31;   
                if (ECKID & BIT30) {
                    /* 409 and later chips ECK setting, real frequency */
                    ECKID &= ~BIT30;
                    ECKID >>= 4;                  /* BIT15~BIT4 identifies the real frequency value */
                    ECKID *= 1000000;             /* ECK value is denoted in unit of Mega Hz */
                    vPLL = cbGetMRN_UMA(TRUE, ECKID);
                } else {
                    /* 353 will use fixed bit to denote clock value */
                    switch(ECKID) {
                    case BIT0:
                        /* ECLK = 166 */
                        vPLL = PLL_166MHz;
                        break;
                    case BIT1:
                        /* ECLK = 200 */
                        vPLL = PLL_200MHz;
                        break;
                    case BIT2:
                        /* ECLK = 250 */
                        vPLL = PLL_250MHz;
                        break;
                    case BIT3:
                        /* ECLK = 275 */
                        vPLL = PLL_275MHz;
                        break;
                    default:
                        /* No change with undefined bit */
                        break;
                    }
                }
            }
        }
    }

    if (pcbe->ChipCaps.FOR_364_ECLK) {
        vSR12 = cbReadRegByte(pcbe, SR_12);
        if ((BIT7 & vSR12) && (0xAD0403 == vPLL)) {
            /* SR12 [7] = 1, this chip is 364 A6
                      * PLL = 250MHz, default ECLK
                      * adjust defualt ECLK to 275MHz for pass premium logo */
            vPLL = 0xBF0403;
        }
    }
    cbSetECLK_UMA(pcbe, vPLL);
    if (pcbe->ChipCaps.for_track_FIFO_Number_control) {
    	/* memory clock */
        GETMCLK_OK = cbGetMCLK_UMA(pcbe, &pMClk);
        pMClk = pMClk/2; /* real clk frequency */
        /* engine clock */
        GETECLK_OK = cbGetECLK_UMA(pcbe, &pEClk);
	    if ((GETMCLK_OK == CBIOS_OK)&&(GETECLK_OK == CBIOS_OK)) {
	        if (pMClk > pEClk) {
	            cbWriteRegByte(pcbe, SR_21, 0x18);
	        } else {
	            cbWriteRegByte(pcbe, SR_21, 0x00);
	        }
        }
     }
}

VOID cbLoadDefaultVDClk(PCBIOS_EXTENSION pcbe)
{
    // defualt VDCLK
    DWORD vPLL = PLL_250MHz;

    if(!pcbe->ChipCaps.VDCLK_Support)
    {
        return;
    }

    if (pcbe->ChipCaps.PLL_USE_409_FORMULA)
    {
        vPLL = PLL_409_250MHz;
    }
    
    if (NULL != pcbe->pVCPInfo)
    {
        if (pcbe->pVCPInfo->version >= VCP1_7)
        {
            WORD VDCLKTbl = pcbe->pVCPInfo->VDCLKTbl;
            vPLL =  *(pcbe->RomData + VDCLKTbl); // SRC0, VDCLK[23:16]
            vPLL <<= 8;  // SRC1, VDCLK[15:8]
            vPLL |= *(pcbe->RomData + VDCLKTbl + 1);
            vPLL <<= 8;  // SRC2, VDCLK[7:0]
            vPLL |= *(pcbe->RomData + VDCLKTbl + 2); 
        }
    }
    
    cbSetVDCLK_UMA(pcbe, vPLL);

}

//---------------------------------------------------------------
// cbInitPanelHWPowerSquence
//     This function will init LCD/LCD2 HW power squence timer registers
//     This function is called during POST / MINIPOST.
//  IN :
//      device: device bit, Only LCD or LCD2 are allowed
//  OUT :
//      NONE    
//---------------------------------------------------------------
VOID cbInitPanelHWPowerSquence(PCBIOS_EXTENSION pcbe, IN DWORD device)
{
    WORD offsetLCDHeader; 

    if ((device & (S3_LCD + S3_LCD2)) == 0)
    {
        cbDbgPrint(0, "Invalid device, should be LCD or LCD2 !\n");
        ASSERT(FALSE);
        return;
    }

    // get Device associate TX type
    if (pcbe->SupportDevices & device)
    {
        BYTE TXType ;

        if(cbGetDITXtype(pcbe, &TXType, device) == FALSE)
        {
            // get TX type fail, add an assert for convenient debug
            ASSERT(0);
            return;
        }

        if(device == S3_LCD2 && TXType != IN_LVDS2)
        {
            // feature for VT3353 and VT3324 
            // If LCD2 support: then LCD1 must use Power sequence1, LCD2 use external(VT1636) or power sequence2
            // If LCD2 do not use IN_LVDS2 TX, so there will be no need to init HW power sequence2
            return;
        }

        //  Power sequence Timer Selection 0: first 1: second
        switch (TXType)
        {
        case IN_LVDS1:
            // IN_LVDS1 Power sequence Timer Selection
            cbWriteRegBits(pcbe, CR_D4, BIT0, 0);
            break;

        case IN_LVDS2:
            // IN_LVDS2 Power sequence Timer Selection
            cbWriteRegBits(pcbe, CR_D4, BIT0, BIT0);
            break;
        default:
            break;
        } // switch TX type
    }

    //initial software powersequence from FPinfoHeader
    if ((NULL != pcbe->pVCPInfo) && (0 != pcbe->pVCPInfo->LCDInfoHeader))
    {

        BYTE panelID = 0;
        if(device == S3_LCD)
        {
            panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
        }
        else if(device == S3_LCD2)
        {
            panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
        }
        else
        {
            // Incorrect device bit, add an assert for convenient debug
            ASSERT(0);
        }

        offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
        if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
        {        
            PFPHeaderData pLCDHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
            pLCDHeader = &pLCDHeader[panelID];
            cbWriteRegByte(pcbe, CR_8B, (BYTE) ((WORD)((pLCDHeader->TD0 * 1000) / TIMEUNIT)) & 0xFF);  //CR8B
            cbWriteRegByte(pcbe, CR_8C, (BYTE) ((WORD)((pLCDHeader->TD1 * 1000) / TIMEUNIT)) & 0xFF);  //CR8C
            cbWriteRegByte(pcbe, CR_8D, (BYTE) ((WORD)((pLCDHeader->TD2 * 1000) / TIMEUNIT)) & 0xFF);  //CR8D
            cbWriteRegByte(pcbe, CR_8E, (BYTE) ((WORD)((pLCDHeader->TD3 * 1000) / TIMEUNIT)) & 0xFF);  //CR8E
            cbWriteRegByte(pcbe, CR_8F, 
                          (BYTE) ((((WORD)((pLCDHeader->TD0 * 1000) / TIMEUNIT)) & 0xF00) >>8 | (((WORD)((pLCDHeader->TD1 * 1000) / TIMEUNIT)) & 0xF00) >>4));
            cbWriteRegByte(pcbe, CR_90, 
                          (BYTE) ((((WORD)((pLCDHeader->TD2 * 1000) / TIMEUNIT)) & 0xF00) >>8 | (((WORD)((pLCDHeader->TD3 * 1000) / TIMEUNIT)) & 0xF00) >>4));
        }
        else //LCD1+2
        {
            PFPHeaderData12 pLCDHeader = (PFPHeaderData12)(pcbe->RomData + offsetLCDHeader);
            pLCDHeader += panelID;
            cbWriteRegByte(pcbe, CR_8B, (BYTE) ((WORD)((pLCDHeader->TD0 * 1000) / TIMEUNIT)) & 0xFF);  //CR8B
            cbWriteRegByte(pcbe, CR_8C, (BYTE) ((WORD)((pLCDHeader->TD1 * 1000) / TIMEUNIT)) & 0xFF);  //CR8C
            cbWriteRegByte(pcbe, CR_8D, (BYTE) ((WORD)((pLCDHeader->TD2 * 1000) / TIMEUNIT)) & 0xFF);  //CR8D
            cbWriteRegByte(pcbe, CR_8E, (BYTE) ((WORD)((pLCDHeader->TD3 * 1000) / TIMEUNIT)) & 0xFF);  //CR8E
            cbWriteRegByte(pcbe, CR_8F, 
                (BYTE) ((((WORD)((pLCDHeader->TD0 * 1000) / TIMEUNIT)) & 0xF00) >>8 | (((WORD)((pLCDHeader->TD1 * 1000) / TIMEUNIT)) & 0xF00) >>4));
            cbWriteRegByte(pcbe, CR_90, 
                (BYTE) ((((WORD)((pLCDHeader->TD2 * 1000) / TIMEUNIT)) & 0xF00) >>8 | (((WORD)((pLCDHeader->TD3 * 1000) / TIMEUNIT)) & 0xF00) >>4));
        }
    }
    else
    {
        // using hard code power sequence value
        cbWriteRegByte(pcbe, CR_8B, 0x5D);
        cbWriteRegByte(pcbe, CR_8C, 0x2B);
        cbWriteRegByte(pcbe, CR_8D, 0x6F);
        cbWriteRegByte(pcbe, CR_8E, 0x2B);
        cbWriteRegByte(pcbe, CR_8F, 0x01);
        cbWriteRegByte(pcbe, CR_90, 0x01);
    }
}

//---------------------------------------------------------------
// cbLoadInitLCDTable
//     This function inits LCD related registers, according to the LCD 
//  property. This function is called during POST / MINIPOST.
//    LCD related register init including
//       1. LCD Scaling Paraneter in table FPconfigTbl
//       2. IGA2 Queue Depth & Read Threshold
//       3. Hardware power sequence timing setting
//       4. Scaling factor 
//       5. DI port width(12 /24 bit switch)
//  IN :
//      NONE
//  OUT :
//      NONE    
//---------------------------------------------------------------
VOID cbLoadInitLCDTable(PCBIOS_EXTENSION pcbe)
{
        
    // hard code FPconfigtbl
    cbWriteRegByte(pcbe, CR_7A, 0x01);    // LCD Scaling Parameter 1
    cbWriteRegByte(pcbe, CR_7B, 0x02);    // LCD Scaling Parameter 2
    cbWriteRegByte(pcbe, CR_7C, 0x03);    // LCD Scaling Parameter 3
    cbWriteRegByte(pcbe, CR_7D, 0x04);    // LCD Scaling Parameter 4
    cbWriteRegByte(pcbe, CR_7E, 0x07);    // LCD Scaling Parameter 5
    cbWriteRegByte(pcbe, CR_7F, 0x0A);    // LCD Scaling Parameter 6
    cbWriteRegByte(pcbe, CR_80, 0x0D);    // LCD Scaling Parameter 7
    cbWriteRegByte(pcbe, CR_81, 0x13);    // LCD Scaling Parameter 8
    cbWriteRegByte(pcbe, CR_82, 0x16);    // LCD Scaling Parameter 9
    cbWriteRegByte(pcbe, CR_83, 0x19);    // LCD Scaling Parameter 10
    cbWriteRegByte(pcbe, CR_84, 0x1C);    // LCD Scaling Parameter 11
    cbWriteRegByte(pcbe, CR_85, 0x1D);    // LCD Scaling Parameter 12
    cbWriteRegByte(pcbe, CR_86, 0x1E);    // LCD Scaling Parameter 13
    cbWriteRegByte(pcbe, CR_87, 0x1F);    // LCD Scaling Parameter 14
      
    // for BIOSEDITOR only
    cbWriteRegByte(pcbe, CR_89, 0x00);   // LCD Timing Control 0
    cbWriteRegByte(pcbe, CR_8A, 0x01);   // LCD Timing Control 1
    cbWriteRegByte(pcbe, CR_68, 0x67);   // 2nd Queue Depth & Read Threshold
    cbWriteRegByte(pcbe, CR_69, 0x00);   // 2nd Display Interrupt Enable & Status
    cbWriteRegByte(pcbe, CR_92, 0x07);   // 2nd Queue Depth & Read Threshold
    cbWriteRegByte(pcbe, CR_9F, 0x00);   // H_SCALE_FACTOR, [1:0]:H_SCALE_FACTOR[1:0]
    cbWriteRegByte(pcbe, CR_A2, 0x40);   // LCD Scaling Factor Selection:1=linear
     
    //initial FPconfigTbl0000 & LCD_CONFIG from VCP1.1
    if (NULL != pcbe->pVCPInfo)
    {
        if (pcbe->pVCPInfo->version >=VCP1_1 && pcbe->pVCPInfo->FPconfigTbl != 0)
        {
            WORD    OffsetInitTbl;
            PVBINITTBL pRegTable;
            OffsetInitTbl = pcbe->pVCPInfo->FPconfigTbl;
            pRegTable = (PVBINITTBL)(pcbe->RomData + OffsetInitTbl);
            cbLoadVBIOSInitTable_UMA(pcbe, pRegTable);
        }
    }
    if (pcbe->SupportDevices & S3_LCD2)
    {
        // If LCD2 support, then we must init both LCD and LCD2 HW power squence
        cbInitPanelHWPowerSquence(pcbe, S3_LCD);
        cbInitPanelHWPowerSquence(pcbe, S3_LCD2);
    }
    else
    {
        cbInitPanelHWPowerSquence(pcbe, S3_LCD);
    }

    // For 336A1 has software strapping for 12/24 bits port configration
    cbWriteRegBits(pcbe, CR_97, BIT7, 0); // default 2 12-bit DVI interfaces
    if (NULL != pcbe->pVCPInfo)
    {
        if (S3_LCD == pcbe->pVCPInfo->DI_DFP.device)
        {
            cbWriteRegBits(pcbe, CR_97, BIT7, BIT7); // 24-bit LCD Panel Interface
        }
    }
}


//---------------------------------------------------------------------
//  cbInitOfTX
//      This function initializes digital interface transmitters(TMDS/LVDS)
//  function inits TX using device info & DI port width
//  IN :
//      NONE
//  OUT :
//      CBIOS_STATUS
//---------------------------------------------------------------------
CBIOS_STATUS cbInitOfTX(PCBIOS_EXTENSION pcbe)
{
    CBIOS_STATUS status = CBIOS_OK;
    
    //if support DVI
    if (pcbe->SupportDevices & S3_DVI)
    {
        status = cbInitTMDS(pcbe, S3_DVI);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init DVI TX fail!\n");
            status = CBIOS_OK;  // for next TX init status
        }
    }
    
    //if support DVI2
    if (pcbe->SupportDevices & S3_DVI2)
    {
        status = cbInitTMDS(pcbe, S3_DVI2);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init DVI2 TX fail!\n");
            status = CBIOS_OK;  // for next TX init status
        }
    }

    //if support LCD
    if (pcbe->SupportDevices & S3_LCD)
    {
        status = cbInitLVDS(pcbe, S3_LCD);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init LCD TX fail!\n");
            status = CBIOS_OK;
        }

        if (pcbe->SupportDevices & S3_LCD2)
        {
            status = cbInitLVDS(pcbe, S3_LCD2);
            if (status != CBIOS_OK)
            {
                cbDbgPrint(0, "Init LCD2 TX fail!\n");
                status = CBIOS_OK;
            }
        }
        cbInitSSC(pcbe);
    }
    // Init fail, add an assert for convenient debug
    ASSERT(status == CBIOS_OK);
    return status;
}

//---------------------------------------------------------------------
//  cbInitOfTVencoder
//      This function initializes TV encoder for TV /HDTV /TV2 /CRT2 device
// which will use encoder 
//  IN :
//      NONE
//  OUT :
//      CBIOS_STATUS
//---------------------------------------------------------------------
CBIOS_STATUS cbInitOfTVencoder(PCBIOS_EXTENSION pcbe)
{
    CBIOS_STATUS status = CBIOS_OK;

    // if HDTV support TV encoder can aslo support TV
    if (pcbe->SupportDevices & (S3_TV | S3_HDTV))
    {
        status = cbInitEncoder(pcbe, S3_TV);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init TV TX fail!\n");
            status = CBIOS_OK;
        }
    }

    // if TV2 support     
    if (pcbe->SupportDevices & S3_TV2)
    {
        status = cbInitEncoder(pcbe, S3_TV2);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init TV2 TX fail!\n");
            status = CBIOS_OK;
        }
    }

    // if CRT2 support
    if (pcbe->SupportDevices & S3_CRT2)
    {
        status = cbInitEncoder(pcbe, S3_CRT2);
        if (status != CBIOS_OK)
        {
            cbDbgPrint(0, "Init CRT2 TX fail!\n");
        }
    }

    return status;
}


//----------------------------------------------------------------------
//  cbInitExtRegs
//      Initialize extended registers when no VCP in VBIOS has been found.
//  Just use CBIOS hardcode value.
//  IN :
//      NONE
//  OUT:
//      NONE
//----------------------------------------------------------------------
VOID cbInitExtRegs(PCBIOS_EXTENSION pcbe)
{
    // FIFO Setting
    cbWriteRegByte(pcbe, SR_16, 0x08);
    cbWriteRegByte(pcbe, SR_17, 0x1F);
    cbWriteRegByte(pcbe, SR_18, 0x0E);
    cbWriteRegByte(pcbe, SR_1A, 0x82);
    cbWriteRegByte(pcbe, SR_1F, 0x00);
    cbWriteRegByte(pcbe, SR_20, 0x40);
    cbWriteRegByte(pcbe, SR_21, 0x40);
    cbWriteRegByte(pcbe, SR_22, 0x1F);
    cbWriteRegByte(pcbe, SR_41, 0x40);
    cbWriteRegByte(pcbe, SR_42, 0x30);
    cbWriteRegByte(pcbe, SR_50, 0x1F);
    // Default disable prefetch mode
    cbWriteRegByte(pcbe, CR_33, 0x00);
    // POWER NOW Setting & DAC Speed Enhancement
    cbWriteRegByte(pcbe, CR_30, 0x0C);
    cbWriteRegByte(pcbe, CR_41, 0x80);
    cbWriteRegByte(pcbe, CR_9D, 0x80);
    cbWriteRegByte(pcbe, CR_42, 0x00); // IGA1 power now active in vblank
    cbWriteRegByte(pcbe, CR_9E, 0x80); // IGA2 power now active while display FIFO almost full
    // Chip Power Management Control
    cbWriteRegByte(pcbe, SR_19, 0x5F);
    // CRT only
    if((pcbe->sPad_1.Out_Dev & S3_CRT) && (!(pcbe->sPad_1.Out_Dev & (~S3_CRT))))     
    {    
        cbWriteRegByte(pcbe, SR_1B, 0x30);
        cbWriteRegByte(pcbe, SR_1E, 0x01);
        cbWriteRegByte(pcbe, SR_2A, 0x00);
    }
    else // not CRT only
    {    
        cbWriteRegByte(pcbe, SR_1B, 0xF0);
        cbWriteRegByte(pcbe, SR_1E, 0xF1);
        cbWriteRegByte(pcbe, SR_2A, 0x0F);
    }

    cbWriteRegByte(pcbe, SR_2D, 0xFF);
    cbWriteRegByte(pcbe, SR_2E, 0xFB);
    cbWriteRegByte(pcbe, SR_3F, 0xBF);
    cbWriteRegByte(pcbe, CR_36, 0x31);

    // Starting Address Init
    cbWriteRegByte(pcbe, CR_34, 0x00);
    cbWriteRegByte(pcbe, CR_48, 0x00);
    cbWriteRegByte(pcbe, CR_62, 0x00);
    cbWriteRegByte(pcbe, CR_63, 0x00);
    cbWriteRegByte(pcbe, CR_64, 0x00);
    cbWriteRegByte(pcbe, CR_A3, 0x00);
    cbWriteRegByte(pcbe, CR_67, 0x00);

    // LCD Pre-fetch Mode enable
    cbWriteRegByte(pcbe, CR_6A, 0x41); 
    // Power_Sequence_Control
    cbWriteRegByte(pcbe, CR_91, 0x00);
    // K8 Control Register
    //cbWriteRegByte(pcbe, SR_51, 0x00);

    cbWriteRegByte(pcbe, SR_40, 0x08);   // PLL Control
    cbWriteRegByte(pcbe, CR_40, 0x00);   // Sys bios set CR40=1 for PCIE16x issue
                                       // We need to clear it to 0
    //cbWriteRegByte(pcbe, CR_43, 0x90);   // CR43[5:4] DAC read sense reference level
                                       // CR43[7:6] DAC sense pattern total 10'b include CR44[7:0]
                                       // used for DAC testing, don't set it on normal operation.
    cbWriteRegByte(pcbe, SR_3E, 0x00);   // For new product, 290/336,324,327,and so on, the i2c is separate from LCD power sequence
                                       // The SR3E[1] work now? it should not work now in hardware
    // SW_12_24_Strapping
    cbWriteRegByte(pcbe, CR_97, 0x00);

    // In older chips, IGA2 LUT read back values are error. Set CR74[7]=0 for fix this issue.
    cbWriteRegByte(pcbe, CR_74, 0x00);
     
}

//-------------------------------------------------------------------------
//  cbInitTMDS
//      Init device (DVI / DVI2) associated TMDS setting ,Now only support 
//  VT1632A
//   IN  : 
//      Device : S3_DVI | S3_DVI2
//   OUT :
//      CBIOS_STATUS
//------------------------------------------------------------------------
CBIOS_STATUS cbInitTMDS(
        PCBIOS_EXTENSION pcbe, 
        IN DWORD Device) 
{
    BYTE DVI_TMDS = TX_EDGE + TX_HEN + TX_VEN; // 0x32, DVI TMDS power default is off
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    WORD DISetting;
    CBIOS_STATUS status = CBIOS_OK;
    i2c.Flags = 0;
    
    //only DVI /DVI2 can connect with TMDS
    if (Device != S3_DVI &&  Device != S3_DVI2)
    {
        cbDbgPrint(0, "Invalid TMDS device !\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // get device associated DI port width
    if (cbGetDIWidth(pcbe, &DISetting, Device) == TRUE)
    {
        // now DVI default is keeped as DDR mode
        DISetting |= _DDR_MODE;
    }
    
    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TXType, Device) == FALSE)
    {
        return CBIOS_ER_LACKOFINFO;
    }
    
    // get Device associate TMDS I2C setting
    if (!cbGetDII2Csetting(pcbe, &i2c, Device))
    {  
        return CBIOS_ER_LACKOFINFO;
    }
   
    // VT1632A need to be configured when post
    if ((TXType == VT3192) || (TXType == SII164))
    {   
        // decide the DI bus width
        if((DISetting & _24BIT_MODE) == 0) 
        {
            //12-bits DI, set BIT3, to DDR mode( 0=SDR, 1=DDR )
            DVI_TMDS |= TX_DSEL; 
        }
        else 
        { 
            // 24-bits DI
            DVI_TMDS |= TX_BSEL;             // BIT2, 0=12-bits, 1=24-bits
            if((DISetting & _DDR_MODE) != 0) // decide the DI clock mode
                DVI_TMDS |= TX_DSEL;
        }
        
        // Set VT1632 TX property 
        // transmitter register index 08h
        i2c.RegIndex = 0x08;
        i2c.IndexData = DVI_TMDS;    
        if(!(I2C_Write_Byte_INV(pcbe, &i2c)))
        {
            return CBIOS_ER_INTERNAL;
        }

        // assume TX programming by i2c always succeed
        i2c.RegIndex = 0x09;
        I2C_Read_Byte_INV(pcbe, &i2c);
        i2c.IndexData &= 0xF6;
        I2C_Write_Byte_INV(pcbe, &i2c);

        i2c.RegIndex = 0x0A;
        I2C_Read_Byte_INV(pcbe, &i2c);
        i2c.IndexData &= 0x0F;
        I2C_Write_Byte_INV(pcbe, &i2c);

        if(TXType == SII164)
        {
            // Special for SII164 ONLY
            // SII164.0C = 89h, Magic byte
            i2c.RegIndex = 0x0C;
            i2c.IndexData = 0x89;
            I2C_Write_Byte_INV(pcbe, &i2c);
        }
    }
	
    if (TXType == TFP410)
    {        
        // Set VT1632 TX property 
        // transmitter register index 08h
        i2c.RegIndex = 0x08;
        i2c.IndexData = DVI_TMDS;    
        if(!(I2C_Write_Byte_INV(pcbe, &i2c)))
        {
            return CBIOS_ER_INTERNAL;
        }

        // assume TX programming by i2c always succeed
        i2c.RegIndex = 0x09;
        i2c.IndexData = 0xB9;
        I2C_Write_Byte_INV(pcbe, &i2c);

        i2c.RegIndex = 0x38;
        i2c.IndexData = 0xE0;
        I2C_Write_Byte_INV(pcbe, &i2c);
    }
    else if (TXType == CH7301)
    {
        // 0x49:BIT0 : Power Management to power on
        i2c.RegIndex = 0x49;
        I2C_Read_Byte_INV(pcbe, &i2c);
        i2c.IndexData &= 0xFE;
        I2C_Write_Byte_INV(pcbe, &i2c);
    }
    
    return status;
}
CBIOS_STATUS cbCheck_CH7305orVT1636(
            PCBIOS_EXTENSION pcbe, 
            INOUT PBYTE ptxtype,
            IN PI2C_CONTROL_UMA pi2c)
{
    CBIOS_STATUS status = CBIOS_OK;
	
	/* Check 7305 or 1636 */
	if(*ptxtype == CH7305_VT1636) {
		pi2c->RegIndex = 0x4A;
		I2C_Read_Byte_INV(pcbe, pi2c); 
	
		if(pi2c->IndexData == CH7305_ID)
			*ptxtype = CH7305_VT1636;
		else
			*ptxtype = VT1636;
	}	
	return status;
}

//------------------------------------------------------------------------
//  cbInitTMDS
//      Init device (LCD / LCD2) associated LCD setting ,Now only support 
//  TTL Type
//   IN  : 
//      Device : S3_LCD | S3_LCD2
//   OUT :
//      CBIOS_STATUS
//------------------------------------------------------------------------
CBIOS_STATUS cbInitLVDS(
            PCBIOS_EXTENSION pcbe, 
            IN DWORD Device)
{
    I2C_CONTROL_UMA i2c;
    BYTE TXType;
    CBIOS_STATUS status = CBIOS_OK;
    BYTE panelID = 0;
    i2c.Flags = 0;
    
    //only LCD / LCD2 can connect with LVDS
    if (Device != S3_LCD &&  Device != S3_LCD2)
    {
        cbDbgPrint(0, "Invalid LVDS device !\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    // get Device associate TX type
    if (cbGetDITXtype(pcbe, &TXType, Device) == FALSE)
    {
        return CBIOS_ER_LACKOFINFO;
    }

    // get Device associate LVDS I2C setting
    if (!cbGetDII2Csetting(pcbe, &i2c, Device))
    {  
        return CBIOS_ER_LACKOFINFO;
    }

    if (Device == S3_LCD)
    {
        panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
    }
    else
    {
        panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
    }

    // for hard wired TX may control SR25[4] according to
    // panel type(dual channel/signel channel
    if (pcbe->pVCPInfo != NULL && pcbe->pVCPInfo->LCDInfoHeader != 0)
    {
        WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
        FPHeaderData LCDHeader;
        if (pcbe->pVCPInfo->miscConfigure & BIT4) // LCD on IGA2 ONLY
        {
            PFPHeaderData pHeader;
            pHeader = (PFPHeaderData)(pcbe->RomData + offsetLCDHeader);
            pHeader += panelID;
            LCDHeader = *pHeader;
        }
        else //LCD 1+2
        {
            // When LCD 1+2 , always use LCD1 to get timing table
            PFPHeaderData12 pHeader12;
            pHeader12 = (PFPHeaderData12)(pcbe->RomData + offsetLCDHeader);
            pHeader12 += pcbe->sPad_4.LCD_DVI2_PanelID;
            LCDHeader.fpControl = pHeader12->fpControl;
            LCDHeader.TD0 = pHeader12->TD0;
            LCDHeader.TD1 = pHeader12->TD1;
            LCDHeader.TD2 = pHeader12->TD2;
            LCDHeader.TD3 = pHeader12->TD3;

            //we can not get member(pointer): fpPanelTblData and fpEntryPoint at here
            //and we do not need these two members at here,so set it to NULL
            LCDHeader.fpPanelTblData = 0;
            LCDHeader.fpEntryPoint = 0;
        }

        cbCheck_CH7305orVT1636(pcbe,&TXType,&i2c);

        switch (TXType)
        {
        case VT1636:
            if (LCDHeader.fpControl & DUAL_CHANNEL)
            {
                i2c.IndexData = 0xE0;   // Dual channel Input Data Mode Select
            }
            else
            {
                i2c.IndexData = 0x00;   // Single channel Input Data Mode Select
            }
            i2c.RegIndex = 0x08;
            I2C_Write_Bit_INV(pcbe, &i2c, 0xE0);

            // load power sequence
            {
                WORD T1, T2, T3, T4, T5;
                T1 = T4 = LCDHeader.TD1 - 1;
                T2 = T3 = (LCDHeader.TD2 + LCDHeader.TD3) / 2 - 1;  // 2ms increment
                T5 = 500 / 100 - 1; // 100ms increment

                i2c.IndexData = ((T5 & 0x0F) << 4) + ((T1 & 0x300) >> 6) + ((T4 & 0x300) >> 8);
                i2c.RegIndex = 0x0B;
                I2C_Write_Byte_INV(pcbe, &i2c);         // 0B

                i2c.IndexData = (T1 & 0xff);
                i2c.RegIndex = 0x0C;
                I2C_Write_Byte_INV(pcbe, &i2c);         // 0C

                i2c.IndexData = (T4 & 0xff);
                i2c.RegIndex = 0x0D;
                I2C_Write_Byte_INV(pcbe, &i2c);         // 0D

                i2c.IndexData = (T2 & 0xff);
                i2c.RegIndex = 0x0E;
                I2C_Write_Byte_INV(pcbe, &i2c);         // 0E

                i2c.IndexData = (T3 & 0xff);
                i2c.RegIndex = 0x0F;
                I2C_Write_Byte_INV(pcbe, &i2c);         // 0F

                i2c.IndexData = (T2 & 0x80) + ((T3 & 0x80) >> 1);
                i2c.RegIndex = 0x10;
                I2C_Write_Bit_INV(pcbe, &i2c, 0xC0);    // 10
            }

            i2c.IndexData = 0xA0;
            i2c.RegIndex = 0x09;
            I2C_Write_Bit_INV(pcbe, &i2c, 0xA0);    // LVDS output power up
            i2c.IndexData = 0x13;
            i2c.RegIndex = 0x10;
            I2C_Write_Bit_INV(pcbe, &i2c, 0x33);    // turn off back light & pws

            // load DPA setting (TBC)

            if (LCDHeader.fpControl & EN_DITHERING)
            {
                i2c.IndexData = 0x50;   // Enable Dithering and set value.Tx0A[6~4]
            }
            else
            {
                i2c.IndexData = 0x00;   // Disable Dithering.Clear Tx0A[6~4]
            }
            i2c.RegIndex = 0x0A;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT6+BIT5+BIT4);

            if (LCDHeader.fpControl & COLOR_DATA_MSB)
            {
                i2c.IndexData = BIT4;   // MSB
            }
            else
            {
                i2c.IndexData = 0x00;   // Preset LSB
            }
            i2c.RegIndex = 0x08;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT4);    // Set MSB ,Tx08[4]
            // VT1636 DPA setting
            if ((NULL != pcbe->pVCPInfo) && (0 != pcbe->pVCPInfo->VT1636DPATbl))
            {
                BYTE *pTblOffset = (PBYTE)(pcbe->RomData + pcbe->pVCPInfo->VT1636DPATbl);
                BYTE *pDataOffset = (PBYTE)(pTblOffset + 2*panelID);
                i2c.IndexData = pDataOffset[0];
                i2c.RegIndex = 0x09;
                //Tx09 CLK_SEL_ST1[4:0]
                I2C_Write_Bit_INV(pcbe, &i2c, BIT4+BIT3+BIT2+BIT1+BIT0);
                i2c.IndexData = pDataOffset[1];
                i2c.RegIndex = 0x08;
                //Tx08 CLK_SEL_ST2[3:0]
                I2C_Write_Bit_INV(pcbe, &i2c,BIT3+BIT2+BIT1+BIT0);
            }
            break;
        
        case CH7305_VT1636:
            if (cbGetDII2Csetting(pcbe, &i2c, Device))
            {
                UCHAR CH7305_LVDS_PLL_TBL[] = 
                {
                    0x66, 0x00,
                    0x6F, 0x00,
                    0x70, 0x40,
                    0x71, 0xED,
                    0x72, 0xA3,
                    0x73, 0xC8,
                    0x74, 0xF6,
                    0x75, 0x00,
                    0x76, 0xAD,
                    0x77, 0x00,
                    0x78, 0x20,
                    0x79, 0x02,
                    0x7A, 0x00,
                    0x7B, 0x00,
                    0x7C, 0x30,
                    0x7D, 0x02,
                    0x7E, 0x00,
                    0x7F, 0x10  
                };

                UCHAR CH7305_LVDS_BIGGER_100M_PLL_TBL[] = 
                {  
                    0x66, 0x00,
                    0x6F, 0x00,
                    0x70, 0x40,
                    0x71, 0xE3,
                    0x72, 0xAD,
                    0x73, 0xDB,
                    0x74, 0xF6,
                    0x75, 0x00,
                    0x76, 0x8F,
                    0x77, 0x00,
                    0x78, 0x60,
                    0x79, 0x02,
                    0x7A, 0x00,
                    0x7B, 0x00,
                    0x7C, 0x30,
                    0x7D, 0x02,
                    0x7E, 0x00,
                    0x7F, 0x10
                };
                PUCHAR pPLL_TBL = CH7305_LVDS_PLL_TBL;
                int i = sizeof(CH7305_LVDS_PLL_TBL) / 2;
               

                if (Device == S3_LCD)
                {
                    panelID = pcbe->sPad_4.LCD_DVI2_PanelID;
                }
                else
                {
                    panelID = pcbe->sPad_4.DVI_LCD2_PanelID;
                }

                if (panelID >= 0x0B || panelID == 0x04 || panelID == 0x05 || panelID == 0x06)
                {
                    pPLL_TBL = CH7305_LVDS_BIGGER_100M_PLL_TBL;
                    i = sizeof(CH7305_LVDS_BIGGER_100M_PLL_TBL) / 2;
                }

                for (;i>0;i--)
                {
                    i2c.RegIndex  = *pPLL_TBL++;
                    i2c.IndexData = *pPLL_TBL++;
                    I2C_Write_Byte_INV(pcbe, &i2c);
                }

            }

            if (LCDHeader.fpControl & DUAL_CHANNEL)
            {
                i2c.IndexData = 0x10;	// Dual channel Input Data Mode Select
            }
            else
            {
                i2c.IndexData = 0x00;	// Single channel Input Data Mode Select
            }
            i2c.RegIndex = 0x64;
            I2C_Write_Bit_INV(pcbe, &i2c, 0x10);

            // load power sequence
            {
                WORD T1, T2, T3, T4, T5;
                T1 = T4 = LCDHeader.TD1 - 1;
                T2 = T3 = (LCDHeader.TD2 + LCDHeader.TD3) / 2 - 1;	// 2ms increment
                T5 = (LCDHeader.TD0 / 50) - 1; // 50ms increment

                //T1------------------
                i2c.IndexData = (T1 & 0xff);
                i2c.RegIndex = 0x67;
                I2C_Write_Bit_INV(pcbe, &i2c, 0x7F);

                i2c.RegIndex = 0x68;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT7);

                //T4------------------
                i2c.IndexData = (T4 & 0xff);
                i2c.RegIndex = 0x6A;
                I2C_Write_Bit_INV(pcbe, &i2c, 0xEF);

                i2c.RegIndex = 0x69;
                I2C_Write_Bit_INV(pcbe, &i2c, BIT7);

                //T5------------------
                i2c.IndexData = (T5& 0xff);
                i2c.RegIndex = 0x6B;
                I2C_Write_Bit_INV(pcbe, &i2c, 0x3F);

                //T2----------------
                i2c.IndexData = (T2& 0xff);
                i2c.RegIndex = 0x68;
                I2C_Write_Bit_INV(pcbe, &i2c, 0x7F);

                //T3----------------
                i2c.IndexData = (T3& 0xff);
                i2c.RegIndex = 0x69;
                I2C_Write_Bit_INV(pcbe, &i2c, 0x7F);
            }

            if (LCDHeader.fpControl & EN_DITHERING)
            {
                i2c.IndexData = 0x00;	// Enable Dithering and set value.Tx0A[6~4]
            }
            else
            {
                i2c.IndexData = BIT3 + BIT5 ;	// Disable Dithering.Clear Tx0A[6~4]
            }
            i2c.RegIndex = 0x64;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT3 + BIT5);

            if (LCDHeader.fpControl & COLOR_DATA_MSB)
            {
                i2c.IndexData = 0x00;	// MSB
            }
            else
            {
                i2c.IndexData = BIT0;	// Preset LSB
            }
            i2c.RegIndex = 0x64;
            I2C_Write_Bit_INV(pcbe, &i2c, BIT0);	// Set MSB ,Tx08[4]
            break;

        case IN_LVDS1:
            cbWriteRegBits(pcbe, CR_88, BIT0, (LCDHeader.fpControl & EN_DITHERING));  // enable dither
            if (LCDHeader.fpControl & DUAL_CHANNEL)
            {
                if (LCDHeader.fpControl & COLOR_DATA_MSB)
                {
                    // Set to one Dual LVDS Channel + MSB in both channel
                    // Default value is LVDS1 + LVDS2 in Initial Tbl
                    cbWriteRegBits(pcbe, CR_D2, BIT5+BIT4+BIT1+BIT0, BIT5);
                }
                else
                {
                    // Set to One Dual LVDS Channel + LSB in both channel
                    // LSB is the default value in Initial Tbl
                    cbWriteRegBits(pcbe, CR_D2, BIT4+BIT5+BIT1+BIT0, BIT5+BIT1+BIT0);
                }
            }
            else
            {
                if (LCDHeader.fpControl & COLOR_DATA_MSB)
                {
                    // LVDS1 Channel + LVDS2 Channel + MSB
                    cbWriteRegBits(pcbe, CR_D2, BIT4+BIT5+BIT1, 0);
                }
                else
                {
                    // LVDS1 Channel + LVDS2 Channel + LVDS1 LSB
                    cbWriteRegBits(pcbe, CR_D2, BIT4+BIT5+BIT1, BIT1);
                }
            }
            break;
            
        case IN_LVDS2:
            cbWriteRegBits(pcbe, CR_D4, BIT6, (LCDHeader.fpControl & EN_DITHERING)<<6);  // enable dither
            if (LCDHeader.fpControl & COLOR_DATA_MSB)
            {
                // LVDS2 Channel set to MSB
                cbWriteRegBits(pcbe, CR_D2, BIT0, 0);
            }
            else
            {
                // LVDS2 Channel set to LSB
                cbWriteRegBits(pcbe, CR_D2, BIT0, BIT0);
            }
            break;
        
        case TTL_PANEL:
            if (pcbe->pVCPInfo->miscConfigure2 & BIT6 ) //353 TTL panel use LVDS1 dithering
            {
                cbWriteRegBits(pcbe, CR_88, BIT0, (LCDHeader.fpControl & EN_DITHERING));     // enable dither
            }
            else if (pcbe->ChipCaps.FOR_409_TTL_PANEL ) //409 TTL panel use LVDS2 dithering
            {
                cbWriteRegBits(pcbe, CR_D4, BIT6, (LCDHeader.fpControl & EN_DITHERING)<<6);  // enable dither
            }
            else
            {
                cbDbgPrint(1, "Not implemented TTL panel!\n");
            }
            break;
            
        case HARDWIRED_LVDS:
            // if TX is 24 bit(VT1634) & LCD is dual channel
            // need to set LCD clock / 2
            cbWriteRegBits(pcbe, CR_88, BIT0, (LCDHeader.fpControl & EN_DITHERING));  // enable dither
            if (LCDHeader.fpControl & DUAL_CHANNEL)
            {
                WORD DISetting;
                //dual channel mode set SR25[4] to 1
                // GPIO 0/1 output enable was configged in loading table: xRInitTbl
                cbWriteRegBits(pcbe, SR_25, BIT4, BIT4);
                cbGetDIWidth(pcbe, &DISetting, S3_LCD);
                if (DISetting == _24BIT_MODE)
                {
                    cbWriteRegBits(pcbe, CR_88, BIT4, BIT4);
                }                    
            }
            break;
            
        default:
            // None-defined TX, add an assert for convenient debug
            ASSERT(0);
            break;
        }

        // S3, POST, restore PWM info from VBIOS image
        cbRestorePWMFromVBIOS(pcbe);

        // trigger PWM. PWM level should be init in init table
        cbWriteRegBits(pcbe, SR_76, BIT0, PWM_Enable); // PWM enable
        cbWriteRegBits(pcbe, SR_78, BIT0, PWM_Fire); // PWM trigger

    }
    else
    {
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}

//------------------------------------------------------------------------
//  cbInitEncoder
//      Init device (LCD / LCD2) associated LCD setting ,Now only support 
//  TTL Type
//   IN  : 
//      Device : S3_LCD | S3_LCD2
//   OUT :
//      CBIOS_STATUS
//------------------------------------------------------------------------
CBIOS_STATUS cbInitEncoder(PCBIOS_EXTENSION pcbe, IN ULONG Device)
{
    CBIOS_STATUS status = CBIOS_OK;
    ULONG TVEncoderType = 0;
    
    //only LCD / LCD2 can connect with LVDS
    if (Device != S3_TV &&  Device != S3_TV2 && Device != S3_CRT2 )
    {
        cbDbgPrint(0, "Invalid LVDS device !\n");
        ASSERT(FALSE);
        return CBIOS_ER_INVALID_PARAMETER;
    }

    if (cbGetDIEncodertype(pcbe, &TVEncoderType, Device) == FALSE)
    {
        cbDbgPrint(1, "Can not find device associated DI port!\n");
        return CBIOS_ER_LACKOFINFO;
    }
    
    switch(TVEncoderType)
    {
    case VT1622:
    case VT1622A:
    case VT1623_3A:
        cbInitTVencoder1623(pcbe, S3_TV); // 1623 only support TV type
        break;
    
    case VT1625_6:
    case VT1625A_6A:
        cbInitTVencoder1625(pcbe, Device);
        break;
    
    case IN_TV:
        status = cbInitInTVEncoder(pcbe);
        break;
    case CRT2Encoder:
        // CRT2 encoder now using VT1625 
        cbInitTVencoder1625(pcbe, Device);
        break;
    default:
        cbDbgPrint(0, "CBIOS only support VT1625 or there is no TV encoder!\n");
        status = CBIOS_ER_LACKOFINFO;
    }

    return status;
}

//-----------------------------------------------------------------------
// cbGetDIWidth
//      DI port width is configured according to DI port type . now only
//  DFP_FULL is 24 bit, other are all 12 bit wide.
//  IN :
//      NONE
//  OUT:
//      pDIWidth : _24BIT_MODE | _12BIT_MODE
//      function status
//----------------------------------------------------------------------
BOOL cbGetDIWidth(
        PCBIOS_EXTENSION pcbe, 
        OUT PWORD pDIWidth,
        IN DWORD device)
{
    PDigitalPortInfo pDIportinfo;
    BOOL status = TRUE;
    
    // CRT connect to a pseudo digital port without TX on it
    // so skip it
    if (!pDIWidth)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (device == S3_CRT)
    {
        cbDbgPrint(0, "CRT is not digital device, has no DI port!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // VT 1636 VT 3192 & hardwared HardWired TX 
    // are all 
    if (cbGetDIPortInfo(pcbe, &pDIportinfo, device) == TRUE)
    {
         switch (pDIportinfo->DIType)
         {
         case DVP0:
         case DVP1:
         case DFP_HIGH:
         case DFP_LOW:        
            // 12 bit DI port
            *pDIWidth = _12BIT_MODE;
            break;
            
         case DFP_FULL:
            // 24 bit DI port
            *pDIWidth = _24BIT_MODE;
            break;
         default:
            cbDbgPrint(1, "error digital port type!\n");
            status = FALSE;
        }
    }
    else 
    {
        status = FALSE;
    }
    
    return status;
          
}


//-----------------------------------------------------------------------
// cbInitExtRegsBits
//   Initialize extended reg bits,  CR32[0], CR88[6:5]
//  IN :
//      NONE
//  OUT :
//      NONE
//----------------------------------------------------------------------
VOID cbInitExtRegsBits(PCBIOS_EXTENSION pcbe)
{
    // Force IGA1 flip stategy by line
    cbWriteRegBits(pcbe, CR_32, 0x01, 0x01); 
    // Force IGA2 flip stategy by line
    cbWriteRegBits(pcbe, CR_88, 0x60, 0x60);
}

//-----------------------------------------------------------------------
// cbGetDeviceAttachedIGAFromHW
//   Get Associate device attached IGA info from Current HW register state
// this function do not rely on CBIOS info. so can be called before CBIOS 
// initialize
//  IN :
//    DWORD device : device bit (only device bit each time)
//  OUT :
//    pIGA : returned IGA info (IGA1 0, IGA2 1)
//    BOOL : function execution status
//----------------------------------------------------------------------
BOOL cbGetDeviceAttachedIGAFromHW(
    PCBIOS_EXTENSION pcbe,
    IN DWORD device,
    OUT PDWORD pIGA)
{
    DI_TYPE DIPortType = None;
    
    if (!pIGA)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // Now for VT1625 HDTV TV shares one DIPort
    if (device == S3_HDTV)
    {
        device = S3_TV;
    }
    // for 324, device in VCP info is word define, so we should translate them first.
    if ( (pcbe->pVCPInfo->version >= VCP1_5) && 
         (pcbe->ChipCaps.S3_device_define_for_324) )
    {
        cbTranslateS3DefineToWordDefine(pcbe, &device);
    }
    
    // get device configured DI port type from VCP
    if ((device == S3_CRT) || ( device == S3_TV &&
        (pcbe->pVCPInfo->miscConfigure & INTERNAL_TV_SUPPORT))) //if interal TV attached
    {
        DIPortType = CRT_PORT;
    }
    else if (pcbe->pVCPInfo == NULL)
    {
        cbDbgPrint(1, "VCP is null!\n");
        return FALSE;
    }
    else if (device & pcbe->pVCPInfo->DI_DVP0.device)
        DIPortType = DVP0;
    else if (device & pcbe->pVCPInfo->DI_DVP1.device)
        DIPortType = DVP1;
    else if (device & pcbe->pVCPInfo->DI_DFPH.device)
        DIPortType = DFP_HIGH;
    else if (device & pcbe->pVCPInfo->DI_DFPL.device)
        DIPortType = DFP_LOW;
    else if (device & pcbe->pVCPInfo->DI_DFP.device)
        DIPortType = DFP_FULL;
    else if (device & pcbe->pVCPInfo->DI_DPPHY.device)
        DIPortType = DPPHY;
    else if (device & pcbe->pVCPInfo->DI_DPMUX.device)
        DIPortType = DPMUX;
    else
    {
        cbDbgPrint(1, "device did not attached to any digital port!\n");
        return FALSE;
    }

    // get current HW status according to DI port type
    // IGA1 0 , IGA2 1 
    switch(DIPortType)
    {
    case CRT_PORT:
        // CRT data source control Reg SR16[6]
        *pIGA = (cbReadRegByte(pcbe, SR_16) & BIT6) >> 6;
        break;
    case DVP0:
        // DVP0 data source control Reg CR96[4]
        *pIGA = (cbReadRegByte(pcbe, CR_96) & BIT4) >> 4;
        break;
    case DVP1:
        // DVP1 data source control Reg CR9B[4]
        *pIGA = (cbReadRegByte(pcbe, CR_9B) & BIT4) >> 4;
        break;
    case DFP_HIGH:
        if (pcbe->ChipCaps.DIPort_data_ctrl)
        {
            // VT3353 DI port source can be configured separately
            // DFPH data source control by it self not come from DVP0
            *pIGA = (cbReadRegByte(pcbe, CR_97) & BIT4) >> 4;
        }
        else
        {
            // DFP_H data source control Reg CR97[4]
            // Hardware limitation DFPH data come from DVP0
            // so also just refrerence DVP0 source reg CR96[4]
            *pIGA = (cbReadRegByte(pcbe, CR_96) & BIT4) >> 4;
        }
        break;
    case DFP_LOW:        
        if (pcbe->ChipCaps.DIPort_data_ctrl)
        {
            // VT3353 DI port source can be configured separately
            // DFPL data source control by it self not come from DVP1
            *pIGA = (cbReadRegByte(pcbe, CR_99) & BIT4) >> 4;
        }
        else
        {
            // DFP_L data source control Reg CR99[4]
            // Hardware limitation DFPL data come from DVP1
            // so also just refrerence DVP1 source reg CR9B[4]
            *pIGA = (cbReadRegByte(pcbe, CR_9B) & BIT4) >> 4;
        }
        break;
    case DFP_FULL:
        // DFP data source control Reg CR97[4], CR99[4] 
        // so also just refrerence DFPH source reg CR97[4]
        *pIGA = (cbReadRegByte(pcbe, CR_97) & BIT4) >> 4;
        break;
    case DPPHY:
        // DPPHY data source control Reg CRFF[1]
        *pIGA = (cbReadRegByte(pcbe, CR_FF) & BIT1) >> 1;
        break;
    case DPMUX:
        // DPMUX data source control Reg CRFF[2]
        *pIGA = (cbReadRegByte(pcbe, CR_FF) & BIT2) >> 2;
        break;
    default:
		break;
    }

    return TRUE;
    
}

//-------------------------------------------
// cbRestorePWMCtrlRegisterFromVBIOS
// when s3 adpter is secondary, our drivr will post by cbios.
// restore sr77, sr78 and src8 from vbios to avoid lcd panel flash
//-------------------------------------------
VOID cbRestorePWMFromVBIOS(PCBIOS_EXTENSION pcbe)
{
    BYTE PanelID = 0;
    BYTE LCDConfig = 0;
    WORD OffsetLCDHeader = 0; 
    WORD OffsetLCDPWMTable = 0;
    PFPHeaderData  pLCDHeader;
    PLCDPWMCONTROL pLCDPWMCtrl;

    if(pcbe->pVCPInfo == NULL || pcbe->RomData == NULL)
    {
        return;
    }

    if(pcbe->pVCPInfo->miscConfigure3 & SUPPORT_RESTORE_PWM_CAP)// if the vbios support pwm contrl cap
    {
        // we only support one PWM, always select first panel ID
        if(pcbe->pVCPInfo->LCDInfoHeader != 0)
        {
            PanelID = pcbe->sPad_4.LCD_DVI2_PanelID;
            OffsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;
            pLCDHeader = (PFPHeaderData)(pcbe->RomData + OffsetLCDHeader);      
            OffsetLCDPWMTable = *(WORD*)(pcbe->RomData + pLCDHeader[PanelID].fpEntryPoint  + OFFSET_PANEL_PWM_CONTROL_TABLE);
            
            pLCDPWMCtrl =  (PLCDPWMCONTROL)(pcbe->RomData + OffsetLCDPWMTable);
            LCDConfig = pLCDHeader[PanelID].fpControl;

            if(LCDConfig & PWM_DUTY_POLARITY)
            {
                cbWriteRegByte(pcbe, SR_77, pLCDPWMCtrl->PWMInverseDDutyLevel);// inverse duty
            }
            else
            {
                cbWriteRegByte(pcbe, SR_77, pLCDPWMCtrl->PWMNormalDDutyLevel); // normal duty
            }

            cbWriteRegBits(pcbe, SR_78, BIT1 + BIT2, (pLCDPWMCtrl->PWMSourceClockSelection) << 1); // pwm clock selection

            if(pcbe->PCIDeviceID == PCI_ID_VT3410)
            {
                cbWriteRegByte(pcbe, SR_C8, (pLCDPWMCtrl->PWMSourceClockDivider));    // panel clock divider
            }
        }
    }
    return;

}


