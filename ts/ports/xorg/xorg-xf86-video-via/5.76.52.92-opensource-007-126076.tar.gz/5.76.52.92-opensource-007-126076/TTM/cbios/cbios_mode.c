/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * Programming info contained in this module about chips can be found at:
 *   ADI ad9389b : http://www.analog.com/static/imported-files/data_sheets/AD9389B.pdf
 *                 http://ez.analog.com/servlet/JiveServlet/download/1741-8-10790/AD9889B%20Programming%20Guide%20RevB.pdf
 *   EDID info : http://en.wikipedia.org/wiki/Extended_display_identification_data
 */
 
#include "cbios_platform.h"
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_vesa_vpit.h"
#include "cbios_cea_timing.h"

#define CEAModeTest  0
#define DPTest       0
UCHAR FAKESVDEDID[256] = 
{   0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x5a, 0x63, 0x20, 0x2a, 0x60, 0x03, 0x00, 0x00,
    0x1a, 0x11, 0x01, 0x03, 0x80, 0x52, 0x2e, 0x78, 0x2a, 0x93, 0x3d, 0xa6, 0x55, 0x47, 0x9b, 0x25,
    0x13, 0x47, 0x4a, 0xb5, 0x6a, 0x00, 0x81, 0x80, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x66, 0x21, 0x50, 0xb0, 0x51, 0x00, 0x1b, 0x30, 0x40, 0x70,
    0x36, 0x00, 0x34, 0xcd, 0x31, 0x00, 0x00, 0x1e, 0x00, 0x00, 0x00, 0xff, 0x00, 0x30, 0x30, 0x38,
    0x36, 0x34, 0x0a, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x00, 0x00, 0x00, 0xfd, 0x00, 0x3c,
    0x4b, 0x1e, 0x40, 0x0b, 0x00, 0x0a, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x00, 0x00, 0x00, 0xfc,
    0x00, 0x41, 0x56, 0x4e, 0x33, 0x37, 0x36, 0x32, 0x77, 0x2d, 0x4e, 0x54, 0x0a, 0x20, 0x01, 0x08,
    0x02, 0x03, 0x19, 0xf1, 0x46, 0x84, 0x05, 0x03, 0x10, 0x02, 0x01, 0x23, 0x09, 0x07, 0x07, 0x83,
    0x01, 0x00, 0x00, 0x65, 0x03, 0x0c, 0x00, 0x10, 0x00, 0x01, 0x1d, 0x00, 0x72, 0x51, 0xd0, 0x1e,
    0x20, 0xff, 0x28, 0x55, 0x00, 0x34, 0xcd, 0x31, 0x00, 0x00, 0x1e, 0x01, 0x1d, 0x80, 0x18, 0x71,
    0x1c, 0x16, 0x20, 0x58, 0x2c, 0x25, 0x00, 0x34, 0xcd, 0x31, 0x00, 0x00, 0x9e, 0x8c, 0x0a, 0xd0,
    0x8a, 0x20, 0xe0, 0x2d, 0x10, 0x10, 0x3e, 0x96, 0x00, 0x34, 0xcd, 0x31, 0x00, 0x00, 0x18, 0x02,
    0x3a, 0x80, 0x18, 0x71, 0x38, 0x2d, 0x40, 0x58, 0x2c, 0x45, 0x00, 0x34, 0xcd, 0x31, 0x00, 0x00,
    0x1e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50
};

UCHAR FAKEDPEDID[128] =
{   
    0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x10, 0xac, 0x36, 0x40, 0x4c, 0x34, 0x34, 0x31,
    0x03, 0x12, 0x01, 0x04, 0xa5, 0x41, 0x29, 0x78, 0x22, 0x8f, 0x95, 0xad, 0x4f, 0x32, 0xb2, 0x25,
    0x0f, 0x50, 0x54, 0xa5, 0x4b, 0x00, 0x81, 0x80, 0xa9, 0x40, 0xd1, 0x00, 0xd1, 0x40, 0x71, 0x4f,
    0x81, 0x00, 0xb3, 0x00, 0x01, 0x01, 0x67, 0x68, 0x00, 0xf0, 0x82, 0x00, 0x35, 0x60, 0x98, 0xE0,
    0x13, 0x00, 0x81, 0x90, 0x21, 0x00, 0x00, 0x1e, 0x00, 0x00, 0x00, 0xff, 0x00, 0x52, 0x57, 0x39,
    0x31, 0x35, 0x38, 0x31, 0x45, 0x31, 0x34, 0x34, 0x4c, 0x0a, 0x00, 0x00, 0x00, 0xfc, 0x00, 0x44,
    0x45, 0x4c, 0x4c, 0x20, 0x34, 0x30, 0x30, 0x38, 0x57, 0x46, 0x50, 0x0a, 0x00, 0x00, 0x00, 0xfd,
    0x00, 0x31, 0x56, 0x1d, 0x71, 0x1c, 0x00, 0x0a, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x00, 0xc7
};


//=============================================================================
// below is new sub functions
//=============================================================================
//*****************************************************************************
// cbSetIGA1Timing
//   This function load timing table on IGA1, if H_Res > pTiming table, goes to
// panning way.
// IN :
//    pTimingTbl : timing table to be set to IGA1
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA1Timing(
    PCBIOS_EXTENSION pcbe, 
    IN PGFXTimingTable pTimingTbl
)
{
    
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
	
    // Set Interlace timing bit
    // for HDTV / TV interlace behavior is support by TV encoder not 
    // in IGA side they are all progressive timing type
    if ( pTimingTbl->Interlaced == INTERLACE)
    {
        cbWriteRegBits(pcbe, CR_33, BIT6, BIT6);
    }
    else
    {
        cbWriteRegBits(pcbe, CR_33, BIT6, 0x00);
    }

    // 410 and later chip, IGA1 has shadow timing, pixel timing and upscaling parameter by MMIO
    // turn them off
    if(pcbe->ChipCaps.IGA1_Support_Pixel_Timing)
    {
        // disable Display End Blanking
        cbWriteRegBits(pcbe, CR_32, BIT2, 0);
        cbWriteRegBits(pcbe, CR_45, BIT0, 0x00);
        cbWriteRegBits(pcbe, CR_FD, BIT6+BIT5, 0x00);
    }

    // load timing
    // downscaling case, target timing has beed loaded.
    if(!(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA1Info.bCurrentModeNeedDownScaler))
    {
        cbSetScalePath(pcbe, IGA1, ST_NONE);

        cbLoadTimingOnIGA1_UMA(pcbe, H_TOTAL,    pTimingTbl->HTotal);
        cbLoadTimingOnIGA1_UMA(pcbe, H_DIS_END,  pTimingTbl->HDisEnd);
        cbLoadTimingOnIGA1_UMA(pcbe, H_BNK_ST,   pTimingTbl->HBlankStart);
        cbLoadTimingOnIGA1_UMA(pcbe, H_BNK_END,  pTimingTbl->HBlankEnd);
        cbLoadTimingOnIGA1_UMA(pcbe, H_SYNC_ST,  pTimingTbl->HSyncStart);
        cbLoadTimingOnIGA1_UMA(pcbe, H_SYNC_END, pTimingTbl->HSyncEnd);
        cbLoadTimingOnIGA1_UMA(pcbe, V_TOTAL,    pTimingTbl->VTotal);
        cbLoadTimingOnIGA1_UMA(pcbe, V_DIS_END,  pTimingTbl->VDisEnd);
        cbLoadTimingOnIGA1_UMA(pcbe, V_BNK_ST,   pTimingTbl->VBlankStart);
        cbLoadTimingOnIGA1_UMA(pcbe, V_BNK_END,  pTimingTbl->VBlankEnd);
        cbLoadTimingOnIGA1_UMA(pcbe, V_SYNC_ST,  pTimingTbl->VSyncStart);
        cbLoadTimingOnIGA1_UMA(pcbe, V_SYNC_END, pTimingTbl->VSyncEnd);

        if(pcbe->ChipCaps.IGA1_Support_Pixel_Timing && (pcbe->IGA1Info.dispDev & (S3_HDMI | S3_HDMI2 | S3_TV | S3_HDTV)))
        {
            // IGA1 pixel timing only enabled when HDMI on IGA1
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_TOTAL,    pTimingTbl->HTotal);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_DIS_END,  pTimingTbl->HDisEnd);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_BNK_ST,   pTimingTbl->HBlankStart);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_BNK_END,  pTimingTbl->HBlankEnd);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_SYNC_ST,  pTimingTbl->HSyncStart);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, H_SYNC_END, pTimingTbl->HSyncEnd);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_TOTAL,    pTimingTbl->VTotal);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_DIS_END,  pTimingTbl->VDisEnd);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_BNK_ST,   pTimingTbl->VBlankStart);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_BNK_END,  pTimingTbl->VBlankEnd);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_SYNC_ST,  pTimingTbl->VSyncStart);
            cbLoadPixelTimingOnIGA1_UMA(pcbe, V_SYNC_END, pTimingTbl->VSyncEnd);
            // if interlace mode enable, we have to adjust HV sync offset 2 to half of HTotal.
            if(pTimingTbl->Interlaced == INTERLACE)
            {
                // SPEC_HALF_LINE_VAL - 1 - (H_TOTAL - H_RETR_ST)
                cbLoadPixelTimingOnIGA1_UMA(pcbe, HVSYNC_Offset2, (pTimingTbl->HTotal/2) -1 - (pTimingTbl->HTotal - pTimingTbl->HSyncStart));
                // enable Display End Blanking
                cbWriteRegBits(pcbe, CR_32, BIT2, BIT2);
            }
            else
            {            
                cbLoadPixelTimingOnIGA1_UMA(pcbe, HVSYNC_Offset2, 0);
            }
            cbWriteRegBits(pcbe, CR_FD, BIT6, BIT6);
        }
    }

    cbLoadTimingOnIGA1_UMA(pcbe, LINE_COMPARE,pTimingTbl->VDisEnd);

    // Power now indicator init
    cbLoadTimingOnIGA1_UMA(pcbe, POWER_NOW_END_POS,  pTimingTbl->VBlankEnd);

    // Program Clocks
    // skip same PLL loading, for reset PLL cause dev flash
//    if (pcbe->IGA1Info.vPLL != pTimingTbl->vPLL) // it is checked in cbProgramDClk1_UMA
    {
        BYTE CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
        BYTE CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
        BYTE CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);

        if(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA1Info.bCurrentModeNeedDownScaler)
        {
            DWORD ClockFreq = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N) * 2;
            DWORD vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, ClockFreq);
            CLK_M = (BYTE)((vPLL & 0xFF0000) >> 16);
            CLK_R = (BYTE)((vPLL & 0x00FF00) >> 8);
            CLK_N = (BYTE) (vPLL & 0x0000FF);
        }

        if((pcbe->pVCPInfo->version >= VCP1_6) && (pcbe->pVCPInfo->miscConfigure3 & AVOID_IGA1_IGA2_SAME_CLK))
        {
            DWORD ClockFreq;
            
            ClockFreq = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N);
            ClockFreq = ClockFreq / 100 * 99;
            pTimingTbl->vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, ClockFreq);
            CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
            CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
            CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);

            // list one special case
            if((pTimingTbl->HDisEnd == 1024) && (pTimingTbl->VDisEnd == 768))
            {
                CLK_M = 0x66;
                CLK_R = 0x0C;
                CLK_N = 0x01;
            }
            if((pTimingTbl->HDisEnd == 1280) && (pTimingTbl->VDisEnd == 1024))
            {
                CLK_M = 0x54;
                CLK_R = 0x08;
                CLK_N = 0x01;
            }
            if((pTimingTbl->HDisEnd == 1680) && (pTimingTbl->VDisEnd == 1050))
            {
                CLK_M = 0x75;
                CLK_R = 0x08;
                CLK_N = 0x01;
            }
        }

        cbProgramDClk1_UMA(pcbe, CLK_M, CLK_R, CLK_N);
    }

    // update it, it is not vbios setmode
    cbWriteRegByte(pcbe, CR_49, CBIOS_SET_MODE_NUMBER);

    return TRUE;
}


/* -----------------------------------------------------------------------
* cbSetIGA1SrcMode
*      This function updates IGA1 source mode associated info. 
*        1. Fetch CNT
*        2. Offset
*        3. color depth
*        4. FIFO setting
*
*  IN :
*      H_Res : H Resolution size
*      H_DisEnd : target timing H display active
*      colorDepth : resolution color depth
*
*
*  OUT:
*      function status
* ------------------------------------------------------------------------- */
BOOL cbSetIGA1SrcMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD H_DisEnd, 
    IN DWORD colorDepth
)
{
    DWORD bytesPerScanLine;
    WORD offset;
    WORD fetchCount;

    /* H resolution 32 byte align */
    bytesPerScanLine = ALIGN_32((colorDepth / 8) * H_Res);
    offset = (WORD)(bytesPerScanLine / 8);  
    
    if ((H_Res >= H_DisEnd) && !(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA1Info.bCurrentModeNeedDownScaler))
    {
        /* need no scaling factor 
               * fetch count depend on Display active */
        fetchCount = (WORD)((DWORD)ALIGN_32((colorDepth / 8) * H_DisEnd) / 16); /* 16-byte alignment */
    }
    else
    {
        /* need scaling factor
               * fetch count depend on resolution */
        fetchCount = (WORD)(bytesPerScanLine / 16);  /*  16-byte alignment */
    }

    /* 410 IGA1 fetch count need add additional value */
    if(pcbe->ChipCaps.HW_FETCHCNT_ADD24)
    {
        fetchCount += 24;
    }
    else
    {
        fetchCount += 4;
    }

    cbLoadTimingOnIGA1_UMA(pcbe, FETCH_COUNT, fetchCount);
    cbLoadTimingOnIGA1_UMA(pcbe, OFFSET,      offset);
    cbLoadTimingOnIGA1_UMA(pcbe, COLOR_DEPTH, (WORD)colorDepth);
    
    cbIGA1_FIFO_Setting_UMA(pcbe, offset);
    
    return TRUE;
}


//--------------------------------------------------------------------------
//cbSetIGA1DevMode
//  This function handles IGA1 new set mode interface for interlace / progressive 
// info.
//  IN DWORD H_Res          :    H resolution size
//  IN DWORD V_Res          :    V resolution size 
//  IN DWORD colorDepth     :    color depth    
//  IN RefreshRateInfo RRateInfo   : refresh rate x 100
//                                    whether interlaced
//--------------------------------------------------------------------------
CBIOS_STATUS cbSetIGA1DevMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
)
{
    GFXTimingTable TargetTimingTbl;
    ScaleFactor sFactor;
    DWORD primarydevice, dev;
    
    TargetTimingTbl.colorDepth = colorDepth;

    //*****************************************************************
    // 1.            find the primary device timing type 
    //*****************************************************************
    // if only one device just itself 
    // if simultaneous case find the primary device 
    primarydevice = cbGetPrimaryDevice(pcbe->IGA1Info.dispDev);
    if (primarydevice == 0) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    //*****************************************************************
    // 2.                   Timing on GFX side 
    //*****************************************************************
    //------------------------------------------------------------
    // 2.1 get GFX side target timing table  
    //------------------------------------------------------------
    if (FALSE == cbGetTargetGFXTimingTbl(pcbe, 
                                         primarydevice, 
                                         H_Res,
                                         V_Res,
                                         RRateInfo,
                                         &TargetTimingTbl))
    {
        cbDbgPrint(1, "IGA1 display device timing error!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    if(pcbe->ChipCaps.InternalDP_Support)
    {
        if(pcbe->IGA1Info.dispDev == S3_DP)
            pcbe->DPSinkCaps[DP1].TimingTbl = TargetTimingTbl;

        if(pcbe->IGA1Info.dispDev == S3_DP2)
            pcbe->DPSinkCaps[DP2].TimingTbl = TargetTimingTbl;
    }
    
    //------------------------------------------------------------
    // 2.2 Adjust target timing GFX side table according to source resolution
    //     and scaler status
    //------------------------------------------------------------
    //if target Timing table is not the same with the wanted mode, then we might need scaler
    //Note: the target mode has considered with device's EDID_ENABLEDEVSCALING_TIMING_TYPE in the above code
    //eg. if CRT is not EDID_ENABLEDEVSCALING_TIMING_TYPE, then for every mode set on CRT, the target mode is 
    //    the same with the wanted mode and needn't scaler.
    pcbe->IGA1Info.bCurrentModeNeedUpScaler = FALSE;
    pcbe->IGA1Info.bCurrentModeNeedDownScaler = FALSE;    
    // since IGA1 has scaling factor so we need to decide 
    // whether use center mode or expansion mode
    // first assume disable IGA1 scaler
    sFactor.HScaleFactor = 0;
    sFactor.VScaleFactor = 0;
    if (pcbe->IGA1Info.curUpScalerState & UPSCALER_PREFERRED)
    {
        if (pcbe->IGA1Info.curUpScalerState & UPSCALER_KEEP_ASPECT_RATIO)
        {
            // for keep AspectRatio, need both src side short than det, then need upscale
            if (H_Res < TargetTimingTbl.HDisEnd && V_Res < TargetTimingTbl.VDisEnd)
            {
                pcbe->IGA1Info.bCurrentModeNeedUpScaler = TRUE;
            }

            // expansion to max when keep aspect ratio
            // short side expantion to max
            // long side expansion, then centering
            cbGetKeepAspectRatioExpTiming(pcbe, H_Res, V_Res, &TargetTimingTbl, &sFactor);
        }
        else
        {
            if ((H_Res < TargetTimingTbl.HDisEnd) || (V_Res < TargetTimingTbl.VDisEnd))
            {
                pcbe->IGA1Info.bCurrentModeNeedUpScaler = TRUE;
            }
            else if ((H_Res > TargetTimingTbl.HDisEnd) || (V_Res > TargetTimingTbl.VDisEnd))
            {
                pcbe->IGA1Info.bCurrentModeNeedDownScaler = TRUE;    
            }


            // for expasion mode just caluclate H / V scaling factor
            cbGetIGAScaleFactor(pcbe, H_Res, V_Res,
                                TargetTimingTbl.HDisEnd, TargetTimingTbl.VDisEnd, TargetTimingTbl.Interlaced, &sFactor);
        }

        // save upscale factor
        pcbe->IGA1Info.curScaleFactor = sFactor;
    }
    else
    {
        cbGetCenterTiming(H_Res, V_Res, &TargetTimingTbl);
    }
    
    // for VT1625 / VT1622 / IN_TV close all DAC to get rid of garbage
    // during the mismatch state between GFX and TV encoder reload timing 
    // we will restore the DAC state hereafter
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
        cbSetTVDACState(pcbe, ALL_DAC_OFF); 
    }

    //----------------------------------------------------------
    // 2.3 load target timing on GFX side IGA1 CRTC
    //  1. source mode
    //  2. scalar setting
    //  3. target mode, polarity and DPA
    //---------------------------------------------------------
    // 2.3.1 update IGA1 SRC mode info
    cbSetIGA1SrcMode(pcbe, H_Res, TargetTimingTbl.HDisEnd, colorDepth);

    // 2.3.2 update IGA1 scalar (410 later chip has the feature of IGA1 scalar)
    if(pcbe->ChipCaps.IGA1_Support_Upscale && pcbe->IGA1Info.bCurrentModeNeedUpScaler)
    {
        cbSetIGAScaleFactor(pcbe, IGA1, ST_UPSCALE, &sFactor);
    }
    else
    {
        cbSetIGAScaleFactor(pcbe, IGA1, ST_NONE, &sFactor);
    }

    // 2.3.3 update IGA1 target timing, polarity and DPA
    // load target timing on IGA1
    if (!cbSetIGA1Timing(pcbe, &TargetTimingTbl))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    else // set timing success, continue loading polarity & DPA
    {
        // get pixel clock
        DWORD pixclock = TargetTimingTbl.HTotal * TargetTimingTbl.VTotal * (TargetTimingTbl.rRateX100 / 100);

        // update DPA and H/V SYNC polarity 
        for (dev = pcbe->IGA1Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
        {
            // update H/V SYNC polarity (HDTV / TV will skip in this function)
            cbSetPolarity(pcbe,GET_LOWEST_BIT1(dev), TargetTimingTbl.HPolarity, TargetTimingTbl.VPolarity);

            // update DI port DPA
            cbSetDeviceDPA(pcbe, GET_LOWEST_BIT1(dev), pixclock);

            // for 410 Internal DP, Update EPHY timing related registers for HDMI,
            // save Timing table for DP for setupMainLink
            if(pcbe->ChipCaps.InternalDP_Support)
            {
                if(dev & (S3_HDMI + S3_DVI + S3_DVI2 + S3_HDMI2))
                {
                    BYTE TxType;
                    cbGetDITXtype(pcbe, &TxType, dev);

                    if(TxType == INTERNAL_DP)
                    {
                        cbUpdateHDMIEPHYReg(pcbe, &TargetTimingTbl);
                        cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT0);
                    }
                }

                if(dev == S3_DP)
                    cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, 0);

                if(dev == S3_DP2)
                    cbWriteRegBits(pcbe, CR_FF, BIT2, 0);
            }
        }
    }

    //*******************************************************************
    // 3.           timing on daugther side (TX / encoder)
    //*******************************************************************
    // now only HDTV / TV / TV2 need to reload timing table on GFX side
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
        DWORD H_Timing, V_Timing;
        // When set daughter card timing, we need real timing, but not mode resolution
        H_Timing = TargetTimingTbl.HBlankStart + (TargetTimingTbl.HTotal - TargetTimingTbl.HBlankEnd);
        V_Timing = TargetTimingTbl.VBlankStart + (TargetTimingTbl.VTotal - TargetTimingTbl.VBlankEnd);

        if (TRUE == cbSetDaughterCardTiming(pcbe, 
                                            primarydevice, 
                                            H_Timing, 
                                            V_Timing, 
                                            RRateInfo))
        {
            // update TV parameters for utility to adjust TV output quality
            cbUpdateTVparameter(pcbe);

            if (primarydevice == S3_HDTV && pcbe->devicepowerstate[HDTVbit] == S3PM_ON)
            {
                // restore DAC status according to HDTV output type
                cbSetTVDACState(pcbe, SET_DAC_ACCORDING_HDTVOutType); 
            }
            else if (primarydevice == S3_TV && pcbe->devicepowerstate[TVbit] == S3PM_ON)
            {
                // restore DAC status according to TV output type
                cbSetTVDACState(pcbe, SET_DAC_ACCORDING_TVOutType);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
    }
    
    //********************************************************************
    // 4.               update information to IGA Info
    //********************************************************************
    {
        pcbe->IGA1Info.HRes = H_Res;
        pcbe->IGA1Info.VRes = V_Res;
        pcbe->IGA1Info.TargetHRes = H_Res;
        pcbe->IGA1Info.TargetVRes = V_Res;
        pcbe->IGA1Info.RRateInfo = RRateInfo;
        pcbe->IGA1Info.ColorDepth = colorDepth;
        pcbe->IGA1Info.HTotal = TargetTimingTbl.HTotal;
        pcbe->IGA1Info.VTotal = TargetTimingTbl.VTotal;
        pcbe->IGA1Info.HDisEnd = TargetTimingTbl.HDisEnd;
        pcbe->IGA1Info.VDisEnd = TargetTimingTbl.VDisEnd;
        pcbe->IGA1Info.vPLL = TargetTimingTbl.vPLL;
    }

    return CBIOS_OK;
}

//--------------------------------------------------------------------------
//cbSetIGA1ModeTiming
//  This function set IGA1 src mode, view size & dest timing
//
//--------------------------------------------------------------------------
BOOL cbSetIGA1ModeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams   pSrc,   // Specify Source Mode to set
    IN PCBiosViewSizeParams     pView,  // Speicfy View Size, from this we can know info such as scale factor.
    IN PCBiosDestTimingParams   pDest   // Specify Destination Timing to set
)
{
    GFXTimingTable TargetTimingTbl;
    ScaleFactor sFactor;
    DWORD primarydevice;
    BOOL bFuncOK;
    CBios_HDMI_FuncOnOff AVMute;
    TargetTimingTbl.colorDepth = pSrc->colorDepth;

    //*****************************************************************
    // 1.            find the primary device timing type 
    //*****************************************************************
    // if only one device just itself 
    // if simultaneous case find the primary device 
    primarydevice = cbGetPrimaryDevice(pcbe->IGA1Info.dispDev);
    if (0 == primarydevice)
    {
        cbDbgPrint(1, "cbSetIGA1ModeTiming: display device combination error!\n");
        return FALSE;
    }

    //*****************************************************************
    // 2.                   Timing on GFX side 
    //*****************************************************************
    //------------------------------------------------------------
    //Set HDMI AVmute on if display device is HDMI 
    if(pcbe->IGA1Info.dispDev & (S3_HDMI+S3_HDMI2))
    {
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            AVMute.FuncOnOff = TRUE;
            AVMute.dispDev = pcbe->IGA1Info.dispDev;
            CBiosSetHDMIAVMute(pcbe, &AVMute);
        }
    }
    //------------------------------------------------------------
    //------------------------------------------------------------
    // 2.1 get GFX side target timing table  
    //------------------------------------------------------------
    bFuncOK = cbGetSpecificGFXTimingTbl(pcbe, 
                                        primarydevice, 
                                        pDest->XRes,
                                        pDest->YRes,
                                        pDest->rRateInfo,
                                        &TargetTimingTbl);
    if (!bFuncOK)
    {
        cbDbgPrint(0, "cbSetIGA1ModeTiming: can't get target timing!\n");
        return FALSE;
    }

    if(pcbe->ChipCaps.InternalDP_Support)
    {
        if(pcbe->IGA1Info.dispDev == S3_DP)
            pcbe->DPSinkCaps[DP1].TimingTbl = TargetTimingTbl;

        if(pcbe->IGA1Info.dispDev == S3_DP2)
            pcbe->DPSinkCaps[DP2].TimingTbl = TargetTimingTbl;
    }

    //------------------------------------------------------------
    // 2.2 Adjust target timing GFX side table according to source resolution
    //     and scaler status
    //------------------------------------------------------------
    // IGA1 has HW scalar (410 later chip has the feature of IGA1 scalar)
    pcbe->IGA1Info.bCurrentModeNeedUpScaler = FALSE;
    pcbe->IGA1Info.bCurrentModeNeedDownScaler = FALSE;
    // we always expand src on view
    if(pcbe->ChipCaps.IGA1_Support_Upscale && ((pSrc->XRes < pView->XRes) || (pSrc->YRes < pView->YRes)))
    {
        pcbe->IGA1Info.bCurrentModeNeedUpScaler = TRUE;
    }
    else if(pcbe->ChipCaps.IGA12_Support_Downscale && ((pSrc->XRes > pView->XRes) || (pSrc->YRes > pView->YRes)))
    {
        pcbe->IGA1Info.bCurrentModeNeedDownScaler = TRUE;
    }
    else
    {
        // IGA1 no scaler, src always left-top on view, so adjust view XY res    
        if (pSrc->XRes < pView->XRes)
        {
            pView->XRes = pSrc->XRes;
        }
        if (pSrc->YRes < pView->YRes)
        {
            pView->YRes = pSrc->YRes;
        }
    }

    // for expasion/downscaling mode just caluclate H / V scaling factor
    cbGetIGAScaleFactor(pcbe, pSrc->XRes, pSrc->YRes, pView->XRes, pView->YRes, PROGRESSIVE, &sFactor);

    // save scale factor
    pcbe->IGA1Info.curScaleFactor = sFactor;

    // view shift on dest
    cbGetShiftTiming(pView, &TargetTimingTbl);

    // for VT1625 / VT1622 / IN_TV close all DAC to get rid of garbage
    // during the mismatch state between GFX and TV encoder reload timing 
    // we will restore the DAC state hereafter
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            cbSetTVDACState(pcbe, ALL_DAC_OFF); 
        }
    }

    //----------------------------------------------------------
    // 2.3 load target timing on GFX side IGA1 CRTC
    //  1. source mode
    //  2. scalar setting
    //  3. target mode, polarity and DPA
    //---------------------------------------------------------
    // 2.3.0 common registers
    cbLoadTable_UMA(pcbe, UMA_ModeCommon);

    // 2.3.1 update IGA1 SRC mode info
    cbSetIGA1SrcMode(pcbe, pSrc->XRes, TargetTimingTbl.HDisEnd, pSrc->colorDepth);

    // 2.3.2 update IGA1 scalar (410 later chip has the feature of IGA1 scalar)
    if(pcbe->ChipCaps.IGA1_Support_Upscale && pcbe->IGA1Info.bCurrentModeNeedUpScaler)
    {
        cbSetIGAScaleFactor(pcbe, IGA1, ST_UPSCALE, &sFactor);
    }
    else if(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA1Info.bCurrentModeNeedDownScaler)
    {
        BYTE CLK_M = (BYTE)((TargetTimingTbl.vPLL & 0xFF0000) >> 16);
        BYTE CLK_R = (BYTE)((TargetTimingTbl.vPLL & 0x00FF00) >> 8);
        BYTE CLK_N = (BYTE) (TargetTimingTbl.vPLL & 0x0000FF);
        DWORD ClockFreq = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N);

        cbSetScalePath(pcbe, IGA1, ST_DOWNSCALE);
        if(cbReadRegByte(pcbe, CR_89) & BIT0)
        {
            DWORD DelayTime = 0;
            ClockFreq /= 1000;
            DelayTime = TargetTimingTbl.HTotal * (TargetTimingTbl.VBlankEnd - TargetTimingTbl.VBlankStart) / 5;
            if(ClockFreq)
                DelayTime = (DelayTime * 1000) / ClockFreq;

            cbWaitVBlank(pcbe, IGA1);		
            cbDelayMicroSeconds(DelayTime);
        }
        cbSetScalePath(pcbe, IGA1, ST_NONE);

        cbSetIGA1DownscaleTargetTiming(pcbe, &TargetTimingTbl);
        cbSetIGA1DownscaleSourceTiming(pcbe, pSrc, pView, &TargetTimingTbl);
        cbSetIGAScaleFactor(pcbe, IGA1, ST_DOWNSCALE, &sFactor);
    }
    else
    {
        cbSetIGAScaleFactor(pcbe, IGA1, ST_NONE, &sFactor);
    }

    // 2.3.3 update IGA1 target timing, polarity and DPA
    // load target timing on IGA1
    if (!cbSetIGA1Timing(pcbe, &TargetTimingTbl))
    {
        return FALSE;
    }
    else // set timing success, continue loading polarity & DPA
    {
        DWORD dev;
        // get pixel clock
        DWORD pixclock = TargetTimingTbl.HTotal * TargetTimingTbl.VTotal * (TargetTimingTbl.rRateX100 / 100);

        // update DPA and H/V SYNC polarity 
        for (dev = pcbe->IGA1Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
        {
            // update H/V SYNC polarity (HDTV / TV will skip in this function)
            cbSetPolarity(pcbe,GET_LOWEST_BIT1(dev), TargetTimingTbl.HPolarity, TargetTimingTbl.VPolarity);

            // update DI port DPA
            cbSetDeviceDPA(pcbe, GET_LOWEST_BIT1(dev), pixclock);

            // for 410 Internal DP, Update EPHY timing related registers for HDMI,
            // save Timing table for DP for setupMainLink
            if(pcbe->ChipCaps.InternalDP_Support)
            {
                if(dev & (S3_HDMI + S3_DVI + S3_DVI2 + S3_HDMI2))
                {
                    BYTE TxType;
                    cbGetDITXtype(pcbe, &TxType, dev);

                    if((TxType == INTERNAL_DP) && (pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE))
                    {
                        cbUpdateHDMIEPHYReg(pcbe, &TargetTimingTbl);
                        cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT0);
                    }
                }

                if(dev == S3_DP)
                    cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, 0);

                if(dev == S3_DP2)
                    cbWriteRegBits(pcbe, CR_FF, BIT2, 0);
            }
        }
    }

    //*******************************************************************
    // 3.           timing on daugther side (TX / encoder)
    //*******************************************************************
    // now only HDTV / TV / TV2 need to reload timing table on GFX side
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            DWORD H_Timing, V_Timing;
            // When set daughter card timing, we need real timing, but not mode resolution
            H_Timing = TargetTimingTbl.HBlankStart + (TargetTimingTbl.HTotal - TargetTimingTbl.HBlankEnd);
            V_Timing = TargetTimingTbl.VBlankStart + (TargetTimingTbl.VTotal - TargetTimingTbl.VBlankEnd);

            if (cbSetDaughterCardTiming(pcbe, 
                                        primarydevice, 
                                        H_Timing, 
                                        V_Timing, 
                                        pDest->rRateInfo))
            {
                // update TV parameters for utility to adjust TV output quality
                cbUpdateTVparameter(pcbe);

                if (primarydevice == S3_HDTV && pcbe->devicepowerstate[HDTVbit] == S3PM_ON)
                {
                    // restore DAC status according to HDTV output type
                    cbSetTVDACState(pcbe, SET_DAC_ACCORDING_HDTVOutType); 
                }
                else if (primarydevice == S3_TV && pcbe->devicepowerstate[TVbit] == S3PM_ON)
                {
                    // restore DAC status according to TV output type
                    cbSetTVDACState(pcbe, SET_DAC_ACCORDING_TVOutType);
                }

            }
            else
            {
                return FALSE;
            }
        }
    }

    //********************************************************************
    // 4.               update information to IGA Info
    //********************************************************************
    {
        pcbe->IGA1Info.HRes = pSrc->XRes;
        pcbe->IGA1Info.VRes = pSrc->YRes;
        pcbe->IGA1Info.TargetHRes = pDest->XRes;
        pcbe->IGA1Info.TargetVRes = pDest->YRes;
        pcbe->IGA1Info.RRateInfo = pDest->rRateInfo;
        pcbe->IGA1Info.ColorDepth = pSrc->colorDepth;
        pcbe->IGA1Info.HTotal = TargetTimingTbl.HTotal;
        pcbe->IGA1Info.VTotal = TargetTimingTbl.VTotal;
        pcbe->IGA1Info.HDisEnd = TargetTimingTbl.HDisEnd;
        pcbe->IGA1Info.VDisEnd = TargetTimingTbl.VDisEnd;
        pcbe->IGA1Info.vPLL = TargetTimingTbl.vPLL;
    }

	//Set HDMI AVmute off if display device is HDMI 
	if(pcbe->IGA1Info.dispDev & (S3_HDMI+S3_HDMI2))
	{
		AVMute.FuncOnOff = FALSE;
		AVMute.dispDev = pcbe->IGA1Info.dispDev;
		CBiosSetHDMIAVMute(pcbe, &AVMute);
	}
	
    return TRUE;
}

//*****************************************************************************
// cbSetIGA1DownscaleSourceTiming
//   This function load timing table on IGA1 downscale source timing.
// IN :
//    pSrc : source resolution to be set to IGA1
//    pTimingTbl : timing table to be set to IGA1 downscale target timing
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA1DownscaleSourceTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams pSrc,
    IN PCBiosViewSizeParams pView,
    IN PGFXTimingTable pTimingTbl
)
{
    GFXTimingTable SrcTimingTbl, *pSrcTimingTbl;
    pSrcTimingTbl = &SrcTimingTbl;
		
    if (!pSrc || !pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // derived source timing
    if (pSrc->XRes <= pView->XRes)
    {
        pSrcTimingTbl->HTotal = pTimingTbl->HTotal;
        pSrcTimingTbl->HDisEnd = pTimingTbl->HDisEnd;
    }
    else
    {
        pSrcTimingTbl->HTotal = pSrc->XRes + (pTimingTbl->HTotal - pTimingTbl->HDisEnd);
        pSrcTimingTbl->HDisEnd = pSrc->XRes;
    }
    pSrcTimingTbl->HBlankStart = pSrcTimingTbl->HDisEnd;
    pSrcTimingTbl->HBlankEnd = pSrcTimingTbl->HTotal;
    pSrcTimingTbl->HSyncStart = pSrcTimingTbl->HDisEnd + 2;
    pSrcTimingTbl->HSyncEnd = pSrcTimingTbl->HSyncStart + 1;

    if (pSrc->YRes <= pView->YRes)
    {
        pSrcTimingTbl->VTotal = pTimingTbl->VTotal;
        pSrcTimingTbl->VDisEnd = pTimingTbl->VDisEnd;
    }
    else
    {
        pSrcTimingTbl->VTotal = pSrc->YRes + (pTimingTbl->VTotal - pTimingTbl->VDisEnd);
        pSrcTimingTbl->VDisEnd = pSrc->YRes;
    }
    pSrcTimingTbl->VBlankStart = pSrcTimingTbl->VDisEnd;
    pSrcTimingTbl->VBlankEnd = pSrcTimingTbl->VTotal;
    pSrcTimingTbl->VSyncStart = pSrcTimingTbl->VDisEnd + 2;
    pSrcTimingTbl->VSyncEnd = pSrcTimingTbl->VSyncStart + 1;

    cbSetScalePath(pcbe, IGA1, ST_NONE);

    // load timing
    cbLoadTimingOnIGA1_UMA(pcbe, H_TOTAL,    pSrcTimingTbl->HTotal);
    cbLoadTimingOnIGA1_UMA(pcbe, H_DIS_END,  pSrcTimingTbl->HDisEnd);
    cbLoadTimingOnIGA1_UMA(pcbe, H_BNK_ST,   pSrcTimingTbl->HBlankStart);
    cbLoadTimingOnIGA1_UMA(pcbe, H_BNK_END,  pSrcTimingTbl->HBlankEnd);
    cbLoadTimingOnIGA1_UMA(pcbe, H_SYNC_ST,  pSrcTimingTbl->HSyncStart);
    cbLoadTimingOnIGA1_UMA(pcbe, H_SYNC_END, pSrcTimingTbl->HSyncEnd);
    cbLoadTimingOnIGA1_UMA(pcbe, V_TOTAL,    pSrcTimingTbl->VTotal);
    cbLoadTimingOnIGA1_UMA(pcbe, V_DIS_END,  pSrcTimingTbl->VDisEnd);
    cbLoadTimingOnIGA1_UMA(pcbe, V_BNK_ST,   pSrcTimingTbl->VBlankStart);
    cbLoadTimingOnIGA1_UMA(pcbe, V_BNK_END,  pSrcTimingTbl->VBlankEnd);
    cbLoadTimingOnIGA1_UMA(pcbe, V_SYNC_ST,  pSrcTimingTbl->VSyncStart);
    cbLoadTimingOnIGA1_UMA(pcbe, V_SYNC_END, pSrcTimingTbl->VSyncEnd);

    return TRUE;
}

//*****************************************************************************
// cbSetIGA1DownscaleTargetTiming
//   This function load timing table on IGA1 downscale target timing.
// IN :
//    pTimingTbl : timing table to be set to IGA1 downscale target timing
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA1DownscaleTargetTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PGFXTimingTable pTimingTbl
)
{
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if(pTimingTbl->HDisEnd > 1024)
    {
        // avoid downscaling target device switch and not set mode again,
        // the other IGA won't turn off buffer sharing for downscaling function
        cbSetScalePath(pcbe, IGA2, ST_DOWNSCALE);
        cbWriteRegBits(pcbe, CR_89, BIT7, 0x00);
    }

    cbSetScalePath(pcbe, IGA1, ST_DOWNSCALE);

    // load timing
    cbLoadTimingOnIGA2_UMA(pcbe, H_TOTAL,    pTimingTbl->HTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, H_DIS_END,  pTimingTbl->HDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_ST,   pTimingTbl->HBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_END,  pTimingTbl->HBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_ST,  pTimingTbl->HSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_END, pTimingTbl->HSyncEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_TOTAL,    pTimingTbl->VTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, V_DIS_END,  pTimingTbl->VDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_ST,   pTimingTbl->VBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_END,  pTimingTbl->VBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_ST,  pTimingTbl->VSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_END, pTimingTbl->VSyncEnd);

    if(pTimingTbl->HDisEnd > 1024)
    {
        cbWriteRegBits(pcbe, CR_89, BIT7, BIT7);

        // enable IGA1/IGA2 downscaling buffer sharing
        // so IGA2 reset can't be enabled
        cbWriteRegBits(pcbe, CR_6A, BIT6, BIT6);
    }
    else
    {
        cbWriteRegBits(pcbe, CR_89, BIT7, 0x00);
    }

    cbSetScalePath(pcbe, IGA1, ST_NONE);

    return TRUE;
}

//*****************************************************************************
// cbSetIGA2Timing
//   This function load timing table on IGA2, if H_Res > pTiming table, goest to
// panning way.
// IN :
//    pTimingTbl : timing table to be set to IGA2
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA2Timing(
    PCBIOS_EXTENSION pcbe, 
    IN PGFXTimingTable pTimingTbl
)
{

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // hardware limitation for 336 /364 chip. only 324 / 353 
    // IGA2 support interlace timing
    // Set Interlace timing bit
    if ( pTimingTbl->Interlaced == INTERLACE)
    {
        cbWriteRegBits(pcbe, CR_67, BIT5, BIT5);
    }
    else
    {
        cbWriteRegBits(pcbe, CR_67, BIT5, 0x00);
    }
       
    // load timing
    // downscaling case, target timing has beed loaded.
    if(!(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA2Info.bCurrentModeNeedDownScaler))
    {
        cbSetScalePath(pcbe, IGA2, ST_NONE);
	
        cbLoadTimingOnIGA2_UMA(pcbe, H_TOTAL,    pTimingTbl->HTotal);
        cbLoadTimingOnIGA2_UMA(pcbe, H_DIS_END,  pTimingTbl->HDisEnd);
        cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_ST,   pTimingTbl->HBlankStart);
        cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_END,  pTimingTbl->HBlankEnd);
        cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_ST,  pTimingTbl->HSyncStart);
        cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_END, pTimingTbl->HSyncEnd);
        cbLoadTimingOnIGA2_UMA(pcbe, V_TOTAL,    pTimingTbl->VTotal);
        cbLoadTimingOnIGA2_UMA(pcbe, V_DIS_END,  pTimingTbl->VDisEnd);
        cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_ST,   pTimingTbl->VBlankStart);
        cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_END,  pTimingTbl->VBlankEnd);
        cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_ST,  pTimingTbl->VSyncStart);
        cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_END, pTimingTbl->VSyncEnd);
    }
    
    // Power now indicator init
    cbLoadTimingOnIGA2_UMA(pcbe, POWER_NOW_END_POS,  pTimingTbl->VBlankEnd);

    // if interlace mode enable, we have to adjust HV sync offset 2 to half of HTotal.
    if ( pTimingTbl->Interlaced == INTERLACE)
    {
        cbLoadTimingOnIGA2_UMA(pcbe, HVSYNC_Offset2, pTimingTbl->HTotal/2);
    }
    else
    {
        cbLoadTimingOnIGA2_UMA(pcbe, HVSYNC_Offset2, 0);
    }

    // Program Clocks
    // skip same PLL loading, for reset PLL cause dev flash
//    if (pcbe->IGA2Info.vPLL != pTimingTbl->vPLL) // it is checked in cbProgramDClk2_UMA
    {
        BYTE CLK_M = (BYTE)((pTimingTbl->vPLL & 0xFF0000) >> 16);
        BYTE CLK_R = (BYTE)((pTimingTbl->vPLL & 0x00FF00) >> 8);
        BYTE CLK_N = (BYTE) (pTimingTbl->vPLL & 0x0000FF);

        if(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA2Info.bCurrentModeNeedDownScaler)
        {
            DWORD ClockFreq = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N) * 2;
            DWORD vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, ClockFreq);
            CLK_M = (BYTE)((vPLL & 0xFF0000) >> 16);
            CLK_R = (BYTE)((vPLL & 0x00FF00) >> 8);
            CLK_N = (BYTE) (vPLL & 0x0000FF);
        }
        cbProgramDClk2_UMA(pcbe, CLK_M, CLK_R, CLK_N);
    }

    // update it, it is not vbios setmode
    cbWriteRegByte(pcbe, CR_49, CBIOS_SET_MODE_NUMBER);

    // this is used for IGA2 register read/write normal, (ex: CR6B[2])
    // if CR_FD[0]=1, CR6B[2] can't update properly, we need to make sure CR_FD[0] only be set in need path
    // make sure CR_FD[0]=0 in default
    cbSetScalePath(pcbe, IGA2, ST_NONE);

    return TRUE;
}

//-------------------------------------------------------------------------
// cbSetIGA2SrcMode
//      This function updates IGA2 source mode associated info. 
//        1. Fetch CNT
//        2. Offset
//        3. color depth
//        4. FIFO setting
//
//  IN :
//      H_Res : H Resolution size
//      H_DisEnd : target timing H display active
//      colorDepth : resolution color depth
//
//  OUT:
//      function status
//-------------------------------------------------------------------------
BOOL cbSetIGA2SrcMode(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD H_DisEnd, 
    IN DWORD colorDepth
)
{
    DWORD bytesPerScanLine;
    WORD offset;
    WORD fetchCount ;

    // H resolution 32 byte align
    bytesPerScanLine = ALIGN_32((colorDepth / 8) * H_Res);    
    offset = (WORD)(bytesPerScanLine / 8); 

    if ((H_Res >= H_DisEnd) && !(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA2Info.bCurrentModeNeedDownScaler))
    {
        // need no scaling factor 
        // fetch count depend on Display active
        fetchCount = (WORD)((DWORD)ALIGN_32((colorDepth / 8) * H_DisEnd) / 16); // 16-byte alignment
    }
    else
    {
        // need scaling factor
        // fetch count depend on resolution
        fetchCount = (WORD)(bytesPerScanLine / 16);  //  16-byte alignment
    }
    
    cbLoadTimingOnIGA2_UMA(pcbe, FETCH_COUNT, fetchCount);
    cbLoadTimingOnIGA2_UMA(pcbe, OFFSET,      offset);
    cbLoadTimingOnIGA2_UMA(pcbe, COLOR_DEPTH, (WORD)colorDepth);

    cbIGA2_FIFO_Setting_UMA(pcbe, offset);

    return TRUE;
}


//--------------------------------------------------------------------------
//cbSetIGA2DevMode 
//  This function handles IGA2 new set mode interface for interlace / progressive 
// info.
//  IN DWORD H_Res          :    H resolution size
//  IN DWORD V_Res          :    V resolution size 
//  IN DWORD colorDepth     :    color depth    
//  IN RefreshRateInfo RRateInfo   : refresh rate x 100
//                                    whether interlaced
//--------------------------------------------------------------------------
CBIOS_STATUS cbSetIGA2DevMode (
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD colorDepth,
    IN RefreshRateInfo RRateInfo
)
{
    GFXTimingTable TargetTimingTbl;
    ScaleFactor sFactor;
    DWORD primarydevice, dev;
    
    TargetTimingTbl.colorDepth = colorDepth;

    //*****************************************************************
    // 1.            find the primary device timing type 
    //*****************************************************************
    // if only one device just itself 
    // if simultaneous case find the primary device 
    primarydevice = cbGetPrimaryDevice(pcbe->IGA2Info.dispDev);
    if (primarydevice == 0) 
    {
        cbDbgPrint(1, "display device combination error!\n");
        return CBIOS_ER_INVALID_PARAMETER;
    }

    
    //*****************************************************************
    // 2.                   Timing on GFX side 
    //*****************************************************************
    //------------------------------------------------------------
    // 2.1 get GFX side target timing table  
    //------------------------------------------------------------
    if (FALSE == cbGetTargetGFXTimingTbl(pcbe, 
                                         primarydevice, 
                                         H_Res,
                                         V_Res,
                                         RRateInfo,
                                         &TargetTimingTbl))
    {
        cbDbgPrint(1, "IGA2 display device timing error!\n");
        return CBIOS_ER_LACKOFINFO;
    }

    if(pcbe->ChipCaps.InternalDP_Support)
    {
        if(pcbe->IGA2Info.dispDev == S3_DP)
            pcbe->DPSinkCaps[DP1].TimingTbl = TargetTimingTbl;

        if(pcbe->IGA2Info.dispDev == S3_DP2)
            pcbe->DPSinkCaps[DP2].TimingTbl = TargetTimingTbl;
    }

    //-----------------------------------------------------------
    // 2.2 Adjust target timing table according to source resolution
    //     and scaler status
    //-----------------------------------------------------------
    //if target mode is not the same with the wanted mode, then we might need scaler
    //Note: the target mode has considered with device's EDID_ENABLEDEVSCALING_TIMING_TYPE in the above code
    //eg. if CRT is not EDID_ENABLEDEVSCALING_TIMING_TYPE, then for every mode set on CRT, the target mode is 
    //    the same with the wanted mode and needn't scaler.
    pcbe->IGA2Info.bCurrentModeNeedUpScaler = FALSE;
    pcbe->IGA2Info.bCurrentModeNeedDownScaler = FALSE;
    // since IGA2 has scaling factor so we need to decide 
    // whether use center mode or expansion mode
    // first assume disable IGA2 scaler
    sFactor.HScaleFactor = 0;
    sFactor.VScaleFactor = 0;
    if (pcbe->IGA2Info.curUpScalerState & UPSCALER_PREFERRED)
    {
        if (pcbe->IGA2Info.curUpScalerState & UPSCALER_KEEP_ASPECT_RATIO)
        {
            // for keep AspectRatio, need both src side short than det, then need upscale
            if (H_Res < TargetTimingTbl.HDisEnd && V_Res < TargetTimingTbl.VDisEnd)
            {
                pcbe->IGA2Info.bCurrentModeNeedUpScaler = TRUE;
            }

            // expansion to max when keep aspect ratio
            // short side expantion to max
            // long side expansion, then centering
            cbGetKeepAspectRatioExpTiming(pcbe, H_Res, V_Res, &TargetTimingTbl, &sFactor);
        }
        else
        {
            if ((H_Res < TargetTimingTbl.HDisEnd) || (V_Res < TargetTimingTbl.VDisEnd))
            {
                pcbe->IGA2Info.bCurrentModeNeedUpScaler = TRUE;
            }
            else if ((H_Res > TargetTimingTbl.HDisEnd) || (V_Res > TargetTimingTbl.VDisEnd))
            {
                pcbe->IGA2Info.bCurrentModeNeedDownScaler = TRUE;    
            }


            // for expasion mode just caluclate H / V scaling factor
            cbGetIGAScaleFactor(pcbe, H_Res, V_Res,
                                TargetTimingTbl.HDisEnd, TargetTimingTbl.VDisEnd, TargetTimingTbl.Interlaced, &sFactor);
        }

        // save upscale factor
        pcbe->IGA2Info.curScaleFactor = sFactor;
    }
    else
    {
        cbGetCenterTiming(H_Res, V_Res, &TargetTimingTbl);
    }

    // for VT1625 / VT1622 / IN_TV close all DAC to get rid of garbage
    // during the mismatch state between GFX and TV encoder reload timing 
    // we will restore the DAC state hereafter
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
        cbSetTVDACState(pcbe, ALL_DAC_OFF); 
    }
    
    //----------------------------------------------------------
    // 2.3 load target timing on GFX side IGA2 CRTC
    //  1. source mode
    //  2. scalar setting
    //  3. target mode, polarity and DPA
    //---------------------------------------------------------
    // 2.3.1 update IGA2 SRC mode info
    cbSetIGA2SrcMode(pcbe, H_Res, TargetTimingTbl.HDisEnd, colorDepth);

    // 2.3.2 update IGA2 scalar
    if(pcbe->IGA2Info.bCurrentModeNeedUpScaler)
    {
        cbSetIGAScaleFactor(pcbe, IGA2, ST_UPSCALE, &sFactor); 
    }
    else
    {
        cbSetIGAScaleFactor(pcbe, IGA2, ST_NONE, &sFactor);
    }

    // 2.3.3 update IGA2 target timing, polarity and DPA
    // load target timing on IGA2
    if (!cbSetIGA2Timing(pcbe, &TargetTimingTbl))
    {
        return CBIOS_ER_INVALID_PARAMETER;
    }
    else // set timing success, continue loading polarity & DPA
    {
        // get pixel clock
        DWORD pixclock = TargetTimingTbl.HTotal * TargetTimingTbl.VTotal * (TargetTimingTbl.rRateX100 / 100);

        // update DPA and H/V SYNC polarity
        for (dev = pcbe->IGA2Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
        {
            // update H/V SYNC polarity (HDTV / TV will skip in this function)
            cbSetPolarity(pcbe, GET_LOWEST_BIT1(dev), TargetTimingTbl.HPolarity, TargetTimingTbl.VPolarity);

            // update DI port DPA
            cbSetDeviceDPA(pcbe, GET_LOWEST_BIT1(dev), pixclock);

            // for 410 Internal DP, Update EPHY timing related registers for HDMI,
            // save Timing table for DP for setupMainLink
            if(pcbe->ChipCaps.InternalDP_Support)
            {
                if(dev & (S3_HDMI + S3_DVI + S3_DVI2 + S3_HDMI2))
                {
                    BYTE TxType;
                    cbGetDITXtype(pcbe, &TxType, dev);

                    if(TxType == INTERNAL_DP)
                    {
                        cbUpdateHDMIEPHYReg(pcbe, &TargetTimingTbl);
                        cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT0 + BIT1);
                    }
                }

                if(dev == S3_DP)
                    cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT1);

                if(dev == S3_DP2)
                    cbWriteRegBits(pcbe, CR_FF, BIT2, BIT2);
            }
        }
    }

    //*******************************************************************
    // 3.           timing on daugther side (TX / encoder)
    //*******************************************************************
    // now only HDTV / TV / TV2 need to reload timing table on GFX side
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
        DWORD H_Timing, V_Timing;
        // When set daughter card timing, we need real timing, but not mode resolution
        H_Timing = TargetTimingTbl.HBlankStart + (TargetTimingTbl.HTotal - TargetTimingTbl.HBlankEnd);
        V_Timing = TargetTimingTbl.VBlankStart + (TargetTimingTbl.VTotal - TargetTimingTbl.VBlankEnd);

        if (TRUE == cbSetDaughterCardTiming(pcbe, 
                                            primarydevice, 
                                            H_Timing, 
                                            V_Timing, 
                                            RRateInfo))
        {   
            // update TV parameters for utility to adjust TV output quality
            cbUpdateTVparameter(pcbe);

            if (primarydevice == S3_HDTV && pcbe->devicepowerstate[HDTVbit] == S3PM_ON)
            {
                // restore DAC status according to HDTV output type
                cbSetTVDACState(pcbe, SET_DAC_ACCORDING_HDTVOutType); 
            }
            else if (primarydevice == S3_TV && pcbe->devicepowerstate[TVbit] == S3PM_ON)
            {
                // restore DAC status according to TV output type
                cbSetTVDACState(pcbe, SET_DAC_ACCORDING_TVOutType);
            }
        }
        else
        {
            return CBIOS_ER_LACKOFINFO;
        }
    }

    
    //********************************************************************
    // 4.               update information to IGA Info
    //********************************************************************
    {
        pcbe->IGA2Info.HRes = H_Res;
        pcbe->IGA2Info.VRes = V_Res;
        pcbe->IGA2Info.TargetHRes = H_Res;
        pcbe->IGA2Info.TargetVRes = V_Res;
        pcbe->IGA2Info.RRateInfo = RRateInfo;
        pcbe->IGA2Info.ColorDepth = colorDepth;
        pcbe->IGA2Info.HTotal = TargetTimingTbl.HTotal;
        pcbe->IGA2Info.VTotal = TargetTimingTbl.VTotal;
        pcbe->IGA2Info.HDisEnd = TargetTimingTbl.HDisEnd;
        pcbe->IGA2Info.VDisEnd = TargetTimingTbl.VDisEnd;
        pcbe->IGA2Info.vPLL = TargetTimingTbl.vPLL;
    }

    return CBIOS_OK;
}

//--------------------------------------------------------------------------
//cbSetIGA2ModeTiming
//  This function set IGA2 src mode, view size & dest timing
//
//--------------------------------------------------------------------------
BOOL cbSetIGA2ModeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams   pSrc,   // Specify Source Mode to set
    IN PCBiosViewSizeParams     pView,  // Speicfy View Size, from this we can know info such as scale factor.
    IN PCBiosDestTimingParams   pDest   // Specify Destination Timing to set
)
{
    GFXTimingTable TargetTimingTbl;
    ScaleFactor sFactor;
    DWORD primarydevice;
    BOOL bFuncOK;
    CBios_HDMI_FuncOnOff AVMute;
    
    TargetTimingTbl.colorDepth = pSrc->colorDepth;

    //*****************************************************************
    // 1.            find the primary device timing type 
    //*****************************************************************
    // if only one device just itself 
    // if simultaneous case find the primary device 
    primarydevice = cbGetPrimaryDevice(pcbe->IGA2Info.dispDev);
    if (0 == primarydevice)
    {
        cbDbgPrint(1, "cbSetIGA2ModeTiming: display device combination error!\n");
        return FALSE;
    }

    //*****************************************************************
    // 2.                   Timing on GFX side 
    //*****************************************************************

    //Set HDMI AVmute on if display device is HDMI 
    if(pcbe->IGA2Info.dispDev & (S3_HDMI+S3_HDMI2))
    {
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            AVMute.FuncOnOff= TRUE;
            AVMute.dispDev = pcbe->IGA2Info.dispDev;
            CBiosSetHDMIAVMute(pcbe, &AVMute);        
        }
    }
    //------------------------------------------------------------
    // 2.1 get GFX side target timing table  
    //------------------------------------------------------------
    bFuncOK = cbGetSpecificGFXTimingTbl(pcbe, 
                                        primarydevice, 
                                        pDest->XRes,
                                        pDest->YRes,
                                        pDest->rRateInfo,
                                        &TargetTimingTbl);
    if (!bFuncOK)
    {
        cbDbgPrint(0, "cbSetIGA2ModeTiming: can't get target timing!\n");
        return FALSE;
    }

    if(pcbe->ChipCaps.InternalDP_Support)
    {
        if(pcbe->IGA2Info.dispDev == S3_DP)
            pcbe->DPSinkCaps[DP1].TimingTbl = TargetTimingTbl;

        if(pcbe->IGA2Info.dispDev == S3_DP2)
            pcbe->DPSinkCaps[DP2].TimingTbl = TargetTimingTbl;
    }

    //-----------------------------------------------------------
    // 2.2 Adjust target timing table according to source resolution
    //     and scaler status
    //-----------------------------------------------------------
    // IGA2 has HW scaler
    pcbe->IGA2Info.bCurrentModeNeedUpScaler = FALSE;
    pcbe->IGA2Info.bCurrentModeNeedDownScaler = FALSE;
    // we always expand src on view
    if ((pSrc->XRes < pView->XRes) || (pSrc->YRes < pView->YRes))
    {
        pcbe->IGA2Info.bCurrentModeNeedUpScaler = TRUE;
    }
    else
    {
        if(pcbe->ChipCaps.IGA12_Support_Downscale && ((pSrc->XRes > pView->XRes) || (pSrc->YRes > pView->YRes)))
        {
            pcbe->IGA2Info.bCurrentModeNeedDownScaler = TRUE;
        }		
    }
		
    // for expasion/downscaling mode just caluclate H / V scaling factor
    cbGetIGAScaleFactor(pcbe, pSrc->XRes, pSrc->YRes, pView->XRes, pView->YRes, PROGRESSIVE, &sFactor);

    // save scale factor
    pcbe->IGA2Info.curScaleFactor = sFactor;

    // view shift on dest
    cbGetShiftTiming(pView, &TargetTimingTbl);

    // for VT1625 / VT1622 / IN_TV close all DAC to get rid of garbage
    // during the mismatch state between GFX and TV encoder reload timing 
    // we will restore the DAC state hereafter
    if ((primarydevice & (S3_HDTV | S3_TV | S3_TV2)) && 
        (pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE))
    {
        cbSetTVDACState(pcbe, ALL_DAC_OFF); 
    }

    //----------------------------------------------------------
    // 2.3 load target timing on GFX side IGA2 CRTC
    //  1. source mode
    //  2. scalar setting
    //  3. target mode, polarity and DPA
    //---------------------------------------------------------
    // 2.3.0 common registers
    cbLoadTable_UMA(pcbe, UMA_ModeCommon);

    // 2.3.1 update IGA2 SRC mode info
    cbSetIGA2SrcMode(pcbe, pSrc->XRes, TargetTimingTbl.HDisEnd, pSrc->colorDepth);

    // 2.3.2 update IGA2 scalar
    if(pcbe->IGA2Info.bCurrentModeNeedUpScaler)
    {
        cbSetIGAScaleFactor(pcbe, IGA2, ST_UPSCALE, &sFactor); 
    }
    else if(pcbe->ChipCaps.IGA12_Support_Downscale && pcbe->IGA2Info.bCurrentModeNeedDownScaler)
    {
        BYTE CLK_M = (BYTE)((TargetTimingTbl.vPLL & 0xFF0000) >> 16);
        BYTE CLK_R = (BYTE)((TargetTimingTbl.vPLL & 0x00FF00) >> 8);
        BYTE CLK_N = (BYTE) (TargetTimingTbl.vPLL & 0x0000FF);
        DWORD ClockFreq = cbCalcClkFromMRN(pcbe, CLK_M, CLK_R, CLK_N);

        cbSetScalePath(pcbe, IGA2, ST_DOWNSCALE);
        if(cbReadRegByte(pcbe, CR_89) & BIT0)
        {
            DWORD DelayTime = 0;
            ClockFreq /= 1000;
            DelayTime = TargetTimingTbl.HTotal * (TargetTimingTbl.VBlankEnd - TargetTimingTbl.VBlankStart) / 5;
            if(ClockFreq)
                DelayTime = (DelayTime * 1000) / ClockFreq;

            cbWaitVBlank(pcbe, IGA2);
            cbDelayMicroSeconds(DelayTime);
        }
        cbSetScalePath(pcbe, IGA2, ST_NONE);

        cbSetIGA2DownscaleTargetTiming(pcbe, &TargetTimingTbl);
        cbSetIGA2DownscaleSourceTiming(pcbe, pSrc, pView, &TargetTimingTbl);
        cbSetIGAScaleFactor(pcbe, IGA2, ST_DOWNSCALE, &sFactor); 
    }
    else
    {
        cbSetIGAScaleFactor(pcbe, IGA2, ST_NONE, &sFactor);
    }

    // 2.3.3 update IGA2 target timing, polarity and DPA
    // load target timing on IGA2
    if (!cbSetIGA2Timing(pcbe, &TargetTimingTbl))
    {
        return FALSE;
    }
    else // set timing success, continue loading polarity & DPA
    {
        DWORD dev;
        // get pixel clock
        DWORD pixclock = TargetTimingTbl.HTotal * TargetTimingTbl.VTotal * (TargetTimingTbl.rRateX100 / 100);

        // update DPA and H/V SYNC polarity
        for (dev = pcbe->IGA2Info.dispDev; GET_LOWEST_BIT1(dev) != 0; dev = CLEAR_LOWEST_BIT1(dev))
        {
            // update H/V SYNC polarity (HDTV / TV will skip in this function)
            cbSetPolarity(pcbe, GET_LOWEST_BIT1(dev), TargetTimingTbl.HPolarity, TargetTimingTbl.VPolarity);

            // update DI port DPA
            cbSetDeviceDPA(pcbe, GET_LOWEST_BIT1(dev), pixclock);

            // for 410 Internal DP, Update EPHY timing related registers for HDMI,
            // save Timing table for DP for setupMainLink
            if(pcbe->ChipCaps.InternalDP_Support)
            {
                if(dev & (S3_HDMI + S3_DVI + S3_DVI2 + S3_HDMI2))
                {
                    BYTE TxType;
                    cbGetDITXtype(pcbe, &TxType, dev);

                    if((TxType == INTERNAL_DP) && (pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE))
                    {
                        cbUpdateHDMIEPHYReg(pcbe, &TargetTimingTbl);
                        cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT0 + BIT1);
                    }
                }

                if(dev == S3_DP)
                    cbWriteRegBits(pcbe, CR_FF, BIT0 + BIT1, BIT1);

                if(dev == S3_DP2)
                    cbWriteRegBits(pcbe, CR_FF, BIT2, BIT2);
            }
        }
    }

    //*******************************************************************
    // 3.           timing on daugther side (TX / encoder)
    //*******************************************************************
    // now only HDTV / TV / TV2 need to reload timing table on GFX side
    if (primarydevice & (S3_HDTV | S3_TV | S3_TV2))
    {
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            DWORD H_Timing, V_Timing;
            // When set daughter card timing, we need real timing, but not mode resolution
            H_Timing = TargetTimingTbl.HBlankStart + (TargetTimingTbl.HTotal - TargetTimingTbl.HBlankEnd);
            V_Timing = TargetTimingTbl.VBlankStart + (TargetTimingTbl.VTotal - TargetTimingTbl.VBlankEnd);

            if (cbSetDaughterCardTiming(pcbe, 
                                        primarydevice, 
                                        H_Timing, 
                                        V_Timing, 
                                        pDest->rRateInfo))
            {   
                // update TV parameters for utility to adjust TV output quality
                cbUpdateTVparameter(pcbe);

                if (primarydevice == S3_HDTV && pcbe->devicepowerstate[HDTVbit] == S3PM_ON)
                {
                    // restore DAC status according to HDTV output type
                    cbSetTVDACState(pcbe, SET_DAC_ACCORDING_HDTVOutType); 
                }
                else if (primarydevice == S3_TV && pcbe->devicepowerstate[TVbit] == S3PM_ON)
                {
                    // restore DAC status according to TV output type
                    cbSetTVDACState(pcbe, SET_DAC_ACCORDING_TVOutType);
                }
            }
            else
            {
                return FALSE;
            }
        }
    }

    //********************************************************************
    // 4.               update information to IGA Info
    //********************************************************************
    {
        pcbe->IGA2Info.HRes = pSrc->XRes;
        pcbe->IGA2Info.VRes = pSrc->YRes;
        pcbe->IGA2Info.TargetHRes = pDest->XRes;
        pcbe->IGA2Info.TargetVRes = pDest->YRes;
        pcbe->IGA2Info.RRateInfo = pDest->rRateInfo;
        pcbe->IGA2Info.ColorDepth = pSrc->colorDepth;
        pcbe->IGA2Info.HTotal = TargetTimingTbl.HTotal;
        pcbe->IGA2Info.VTotal = TargetTimingTbl.VTotal;
        pcbe->IGA2Info.HDisEnd = TargetTimingTbl.HDisEnd;
        pcbe->IGA2Info.VDisEnd = TargetTimingTbl.VDisEnd;
        pcbe->IGA2Info.vPLL = TargetTimingTbl.vPLL;
    }

	//Set HDMI AVmute off if display device is HDMI 
	if(pcbe->IGA2Info.dispDev & (S3_HDMI+S3_HDMI2))
	{
#if LINUX_PLATFORM
        if(pcbe->TimingAttr == TIMING_PARA_FULL_UPDATE)
#endif
        {
            AVMute.FuncOnOff = FALSE;
		    AVMute.dispDev = pcbe->IGA2Info.dispDev;
		    CBiosSetHDMIAVMute(pcbe, &AVMute);        
        }
	}
	
    return TRUE;
}

//*****************************************************************************
// cbSetIGA2DownscaleSourceTiming
//   This function load timing table on IGA2 downscale source timing.
// IN :
//    pSrc : source resolution to be set to IGA2
//    pTimingTbl : timing table to be set to IGA2 downscale target timing
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA2DownscaleSourceTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBiosSourceModeParams pSrc,
    IN PCBiosViewSizeParams pView,
    IN PGFXTimingTable pTimingTbl
)
{
    GFXTimingTable SrcTimingTbl, *pSrcTimingTbl;
    pSrcTimingTbl = &SrcTimingTbl;
		
    if (!pSrc || !pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // derived source timing
    if (pSrc->XRes <= pView->XRes)
    {
        pSrcTimingTbl->HTotal = pTimingTbl->HTotal;
        pSrcTimingTbl->HDisEnd = pTimingTbl->HDisEnd;
    }
    else
    {
        pSrcTimingTbl->HTotal = pSrc->XRes + (pTimingTbl->HTotal - pTimingTbl->HDisEnd);
        pSrcTimingTbl->HDisEnd = pSrc->XRes;
    }
    pSrcTimingTbl->HBlankStart = pSrcTimingTbl->HDisEnd;
    pSrcTimingTbl->HBlankEnd = pSrcTimingTbl->HTotal;
    pSrcTimingTbl->HSyncStart = pSrcTimingTbl->HDisEnd + 2;
    pSrcTimingTbl->HSyncEnd = pSrcTimingTbl->HSyncStart + 1;

    if (pSrc->YRes <= pView->YRes)
    {
        pSrcTimingTbl->VTotal = pTimingTbl->VTotal;
        pSrcTimingTbl->VDisEnd = pTimingTbl->VDisEnd;
    }
    else
    {
        pSrcTimingTbl->VTotal = pSrc->YRes + (pTimingTbl->VTotal - pTimingTbl->VDisEnd);
        pSrcTimingTbl->VDisEnd = pSrc->YRes;
    }
    pSrcTimingTbl->VBlankStart = pSrcTimingTbl->VDisEnd;
    pSrcTimingTbl->VBlankEnd = pSrcTimingTbl->VTotal;
    pSrcTimingTbl->VSyncStart = pSrcTimingTbl->VDisEnd + 2;
    pSrcTimingTbl->VSyncEnd = pSrcTimingTbl->VSyncStart + 1;

    cbSetScalePath(pcbe, IGA2, ST_NONE);

    // load timing
    cbLoadTimingOnIGA2_UMA(pcbe, H_TOTAL,    pSrcTimingTbl->HTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, H_DIS_END,  pSrcTimingTbl->HDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_ST,   pSrcTimingTbl->HBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_END,  pSrcTimingTbl->HBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_ST,  pSrcTimingTbl->HSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_END, pSrcTimingTbl->HSyncEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_TOTAL,    pSrcTimingTbl->VTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, V_DIS_END,  pSrcTimingTbl->VDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_ST,   pSrcTimingTbl->VBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_END,  pSrcTimingTbl->VBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_ST,  pSrcTimingTbl->VSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_END, pSrcTimingTbl->VSyncEnd);

    return TRUE;
}

//*****************************************************************************
// cbSetIGA2DownscaleTargetTiming
//   This function load timing table on IGA2 downscale target timing.
// IN :
//    pTimingTbl : timing table to be set to IGA2 downscale target timing
// OUT :
//   function return status
//****************************************************************************
BOOL cbSetIGA2DownscaleTargetTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PGFXTimingTable pTimingTbl
)
{
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if(pTimingTbl->HDisEnd > 1024)
    {
        // avoid downscaling target device switch and not set mode again,
        // the other IGA won't turn off buffer sharing for downscaling function
        cbSetScalePath(pcbe, IGA1, ST_DOWNSCALE);
        cbWriteRegBits(pcbe, CR_89, BIT7, 0x00);
    }

    cbSetScalePath(pcbe, IGA2, ST_DOWNSCALE);

    // load timing
    cbLoadTimingOnIGA2_UMA(pcbe, H_TOTAL,    pTimingTbl->HTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, H_DIS_END,  pTimingTbl->HDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_ST,   pTimingTbl->HBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_BNK_END,  pTimingTbl->HBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_ST,  pTimingTbl->HSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, H_SYNC_END, pTimingTbl->HSyncEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_TOTAL,    pTimingTbl->VTotal);
    cbLoadTimingOnIGA2_UMA(pcbe, V_DIS_END,  pTimingTbl->VDisEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_ST,   pTimingTbl->VBlankStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_BNK_END,  pTimingTbl->VBlankEnd);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_ST,  pTimingTbl->VSyncStart);
    cbLoadTimingOnIGA2_UMA(pcbe, V_SYNC_END, pTimingTbl->VSyncEnd);

    if(pTimingTbl->HDisEnd > 1024)
    {
        cbWriteRegBits(pcbe, CR_89, BIT7, BIT7);
    }
    else
    {
        cbWriteRegBits(pcbe, CR_89, BIT7, 0x00);
    }

    cbSetScalePath(pcbe, IGA2, ST_NONE);

    return TRUE;
}

//--------------------------------------------------------------------------
// cbSetDaughterCardTiming
//    This function sets device associated daugther card timing according to 
// H ,V resolution & refresh rate. Now only TV / HDTV encoder need to load timing
// when set mode.
//
//  IN :
//      dispDev : display device 
//      H_Res   : resolution H size
//      V_Res   : resolution V size
//    RRateInfo : refresh rate info (refresh rate & interlaced bit)
//  OUT :
//      function status
//
//--------------------------------------------------------------------------
BOOL cbSetDaughterCardTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo)
{
    PTV_FUNCTION_VCP pTVFunc;               // TV function data table pointer
    PTV_FUNCTION_UMA pTVFunc_CBIOS;         // CBIOS TV func data table pointer 
    PTV_FUNCTION_VCP pHDTVFunc;             // HDTV function data table pointer
    BYTE *pHDTVPatch;                       // HDTV refine func data table pointer
    I2C_CONTROL_UMA i2c;  
    ULONG encodertype;
    i2c.Flags = 0;

    if ((dispDev & (S3_TV | S3_TV2 | S3_HDTV)) == 0)
    {
        cbDbgPrint(0, "Wrong device, only TV,TV2 and HDTV has daughter card timing!\n");
        ASSERT(FALSE);
        return FALSE;
    }
  
    if (cbGetDIEncodertype(pcbe, &encodertype, S3_TV) ==FALSE)
    {
        cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
        return FALSE;
    }

    if (dispDev & (S3_TV | S3_TV2))
    {
        cbGetDII2Csetting(pcbe, &i2c, S3_TV);       // Get I2C port info of TV. 
        
        if (TRUE == cbGetVBIOSTVEncoderTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, &pTVFunc))
        {

            // load TV encoder register here
            // default TV table TV_FUNC
            cbFillTVFunctionRegs(pcbe, pTVFunc, TV_FUNC);
            // function for TV table
            cbPatchTVFunctions(pcbe, pTVFunc);
            switch (encodertype)
            {
            case VT1625_6:
            case VT1625A_6A:
                cbTV1625Reset_UMA(pcbe, &i2c);
                break;
            case IN_TV:
                if ( cbIsNativeTVTiming(pcbe, H_Res, V_Res, S3_TV) )
                {
                    // function for bypass mode
                    cbPatchforBypassMode(pcbe, H_Res, V_Res, S3_TV);
                }
                else //not bypass mode
                {
                    InTV_Write_Byte_UMA(pcbe, 0x02, 0x41);  // don't bypass
                    InTV_Write_Byte_UMA(pcbe, 0x03, 0x80);  // SD enable
                }
                break;
            default:
               cbDbgPrint(1, "Can not support the TV encoder type!\n");
               break;
            }
        }
        else if (TRUE == cbGetCBIOSTVEncoderTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, &pTVFunc_CBIOS))
        {
            // can not find TV table in VBIOS                
            // need search timing table in cbios again
            // now only TV 1625 table has been moved to CBIOS
            cbFillTVFunctionRegs_CBIOS(pcbe, pTVFunc_CBIOS, TV_FUNC);
            cbPatchTVFunctions_CBIOS(pcbe, pTVFunc_CBIOS);
            cbTV1625Reset_UMA(pcbe, &i2c);
        }
        else
        {
            return FALSE;
        }
    }
    else if (dispDev & S3_HDTV)
    {
        cbGetDII2Csetting(pcbe, &i2c, S3_HDTV);       // Get I2C port info of HDTV. 
        if (TRUE == cbGetVBIOSHDTVEncoderTimingTable(pcbe,(WORD)H_Res, (WORD)V_Res, &pHDTVFunc, &pHDTVPatch))
        {

            // load HDTV encoder register here
            // default HDTV table TV_FUNC
            cbFillTVFunctionRegs(pcbe, pHDTVFunc, TV_FUNC);
            // function for HDTV table
            cbPatchHDTVFunctions(pcbe, pHDTVPatch);
            switch (encodertype)
            {
            case VT1625_6:
            case VT1625A_6A:
                cbTV1625Reset_UMA(pcbe, &i2c);
                break;
            case IN_TV:
                if ( cbIsNativeTVTiming(pcbe, H_Res, V_Res, S3_HDTV) )
                {
                    // function for bypass mode
                    cbPatchforBypassMode(pcbe, H_Res, V_Res, S3_HDTV);
                }
                else //not bypass mode
                {
                    InTV_Write_Byte_UMA(pcbe, 0x02, 0x41);       // don't bypass
                    InTV_Write_Byte_UMA(pcbe, 0x03, 0x80);       // SD enable
                    InTV_Write_Bits_UMA(pcbe, 0x3B, 0x01, BIT0); // async mode enable
                }
                break;
            default:
               cbDbgPrint(1, "Can not support the TV encoder type!\n");
               break;
            }
        }
        else
        {
            return FALSE;
        }
    }

    return TRUE;
}

//--------------------------------------------------------------------------
// cbGetTargetGFXTimingTbl
//    This function gets device associated resolution timing table on GFX side.  
//  Different device may have different timing policies. Since Mode table is on GFX
//  side only , so for TV / HDTV (VT1622, VT1625) register table won't be load here
//  this still requires refine work.
//
//  IN :
//      dispDev : display device 
//      H_Res   : resolution H size
//      V_Res   : resolution V size
//    RRateInfo : refresh rate info (refresh rate & interlaced bit)
//  OUT :
//      pTimingTbl   : pointer to timing structure
//
//--------------------------------------------------------------------------
BOOL cbGetTargetGFXTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    BOOL status = FALSE;
    DWORD devicetimingtype;
    
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // aid for DTM media center test, we need to report 1080p@59pHz, 1080i@59Hz, 720p@59Hz, 480p@59Hz
    if(dispDev & (S3_HDMI + S3_HDMI2))
    {
        if( (H_Res == 1920 && V_Res == 1080) ||
            (H_Res == 1280 && V_Res == 720) ||
            (H_Res == 720 && V_Res == 480) )
        {
            if(RRateInfo.rRateX100 == 5900)
                RRateInfo.rRateX100 = 6000;
        }
    }
    
    //----------------------------------------------------
    // 1. Get Device timing type
    //----------------------------------------------------
    switch (dispDev)
    {
    case S3_CRT:
        devicetimingtype = pcbe->devicetimingtype[CRTbit];
        break;
        
    case S3_DVI:
        devicetimingtype = pcbe->devicetimingtype[DVIbit];
        break;
        
    case S3_DVI2:
        devicetimingtype = pcbe->devicetimingtype[DVI2bit];
        break;      
        
    case S3_LCD:
        devicetimingtype = pcbe->devicetimingtype[LCDbit];
        break;

    case S3_LCD2:
        devicetimingtype = pcbe->devicetimingtype[LCD2bit];
        break;

    case S3_CRT2:
        devicetimingtype = pcbe->devicetimingtype[CRT2bit];
        break;
        
    case S3_TV:
        devicetimingtype = pcbe->devicetimingtype[TVbit];
        break;
        
    case S3_HDTV:
        devicetimingtype = pcbe->devicetimingtype[HDTVbit];
        break;

    case S3_HDMI:
        devicetimingtype = pcbe->devicetimingtype[HDMIbit];
        break;

    case S3_HDMI2:
        devicetimingtype = pcbe->devicetimingtype[HDMI2bit];
        break;

    case S3_DP:
        devicetimingtype = pcbe->devicetimingtype[DPbit];
        break;

    case S3_DP2:
        devicetimingtype = pcbe->devicetimingtype[DP2bit];
        break;
        
    default:
        cbDbgPrint(1, "Function cbGetTargetGFXTimingTbl input error!\n");
        return FALSE;
    }


    //-----------------------------------------------------
    // 2. get device timing table according to timing type
    //-----------------------------------------------------
    switch(devicetimingtype)
    {
    case VESAVPIT_TIMING_TYPE:
        // VPIT timing table 
        // 1. EDID detailed timing
        // 2. VBIOS vesavpit
        // 3. CBIOS vesavpit
        status = cbGetCRTTypeTimingTbl(pcbe, 
                                       dispDev,
                                       H_Res,
                                       V_Res,
                                       RRateInfo,
                                       pTimingTbl);
        break;

    case EDID_ENABLEDEVSCALING_TIMING_TYPE:
    case VESAVPIT_EDID_TIMING_TYPE:
        // EDID enable device scaling timing table
        // 1. find in customize timing 
        // 2. find in EDID detailed timing 
        // 3. find in est /std timing & has timing table in VESAVPIT timing
        // 4. else use closest customize timing or EDID timing as target timing 
        status = cbGetEDIDTimingTbl(pcbe, 
                                    dispDev,
                                    H_Res,
                                    V_Res,
                                    RRateInfo,
                                    pTimingTbl);
        break;
        
    case EDID_DISABLEDEVSCALING_TIMING_TYPE:
        // EDID no device scale timing type
        // all the mode center on max target timing from customize timing or EDID timing
        status = cbGetMaxTarTimingFromEDIDandCusTiming(pcbe, 
                                                       dispDev, 
                                                       RRateInfo,
                                                       pTimingTbl);
        break;

    case VESAFILTERBYEDID_TIMING_TYPE:
        // VBIOS VESAVPIT filter by EDID panelsize timing table
        // customize timing less than EDID detailed timing
        // all VESAVPIT timing which is less then EDID panel size
        status = cbGetVESATimingFilterByEDIDTypeTimingTbl(pcbe, 
                                                          dispDev,
                                                          H_Res,
                                                          V_Res,
                                                          RRateInfo,
                                                          pTimingTbl);
        break;
        
    case TV_TIMING_TYPE:
        // TV timing table from VBIOS or CBIOS table
        if (FALSE == cbGetVBIOSTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, pTimingTbl))
        {
             // if can not find this contraction level timing table
             // continue to find in CBIOS table
             status = cbGetCBIOSTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, pTimingTbl);
        }
        else
        {
            status = TRUE;
        }
        break;
        
    case HDTV_TIMING_TYPE:
        // HDTV timing table from VBIOS timing table
        status = cbGetVBIOSHDTVGFXTimingTable(pcbe,(WORD)H_Res, (WORD)V_Res, pTimingTbl);
        break;
        
    default:
        cbDbgPrint(1, "Device timing type error!\n");
        return FALSE;
    }


    //-----------------------------------------------------------------------
    // 3. EDID timing type defined but EDID invalid case
    //-----------------------------------------------------------------------
    if (status == FALSE && (devicetimingtype & (EDID_ENABLEDEVSCALING_TIMING_TYPE|EDID_DISABLEDEVSCALING_TIMING_TYPE|VESAVPIT_EDID_TIMING_TYPE)) )
    {
        if (dispDev & (S3_LCD|S3_LCD2))
        {
            // LCD / LCD2 no EDID case and no customize timing
            // 1. EDID broken
            // 2. no DDC port
            // use ROM image panel timing as Max target mode according to panel ID
            status = cbGetVBIOSPanelTimingTable(pcbe, dispDev, pTimingTbl);
        }
        else if (dispDev & (S3_HDMI + S3_HDMI2))
        {
            if(devicetimingtype == VESAVPIT_EDID_TIMING_TYPE)
            {
                // HDMI case use reduce blanking timing
                // if can't get reduce blanking timing, just use vesa vpit timing
                if ( cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, TRUE, pTimingTbl)
                    && H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart )
                {
                    status = TRUE;
                }
                else
                {
                    if ( (status = cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl)) == FALSE )
                    {
                        // HDMI no EDID case and no customize timing
                        // use CBIOS hardcode CEA timing type
                        status = cbGetCEATypeTimingTbl(pcbe,
                                                       H_Res,
                                                       V_Res,
                                                       RRateInfo,
                                                       pTimingTbl);
                    }
                }
            }
            else
            {
                // HDMI no EDID case and no customize timing
                // use CBIOS hardcode CEA timing type
                status = cbGetCEATypeTimingTbl(pcbe,
                                               H_Res,
                                               V_Res,
                                               RRateInfo,
                                               pTimingTbl);
            }
        }
        else if (dispDev & (S3_DVI | S3_DVI2))
        {
            // DVI case use reduce blanking timing
            // if can't get reduce blanking timing, just use vesa vpit timing
            if ( cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, TRUE, pTimingTbl)
                && H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart )
            {
                status = TRUE;
            }
            else
            {
                status = cbGetVBIOSVesaTimingTable(pcbe, 
                                                   H_Res, 
                                                   V_Res, 
                                                   RRateInfo,
                                                   FALSE,
                                                   pTimingTbl);
            }
        }
        else
        {
            // other case use VESAVPIT timing
            status = cbGetVBIOSVesaTimingTable(pcbe, 
                                               H_Res, 
                                               V_Res, 
                                               RRateInfo,
                                               FALSE,
                                               pTimingTbl);
        }
    }


    
    return status;
}

//--------------------------------------------------------------------------
// cbGetSpecificGFXTimingTbl
//    get timing specified by caller, the rule is:
//    1. get from EDID
//    2. get from VBIOS/CBIOS timing table
//    3. calc it by CVT/GTF
//    (Notice: TV/HDTV rule is different, it just refer VBIOS timing table)
//
//  IN :
//      dispDev : display device 
//      H_Res   : timing H resolution
//      V_Res   : timing V resolution
//    RRateInfo : refresh rate info (refresh rate & interlaced bit)
//  OUT :
//      pTimingTbl   : pointer to timing structure
//
//--------------------------------------------------------------------------
BOOL cbGetSpecificGFXTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    BOOL status = FALSE;
    // get real disp end, if interlace, v disp = v res / 2
    DWORD H_disp = H_Res;
    DWORD V_disp = (INTERLACE == RRateInfo.interlaced) ? (V_Res/2) : V_Res;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer! (pTimingTbl) in (cbGetSpecificGFXTimingTbl)\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // aid for DTM media center test, we need to report 1080p@59Hz, 1080i@59Hz, 720p@59Hz, 480p@59Hz
    if (dispDev & (S3_HDMI + S3_HDMI2))
    {
        if( (H_Res == 1920 && V_Res == 1080) ||
            (H_Res == 1280 && V_Res == 720) ||
            (H_Res == 720 && V_Res == 480) )
        {
            if(RRateInfo.rRateX100 == 5900)
                RRateInfo.rRateX100 = 6000;
        }
    }

    //----------------------------------------------------
    // 1. Get Device timing type
    //----------------------------------------------------
    switch (dispDev)
    {
    case S3_CRT:
    case S3_DVI:
    case S3_DVI2:
    case S3_LCD:
    case S3_LCD2:
    case S3_CRT2:
    case S3_HDMI:
    case S3_HDMI2:
    case S3_DP:
    case S3_DP2:
        // ----- step 1 -----
        // get EDID timing first
        status = cbGetEDIDTimingTbl(pcbe, dispDev, H_Res, V_Res, RRateInfo, pTimingTbl);

        // ----- step 2 -----
        // if not get match timing, use non EDID method
        if (!status || pTimingTbl->HDisEnd != H_disp || pTimingTbl->VDisEnd != V_disp)
        {
            if (dispDev & (S3_LCD|S3_LCD2))
            {
                // LCD / LCD2 no EDID case and no customize timing
                // 1. EDID broken
                // 2. no DDC port
                // use ROM image panel timing as Max target mode according to panel ID
                status = cbGetVBIOSPanelTimingTable(pcbe, dispDev, pTimingTbl);
            }
            else if (dispDev & (S3_HDMI | S3_HDMI2))
            {
                // HDMI no EDID case and no customize timing
                // use CBIOS hardcode CEA timing type
                status = cbGetCEATypeTimingTbl(pcbe, H_Res, V_Res, RRateInfo, pTimingTbl);
            }
            else if (dispDev & (S3_DVI | S3_DVI2))
            {
                // DVI case use reduce blanking timing
                // if can't get reduce blanking timing, just use vesa vpit timing
                if ( cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, TRUE, pTimingTbl)
                    && H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart )
                {
                    status = TRUE;
                }
                else
                {
                    status = cbGetVBIOSVesaTimingTable(pcbe, 
                                                       H_Res, 
                                                       V_Res, 
                                                       RRateInfo,
                                                       FALSE,
                                                       pTimingTbl);
                }
            }
            else
            {
                // other case use VESAVPIT timing
                status = cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl);
                if (!status)
                {
                    // get closest timing table in CBIOS 
                    status = cbGetCBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo,
                                                       MODE_TABLE_CBIOS, CBIOS_GENRIC_MODESUPPORT_NUM, pTimingTbl);
                }
            }
        }

        // ----- step 3 -----
        // if still can't get match timing, calc it
        if (!status || pTimingTbl->HDisEnd != H_disp || pTimingTbl->VDisEnd != V_disp)
        {
            status = cbGetCVTTiming(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl);
            if (!status)
            {
                status = cbGetGTFTiming(pcbe, H_Res, V_Res, RRateInfo, FALSE, FALSE, pTimingTbl);
            }
        }
        break;

    case S3_TV:
        // TV timing table from VBIOS or CBIOS table
        status = cbGetVBIOSTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, pTimingTbl);
        if (!status)
        {
            // if can not find this contraction level timing table
            // continue to find in CBIOS table
            status = cbGetCBIOSTVGFXTimingTable(pcbe, (WORD)H_Res, (WORD)V_Res, pTimingTbl);
        }
        break;

    case S3_HDTV:
        // HDTV timing table from VBIOS timing table
        status = cbGetVBIOSHDTVGFXTimingTable(pcbe,(WORD)H_Res, (WORD)V_Res, pTimingTbl);
        break;

    default:
        cbDbgPrint(1, "Function cbGetSpecificGFXTimingTbl input device error!\n");
        return FALSE;
    }

    return status;
}

//---------------------------------------------------------------------
// cbSetScalePath
//     This function changes the destination of scaling up/down and CRTC timing registers
// IN : 
//      IGA_Num : for which IGA
//      scaletype : upscaling or downscaling
// OUT:
//      NONE
//---------------------------------------------------------------------
void cbSetScalePath(
    PCBIOS_EXTENSION pcbe,
    IN DWORD IGA_Num,
    IN ScaleType SType
)
{
    BYTE REG_CRFD = cbReadRegByte(pcbe, CR_FD);
	
    if(pcbe->ChipCaps.IGA1_Support_Upscale || pcbe->ChipCaps.IGA12_Support_Downscale)
    {
        if(IGA_Num == IGA1)
        {
            REG_CRFD |= BIT7;
        }
        else
        {
            REG_CRFD &= ~BIT7;
        }
    }
    if(pcbe->ChipCaps.IGA12_Support_Downscale)
    {
        switch(SType)
        {
            case  ST_NONE:
            case  ST_UPSCALE:
                REG_CRFD &= ~BIT0;
                break;
            case  ST_DOWNSCALE:
                REG_CRFD |= BIT0;
                break;
            default:
                break;
        }
    }

    cbWriteRegByte(pcbe, CR_FD, REG_CRFD);
}

//---------------------------------------------------------------------
// cbSetIGAScaleFactor
//     This function configurate the path to set scale factor for IGA
// IN : 
//      IGA_Num : for which IGA
//      scaletype : upscaling or downscaling
//      pScaleFactor : H / V scale value (0 if close the scaler) 
// OUT:
//      NONE
//---------------------------------------------------------------------
void cbSetIGAScaleFactor(
    PCBIOS_EXTENSION pcbe,
    IN DWORD IGA_Num,    
    IN ScaleType SType,
    IN PScaleFactor pScaleFactor
)
{
    if(pcbe->ChipCaps.IGA1_Support_Upscale || pcbe->ChipCaps.IGA12_Support_Downscale)
    {
        if(SType == ST_UPSCALE)
        {
            if(IGA_Num == IGA1 && pScaleFactor->HScaleFactor != 0)
            {
                pScaleFactor->HScaleFactor -= 1;
            }
            if(IGA_Num == IGA1 && pScaleFactor->VScaleFactor != 0)
            {
                pScaleFactor->VScaleFactor += 1;
            }
            if(IGA_Num == IGA2 && pScaleFactor->VScaleFactor != 0)
            {
                pScaleFactor->VScaleFactor -= 1;
            }
        }
        cbSetScalePath(pcbe, IGA_Num, SType);
        cbSetScaleFactor(pcbe, SType, pScaleFactor);
    }
    else
    {
        if(IGA_Num == IGA2)
        {
            cbSetScaleFactor(pcbe, SType, pScaleFactor);
        }
    }
}

//---------------------------------------------------------------------
// cbSetScaleFactor
//     This function fills IGA scaling factor value & behavior into registers
// Our scaler composes V / H direction scaler. 
// For H direction scaler, it will be set as pixel interpolation mode by using CR79[1], 
// For V direction scaler, just use duplication as default before VT3410, 
// but it will be set as pixel interpolation mode by using CR79[2], if VT3410 and later chips.
// IN : 
//      scaletype : upscaling or downscaling
//      pScaleFactor : H / V scale value (0 if close the scaler) 
// OUT:
//      NONE
//---------------------------------------------------------------------
void cbSetScaleFactor(
    PCBIOS_EXTENSION pcbe,
    IN ScaleType SType,
    IN PScaleFactor pScaleFactor
)
{
    if ((0 == pScaleFactor->HScaleFactor)
        && (0 == pScaleFactor->VScaleFactor))
    {
        // disable total scaler
        if(pcbe->ChipCaps.IGA12_Support_Downscale)
        {
            cbWriteRegBits(pcbe, CR_89, BIT7+BIT0, 0x00);
        }
        cbWriteRegBits(pcbe, CR_79, BIT0, 0x00);
    }
    else
    {
        // V scale set to duplication since current chipset do not support V interpolation
        // but VT3410 and later chip, V scale set to linear interpolation        
        // (CR79[2] = 0: V_Duplication  1: V_Interpolation)
        // VT3353 and later chip  
        // H scale set to linear interpolation
        // (CR79[1] = 0: H_Duplication  1: H_Interpolation)
        // enable total scaler CR79[0]=1 for upscaling 
        // enable total scaler CR89[7]=1 enable downscaling IGA1/IGA2 Buffer Sharing
        // enable total scaler CR89[0]=1 for downscaling
        BYTE REG_CR79 = cbReadRegByte(pcbe, CR_79)|BIT1|BIT0;
        if(pcbe->ChipCaps.IGA1_Support_Upscale) // VT3410 and later chip
        {
            REG_CR79 |= BIT2;
        }
        if(pcbe->ChipCaps.IGA12_Support_Downscale)
        {
            BYTE REG_CR89 = cbReadRegByte(pcbe, CR_89);
            if(SType == ST_DOWNSCALE)
            {
                REG_CR79 &= ~BIT0;
                REG_CR89 |= BIT0;
            }
            else
            {
                REG_CR89 &= ~(BIT7+BIT0);
            }
            cbWriteRegByte(pcbe, CR_89, REG_CR89);
        }
        cbWriteRegByte(pcbe, CR_79, REG_CR79);

        if (pScaleFactor->HScaleFactor != 0)
        {
            // fill scaling factor
            cbLoadTimingOnIGA2_UMA(pcbe, H_SCALING_FACTOR, pScaleFactor->HScaleFactor);
            // enable H scaler CRA2[7]=1 (CRA2[6] = 1: linear mode)
            cbWriteRegBits(pcbe, CR_A2, BIT6+BIT7, BIT6+BIT7);
        }
        else
        {
            // disable H scaler
            cbWriteRegBits(pcbe, CR_A2, BIT7, 0x00);
        }

        if (pScaleFactor->VScaleFactor != 0)
        {
            // fill scaling factor
            cbLoadTimingOnIGA2_UMA(pcbe, V_SCALING_FACTOR, pScaleFactor->VScaleFactor);
            // enable V scaler CRA2[3]=1
            cbWriteRegBits(pcbe, CR_A2, BIT3, BIT3);
        }
        else
        {
            // disable V scaler
            cbWriteRegBits(pcbe, CR_A2, BIT3, 0x00);
        }
    }
}

//----------------------------------------------------------------------------
// cbIsDevEDIDValid
//      This function check is device EDID match device feature. the feature including:
//      1. digital or analog
//      2. HDMI IEEE OUI
//  
//  OUT : 
//      return TRUE or FALSE  
//          
//----------------------------------------------------------------------------
#define IsDigitalMonitor(pEDIDByteBuf) ((pEDIDByteBuf)[0x14] & BIT7)  // EDID 0x14 [7] = 1: digital, 0: analog

BOOL cbIsDevEDIDValid(
    PCBIOS_EXTENSION pcbe, 
    DWORD dev,
    PBYTE pEDIDBuf,
    DWORD bufLen)
{
    PDigitalPortInfo PDIPort = NULL;

    if ( NULL == pEDIDBuf || bufLen < EDID1_X_BLOCKSIZE || MORE_THAN_1BIT(dev) )
    {
        return FALSE;
    }

    switch (dev)
    {
    case S3_CRT:
    case S3_CRT2:
        if (IsDigitalMonitor(pEDIDBuf))
        {
            return FALSE;
        }
        break;

    case S3_HDMI1:
    case S3_HDMI2:
    case S3_HDMI:
    case S3_HDMI4:
        if (!cbIsHDMIOUIExistInEDID(pEDIDBuf, bufLen) || !IsDigitalMonitor(pEDIDBuf))
        {
            return FALSE;
        }
        break;

    case S3_DVI:
    case S3_DVI2:
    case S3_DVI3:
    case S3_DVI4:
        if (!IsDigitalMonitor(pEDIDBuf))
        {
            if(pcbe->pVCPInfo->version >= VCP1_6)
            {
                if((pcbe->pVCPInfo->miscConfigure3 & CRT_DVI_SHARE_CONNECTOR) && (dev != S3_DVI))
                {
                    return FALSE;
                }
                if((pcbe->pVCPInfo->miscConfigure3 & CRT_DVI2_SHARE_CONNECTOR) && (dev != S3_DVI2))
                {
                    return FALSE;
                }
            }
            else
            {
                return FALSE;
            }
        }
        // get device on which DI port
        if (!cbGetDIPortInfo(pcbe, &PDIPort, dev))
        {
            cbDbgPrint(1, "can not get device DI port information. \n");
            return FALSE;
        }
        // if has HDMI support on same port, we must distinguish DVI with HDMI
        // else we can accept HDMI EDID on DVI encoder like VT1632
        if (PDIPort->PortInfo.device & (S3_HDMI1+S3_HDMI2+S3_HDMI+S3_HDMI4))
        {
            if (cbIsHDMIOUIExistInEDID(pEDIDBuf, bufLen))
            {
                return FALSE;
            }
        }
        break;

    case S3_DP:
    case S3_DP2:
        if (!IsDigitalMonitor(pEDIDBuf))
        {
            
            return FALSE;
        }
        break;

    default:
        break;
    }

    return TRUE;
}

//----------------------------------------------------------------------------
// cbUpdateAllDevRealEDIDOnDIPort
//      This function update all device real EDID with specific EDID on specific DI port
//      1. if specific EDID match some device, update their real EDID by specific EDID
//      2. if specific EDID not match some device, clear their real EDID
//      device real EDID including EDID info, when fake EDID not available
//
//  OUT : 
//
//----------------------------------------------------------------------------
VOID cbUpdateAllDevRealEDIDOnDIPort(
    PCBIOS_EXTENSION pcbe, 
    PDigitalPortInfo pDIPort,
    PBYTE pEDIDBuf,
    DWORD bufLen)
{
    DWORD i;
    // search all device on DI port
    for (i=0; i<32; i++)
    {
        DWORD curDev = _BIT(i);

        // if this device on the DI port
        if (pDIPort->PortInfo.device & curDev)
        {
            // if EDID match this device, fill in, else clear this device
            if (cbIsDevEDIDValid(pcbe, curDev, pEDIDBuf, bufLen))
            {
                PCBIOS_DEV_EDID pEDID = &(pcbe->devEDID[i]);

                // fill device EDID to real EDID buf
                memcpy(pEDID->realEDIDbuf.EdidBuffer, pEDIDBuf, bufLen);
                pEDID->realEDIDbuf.EdidBufferLen = bufLen;

                // if not fake edid, we need parser real edid and update to edid data
                if (!pEDID->bFakeEDID)
                {
                    // now we can only check parse the EDID 1_X base block
                    if (!cbEDIDParser_UMA(pcbe, pEDIDBuf, bufLen, &(pEDID->EDIDInfo)))
                    {
                        // if parser EDID fail, clear real EDID buffer
                        memset(&(pEDID->realEDIDbuf), 0, sizeof(CBIOS_EDID_BUFFER));
                    }
                }
            }
            else
            {
                cbClearEDIDBuf(pcbe, curDev);
            }
        } // if device on DI port
    } // for all device
}

//----------------------------------------------------------------------------
// cbControlVDDSignalForEDP
//      This function is used to control the VDD siganl when using DP2 with EDP
//
//  OUT : 
//----------------------------------------------------------------------------
void cbControlVDDSignalForEDP(PCBIOS_EXTENSION pcbe, BOOL isTurnOn)
{
	BYTE CR91;
	WORD timer;
	DWORD mmC7B0 = 0;
    PEDPPOWERDELAYDATA pEDPTimingTbl = NULL;
    pEDPTimingTbl = (PEDPPOWERDELAYDATA)(pcbe->RomData + pcbe->pVCPInfo->EDPInfoHeader);
    
    if(pcbe->ChipCaps.UseEDPOnDP2 == TRUE)
    {
    	if(isTurnOn)
    	{
    		CR91 = cbReadRegByte(pcbe,CR_91) | 0x10;
    		cbWriteRegByte(pcbe, CR_91, CR91);
    		for(timer = 0 ; timer <= (pEDPTimingTbl->TD3)*1000 ; timer ++)
    		{
    			mmC7B0 = ReadMMIOUlong(CB_MMIO_OFFSET(0xC7B0));
    			if((mmC7B0 & 0xC0000000) == 0x40000000)
    				break;
    			cbDelayMicroSeconds(1);
    		}
    	}
    	else
    	{
    		CR91 = cbReadRegByte(pcbe,CR_91) & 0xEF;
    		cbWriteRegByte(pcbe, CR_91, CR91);
    		cbDelayMicroSeconds((pEDPTimingTbl->TD12)*1000);
    	}
    }
}

//----------------------------------------------------------------------------
// cbControlBLSignalForEDP
//      This function is used to control the Back Light siganl when using DP2 with EDP
//
//  OUT : 
//----------------------------------------------------------------------------
void cbControlBLSignalForEDP(PCBIOS_EXTENSION pcbe, BOOL isTurnOn)
{
	BYTE CR91;
    PEDPPOWERDELAYDATA pEDPTimingTbl = NULL;
    pEDPTimingTbl = (PEDPPOWERDELAYDATA)(pcbe->RomData + pcbe->pVCPInfo->EDPInfoHeader);

    if(pcbe->ChipCaps.UseEDPOnDP2 == TRUE)
    {
    	if(isTurnOn)
    	{
    		cbDelayMicroSeconds((pEDPTimingTbl->TD8)*1000);
    		CR91 = cbReadRegByte(pcbe,CR_91) | 0x02;
    		cbWriteRegByte(pcbe, CR_91, CR91);
    		
    	}
    	else
    	{
    		CR91 = cbReadRegByte(pcbe, CR_91) & 0xFD;
    		cbWriteRegByte(pcbe, CR_91, CR91);
    		cbDelayMicroSeconds((pEDPTimingTbl->TD8)*1000);
    	}
    }
}

//---------------------------------------------------------------------------
// cbIsEDIDCKMSame
//      This function checks if the Device's EDID check sum byte same as 
//   previous.
//
//   OUT:
//      TRUE for same, FALSe for different
//---------------------------------------------------------------------------
BOOL cbIsEDIDCKMSame(PCBIOS_EXTENSION pcbe, DWORD Device, OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid)
{
    BOOL                status = FALSE;
    PCBIOS_DEV_EDID     pEDID = NULL;
    PDigitalPortInfo    PDIPort = NULL;
    I2C_CONTROL_UMA     i2c;
    BYTE                preCheckSum = 0, curCheckSum = 0xFF, i = 0;
    DWORD               PortDevice = 0, testDevice = 0;

    if (!cbGetDIPortInfo(pcbe, &PDIPort, Device))
    {
        cbDbgPrint(1, "can not get device DI port information. \n");
        return FALSE;
    }

    PortDevice = PDIPort->PortInfo.device;

    while(PortDevice != 0)
    {
        testDevice = ((PortDevice ^ (PortDevice - 1)) + 1) >> 1;

        i = 0;
        while((testDevice >> i) != 1)
            i++;

        pEDID = &(pcbe->devEDID[i]);
        if(pEDID->realEDIDbuf.EdidBufferLen != 0)
        {   
            preCheckSum = pEDID->realEDIDbuf.EdidBuffer[0x7F];
            memcpy(pCBParamGetEdid->EdidBuffer, pEDID->realEDIDbuf.EdidBuffer, pEDID->realEDIDbuf.EdidBufferLen);
            pCBParamGetEdid->EdidBufferLen = pEDID->realEDIDbuf.EdidBufferLen;
            break;
        }
        PortDevice ^= testDevice;
    }

    if(PortDevice == 0) // means no previous EDID
        return status;

    i2c.I2cPort = PDIPort->PortInfo.I2CPort;
    i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
    i2c.RegIndex = 0x7F;

    switch(PDIPort->PortInfo.TXType)
    {
        case AD9389B:
            i2c.SlaveAddr = 0xA0;
            I2C_Read_Byte_INV(pcbe, &i2c);
            curCheckSum = i2c.IndexData;
            break;
            
        case INTERNAL_DP:
            i2c.SlaveAddr = 0xA0;
            cbHDMII2CReadByte(pcbe, &i2c);
            curCheckSum = i2c.IndexData;
            break;
            
        default :
            break;
    }

    if(preCheckSum == curCheckSum)
        status = TRUE;

    return status;
}

//----------------------------------------------------------------------------
// cbGetEDID_UMA
//      This function fills the buffer with real EDID value passed by PCBIOS_PARAM_GET_EDID
//  structure. This function likes the VBE/DDC function (spec2.0). We get EDID from 
//  DDC 2B level(support uni-direction I2C), and will read EDID from subaddress 0xA0
//  (general case), from 0xA2( P & D device) or 0xA6 (DFPI device). 
//      Since now our CBIOS can only handle EDID 1.X we will only parse EDID 1.X version
//  while for EDID 2.0 function just return.
//  
//  OUT : 
//      pCBParamGetEdid : device EDID buffer structure  
//          
//----------------------------------------------------------------------------
BOOL cbGetEDID_UMA(
    PCBIOS_EXTENSION pcbe, 
    OUT PCBIOS_PARAM_GET_EDID pCBParamGetEdid)
{
    BOOL status = TRUE;
    I2C_CONTROL_UMA i2c;
    BYTE EDIDVersion = EDID_NONE;
    ULONG bufferlen, i;
     //default assume HDMI is power on
    BOOL  bAD9389PowerOFF = FALSE;
    PCBIOS_DEV_EDID pEDID = NULL;
    PDigitalPortInfo PDIPort = NULL;
	ULONG encodertype = 0;

    i2c.Flags = 0;
    
    if (!pCBParamGetEdid || !pCBParamGetEdid->EdidBuffer)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    //TV / HDTV do not have EDID
    if(pCBParamGetEdid->DisplayDeviceDWord & (S3_TV | S3_HDTV))
    {
        cbDbgPrint(1, "TV / HDTV do not have EDID!\n");
        return FALSE;
    }

    //CRT2 do not have EDID except CH7301
    if(pCBParamGetEdid->DisplayDeviceDWord & S3_CRT2)
    {
        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return FALSE;
        }

        if(encodertype != CH7301)
        {
            cbDbgPrint(1, "CRT2 do not have EDID!\n");
            return FALSE;
        }
    }
    
    // get dev EDID storage data addr
    pEDID = &( pcbe->devEDID[cbGetLowestBitPos(pCBParamGetEdid->DisplayDeviceDWord)] );
    // get dev port to get dev Int/I2C
    if (!cbGetDIPortInfo(pcbe, &PDIPort, pCBParamGetEdid->DisplayDeviceDWord))
    {
        cbDbgPrint(1, "can not get device DI port information. \n");
        return FALSE;
    }

    //If device support Hot plug interrupt, and hotplug interrupt not happen since last time get EDID buffer
    //Then we will just return EDID buffer, We only get real device's EDID if NOT support hotplug interrupt or hotplug happened
    if(PDIPort->bIsEDIDUpdated)
    {
        unsigned long EDID_BufferSize;
        if (pEDID->realEDIDbuf.EdidBufferLen == 0)
        {
            //Currently, device not connected or has no EDID
            return FALSE;
        }

        if (pCBParamGetEdid->EdidBufferLen < pEDID->realEDIDbuf.EdidBufferLen)
        {
            //Driver is older than cbios, so use driver's buffer size
            EDID_BufferSize = pCBParamGetEdid->EdidBufferLen;
        }
        else
        {
            //Driver is not older than cbios, so use what we can take as buffer size
            EDID_BufferSize = pEDID->realEDIDbuf.EdidBufferLen;
        }
        memset(pCBParamGetEdid->EdidBuffer, 0, EDID_BufferSize); // clear structure
        memcpy(pCBParamGetEdid->EdidBuffer, pEDID->realEDIDbuf.EdidBuffer, EDID_BufferSize);
        pCBParamGetEdid->EdidBufferLen = EDID_BufferSize;
        return TRUE;
    }

    // In case of using EDP on DP2, if DP2 power signal turn off, we must turn the power(VDD) on for getting EDID info
    if(pcbe->devicepowerstate[DP2bit] == S3PM_OFF && pCBParamGetEdid->DisplayDeviceDWord == S3_DP2)
		cbControlVDDSignalForEDP(pcbe, TRUE);
    
    // Ad9389 will power down itself when HPD happened.
    // We have to power on it before trying to read EDID.
    if (PDIPort->PortInfo.TXType==AD9389B)
    {
        //Below case means : 9389 has connected a device
        i2c.I2cPort = PDIPort->PortInfo.I2CPort;
        i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
        // If turn on AD9389, it will buffer device's EDID automatically

        i2c.RegIndex = 0x41;
        I2C_Read_Byte_INV(pcbe, &i2c);
        if(i2c.IndexData & BIT6)// AD9389 is power off
        {
            bAD9389PowerOFF = TRUE;
            pcbe->TurnOnAD9389ing = TRUE;
            //We just turn on AD9389 0x41[6] = 0;
            i2c.IndexData = 0x10;  //Power on
            I2C_Write_Byte_INV(pcbe, &i2c);   
        }

        // Here we check 0xC5[4] (EDID_Ready_Flag) instead of 0x96[2] (EDID_READY_Interrupt).
        // Because interrupt might happen only once, but we may try to get EDID many times.
        i = 0;
        i2c.RegIndex = 0xC5;
        do
        {
            cbDelayMicroSeconds(10000);
            I2C_Read_Byte_INV(pcbe, &i2c);
            i++;
        }
        while(!(i2c.IndexData & BIT4) && i < 10);
            
        i2c.RegIndex  = 0x43;
        i2c.IndexData = 0xA0;  //Assign DDC port as A0
        I2C_Write_Byte_INV(pcbe, &i2c);
    }
    // 2.---------------- get EDID subaddr & EDID length ----------------------
    // for EDID 1.x 0x7E stores EDID Extansion flag
    // for EDID 2.x 0x7E stores Map of Timing info
    i2c.I2cPort = PDIPort->PortInfo.DDCPort;
    i2c.RegIndex = 0x7E; 

    // DDC2B basic capiblity 
    // read EDID1.X I2C subAddr should be 0xA0
    // EDID1.X takes the first priority since our CBIOS can only
    // pareser EDID 1.X datastructure
    i2c.SlaveAddr = 0xA0;
    for (i = 0; i < DDCMAXTRIES; i++)
    {
        if (I2C_Read_Byte_INV(pcbe, &i2c) == TRUE)
        {
            EDIDVersion = EDID1_X;
            break;
        }
    }

    if( PDIPort->PortInfo.TXType == INTERNAL_DP && 
       (pCBParamGetEdid->DisplayDeviceDWord == S3_HDMI || 
        pCBParamGetEdid->DisplayDeviceDWord == S3_DVI ||
        pCBParamGetEdid->DisplayDeviceDWord == S3_DVI2) )
    {
        if(cbHDMII2CReadByte(pcbe, &i2c) == TRUE)
        {
            EDIDVersion = EDID1_X;
        }
    }

    if( pCBParamGetEdid->DisplayDeviceDWord & (S3_DP | S3_DP2) )
    {
        AUX_CONTROL_UMA AUX;
        AUX.Function = I2C_READ;
        AUX.I2cPort = 0xA0;
        AUX.Length = 0x01;
        AUX.Offset = 0x7E;
        
        if(pCBParamGetEdid->DisplayDeviceDWord == S3_DP)
        {
            if(cbDPAuxChRW(pcbe, &AUX, DP1))
                EDIDVersion = EDID1_X;
        }
                
        if(pCBParamGetEdid->DisplayDeviceDWord == S3_DP2)
        {
            if(cbDPAuxChRW(pcbe, &AUX, DP2))
                EDIDVersion = EDID1_X;
        }

        i2c.IndexData = AUX.Data[0];
    }

    if (EDIDVersion == EDID1_X)
    {   
        // for EDID 1_X we return both base block & extension block
        bufferlen = EDID1_X_BLOCKSIZE * (i2c.IndexData + 1);
    }
    else if (EDIDVersion == EDID2_0)
    {
        // now for EDID 2.0 we just return first 256 Byte block
        // no extansion block
        bufferlen = EDID2_0_BLOCKSIZE;
    }
    else
    {
        // no EDID case set buffer len to zero
        bufferlen = 0;
        status = FALSE;
    }

    // current we only support 512 bytes EDID data
    if(bufferlen > 512)
        return FALSE;

    bufferlen = (pCBParamGetEdid->EdidBufferLen > bufferlen) ? 
                 bufferlen : pCBParamGetEdid->EdidBufferLen;
    
    // 3.-------------------read & check EDID checksum-------------------------
    if (EDIDVersion == EDID1_X)
    {
        BYTE blocknum;
        ULONG flags = 0;

        // We support panel have correct fail EDID checksum feature
        if((pCBParamGetEdid->DisplayDeviceDWord & S3_LCD) && 
            (pcbe->pVCPInfo->miscConfigure2 & LCD_NOT_VERIFY_CHECKSUM))
        {
            flags = CORRECT_FAIL_EDID;
        }
        else if((pCBParamGetEdid->DisplayDeviceDWord & (S3_DVI+S3_DVI2+S3_HDMI2+S3_HDMI)) && 
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_DVI_NOT_VERIFY_CHECKSUM))
        {
            flags = CORRECT_FAIL_EDID;
        }
        else
        {
            flags = VERIFY_CHECKSUM;
        }
        
        // EDID 1.x : read & test every 128 byte as one block
        if(PDIPort->PortInfo.TXType == INTERNAL_DP && 
            (pCBParamGetEdid->DisplayDeviceDWord == S3_HDMI || 
             pCBParamGetEdid->DisplayDeviceDWord == S3_DVI ||
             pCBParamGetEdid->DisplayDeviceDWord == S3_DVI2) )
        {                  
            cbHDMII2CReadBytes(pcbe, &i2c, (PBYTE)pCBParamGetEdid->EdidBuffer, bufferlen);                                            
        }
        else if(pCBParamGetEdid->DisplayDeviceDWord == S3_DP || pCBParamGetEdid->DisplayDeviceDWord == S3_DP2)
        {            
            AUX_CONTROL_UMA AUX;
            BYTE checksum = 0;
            AUX.Function = I2C_READ;
            AUX.I2cPort = 0xA0;
            AUX.Length = 0x01;

            for(i = 0; i < bufferlen; i++)
            {
                AUX.Offset = i;
                if(pCBParamGetEdid->DisplayDeviceDWord == S3_DP)
                    cbDPAuxChRW(pcbe, &AUX, DP1);
                if(pCBParamGetEdid->DisplayDeviceDWord == S3_DP2)
                    cbDPAuxChRW(pcbe, &AUX, DP2);

                if( (i % 128) == 0x7F)
                {
                    *(pCBParamGetEdid->EdidBuffer + i) = (0x100 - checksum);
                    checksum = 0;
                }
                else    
                {
                    *(pCBParamGetEdid->EdidBuffer + i) = AUX.Data[0];
                    checksum += AUX.Data[0];   
                }
            }

            
            //memcpy((PBYTE)pCBParamGetEdid->EdidBuffer, FAKEDPEDID, 128);

        }
        else 
        {
            for (blocknum = 0; blocknum < (bufferlen >> 7); blocknum++)
            {
                i2c.RegIndex = (BYTE) 0x80 * blocknum;
                if (FALSE == I2C_Data_Request_INV(pcbe,
                                                  &i2c,
                                                  EDID1_X_BLOCKSIZE,
                                                  flags,
                                                  (PBYTE)pCBParamGetEdid->EdidBuffer + EDID1_X_BLOCKSIZE * blocknum))
                {   
                    // if one block read error do not return remaining EDID blocks
                    break;
                }
            }

            // a safe guard to prevent bufferlen=0 then there will be a access violation cause driver crash
            if(blocknum == 0)
            {
                blocknum = 1;
            }
            
            bufferlen = EDID1_X_BLOCKSIZE * blocknum;
        }

        //for HDMI 4-block EDID read
        if(*(pCBParamGetEdid->EdidBuffer + 0x7E) > 1)
        {
            cbGetFourBlockEDID(pcbe, &i2c, PDIPort, flags, pCBParamGetEdid);
        }
        
#if CEAModeTest
        // HDMI CEA modes test, we will use fake EDID at block 1
        if( (pCBParamGetEdid->DisplayDeviceDWord == S3_HDMI ||
            (pCBParamGetEdid->DisplayDeviceDWord == S3_DVI && PDIPort->PortInfo.TXType == AD9389B) ||
            (pCBParamGetEdid->DisplayDeviceDWord == S3_DVI2 && PDIPort->PortInfo.TXType == AD9389B))
            && bufferlen > 128)
        {
            memcpy((PBYTE)pCBParamGetEdid->EdidBuffer + EDID1_X_BLOCKSIZE, FAKESVDEDID, 128);
        }   
#endif

        // we must update all device EDID on this I2C line (DI port)
        cbUpdateAllDevRealEDIDOnDIPort(pcbe, PDIPort, pCBParamGetEdid->EdidBuffer, bufferlen);
        if (0 == pEDID->realEDIDbuf.EdidBufferLen)
        {
            status = FALSE;
        }

        if ((pCBParamGetEdid->DisplayDeviceDWord & (S3_LCD))||(pCBParamGetEdid->DisplayDeviceDWord & (S3_LCD2)))
        {
            int csum=0;
            PEDID_BLOCK0_DATA_UMA pEDIDBlock_0_Data = (EDID_BLOCK0_DATA_UMA*)pCBParamGetEdid->EdidBuffer;
            // aid for established timing table
            pEDIDBlock_0_Data->EstTimings[0] |= (BIT0 | BIT5);
            pEDIDBlock_0_Data->EstTimings[1] |= BIT3;
            // Correct Checksum
            for (i=0; i<bufferlen-1; i++)
            {
                csum += ((UCHAR *)pEDIDBlock_0_Data)[i];
            }    
            pEDIDBlock_0_Data->Checksum = (UCHAR)(0x100 - (csum & 0xFF));
        } // if LCD or LCD2
    }
    else if (EDIDVersion == EDID2_0)
    {
        // EDID 2.0 just read bufferlen (bufferlen <= 256) & do checksum
        i2c.RegIndex = 0x00;
        if (FALSE == I2C_Data_Request_INV(pcbe,
                                          &i2c,
                                          bufferlen,
                                          VERIFY_CHECKSUM,
                                          pCBParamGetEdid->EdidBuffer))
        {                                  
            status = FALSE;
        }
    }
    // 4. -------------------------------------------------------------
    // if I2C read error or checksum not right(invalid EDID)
    // or EDID version >= 2.0 can not be parsed by CBIOS
    if (status != TRUE || EDIDVersion != EDID1_X || bufferlen == 0)
    {
        cbDbgPrint(1, "EDID read error or Can not parse EDID2.0 !\n");
        if (pEDID->bFakeEDID)
        {
            // fake EDID valid, just set real EDID buffer to zero
            memset(&(pEDID->realEDIDbuf), 0, sizeof(CBIOS_EDID_BUFFER));
        }
        else
        {
            // set all EDID info to zero
            memset(pEDID, 0, sizeof(CBIOS_DEV_EDID));
        }
    }
    if(status)
    {
        //Copy EDID to Cbios EDID buffer, update EDID Buffer length
        //Always save EDID buffer even if we can not parser it, because drive may still need it
        pEDID->realEDIDbuf.EdidBufferLen = bufferlen;
        pCBParamGetEdid->EdidBufferLen = bufferlen;
        memset(pEDID->realEDIDbuf.EdidBuffer, 0, MAX_EDID_SIZE); // clear structure
        memcpy(pEDID->realEDIDbuf.EdidBuffer, pCBParamGetEdid->EdidBuffer, bufferlen);
    }

    if((pCBParamGetEdid->type != EDID_ANALOG) && (PDIPort->bHPDInterrpted && status))
    {
        // If HDP interrupted, then after getting EDID, set it to be updated
        PDIPort->bIsEDIDUpdated = TRUE;
    }
    
    // restore AD9389 power state
    if(PDIPort->PortInfo.TXType==AD9389B)
    {
        i2c.I2cPort = PDIPort->PortInfo.I2CPort;
        i2c.SlaveAddr = PDIPort->PortInfo.I2CSubAddr;
        if(bAD9389PowerOFF)
        {
            cbHDMIClear_AV_Mute(pcbe,i2c);
            i2c.RegIndex  = 0x41;
            i2c.IndexData = 0x50;  //Turn power off
            I2C_Write_Byte_INV(pcbe, &i2c);
            pcbe->TurnOnAD9389ing = FALSE;
        }
    }

    // In case of using EDP on DP2, if DP2 power signal original status is off, 
    // we must turn the power off (DP2 VDD) after geeting EDID info.
    if(pcbe->devicepowerstate[DP2bit] == S3PM_OFF && pCBParamGetEdid->DisplayDeviceDWord == S3_DP2)
		cbControlVDDSignalForEDP(pcbe, FALSE);	

    return status;
}

//*****************************************************************************
//
//  cbEDIDParser_UMA
//
//  Parser device EDID
//  Get Established, Standard & Detailed Timing
//
//  Parameters:
//      EDIDBuffer:     contain EDID data
//      EDIDStruct:     return parsered EDID info
//
//  Return Value:
//      None
//
//*****************************************************************************
static BYTE const EDID1_Xheader[] = {0x00, 
                                   0xFF, 
                                   0xFF, 
                                   0xFF, 
                                   0xFF, 
                                   0xFF, 
                                   0xFF, 
                                   0x00};

static CBIOS_S3MODE_INFO const EstTiming[] = {
    { 800,  600,  6000,  1 },       // EDID23h[0]: 800x600@60Hz
    { 800,  600,  5600,  0 },       // EDID23h[1]: 800x600@56Hz
    { 640,  480,  7500,  1 },       // EDID23h[2]: 640x480@75Hz
    { 640,  480,  7200,  1 },       // EDID23h[3]: 640x480@72Hz
    { 640,  480,  6700,  0 },       // EDID23h[4]: 640x480@67Hz
    { 640,  480,  6000,  1 },       // EDID23h[5]: 640x480@60Hz
    { 720,  400,  8800,  0 },       // EDID23h[6]: 720x400@88Hz
    { 720,  400,  7000,  0 },       // EDID23h[7]: 720x400@70Hz
    { 1280, 1024, 7500,  1 },       // EDID24h[0]: 1280x1024@75Hz
    { 1024, 768,  7500,  1 },       // EDID24h[1]: 1024x768@75Hz
    { 1024, 768,  7000,  1 },       // EDID24h[2]: 1024x768@70Hz
    { 1024, 768,  6000,  1 },       // EDID24h[3]: 1024x768@60Hz
    { 1024, 768,  8700,  0 },       // EDID24h[4]: 1024x768@87HzInterlace
    { 832,  624,  7500,  0 },       // EDID24h[5]: 832x624@75Hz
    { 800,  600,  7500,  1 },       // EDID24h[6]: 800x600@75Hz
    { 800,  600,  7200,  1 },       // EDID24h[7]: 800x600@72Hz
};


//--------------------------------------------------------------------------
// cbClearEDIDBuf
//
//  This function is used to clear specified device's EDID buffer in pcbe. Now if we
//  find device is disconnected when sense, we should clear corresponding EDID buffer.
//
//  IN: 
//      device
//  Ret:
//      TRUE or FALSE
//--------------------------------------------------------------------------
BOOL cbClearEDIDBuf(PCBIOS_EXTENSION pcbe, DWORD device)
{
    ULONG encodertype;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(device)] );

    //TV / HDTV do not have EDID
    if(device & (S3_TV | S3_HDTV))
    {
        cbDbgPrint(1, "TV / HDTV do not have EDID!\n");
        return FALSE;
    }

    //CRT2 do not have EDID except CH7301
    if(device & S3_CRT2)
    {
        // get CRT2 associated TxType
        if (cbGetDIEncodertype(pcbe, &encodertype, S3_CRT2) == FALSE)
        {
            cbDbgPrint(1, "Can not find device associate encode in DI port info!\n");
            return FALSE;
        }

        if(encodertype != CH7301)
        {
            cbDbgPrint(1, "CRT2 do not have EDID!\n");
            return FALSE;
        }
    }

    if (pEDID->bFakeEDID)
    {
        // using fake EDID, just clear device's real EDID buffer
        memset(&(pEDID->realEDIDbuf), 0, sizeof(CBIOS_EDID_BUFFER));
    }
    else
    {
        // clear all port EDID info
        memset(pEDID, 0, sizeof(CBIOS_DEV_EDID));
    }

    return TRUE;

}

//--------------------------------------------------------------------------
// cbEDIDParser_UMA
//
//     cbEDIDParser_UMA now supports EDID1_X 
//  1. Block 0 : first 128 Bytes block parse the process comes into 3 parts: 
//      1. EST timing 2. STD timing 3. Detailed timing. 
//  2. Block 1, 2, 3 : now function just parse CEA extansion block
//      now we just parser CEA extansion block 1
//  Parsed EDID info will store in CBIOS data structure.
//  
//  IN 
//      EDIDBuffer  :  EDID data buffer 
//      Length      :  EDID data buffer length (can not be less than 128 Bytes)
//      pEDIDInfo  :  EDID info structure
//  
//--------------------------------------------------------------------------
BOOL cbEDIDParser_UMA(PCBIOS_EXTENSION pcbe, 
    IN void* EDIDBuffer, 
    IN ULONG Length,
    OUT CBIOS_EDID_INFO* pEDIDInfo)
{
    PEDID_BLOCK0_DATA_UMA pEDIDBlock_0_Data = (EDID_BLOCK0_DATA_UMA*)EDIDBuffer;
    PBYTE pEDIDBlock_Ext_Data = (PBYTE)EDIDBuffer + EDID1_X_BLOCKSIZE;
    ULONG i, j, SVDcounter = 0;
    WORD EDIDESTModeList;
    PDETAILEDTIMING pDetailedTiming = NULL;

    if (!EDIDBuffer || !pEDIDInfo)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (Length < 128 || Length > 256)
    {
        cbDbgPrint(0, "EDID buffer length = %d!\n", Length);
        ASSERT(FALSE);
        Length = (Length < 128) ? 0 : 256;
    }

    // the EDID1_x data Length shound be n*128 
    if ((Length == 0) || (Length & 0x7F) != 0)
    {
        return FALSE;
    }
    
    //*************************************************************************
    //                       Base Block (Block 0) parse
    //*************************************************************************
    // when we check EDID 1.x version
    // 1. check EDID header first
    for (i = 0; i < 8; i++)
    {
        if (pEDIDBlock_0_Data->Header[i] != EDID1_Xheader[i])
        {
            return FALSE;
        }
    }

    // add this code to prevent EDID invalid case
    if(pEDIDBlock_0_Data->EDIDVersion[0] >= 4)
    {
        return FALSE;
    }
    
    pEDIDInfo->EDIDVersion = EDID1_X;
    
    
    // 2. Setup Established Timing Table  
    EDIDESTModeList = (WORD)(pEDIDBlock_0_Data->EstTimings[1]<<8) +
                      (WORD)(pEDIDBlock_0_Data->EstTimings[0]);
    for(i = 0; i < 16; i++)
    {
        pEDIDInfo->EstTimings[i] = EstTiming[i];

        // if VESAVPIT do not support this EST timing
        // set this establish timing to zero
        if (!( EDIDESTModeList & (1<<i))) 
        {
            pEDIDInfo->EstTimings[i].Valid = 0;
        }
    }
    
    
    // 3. Setup Standard Timing Table
    for (i = 0; i < 8; i++)
    {
        // according to EDID 1.3 spec
        // unused field in std mode should be set as 0x01, 0x01
        if(pEDIDBlock_0_Data->StdTimingIDs[i*2] == 0x01)
        {
            pEDIDInfo->StdTimings[i].Valid = 0;
        }
        else
        {
            pEDIDInfo->StdTimings[i].Valid = 1;
            pEDIDInfo->StdTimings[i].XResolution = 
                (WORD)( pEDIDBlock_0_Data->StdTimingIDs[2*i] + 31 ) * 8; 
            pEDIDInfo->StdTimings[i].rrateX100 =
                ((pEDIDBlock_0_Data->StdTimingIDs[2*i+1] & 0x3F) + 60)*100;
        
            switch( ( (pEDIDBlock_0_Data->StdTimingIDs[2*i+1]& 0xC0) >> 6) )//Image Aspect ratio
            {
            case 0: // 16:10 Aspect ratio
                pEDIDInfo->StdTimings[i].YResolution = pEDIDInfo->StdTimings[i].XResolution /16 * 10;
                break;
            case 1: // 4:3 Aspect ratio
                pEDIDInfo->StdTimings[i].YResolution = pEDIDInfo->StdTimings[i].XResolution /4 * 3;
                break;
            case 2: // 5:4 Aspect ratio
                pEDIDInfo->StdTimings[i].YResolution = pEDIDInfo->StdTimings[i].XResolution /5 * 4;
                break;
            case 3: // 16:9 Aspect ratio
                pEDIDInfo->StdTimings[i].YResolution = pEDIDInfo->StdTimings[i].XResolution /16 * 9;
                break;
            }
        }

        // add this code to prevent EDID invalid case
        if(pEDIDInfo->StdTimings[i].XResolution > 2048)
        {
            pEDIDInfo->StdTimings[i].Valid = 0;
            continue;
        }
    }
    
    
    // 4. Setup Detailed Timing table
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {   
        // Detailed Timing Descriptor (18 Byte each)
        cbEDIDDTDParse(pcbe, &pEDIDInfo->DtlTimings[i], &pEDIDBlock_0_Data->DtlTimings[i]);
    }


    // invalidate all the CEA extension timing info first
    // now CBIOS only have one extension info datastructure, clear it first 
    // everytime before parse CEA extension block
    memset(&(pEDIDInfo->CEABlock_1), 0, sizeof(CEA_EXTANSION_EDIDINFO));

    //*************************************************************************
    //                          Block 1, 2.... parse
    //          now only parse EDID CEA extansion block Tag 0x02
    //*************************************************************************
    for (i = EDID1_X_BLOCKSIZE; i < Length; i += EDID1_X_BLOCKSIZE)
    {
        // now CBIOS only parse CEA extansion block
        if (pEDIDBlock_Ext_Data[0x00] == EDID_CEAEXTENSION_TAG)
        {
             // Get the extension tag
            pEDIDInfo->CEABlock_1.CEA861MiscAttrib.Tag = pEDIDBlock_Ext_Data[0x00];
            pEDIDInfo->CEABlock_1.CEAExtBlockTag = pEDIDBlock_Ext_Data[0x00];
            // Get the extension block revision 
            pEDIDInfo->CEABlock_1.CEA861MiscAttrib.RevisionNumber = pEDIDBlock_Ext_Data[0x01];
            // Get the offset of the DTD
            pEDIDInfo->CEABlock_1.CEA861MiscAttrib.OffsetOfDetailedTimingBlock = pEDIDBlock_Ext_Data[0x02];

            // info for Version 1.3 and above
            if (pEDIDInfo->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
            {
                DWORD datablockoffset;

                // 1. Get the total number of native format in DTD and also 
                // indication of underscan support, audio support and support of YCbCr
                pEDIDInfo->CEABlock_1.CEA861MiscAttrib.TotalNumberOfNativeFormat = 
                              pEDIDBlock_Ext_Data[0x03] & NUM_OF_NATIVE_DTD_MASK; 
                pEDIDInfo->CEABlock_1.CEA861MiscAttrib.IsSupportYCbCr422 = 
                             (pEDIDBlock_Ext_Data[0x03] & YCbCr422_CAP_MASK) >> 4;   
                pEDIDInfo->CEABlock_1.CEA861MiscAttrib.IsSupportYCbCr444 = 
                             (pEDIDBlock_Ext_Data[0x03] & YCbCr444_CAP_MASK) >> 5;
                pEDIDInfo->CEABlock_1.CEA861MiscAttrib.IsSupportBasicAudio = 
                             (pEDIDBlock_Ext_Data[0x03] & BASIC_AUDIO_CAP_MASK) >> 6;
                pEDIDInfo->CEABlock_1.CEA861MiscAttrib.IsSupportUnderScan = 
                             (pEDIDBlock_Ext_Data[0x03] & UNDERSCAN_CAP_MASK) >> 7;

                // 2. Data block info parse
                // According to CEA861, the order of data blocks is not constrained, so check them all
                // actually CEA861 assumes the existance of same CEA data block type, now we just deal with 1
                for (datablockoffset = 0x04; 
                     datablockoffset < pEDIDInfo->CEABlock_1.CEA861MiscAttrib.OffsetOfDetailedTimingBlock; 
                     /*none*/)
                {
                    if ((pEDIDBlock_Ext_Data[datablockoffset] & 0xE0) == (VIDEO_DATA_BLOCK_TAG << 5))
                    {
                        // Video Data Block 
                        // Include one or more SVDs
                        for (j = 0; j < (DWORD)(pEDIDBlock_Ext_Data[datablockoffset] & 0x1F); j++)
                        {
                            // SVD BIT 7 native format
                            if (pEDIDBlock_Ext_Data[datablockoffset+j+1] & BIT7)
                            {
                                pEDIDInfo->CEABlock_1.ShortVideoDescriptor[SVDcounter].IsNativeMode = TRUE;
                            }
                            // SVD BIT[6:0] Video Identification Code
                            pEDIDInfo->CEABlock_1.ShortVideoDescriptor[SVDcounter].SVD = pEDIDBlock_Ext_Data[datablockoffset+j+1] & 0x7F;
                            SVDcounter++;
                        }
                    }
                    else if ((pEDIDBlock_Ext_Data[datablockoffset] & 0xE0) == (VENDOR_SPECIFIC_DATA_BLOCK_TAG << 5))
                    {
                        // Vendor Specific Data Block
                        // 24-bit IEEE Registration display device interface(HDMI / DVI ...)
                        if((pEDIDBlock_Ext_Data[datablockoffset+1] == 0x03) 
                        && (pEDIDBlock_Ext_Data[datablockoffset+2] == 0x0C)
                        && (pEDIDBlock_Ext_Data[datablockoffset+3] == 0x00))
                        {
                            pEDIDInfo->CEABlock_1.CEA861MiscAttrib.IsHDMIDevice = TRUE;
                        }
                    }       

                    if ( (pEDIDBlock_Ext_Data[datablockoffset] & 0xE0) == (SPEAKER_ALLOCATION_DATA_BLOCK_TAG << 5) )
                    {
                        // SPEAKER_ALLOCATION_DATA_BLOCK length fix to 4 (include tag)
                        datablockoffset += 4;
                    }
                    else
                    {
                        datablockoffset += (pEDIDBlock_Ext_Data[datablockoffset] & 0x1F) + 1;
                    }
                }
            }

           
            // Setup DTD table from CEA 861 extansion block  
            //      V1.1 only use DTD 
            //      V1.3 takes SVD as first priority
            if (pEDIDInfo->CEABlock_1.CEA861MiscAttrib.OffsetOfDetailedTimingBlock != 0)
            {                 
                // base on available room size, get potential DTD number 
                DWORD maxDTDNum = (128 - pEDIDInfo->CEABlock_1.CEA861MiscAttrib.OffsetOfDetailedTimingBlock) / 18;
                
                // get DTD block starting address
                pDetailedTiming = (PDETAILEDTIMING)(pEDIDBlock_Ext_Data + 
                                  pEDIDInfo->CEABlock_1.CEA861MiscAttrib.OffsetOfDetailedTimingBlock); 
                
                for (j = 0; j < maxDTDNum; j++)
                {   
                    // Parse Extension block Detailed Timing Descriptor DTD (18 Bytes each)
                    // according to CEA861 spec, source device should be capable of skipping
                    // additional extensions that they can not understand when encountered within block1
                    if (cbEDIDDTDParse(pcbe, &pEDIDInfo->CEABlock_1.DtlTimings[j], &pDetailedTiming[j]) == FALSE)
                    {
                        break;
                    }
                }
            }
            
            // now we only parse and store first CEA extansion block
            break;
        }

        pEDIDBlock_Ext_Data += EDID1_X_BLOCKSIZE;
    }

    return TRUE;
}

//--------------------------------------------------------------------------
// cbEDIDDTDParse
//    This function parse EDID DTD (detailed timing descriptor) 18 byte each
//  and store the info to CBIOS info data structure
//  IN :
//      pCBiosDTDInfo : CBIOS datastructure to store datailed timing descriptor
//      pDetailedTimingData : detailed timing from EDID data(18 Byte each)
//      
//  OUT :
//      function status
//--------------------------------------------------------------------------
BOOL cbEDIDDTDParse(PCBIOS_EXTENSION pcbe, 
    OUT PEDID_DETAILEDTIMING_INFO pCBiosDTDInfo,
    IN  PDETAILEDTIMING pDetailedTimingData)
{
    DWORD EDIDPixelClk;
    DWORD RatioX100 = 0;

    if (!pCBiosDTDInfo || !pDetailedTimingData)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // if not a detailed timing block ( pixel clock is set to 0 means it's a 
    // monitor descriptor description block. So skip this detailed timing block parse 
    if(pDetailedTimingData->PixelClock[0] == 0 
    && pDetailedTimingData->PixelClock[1] == 0)
    {
        pCBiosDTDInfo->Valid = 0;
        return FALSE;
    }

    pCBiosDTDInfo->Valid = 1;
    
    // ------------------ 4.1 Pixel clock / 10,000 stores LSB first 
    EDIDPixelClk = ( (WORD)(pDetailedTimingData->PixelClock[1] << 8)
            + pDetailedTimingData->PixelClock[0] ) * 10000; 
    
    pCBiosDTDInfo->PLL_MRN =  cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, EDIDPixelClk);

    //*******************************  HORIZONTAL  ************************************                                        
    // ------------------ 4.2 Horizontal Active 
    pCBiosDTDInfo->HActive  = (WORD) pDetailedTimingData->HActive
            + ((pDetailedTimingData->HActive_Blank & H_ACTIVE_HIGHTBITS_MASK) << 4);
    pCBiosDTDInfo->XResolution = pCBiosDTDInfo->HActive;
    
    // ------------------ 4.3 Horizontal Blanking                                     
    pCBiosDTDInfo->HBlank = (WORD) pDetailedTimingData->HBlank
            + ((pDetailedTimingData->HActive_Blank & H_BLANK_HIGHTBITS_MASK) << 8);
                                                     
    // ------------------ 4.4 Horizontal Sync Offset                                            
    pCBiosDTDInfo->HSyncOffset = (WORD) pDetailedTimingData->HSyncOffset 
            + ((pDetailedTimingData->HVSyncOffset_Width & H_SYNCOFFSET_HIGHBITS_MASK) << 2);
                                        
    // ------------------ 4.5 Horizontal Sync Pulse Width
    pCBiosDTDInfo->HSyncPulseWidth = (WORD) pDetailedTimingData->HSyncWidth
            + ((pDetailedTimingData->HVSyncOffset_Width & H_SYNCWIDTH_HIGHBITS_MASK) << 4);

    //*******************************  VERTICAL  ************************************ 
    // ------------------ 4.6 Vertical Active 
    pCBiosDTDInfo->VActive =  (WORD) pDetailedTimingData->VActive
            + ((pDetailedTimingData->VActive_Blank & V_ACTIVE_HIGHTBITS_MASK) << 4);
    pCBiosDTDInfo->YResolution = pCBiosDTDInfo->VActive;

    // ------------------ 4.7 Vertical Blanking
    pCBiosDTDInfo->VBlank = (WORD) pDetailedTimingData->VBlank
            + ((pDetailedTimingData->VActive_Blank & V_BLANK_HIGHTBITS_MASK) << 8);

    // ------------------ 4.8 Vertical Sync Offset
    pCBiosDTDInfo->VSyncOffset = (WORD) ((pDetailedTimingData->VSyncOffset_Width & V_SYNCOFFSET_LOWBITS_MASK) >> 4)
            + ((pDetailedTimingData->HVSyncOffset_Width & V_SYNCOFFSET_HIGHBITS_MASK) << 2);
                                        
    // ------------------ 4.9 Vertical Sync Pulse Width
    pCBiosDTDInfo->VSyncPulseWidth = (WORD) (pDetailedTimingData->VSyncOffset_Width & V_SYNCWIDTH_LOWBITS_MASK) 
            + ((pDetailedTimingData->HVSyncOffset_Width & V_SYNCWIDTH_HIGHBITS_MASK) << 4);
                                        
    // ------------------ 4.10 H / V Border 
    // for EDID std H/V border is one part of H/V blanking
    pCBiosDTDInfo->HBorder = pDetailedTimingData->HBorder;
    pCBiosDTDInfo->VBorder = pDetailedTimingData->VBorder;

    // ------------------ 4.11 Refresh rate X 100
    {
        DWORD Htotal_x_Vtotal =
            (pCBiosDTDInfo->HActive + pCBiosDTDInfo->HBlank) * (pCBiosDTDInfo->VActive + pCBiosDTDInfo->VBlank);
        if (0 == Htotal_x_Vtotal)
        {
            pCBiosDTDInfo->rRateX100 = 0;
        }
        else
        {
            pCBiosDTDInfo->rRateX100 = (WORD)( EDIDPixelClk / (Htotal_x_Vtotal / 100) );
        }
    }

    // make sure detail timing can meet our VBIOS default refresh rate support
    // when this refresh rate is 59~60 make 60 is default
    if ((pCBiosDTDInfo->rRateX100 >= 5900) &&
        (pCBiosDTDInfo->rRateX100 <= 6000))
    {
        pCBiosDTDInfo->rRateX100 = 6000;
    }
    
    // ------------------ 4.12 H / V Image Size        
    pCBiosDTDInfo->HImageSize = (WORD) pDetailedTimingData->HImageSize
            + ((pDetailedTimingData->HVImageSize & H_IMAGE_HIGHTBITS_MASK) << 4);
    pCBiosDTDInfo->VImageSize = (WORD) pDetailedTimingData->VImageSize
            + ((pDetailedTimingData->HVImageSize & V_IMAGE_HIGHTBITS_MASK) << 8);
                                        
    // ------------------ 4.13 Aspect Ratio
    if (pDetailedTimingData->VImageSize != 0)
    {
        RatioX100 = (DWORD)pCBiosDTDInfo->HImageSize * 100 / (DWORD)pCBiosDTDInfo->VImageSize;
    }

    // get DTD aspect ratio
    pCBiosDTDInfo->AspectRatio = CBIOS_NONE;
    if (120 <= RatioX100 && RatioX100 < 140)
    {
        if (RatioX100 >= 130)
        {
            pCBiosDTDInfo->AspectRatio = CBIOS_RATIO_4_3;
        }
        else
        {
            pCBiosDTDInfo->AspectRatio = CBIOS_RATIO_5_4;
        }
    }
    else if (160 <= RatioX100 && RatioX100 < 180)
    {
        if (RatioX100 >= 170)
        {
            pCBiosDTDInfo->AspectRatio = CBIOS_RATIO_16_9;
        }
        else
        {
            pCBiosDTDInfo->AspectRatio = CBIOS_RATIO_16_10;
        }
    }

    // ------------------ 4.14 H / V Sync Polarity
    // default detailed H / V polartiy positive
    pCBiosDTDInfo->HPolarity = CBIOS_POSITIVE;
    pCBiosDTDInfo->VPolarity = CBIOS_POSITIVE;
    // if detailed timing offset 0x11 bit[4:3] is 1, 1 
    // it means bit[2:1] V / H singal polarity
    if((pDetailedTimingData->Flags & (BIT4 | BIT3)) == (BIT4 + BIT3))
    {
        // HSync / VSync= 1, means HSync is positive.
        // else, means negative. the same as VSync.
        if ((pDetailedTimingData->Flags & BIT2) == 0)
        {
            pCBiosDTDInfo->VPolarity = CBIOS_NEGATIVE;
        }
        if ((pDetailedTimingData->Flags & BIT1) == 0)
        {
            pCBiosDTDInfo->HPolarity = CBIOS_NEGATIVE;
        }
    }

    // ------------------ 4.15 Interlace or Progressive
    if(pDetailedTimingData->Flags & BIT7)
    {
        // for interlaced mode we support V resolution is 
        // twice the real V disp active timing
        pCBiosDTDInfo->Interlaced = INTERLACE;
        pCBiosDTDInfo->YResolution *= 2;
    }
    else
    {
        pCBiosDTDInfo->Interlaced = PROGRESSIVE;            
    }   

    // add this code to prevent EDID invalid case
    if (0 == pCBiosDTDInfo->rRateX100)
    {
        pCBiosDTDInfo->Valid = 0;
    }

    // Special aid for 1360x768@60Hz.
    // For Sharp LC-42D640 monitor, pclk = 85.5MHz, we will choose 85.1931MHz, but it only accepts 85.9090
    if(pCBiosDTDInfo->XResolution == 1360 && pCBiosDTDInfo->YResolution == 768 && EDIDPixelClk == 85500000)
        pCBiosDTDInfo->PLL_MRN = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, 86000000);

    return TRUE;
}

//-----------------------------------------------------------------------
// cbIsDigitalOrAnalogMonitor
//      This function imediately check device EDID match device feature: digital or analog monitor
//   IN :
//      Device : device bit
//  OUT :
//      ptype : EDID Monitor type
//  Return Value:
//      function return status  
//-----------------------------------------------------------------------
BOOL cbIsDigitalOrAnalogMonitor(
        PCBIOS_EXTENSION pcbe,
        IN DWORD Device,
        OUT PEDID_MONITOR_TYPE ptype)
{
    I2C_CONTROL_UMA i2c;
    i2c.Flags = 0;

    if (!cbGetDeviceDDCPort(pcbe, &i2c, Device))
    {
        return FALSE;
    }

    //check EDID Offset 14h for Analog / Digital Signal Level
    i2c.SlaveAddr = 0xA0;
    i2c.RegIndex  = 0x14;
    if (I2C_Read_Byte_INV(pcbe, &i2c))
    {
        if(i2c.IndexData & 0x80)
        {
            // digital monitor connected
            *ptype = EDID_DIGITAL;
        }
        else
        {
            // analog monitor connected
            *ptype = EDID_ANALOG;
        }
        return TRUE;
    }
    return FALSE;
}

//--------------------------------------------------------------------------
// cbUpdateLCD_panel_ID
//
//    cbUpdateLCD_panel_ID Search LCD Panel ID for LCD panel have EDID
//  
//  IN 
//      pEDIDTimingInfo  :  EDID info structure  
//      dispDev : display device 
//
//  
//--------------------------------------------------------------------------

BOOL cbUpdateLCD_panel_ID(
     PCBIOS_EXTENSION pcbe, 
     IN CBIOS_EDID_INFO* pEDIDTimingInfo,
     IN DWORD device)
{
    DWORD i;
    BYTE panelID;
    WORD offsetLCDHeader = pcbe->pVCPInfo->LCDInfoHeader;

    if(offsetLCDHeader == 0)
    {
        return FALSE;
    }
    if (!pEDIDTimingInfo )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // search in 4 detail timings
    for (i=0; i<4; i++)
    {
        DWORD XRes;
        DWORD YRes;
        if ( !(pEDIDTimingInfo->DtlTimings[i].Valid) )
        {
            continue;
        }
        XRes = pEDIDTimingInfo->DtlTimings[i].HActive;
        YRes = pEDIDTimingInfo->DtlTimings[i].VActive;

        // match with 16 panel resolutions
        for (panelID=0; panelID<=MAX_PANELID; panelID++)
        {
            PFPHeaderData pLCDHeader = (PFPHeaderData)&(pcbe->RomData[offsetLCDHeader]);
            WORD offsetLCDEntry = pLCDHeader[panelID].fpEntryPoint;
            WORD offsetLCDTable = *( (WORD*)(pcbe->RomData + offsetLCDEntry));
            PLCDInitTbl pLCDTable = (PLCDInitTbl)&(pcbe->RomData[offsetLCDTable]);

            if ((XRes == pLCDTable->H_DisEnd) && (YRes == pLCDTable->V_DisEnd))
            {
                // found match panel ID, update scrath pad
                if(device == S3_LCD)
                {
                    pcbe->sPad_4.LCD_DVI2_PanelID = panelID;
                }
                else if(device == S3_LCD2)
                {
                    pcbe->sPad_4.DVI_LCD2_PanelID = panelID;
                }
                return TRUE;
            }
        }
    }

    // not found match panel ID
    cbDbgPrint(1, "Can not get EDID Panel ID Information!\n");
    return FALSE;
}

//--------------------------------------------------------------------------
//  cbIsResolutionExistInEDIDSTDTiming
//      This function finds whether there will be fit timing for the given 
//  resolution in EDID std timing. 
//
//  IN :
//     pEDID : EDID info pointer
//     XRes  : resolution X size
//     YRes  : resolution Y size
//  OUT :
//     function return status
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInEDIDSTDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes)
{
    int i;
    
    if (!pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // check in Standard timing
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
            && ( pEDID->StdTimings[i].XResolution == XRes )
            && ( pEDID->StdTimings[i].YResolution == YRes ))
        {
            // resolution exist in Standard timing
            return TRUE;
        }
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbIsResolutionExistInEDIDDetailedTiming
//      This function finds whether there will be fit timing for the given 
//  resolution in Detailed timing. Since there will be interlaced mode, so 
//  we will use Detailed timig supported X, Y resolution to do comparing work
//
//  IN :
//     pEDID : EDID info pointer
//     XRes  : resolution X size
//     YRes  : resolution Y size
//  OUT :
//     function return status
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInEDIDDetailedTiming(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes)
{    
    int i;
    
    if (!pEDID )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // check in detail timing
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->DtlTimings[i].Valid)
            && ( pEDID->DtlTimings[i].XResolution == XRes )
            && ( pEDID->DtlTimings[i].YResolution == YRes ) )
        {
            // resolution exist in EDID
            return TRUE;
        }
    }
    
    return FALSE;
}

//---------------------------------------------------------------------------
//  cbIsResolutionInEDIDEstStdTiming
//      This function checks whether resolution stores in EDID est / std timing
//  IN :
//      pEDID : EDID parser structure
//      XRes  : resoltion y size
//      YRes  : resoltion y size
//  OUT :
//      Function status
//---------------------------------------------------------------------------
BOOL cbIsResolutionInEDIDEstStdTiming(
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes)
{
    int i;

    if (!pEDID )
    {
        ASSERT(FALSE);
        return FALSE;
    }
  
    // check in Standard timing
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
            && ( pEDID->StdTimings[i].XResolution == XRes )
            && ( pEDID->StdTimings[i].YResolution == YRes ))
        {
            // resolution exist in Standard timing
            return TRUE;
        }
    }

    // check in Establish timing
    for (i = 0; i < 16; i++)
    {
        if ( (pEDID->EstTimings[i].Valid)
            && ( pEDID->EstTimings[i].XResolution == XRes )
            && ( pEDID->EstTimings[i].YResolution == YRes ))
        {
            // resolution exist in Establish timing
            return TRUE;
        }
    }

    return FALSE;
}

//----------------------------------------------------------------------
// cbIsTimingInEDIDDetailedTiming
//     This function checks whether timing passed (X, Y refreshrate( interlaced / progressive)
//  exists in EDID detailed timing
//  IN:
//          XRes : X Resolution 
//          YRes : Y Resolution
//     rRateInfo : Refresh rate x 100
//                 whether interlaced 
//---------------------------------------------------------------------
BOOL cbIsTimingInEDIDDetailedTiming(
     IN PCBIOS_EDID_INFO pEDID,
     IN DWORD XRes, 
     IN DWORD YRes, 
     IN RefreshRateInfo rRateInfo)
{
    int i;

    if (!pEDID )
    {
        ASSERT(FALSE);
        return FALSE;
    }
    
    // check in detail timing
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->DtlTimings[i].Valid)
            && ( pEDID->DtlTimings[i].XResolution == XRes )
            && ( pEDID->DtlTimings[i].YResolution == YRes ) 
            && ( pEDID->DtlTimings[i].rRateX100 == rRateInfo.rRateX100)
            && ( pEDID->DtlTimings[i].Interlaced == rRateInfo.interlaced))
        {
            // resolution exist in EDID
            return TRUE;
        }
    }
    
    return FALSE;
}

BOOL cbIsTimingInEDIDEstStdTiming(
    PCBIOS_EDID_INFO pEDID, 
    WORD XRes, 
    WORD YRes, 
    WORD rrateX100)
{
    int i;
    
    if (!pEDID )
    {
        ASSERT(FALSE);
        return FALSE;
    }

    // check in Establish timing
    for (i = 0; i < 16; i++)
    {
        if ( (pEDID->EstTimings[i].Valid)
            && ( pEDID->EstTimings[i].XResolution == XRes )
            && ( pEDID->EstTimings[i].YResolution == YRes )
            && ( pEDID->EstTimings[i].rrateX100 == rrateX100 ) )
        {
            // resolution exist in Establish timing
            return TRUE;
        }
    }
    // check in Standard timing
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
            && ( pEDID->StdTimings[i].XResolution == XRes )
            && ( pEDID->StdTimings[i].YResolution == YRes )
            && ( pEDID->StdTimings[i].rrateX100 == rrateX100 ) )
        {
            // resolution exist in Standard timing
            return TRUE;
        }
    }

    return FALSE;
}


//----------------------------------------------------------------------------
// cbGetMaxResolutionFromEDIDTiming
//  This function get the biggest resolution from EDID (EST / STD / Detailed)
// timing. This function should be called after device EDID has been parsed 
// (function : cbEDIDParser_UMA has been called)
//
//    IN : 
//       pEDID : device EDID data pointer
//    OUT :
//       pxRes  : xRes
//       pyRes  : yRes
//---------------------------------------------------------------------------
 BOOL cbGetMaxResolutionFromEDIDTiming(
    PCBIOS_EXTENSION pcbe,
    IN PCBIOS_EDID_INFO pEDID,
    OUT PDWORD pxRes, 
    OUT PDWORD pyRes)
 {
     DWORD xRes = 0, yRes = 0;
     ULONG i;
     BOOL status = TRUE;

    if (!pEDID || !pxRes || !pyRes )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
     
     //----------------- CEA extension block 1 check -------------------
     if (pEDID->CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
     {
        // CEA extension block 1.3 or above, first check SVD 
        if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {   
               // more robust check all SVD 
               if (pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD != 0
                && ( CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes >= xRes
                && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes >= yRes)
               {
                    xRes = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes;
                    yRes = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes;
               }
            }
        }
     
        // check in DTD in CEA extension block
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if ( (pEDID->CEABlock_1.DtlTimings[i].Valid)
                && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                && ( pEDID->CEABlock_1.DtlTimings[i].XResolution >= xRes )
                && ( pEDID->CEABlock_1.DtlTimings[i].YResolution >= yRes ) )
            {
                // resolution exist in EDID
                xRes = pEDID->CEABlock_1.DtlTimings[i].XResolution;
                yRes = pEDID->CEABlock_1.DtlTimings[i].YResolution;
            }
        }
     }
         

     //----------------- EDID block 0 data check ------------------ 
     // check in Detailed timing
     for (i = 0; i < 4; i++)
     {
         if ( (pEDID->DtlTimings[i].Valid)
             && ( pEDID->DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
             && ( pEDID->DtlTimings[i].XResolution >= xRes )
             && ( pEDID->DtlTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->DtlTimings[i].XResolution;
             yRes = pEDID->DtlTimings[i].YResolution;
         }
     }

     // check in Standard timing
     for (i = 0; i < 8; i++)
     {
         if ( (pEDID->StdTimings[i].Valid)
             && ( pEDID->StdTimings[i].XResolution >= xRes )
             && ( pEDID->StdTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->StdTimings[i].XResolution;
             yRes = pEDID->StdTimings[i].YResolution;
         }
     }

     // check in Establish timing
     for (i = 0; i < 16; i++)
     {
         if ( (pEDID->EstTimings[i].Valid)
             && ( pEDID->EstTimings[i].XResolution >= xRes )
             && ( pEDID->EstTimings[i].YResolution >= yRes ) )
         {
             xRes = pEDID->EstTimings[i].XResolution;
             yRes = pEDID->EstTimings[i].YResolution;
         }
     }
    
        
     if (xRes > 0 && yRes > 0)
     {
        *pxRes = xRes;
        *pyRes = yRes;
     }
     else
     {
         status = FALSE;
     }
     
     return status;
}

void cbHDMISet_AV_Mute(PCBIOS_EXTENSION pcbe, 
     IN I2C_CONTROL_UMA i2c)
{
    i2c.RegIndex  = 0xA1;
    I2C_Read_Byte_INV(pcbe, &i2c);    
    i2c.IndexData |= 0x38;  //[5:3]
    I2C_Write_Byte_INV(pcbe, &i2c);

    i2c.RegIndex  = 0x45;
    I2C_Read_Byte_INV(pcbe, &i2c);
    i2c.IndexData &= 0x3F;  //Keep Bit[5:0]
    i2c.IndexData |= 0x40;  //Disable Bit[7], Enable Bit[6]
    I2C_Write_Byte_INV(pcbe, &i2c);
}
     
void cbHDMIClear_AV_Mute(PCBIOS_EXTENSION pcbe, 
     IN I2C_CONTROL_UMA i2c)
{
    i2c.RegIndex  = 0xA1;
    I2C_Read_Byte_INV(pcbe, &i2c);
    i2c.IndexData &= 0xC7;  //[5:3]
    I2C_Write_Byte_INV(pcbe, &i2c);

    i2c.RegIndex  = 0x45;
    I2C_Read_Byte_INV(pcbe, &i2c);
    i2c.IndexData &= 0x3F;  //Keep Bit[5:0]
    i2c.IndexData |= 0x80;  //Disable Bit[6], Enable Bit[7]
    I2C_Write_Byte_INV(pcbe, &i2c);
}
//----------------------------------------------------------------------------
// cbIsHDMIOUIExistInEDID
//  This function will check the input EDID buffer, and try to find the HDMI IEEE OUI tag in EDID
//    IN  : 
//       pEDID : device EDID data pointer
//    OUT :
//       None
//    Return:
//       TRUE---Found the HDMI IEEE OUI in EDID, No---NOT found
//---------------------------------------------------------------------------
BOOL cbIsHDMIOUIExistInEDID(
    PBYTE pEDIDBuf,
    DWORD bufLen)
{
    if(bufLen >= EDID1_X_BLOCKSIZE*2)
    {
        if(pEDIDBuf[0x80] == EDID_CEAEXTENSION_TAG && pEDIDBuf[0x81] == EDID_CEAEXTENSION_VER3)
        {
            ULONG ucNextDataBlockIndex = 0x84;

            //There are totally 6 blocks need to check:
            // Audio Data Block, Video Data Block, Vendor Specific Block,
            // Speaker Allocation Block, VESA DTC Block, Extended Block
            while(ucNextDataBlockIndex < bufLen)
            {
                if ( (pEDIDBuf[ucNextDataBlockIndex] & 0xE0) == (VENDOR_SPECIFIC_DATA_BLOCK_TAG<<5) )
                {
                    // ucNextDataBlockIndex+1 Point to content of Vendor Specific Block
                    if( pEDIDBuf[ucNextDataBlockIndex+1]==0x03 &&
                        pEDIDBuf[ucNextDataBlockIndex+2]==0x0C &&
                        pEDIDBuf[ucNextDataBlockIndex+3]==0x00 )
                    {
                        return TRUE;
                    }
                }
                //ucNextDataBlockIndex point to next block
                if ( (pEDIDBuf[ucNextDataBlockIndex] & 0xE0) == (SPEAKER_ALLOCATION_DATA_BLOCK_TAG<<5) )
                {
                    // SPEAKER_ALLOCATION_DATA_BLOCK length fix to 4 (include tag)
                    ucNextDataBlockIndex += 4;
                }
                else
                {
                    ucNextDataBlockIndex += (pEDIDBuf[ucNextDataBlockIndex] & 0x1F)+1;
                }
            }
        }
    }
    return FALSE;
}

//------------------------------------------------------------------------
// cbTransEDIDDetailedTiming
//
//    This function transfers EDID detailed timing to our GFX timing table
//  According to EDID detailed timing spec, Blanking time contains border
//  while in VESA timing spec, border is not in blanking time. Our GFX is 
//  the same as VESA std. so need special treatment for H/V Border
//
//  IN : 
//      pEDIDDTDTiming : CBIOS EDID Detailed timing storage structure
//      bBorderInSyncOffset : Sync offset include border or not
//  OUT :
//      pTimingTbl : UMA mode timing pointer
//------------------------------------------------------------------------
void cbTransEDIDDetailedTiming(
    IN  PEDID_DETAILEDTIMING_INFO pEDIDDTDTiming,
    BOOL bBorderInSyncOffset,
    OUT PGFXTimingTable pTimingTbl)
{
    if (!pEDIDDTDTiming || !pTimingTbl )
    {
        ASSERT(FALSE);
        return;
    }
    
    pTimingTbl->vPLL       = pEDIDDTDTiming->PLL_MRN;
    pTimingTbl->rRateX100  = pEDIDDTDTiming->rRateX100;
    pTimingTbl->HPolarity  = pEDIDDTDTiming->HPolarity;
    pTimingTbl->VPolarity  = pEDIDDTDTiming->VPolarity;
    pTimingTbl->Interlaced = pEDIDDTDTiming->Interlaced;

    // horizontal
    pTimingTbl->HTotal      = pEDIDDTDTiming->HActive + pEDIDDTDTiming->HBlank;
    pTimingTbl->HDisEnd     = pEDIDDTDTiming->HActive;
    pTimingTbl->HBlankStart = pEDIDDTDTiming->HActive + pEDIDDTDTiming->HBorder;
    pTimingTbl->HBlankEnd   = pTimingTbl->HTotal - pEDIDDTDTiming->HBorder;
    if (bBorderInSyncOffset)
    {
        // border in sync offset, means sync offset based on display end
        pTimingTbl->HSyncStart  = pEDIDDTDTiming->HActive + pEDIDDTDTiming->HSyncOffset;
    }
    else
    {
        // border not in sync offset, means sync offset based on blank start
        pTimingTbl->HSyncStart  = pTimingTbl->HBlankStart + pEDIDDTDTiming->HSyncOffset;
    }
    pTimingTbl->HSyncEnd    = pTimingTbl->HSyncStart + pEDIDDTDTiming->HSyncPulseWidth;
    

    // vertical
    pTimingTbl->VTotal      = pEDIDDTDTiming->VActive + pEDIDDTDTiming->VBlank;
    pTimingTbl->VDisEnd     = pEDIDDTDTiming->VActive;
    pTimingTbl->VBlankStart = pEDIDDTDTiming->VActive + pEDIDDTDTiming->VBorder;
    pTimingTbl->VBlankEnd   = pTimingTbl->VTotal - pEDIDDTDTiming->VBorder;
    if (bBorderInSyncOffset)
    {
        // border in sync offset, means sync offset based on display end
        pTimingTbl->VSyncStart  = pEDIDDTDTiming->VActive + pEDIDDTDTiming->VSyncOffset;
    }
    else
    {
        // border not in sync offset, means sync offset based on blank start
        pTimingTbl->VSyncStart  = pTimingTbl->VBlankStart + pEDIDDTDTiming->VSyncOffset;
    }
    pTimingTbl->VSyncEnd    = pTimingTbl->VSyncStart + pEDIDDTDTiming->VSyncPulseWidth;

    // timing aspect ratio
    pTimingTbl->AspectRatio = pEDIDDTDTiming->AspectRatio;

    // default interlace timing
    // V sync offset value is half of the H total
    if (pTimingTbl->Interlaced == INTERLACE)
    {
        pTimingTbl->VSyncOffset = pTimingTbl->HTotal / 2;
    }
    else
    {
        pTimingTbl->VSyncOffset = 0;
    }
}

//------------------------------------------------------------------------
// cbTransEDIDSVDTiming
//
//    This function transfers CEA entension block SVD timing to our GFX timing 
//  table.
//
//  IN : 
//      pSVDTiming : EDID SVD Timing entity
//  OUT :
//      pTimingTbl : UMA GFX timing pointer
//------------------------------------------------------------------------
void cbTransEDIDSVDTiming(
    IN  PCBIOS_EXTENSION pcbe,
    IN  CEA_861_Timing_Tbl *pSVDTiming,
    OUT PGFXTimingTable pTimingTbl)
{
    PDigitalPortInfo PDIPort = NULL;
    BOOL IsDuplicatedMode = FALSE;
    DWORD i = 0;

    if (!pSVDTiming || !pTimingTbl )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return;
    }

    // get TX information
    cbGetDIPortInfo(pcbe, &PDIPort, S3_HDMI);
    // judge if selected mode is duplicated modes
    for( i=0; i<CEA_DUPLICATED_MODE_NUM; i++ )
    {
        if( pSVDTiming->Video_ID_Code == CEA_DUPLICATED_MODE[i] )
        {
            IsDuplicatedMode = TRUE;
        }
    }

    pTimingTbl->vPLL       = GET_CHIP_MRN(pcbe->ChipCaps.PLL_USE_409_FORMULA, pSVDTiming->PLL_MRN);
    pTimingTbl->rRateX100  = pSVDTiming->rRateX100;
    pTimingTbl->HPolarity  = (pSVDTiming->HPolarity & ATT_PHS) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
    pTimingTbl->VPolarity  = (pSVDTiming->VPolarity & ATT_PVS) ? CBIOS_POSITIVE : CBIOS_NEGATIVE;
    pTimingTbl->Interlaced = pSVDTiming->Interlaced;

    // horizontal
    if( IsDuplicatedMode && PDIPort->PortInfo.TXType == AD9389B ) 
    {
        pTimingTbl->HTotal      = pSVDTiming->HTotal/2;
        pTimingTbl->HDisEnd     = pSVDTiming->HDisEnd/2;
        pTimingTbl->HBlankStart = pSVDTiming->HBlankStart/2;
        pTimingTbl->HBlankEnd   = pSVDTiming->HBlankEnd/2;
        pTimingTbl->HSyncStart  = pSVDTiming->HSyncStart/2;
        pTimingTbl->HSyncEnd    = pSVDTiming->HSyncEnd/2;
    }
    else
    {
        pTimingTbl->HTotal      = pSVDTiming->HTotal;
        pTimingTbl->HDisEnd     = pSVDTiming->HDisEnd;
        pTimingTbl->HBlankStart = pSVDTiming->HBlankStart;
        pTimingTbl->HBlankEnd   = pSVDTiming->HBlankEnd;
        pTimingTbl->HSyncStart  = pSVDTiming->HSyncStart;
        pTimingTbl->HSyncEnd    = pSVDTiming->HSyncEnd;
    }

    // vertical
    pTimingTbl->VTotal      = pSVDTiming->VTotal;
    pTimingTbl->VDisEnd     = pSVDTiming->VDisEnd;
    pTimingTbl->VBlankStart = pSVDTiming->VBlankStart;
    pTimingTbl->VBlankEnd   = pSVDTiming->VBlankEnd;
    pTimingTbl->VSyncStart  = pSVDTiming->VSyncStart;
    pTimingTbl->VSyncEnd    = pSVDTiming->VSyncEnd;
    pTimingTbl->VSyncOffset = pSVDTiming->VSyncOffset;

    // timing Aspect Ratio 
    pTimingTbl->AspectRatio = pSVDTiming->AspectRatio;

}

//-------------------------------------------------------------------------
//cbGetCEATypeTimingTbl
//     This function query if timing is stored in CEA timing table. Timing includes
//  X / Y resolution & refreshrate( interlace / non interlace)
//  IN : 
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number x 100
//              whether interlaced
//  OUT :
//     pTimingTbl  : Timing table
//     function return status
//------------------------------------------------------------------------
BOOL cbGetCEATypeTimingTbl(
    IN PCBIOS_EXTENSION pcbe,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl
)
{
    int i;
    
    if (!pTimingTbl )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    for (i = 0; i < CEA861_FORMAT_NUM; i++)
    {
        if (CEA861_FormatTimingTbl[i].HDisEnd == H_Res
         && ( CEA861_FormatTimingTbl[i].Interlaced == PROGRESSIVE ||
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT))
         && CEA861_FormatTimingTbl[i].VDisEnd == V_Res
         && CEA861_FormatTimingTbl[i].rRateX100 == rRateInfo.rRateX100
         && CEA861_FormatTimingTbl[i].Interlaced == rRateInfo.interlaced)
        {
            cbTransEDIDSVDTiming(pcbe, &CEA861_FormatTimingTbl[i], pTimingTbl);
            return TRUE;
        }
    }
    
    return FALSE;
}

//------------------------------------------------------------------------------
// cbGetEDIDSVDandDTDTiming
//   This function finds the closest timing from CEA SVD & EDID detailed timing. we need to 
//  transfer EDID detailed timing to the generic UMA timing table
//  IN : 
//     pEDID : EDID datasturcture pointer
//     XRes  : X resolution 
//     YRes  : Y resolution
//     rRateInfo : refresh rate number 
//              whether interlaced
//  OUT :
//     pTimingTbl  : CBIOS general Timing table
//     function return status
//------------------------------------------------------------------------------
BOOL cbGetEDIDSVDandDTDTiming(
    IN PCBIOS_EXTENSION pcbe,
    IN PCBIOS_EDID_INFO pEDID, 
    IN WORD XRes, 
    IN WORD YRes, 
    IN RefreshRateInfo rRateInfo, 
    OUT PGFXTimingTable pTimingTbl)
{
    int i;
    WORD curX = MAX_H_RES, curY = MAX_V_RES;
    PCEA_861_Timing_Tbl pClosestSVDTiming = NULL;
    PEDID_DETAILEDTIMING_INFO pClosestDTDTiming = NULL;

    if (!pTimingTbl )
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if(NULL == pEDID)
    {
        return FALSE;
    }

    // 1.-------- check CEA extension block EDID --------------
    if (pEDID->CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
    {
        // 1.1 --- if EDID extension block version 1.3 or above check SVDS ---
        if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {
                if (pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD != 0
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes <= curX 
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes >= XRes 
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes <= curY
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes >= YRes
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].rRateX100 == rRateInfo.rRateX100
                    && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == rRateInfo.interlaced)

                {
                    curX = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes;
                    curY = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes;
                    pClosestSVDTiming = &(CEA861_FormatTimingTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1]);
                }
            }
        }

        // 1.2 ----------------- check DTDs in Ext block ----------------------
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if ((pEDID->CEABlock_1.DtlTimings[i].Valid)
                && pEDID->CEABlock_1.DtlTimings[i].XResolution <= curX 
                && pEDID->CEABlock_1.DtlTimings[i].XResolution >= XRes 
                && pEDID->CEABlock_1.DtlTimings[i].YResolution <= curY
                && pEDID->CEABlock_1.DtlTimings[i].YResolution >= YRes
                && pEDID->CEABlock_1.DtlTimings[i].rRateX100 == rRateInfo.rRateX100
                && pEDID->CEABlock_1.DtlTimings[i].Interlaced == rRateInfo.interlaced)
            {
                curX =  pEDID->CEABlock_1.DtlTimings[i].XResolution;
                curY =  pEDID->CEABlock_1.DtlTimings[i].YResolution;
                pClosestDTDTiming = &(pEDID->CEABlock_1.DtlTimings[i]);
            }
        }
    }

    // 2. check in baseblock detail timing
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->DtlTimings[i].Valid)
            && ( pEDID->DtlTimings[i].XResolution <= curX )
            && ( pEDID->DtlTimings[i].XResolution >= XRes )
            && ( pEDID->DtlTimings[i].YResolution <= curY )
            && ( pEDID->DtlTimings[i].YResolution >= YRes )
            && ( pEDID->DtlTimings[i].rRateX100 == rRateInfo.rRateX100 )
            && ( pEDID->DtlTimings[i].Interlaced == rRateInfo.interlaced) )
        {
            curX =  pEDID->DtlTimings[i].XResolution;
            curY =  pEDID->DtlTimings[i].YResolution;
            pClosestDTDTiming = &(pEDID->DtlTimings[i]);
        }
    }

    // for DTD check is behind SVD, so DTD must closer
    if (pClosestDTDTiming != NULL)
    {
        // CEA DTD border not in sync offset
        cbTransEDIDDetailedTiming(pClosestDTDTiming, FALSE, pTimingTbl);
        return TRUE;
    }
    else if (pClosestSVDTiming != NULL)
    {
        cbTransEDIDSVDTiming(pcbe, pClosestSVDTiming, pTimingTbl);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//-------------------------------------------------------------------------
//  cbGetTimingFromEDID
//      This function returns the given EDID timing table which can support 
//  the given resolution. 
//      1. Detailed timing 
//      2. STD timing 
//      3. EST timing
//  the priority order is given by E_EDID standard for GTF supported device
//  IN : 
//      pEDID : pointer to where EDID stored
//      XRes  : X resolution
//      YRes  : Y resolution
//  rRateInfo : refresh rate information
//  OUT :
//      pTimingTbl  : general timing returned
//-------------------------------------------------------------------------
BOOL cbGetTimingFromEDID(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID, 
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo, 
    IN BOOL bReduceBlk,
    OUT PGFXTimingTable pTimingTbl)
{
    int i;

    if (!pTimingTbl || !pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // 1.-------- check CEA extension block EDID --------------
    if (pEDID->CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
    {
        // 1.1 --- if EDID extension block version 1.3 or above check SVDS ---
        if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {
                if (pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD != 0
                 && ( CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes == H_Res 
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes == V_Res
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].rRateX100 == rRateInfo.rRateX100
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == rRateInfo.interlaced)
    
                {
                    cbTransEDIDSVDTiming(pcbe, &(CEA861_FormatTimingTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1]), pTimingTbl);
                    return TRUE;
                }
            }
        }
    
        // 1.2 ----------------- check DTDs in Ext block ----------------------
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if ((pEDID->CEABlock_1.DtlTimings[i].Valid)
              && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
              && pEDID->CEABlock_1.DtlTimings[i].XResolution == H_Res 
              && pEDID->CEABlock_1.DtlTimings[i].YResolution == V_Res
              && pEDID->CEABlock_1.DtlTimings[i].rRateX100 == rRateInfo.rRateX100
              && pEDID->CEABlock_1.DtlTimings[i].Interlaced == rRateInfo.interlaced)
            {
                // CEA DTD border not in sync offset
                cbTransEDIDDetailedTiming(&(pEDID->CEABlock_1.DtlTimings[i]), FALSE, pTimingTbl);
                return TRUE;
            }
        }
    }

    // transfer detail timing to real timing table
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->DtlTimings[i].Valid)
            && ( pEDID->DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT))
            && ( H_Res == pEDID->DtlTimings[i].XResolution)
            && ( V_Res == pEDID->DtlTimings[i].YResolution)
            && ( pEDID->DtlTimings[i].rRateX100 == rRateInfo.rRateX100 )
            && ( pEDID->DtlTimings[i].Interlaced == rRateInfo.interlaced)) 
        {
            // transfer EDID detailed timing to UMA timing tbl
            // EDID first block Detail timing border in sync offset
            cbTransEDIDDetailedTiming(&pEDID->DtlTimings[i], TRUE, pTimingTbl);
            return TRUE;
        }
    }

    // transfer Standard timing(VESAVPIT) to real timing table
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
            && ( pEDID->StdTimings[i].XResolution == H_Res )
            && ( pEDID->StdTimings[i].YResolution == V_Res )
            && ( pEDID->StdTimings[i].rrateX100 == rRateInfo.rRateX100 )
            && ( rRateInfo.interlaced == PROGRESSIVE ||
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) ) )
        {
            return cbGetSTDTiming(pcbe, bReduceBlk, H_Res, V_Res, rRateInfo.rRateX100, pTimingTbl);
        }
    }

    // transfer established timing(DMT timing) to real timing table
    for (i = 0; i < 16; i++)
    {
        if ( (pEDID->EstTimings[i].Valid)
        && ( pEDID->EstTimings[i].XResolution == H_Res )
        && ( pEDID->EstTimings[i].YResolution == V_Res )
        && ( pEDID->EstTimings[i].rrateX100 == rRateInfo.rRateX100 )
        && ( rRateInfo.interlaced == PROGRESSIVE ||
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) ) )
        {
            // transfer DMT VESAVPIT in CBIOS to UMA timing tbl
            if (pcbe->ChipCaps.PLL_USE_409_FORMULA)
                return cbGetCBIOSVesaTimingTable(pcbe, H_Res, V_Res, rRateInfo, VESA_DMT_TABLE_409, CBIOS_DMT_MODESUPPORT_NUM, pTimingTbl);
            else
                return cbGetCBIOSVesaTimingTable(pcbe, H_Res, V_Res, rRateInfo, VESA_DMT_TABLE, CBIOS_DMT_MODESUPPORT_NUM, pTimingTbl);
        }
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbGetClosestEDIDTimingResolution
//      This function finds the nearest resolution in EDID (EST / STD / DETAILED)
//  timing as the given mode's target Mode. If no EDID timing bigger than given mode 
//  also return FALSE.
//  IN :
//       pEDID  : EDID timing info pointer
//       H_Res  : Mode H Resolution
//       V_Res  : Mode V Resolution
//
//  OUT :
//       pEDIDTargetHRes : nearest EDID mode H resolution size pointer
//       pEDIDTargetVRes : nearest EDID mode V resolution size pointer
//       function return status  
//--------------------------------------------------------------------------
BOOL cbGetClosestEDIDTimingResolution(    
    PCBIOS_EXTENSION pcbe, 
    PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PDWORD pEDIDTargetHRes,
    OUT PDWORD pEDIDTargetVRes)
{
    DWORD EDIDTargetHRes = MAX_H_RES, EDIDTargetVRes = MAX_V_RES;
    ULONG i;
    
    if (!pEDIDTargetVRes || !pEDIDTargetHRes || !pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // 1.-------- refresh rate from CEA extension block EDID --------------
    if (pEDID->CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
    {
        // 1.1 --- if EDID extension block version 1.3 or above check SVDS ---
        if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {
                if (pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD != 0
                 && ( CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes >= H_Res 
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes >= V_Res
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes <= EDIDTargetHRes
                 && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes <= EDIDTargetVRes)

                {
                    EDIDTargetHRes = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes;
                    EDIDTargetVRes = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes;
                }
            }
        }
    
        // 1.2 ----------------- check DTDs in Ext block ----------------------
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if ((pEDID->CEABlock_1.DtlTimings[i].Valid)
              && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
              && pEDID->CEABlock_1.DtlTimings[i].XResolution >= H_Res 
              && pEDID->CEABlock_1.DtlTimings[i].YResolution >= V_Res
              && pEDID->CEABlock_1.DtlTimings[i].XResolution <= EDIDTargetHRes
              && pEDID->CEABlock_1.DtlTimings[i].YResolution <= EDIDTargetVRes)
            {
                EDIDTargetHRes = pEDID->CEABlock_1.DtlTimings[i].XResolution;
                EDIDTargetVRes = pEDID->CEABlock_1.DtlTimings[i].YResolution;
            }
        }
    }
    
    // 2.-------- refresh rate from CEA extension block EDID --------------
    // 2.1 --- check in detailed timing
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
       if ( (pEDID->DtlTimings[i].Valid)
        && ( pEDID->DtlTimings[i].Interlaced == PROGRESSIVE ||
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
        && ( pEDID->DtlTimings[i].XResolution >= H_Res )
        && ( pEDID->DtlTimings[i].YResolution >= V_Res )
        && ( pEDID->DtlTimings[i].XResolution <= EDIDTargetHRes)
        && ( pEDID->DtlTimings[i].YResolution <= EDIDTargetVRes))
       {
            EDIDTargetHRes = pEDID->DtlTimings[i].XResolution;
            EDIDTargetVRes = pEDID->DtlTimings[i].YResolution;
       }
    }

    // 2.2 --- check in Standard timing
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
        && ( pEDID->StdTimings[i].XResolution >= H_Res )
        && ( pEDID->StdTimings[i].YResolution >= V_Res )
        && ( pEDID->StdTimings[i].XResolution <= EDIDTargetHRes)
        && ( pEDID->StdTimings[i].YResolution <= EDIDTargetVRes))
        {
            // resolution exist in Standard timing
            EDIDTargetHRes = pEDID->StdTimings[i].XResolution;
            EDIDTargetVRes = pEDID->StdTimings[i].YResolution;
        }
    }
    
    // 2.3 --- check in est timing
    for (i = 0; i < 16; i++)
    {
        if ( (pEDID->EstTimings[i].Valid)
        && ( pEDID->EstTimings[i].XResolution >= H_Res )
        && ( pEDID->EstTimings[i].YResolution >= V_Res )
        && ( pEDID->EstTimings[i].XResolution <= EDIDTargetHRes)
        && ( pEDID->EstTimings[i].YResolution <= EDIDTargetVRes))
        {
            // resolution exist in Establish timing
            EDIDTargetHRes = pEDID->EstTimings[i].XResolution;
            EDIDTargetVRes = pEDID->EstTimings[i].YResolution;
        }
    }
    
    if (EDIDTargetHRes != MAX_H_RES)
    {
        *pEDIDTargetHRes = EDIDTargetHRes;
        *pEDIDTargetVRes = EDIDTargetVRes;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

BOOL cbIsDuplicateMode(PCBIOS_EXTENSION pcbe, IN DWORD SVDIndex)
{
    BOOL    status = FALSE;
    DWORD   i = 0;
    
    for(i = 0; i < CEA_DUPLICATED_MODE_NUM; i++)
    {
        if(CEA861_FormatTbl[SVDIndex - 1].Video_ID_Code == CEA_DUPLICATED_MODE[i])
        {
            status = TRUE;
            break;
        }
    }

    return status;
}

//--------------------------------------------------------------------------
//  cbIsDClkOverLimit
//      This function check if the dot clock over hardware limits
//  IN :
//     dispDev : display device bit
//       DClk  : dot clock(hz)
//  return:
//      True: DClk over the limits
//      False:DClk is not over the limits
//--------------------------------------------------------------------------
BOOL cbIsDClkOverLimit(PCBIOS_EXTENSION pcbe,IN DWORD dispDev,IN DWORD DClk)
{
    //filter by IGA max frequency
    if(DClk >= IGA_MAX_FREQUENCY)
    {
        return TRUE;
    }
    // filter mode over TMDS link limitation
    // DVI/DVI2 use TMDS link
    if ( (S3_DVI | S3_DVI2) & dispDev )
    {
        
        if ( DClk >= TMDS_LINK_FREQUENCY )
        {
            return TRUE;
        }
    }
    // filter mode by CRT RAM DAC speed
    else if(S3_CRT & dispDev)
    {
        if(DClk >= CRT_RAMDAC_FREQUENCY)
        {
            return TRUE;
        }
    }
    // filter mode by DP Lane/Link Speed
    else if( (S3_DP | S3_DP2) & dispDev)
    {
        DWORD DPCaps = 0;

        if(dispDev == S3_DP)
            DPCaps = pcbe->DPSinkCaps[DP1].LinkSpeed * pcbe->DPSinkCaps[DP1].LaneNumber * 100;
        else
            DPCaps = pcbe->DPSinkCaps[DP2].LinkSpeed * pcbe->DPSinkCaps[DP2].LaneNumber * 100;

        DPCaps = (DPCaps / 400) * ( 100 + DP_GOLDEN_RATIO);

        if(DClk >= DPCaps)
            return TRUE;
    }
    // filter mode by HDMI AD9389B hw limitation
    else if((S3_HDMI | S3_HDMI2) & dispDev)
    {
        PDigitalPortInfo PDIPort = NULL;
        if (!cbGetDIPortInfo(pcbe, &PDIPort, dispDev))
        {
            cbDbgPrint(1, "can not get device DI port information. \n");
            return FALSE;
        }

        if(PDIPort->PortInfo.TXType == AD9389B)
        {
            if(DClk >= 150000000)
                return TRUE;
        }
    }
    
    return FALSE;
}

#if !LINUX_PLATFORM
BOOL cbAD9389VesaModeFilter(PCBIOS_EXTENSION pcbe,IN DWORD dispDev, WORD XRes, WORD YRes, WORD RRate)
{
    PDigitalPortInfo PDIPort = NULL;
    BOOL status = FALSE;
    
    AD9389ModeFilter Table[] = 
    {
        {   800,    600,    75},
        {   800,    600,    60},
    };
    
    DWORD TableSize = sizeof(Table) / sizeof(AD9389ModeFilter), i = 0;
    
    if (!cbGetDIPortInfo(pcbe, &PDIPort, dispDev))
    {
        cbDbgPrint(1, "can not get device DI port information. \n");
        return FALSE;
    }

    if(PDIPort->PortInfo.TXType == AD9389B)
    {
        for(i = 0; i < TableSize; i++)
        {
            if( XRes == Table[i].XRes && 
                YRes == Table[i].YRes &&
                RRate/100 == Table[i].RRate )
            {
                status = TRUE;
                break;
            }
        }
    }

    return status;
}
#endif

void cbSortRefreshRateBuffer(PRefreshRateInfo pRRatesInfoBuf, PDWORD prrNum)
{
    ULONG i, tail=0;
    RefreshRateInfo NewRRInfo, TempRRInfo;

    if (NULL == pRRatesInfoBuf) // no buffer for sort
        return;

    for(tail=0; tail < *prrNum; tail++)
    {
        NewRRInfo.interlaced = pRRatesInfoBuf[tail].interlaced;    // default max RRate
        NewRRInfo.rRateX100  = pRRatesInfoBuf[tail].rRateX100;
        for(i=0; i<tail; i++)
        {
            TempRRInfo.interlaced = pRRatesInfoBuf[i].interlaced;    // original RRate
            TempRRInfo.rRateX100  = pRRatesInfoBuf[i].rRateX100;
            if(pRRatesInfoBuf[i].rRateX100 > NewRRInfo.rRateX100)
            {
                pRRatesInfoBuf[i].interlaced = NewRRInfo.interlaced;    // swap RRate
                pRRatesInfoBuf[i].rRateX100  = NewRRInfo.rRateX100;
                NewRRInfo.interlaced = TempRRInfo.interlaced;
                NewRRInfo.rRateX100  = TempRRInfo.rRateX100;
            }
            else
            {
                pRRatesInfoBuf[i].interlaced = TempRRInfo.interlaced;    // keep RRate
                pRRatesInfoBuf[i].rRateX100  = TempRRInfo.rRateX100;
            }
        }
        pRRatesInfoBuf[tail].interlaced = NewRRInfo.interlaced; // final RRate
        pRRatesInfoBuf[tail].rRateX100  = NewRRInfo.rRateX100;
    }

    TempRRInfo.rRateX100 = 0;
    for(i=0, tail=0; tail < *prrNum; tail++)
    {
        if(TempRRInfo.rRateX100 != pRRatesInfoBuf[tail].rRateX100)
        {
            pRRatesInfoBuf[i].rRateX100 = pRRatesInfoBuf[tail].rRateX100;
            pRRatesInfoBuf[i].interlaced = pRRatesInfoBuf[tail].interlaced;
            TempRRInfo.rRateX100 = pRRatesInfoBuf[i].rRateX100;
            i++;
        }
    }
    *prrNum = i; // update back to 
}

//--------------------------------------------------------------------------
//  cbGetRefreshRateBufferInEDIDTiming
//      This function fills all the refresh rate supported according to resolution
//  and device type which EDID timing can support
//  IN :
//     dispDev : display device bit
//       H_Res : H resolution size
//       V_Res : V resolution size
//  OUT :
//   pRRateNum : refresh rate number pointer
//       function return status  
//--------------------------------------------------------------------------
BOOL cbGetRefreshRateBufferInEDIDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PRefreshRateInfo pRRatesInfoBuf,
    IN DWORD BufSize,
    OUT PDWORD pRefreshNum)
{
    ULONG i, rrNum = 0;

    if (!pRefreshNum || !pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (NULL == pRefreshNum)
    {
        // not need fill buffer, set size = 0 for later logic
        BufSize = 0;
    }

    // 1.-------- refresh rate from CEA extension block EDID --------------
    if (pEDID->CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
    {
        // 1.1 --- if EDID extension block version 1.3 or above check SVDS ---
        if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {
                BYTE SVDIndex = pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD;
                if(SVDIndex != 0)
                {
                    if ( cbIsDClkOverLimit(pcbe, dispDev, CEA861_FormatTimingTbl[SVDIndex-1].PLL_SEED) )
                    {
                        continue;
                    }
                    
                    if(!pcbe->ChipCaps.HDMI_SUPPORT_DUPLICATE_MODE)
                    {
                        if(cbIsDuplicateMode(pcbe, SVDIndex))
                            continue;
                    }
                }
                if (SVDIndex != 0
                    && ( CEA861_FormatTbl[SVDIndex - 1].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                    && CEA861_FormatTbl[SVDIndex - 1].XRes == H_Res 
                    && CEA861_FormatTbl[SVDIndex - 1].YRes == V_Res)
                {
                    // refresh rate exist in EDID while not in Customize timing
                    if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
                    {
                        // if enough space in the buffer, fill in
                        pRRatesInfoBuf[rrNum].rRateX100 = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].rRateX100;
                        pRRatesInfoBuf[rrNum].interlaced = CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced;
                    }
                    rrNum++;  // report EDID detail timing rrate

                    if(CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].rRateX100 == 6000)
                    {
                        // To pass DTM test, we have to report 59Hz modes to HDMI's mode table
                        if(dispDev & (S3_HDMI+S3_HDMI2))
                            cbAdd59HzModes(pcbe, dispDev, H_Res, V_Res, BufSize, CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced, pRRatesInfoBuf, &rrNum);
                    }                    
                }
            }
        }

        // 1.2 ----------------- check DTDs in Ext block ----------------------
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if (pEDID->CEABlock_1.DtlTimings[i].Valid)
            {
                if( cbIsDClkOverLimit(pcbe, dispDev,
                                       cbCalcClkFromDWORDMRN(pcbe, pEDID->CEABlock_1.DtlTimings[i].PLL_MRN) ) )
                {
                    continue;
                }
            }
            if ((pEDID->CEABlock_1.DtlTimings[i].Valid)
                && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                && pEDID->CEABlock_1.DtlTimings[i].XResolution == H_Res 
                && pEDID->CEABlock_1.DtlTimings[i].YResolution == V_Res)
            {
                // refresh rate exist in EDID while not in Customize timing
                if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
                {
                    // if enough space in the buffer, fill in
                    pRRatesInfoBuf[rrNum].rRateX100 = pEDID->CEABlock_1.DtlTimings[i].rRateX100;
                    pRRatesInfoBuf[rrNum].interlaced = pEDID->CEABlock_1.DtlTimings[i].Interlaced;
                }
                rrNum++;  // report EDID detail timing rrate  

                if(pEDID->CEABlock_1.DtlTimings[i].rRateX100 == 6000)
                {
                    // To pass DTM test, we have to report 59Hz modes to HDMI's mode table
                    if(dispDev & (S3_HDMI+S3_HDMI2))
                        cbAdd59HzModes(pcbe, dispDev, H_Res, V_Res, BufSize, pEDID->CEABlock_1.DtlTimings[i].Interlaced, pRRatesInfoBuf, &rrNum);
                }                
            }
        }
    }

    // 2.-------- refresh rate from CEA extension block EDID --------------
    // 2.1 ---- EDID detailed timing
    for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
    {
        if (pEDID->DtlTimings[i].Valid )
        {
            if(cbIsDClkOverLimit(pcbe, dispDev,
                                  cbCalcClkFromDWORDMRN(pcbe, pEDID->DtlTimings[i].PLL_MRN) ) )
            {
                continue;
            }

#if !LINUX_PLATFORM
            if(cbAD9389VesaModeFilter(pcbe, dispDev, pEDID->DtlTimings[i].XResolution, 
                pEDID->DtlTimings[i].YResolution, pEDID->DtlTimings[i].rRateX100))
            {
                continue;
            }
#endif
        }
        // center on Nearest EDID detailed timing 
        if ( (pEDID->DtlTimings[i].Valid)
            && ( pEDID->DtlTimings[i].Interlaced == PROGRESSIVE ||
            (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && ( pEDID->DtlTimings[i].XResolution == H_Res)
            && ( pEDID->DtlTimings[i].YResolution == V_Res))
        {
            // refresh rate exist in EDID while not in Customize timing
            if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
            {
                // if enough space in the buffer, fill in
                pRRatesInfoBuf[rrNum].rRateX100 = pEDID->DtlTimings[i].rRateX100;
                pRRatesInfoBuf[rrNum].interlaced = pEDID->DtlTimings[i].Interlaced;
            }
            rrNum++;  // report EDID detail timing rrate
            
            if(pEDID->DtlTimings[i].rRateX100 == 6000)
            {
                // To pass DTM test, we have to report 59Hz modes to HDMI's mode table
                if(dispDev & (S3_HDMI+S3_HDMI2))
                    cbAdd59HzModes(pcbe, dispDev, H_Res, V_Res, BufSize, pEDID->DtlTimings[i].Interlaced, pRRatesInfoBuf, &rrNum);
            }            
        }
    }

    // 2.2 --- EDID STD timing
    for (i = 0; i < 8; i++)
    {
        if ( (pEDID->StdTimings[i].Valid)
            && ( pEDID->StdTimings[i].XResolution == H_Res)
            && ( pEDID->StdTimings[i].YResolution == V_Res))
        {
            if(pEDID->StdTimings[i].Valid)
            {
                GFXTimingTable TimingTbl;
                BOOL bReduceBlk = FALSE;

                if(dispDev & (S3_DVI | S3_DVI2 | S3_DP | S3_DP2))
                    bReduceBlk = TRUE;

                cbGetSTDTiming(pcbe, bReduceBlk, H_Res, V_Res, pEDID->StdTimings[i].rrateX100, &TimingTbl);
                
                if(cbIsDClkOverLimit(pcbe, dispDev, (TimingTbl.HTotal * TimingTbl.VTotal * TimingTbl.rRateX100 / 100)))
                {
                    continue;
                }

#if !LINUX_PLATFORM
                if(cbAD9389VesaModeFilter(pcbe, dispDev, TimingTbl.HDisEnd, TimingTbl.VDisEnd, (WORD)TimingTbl.rRateX100))
                {
                    continue;
                }
#endif
            }
            // if not in EDID detailed & customized refresh rate
            // Is buffer size enough for saving next refresh rate?
            if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
            {
                // if enough space in the buffer, fill in
                pRRatesInfoBuf[rrNum].rRateX100 =  pEDID->StdTimings[i].rrateX100;
                pRRatesInfoBuf[rrNum].interlaced = PROGRESSIVE;
            }
            rrNum++;

            if(pEDID->StdTimings[i].rrateX100 == 6000)
            {
                // To pass DTM test, we have to report 59Hz modes to HDMI's mode table
                if(dispDev & (S3_HDMI+S3_HDMI2))
                    cbAdd59HzModes(pcbe, dispDev, H_Res, V_Res, BufSize, PROGRESSIVE, pRRatesInfoBuf, &rrNum);
            }            
        }
    }

    // 2.3 --- EDID EST timing
    for (i = 0; i < 16; i++)
    {
        if ( (pEDID->EstTimings[i].Valid)
            && ( pEDID->EstTimings[i].XResolution == H_Res)
            && ( pEDID->EstTimings[i].YResolution == V_Res))
        {
#if !LINUX_PLATFORM
            if(cbAD9389VesaModeFilter(pcbe, dispDev, (WORD)H_Res, (WORD)V_Res, (WORD)pEDID->EstTimings[i].rrateX100))
            {
                continue;
            }
#endif
            // if not in EDID detailed & customized refresh rate
            // Is buffer size enough for saving next refresh rate?
            if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
            {
                // if enough space in the buffer, fill in
                pRRatesInfoBuf[rrNum].rRateX100 =  pEDID->EstTimings[i].rrateX100;
                pRRatesInfoBuf[rrNum].interlaced = PROGRESSIVE;
            }
            rrNum++;

            if(pEDID->EstTimings[i].rrateX100 == 6000)
            {
                // To pass DTM test, we have to report 59Hz modes to HDMI's mode table
                if(dispDev & (S3_HDMI+S3_HDMI2))
                    cbAdd59HzModes(pcbe, dispDev, H_Res, V_Res, BufSize, PROGRESSIVE, pRRatesInfoBuf, &rrNum);
            }            
        }
    }

    *pRefreshNum = rrNum;
    return TRUE;
}

BOOL cbAdd59HzModes(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD BufSize,
    IN BYTE bInterlace,
    OUT PRefreshRateInfo pRRatesInfoBuf,
    OUT PDWORD rrNum)
{

    // check resolution, only add 1920x1080@59Hz, 1280x720@59Hz, 720x480@59Hz
    if(H_Res == 1920 && V_Res == 1080)
    {
        if ( bInterlace == PROGRESSIVE && ((*rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
        {
            pRRatesInfoBuf[*rrNum].rRateX100 = 5900;
            pRRatesInfoBuf[*rrNum].interlaced = PROGRESSIVE;
        }
        if(bInterlace == PROGRESSIVE)
            (*rrNum)++;
        if ( bInterlace == INTERLACE && ((*rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
        {
            pRRatesInfoBuf[*rrNum].rRateX100 = 5900;
            pRRatesInfoBuf[*rrNum].interlaced = INTERLACE;
        }
        if(bInterlace == INTERLACE)
            (*rrNum)++;
        return TRUE;
    }
    else if(H_Res == 1280 && V_Res == 720)
    {
        if ( bInterlace == PROGRESSIVE && ((*rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
        {
            pRRatesInfoBuf[*rrNum].rRateX100 = 5900;
            pRRatesInfoBuf[*rrNum].interlaced = PROGRESSIVE;
        }
        if(bInterlace == PROGRESSIVE)
            (*rrNum)++;
        return TRUE;
    }
    else if(H_Res == 720 && V_Res == 480)
    {
        if ( bInterlace == PROGRESSIVE && ((*rrNum+1) * sizeof(RefreshRateInfo)) <= BufSize )
        {
            pRRatesInfoBuf[*rrNum].rRateX100 = 5900;
            pRRatesInfoBuf[*rrNum].interlaced = PROGRESSIVE;
        }
        if(bInterlace == PROGRESSIVE)
            (*rrNum)++;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//--------------------------------------------------------------------------
//  cbIsResolutionExistInCustomizeTiming
//      This function checks whether the device associate resolution supports in 
//  custermize timing table 
//  IN :
//     dispDev : display device bit
//       H_Res : H resolution size
//       V_Res : V resolution size
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL;
    ULONG i;
    
    // search in customize timing table
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
            && (H_Res == pEntityBufferCur->H_Res)
            && (V_Res == pEntityBufferCur->V_Res))
            {
                return TRUE;
            }
            pEntityBufferCur++;
        }
     }

     return FALSE;
}


//--------------------------------------------------------------------------
//  cbIsResolutionExistInSVD
//      This function checks whether the device associate SVDs support given 
//  resolution parameter
//  IN :
//       pEDID : device associated EDID info structure in CBIOS
//       H_Res : H resolution size
//       V_Res : V resolution size
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInSVD(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res)
{
    ULONG i;

    if (!pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // if EDID extension block version 1.3 or above
    if (pEDID->CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
    {
       for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
       {
           if (pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD != 0
            && ( CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].XRes == H_Res 
            && CEA861_FormatTbl[pEDID->CEABlock_1.ShortVideoDescriptor[i].SVD - 1].YRes == V_Res)
           {
               return TRUE;
           }
       }
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbIsResolutionExistInCEAExt
//      This function checks whether the device associate EDID CEA extension 
//  block (SVDs and DTDs) supports given resolution 
//
//  IN :
//       pEDID : device associated EDID info structure in CBIOS
//       H_Res : H resolution size
//       V_Res : V resolution size
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInCEAExt(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res)
{
    ULONG i;

    if (!pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // if extension block is not CEA extension 
    // return FALSE
    if (pEDID->CEABlock_1.CEAExtBlockTag != EDID_CEAEXTENSION_TAG)
    {
        return FALSE;
    }

    // check in CEA extension SVDs 
    if (TRUE == cbIsResolutionExistInSVD(pcbe,
                                         pEDID,
                                         H_Res,
                                         V_Res))
    {
        return TRUE;
    }

    // check in CEA extension DTDs
    for (i = 0; i < CEAEXT_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->CEABlock_1.DtlTimings[i].Valid)
            && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && ( pEDID->CEABlock_1.DtlTimings[i].XResolution == H_Res )
            && ( pEDID->CEABlock_1.DtlTimings[i].YResolution == V_Res ) )
        {
            // resolution exist in EDID
            return TRUE;
        }
    }

    return FALSE;
}


//--------------------------------------------------------------------------
//  cbIsResolutionExistInEDID
//      This function checks whether the device associate whole EDID  
//  block (SVDs , DTDs , ESTs, STDs) support given resolution 
//
//  IN :
//       pEDID : device associated EDID info structure in CBIOS
//       H_Res : H resolution size
//       V_Res : V resolution size
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsResolutionExistInEDID(
    PCBIOS_EXTENSION pcbe,
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res)
{
    BOOL IsResolutionExist = cbIsResolutionExistInCEAExt(pcbe, pEDID, H_Res, V_Res) 
                             || cbIsResolutionExistInEDIDDetailedTiming(pcbe, pEDID, (WORD)H_Res, (WORD)V_Res) 
                             || cbIsResolutionInEDIDEstStdTiming(pEDID, (WORD)H_Res, (WORD)V_Res);
    
    return IsResolutionExist;
}

//--------------------------------------------------------------------------
//  cbIsTimingExistInCEAExt
//      This function checks whether the device associate EDID CEA extension 
//  block supports given timing 
//
//  IN :
//       pEDID : device associated EDID info structure in CBIOS
//       H_Res : H resolution size
//       V_Res : V resolution size
//       PLL_MRN: clock in PLL MRN format
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsTimingExistInCEAExt(
    PCBIOS_EXTENSION pcbe, 
    IN PCBIOS_EDID_INFO pEDID,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD PLL_MRN)
{
    ULONG i;

    if (!pEDID)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // if extension block is not CEA extension 
    // return FALSE
    if (pEDID->CEABlock_1.CEAExtBlockTag != EDID_CEAEXTENSION_TAG)
    {
        return FALSE;
    }

   // check in CEA extension SVDs 
    if (TRUE == cbIsResolutionExistInSVD(pcbe,
                                         pEDID,
                                         H_Res,
                                         V_Res))
    {
        return TRUE;
    }	

    // check in CEA extension DTDs
    for (i = 0; i < CEAEXT_MAX_DTD_NUM; i++)
    {
        if ( (pEDID->CEABlock_1.DtlTimings[i].Valid)
            && ( pEDID->CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && ( pEDID->CEABlock_1.DtlTimings[i].XResolution == H_Res )
            && ( pEDID->CEABlock_1.DtlTimings[i].YResolution == V_Res )
            && ( pEDID->CEABlock_1.DtlTimings[i].PLL_MRN == PLL_MRN))
        {
            // resolution exist in EDID block 1
            return TRUE;
        }
    }

    return FALSE;
}


//--------------------------------------------------------------------------
//  cbIsTimingInCustomizeTiming
//      This function checks whether the device associate timing (resolution 
//  & refresh rate) supports in 
//  custermize timing table 
//  IN :
//     dispDev : display device bit
//       H_Res : H resolution size
//       V_Res : V resolution size
//   rRateInfo : refresh rate info (refresh rate x 100 & interlaced)
//  OUT :
//      function return status  
//--------------------------------------------------------------------------
BOOL cbIsTimingInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL;
    ULONG i;
    
    // search in customize timing table
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
            && (H_Res == pEntityBufferCur->H_Res)
            && (V_Res == pEntityBufferCur->V_Res)
            && (rRateInfo.rRateX100 == pEntityBufferCur->rRateX100)
            && (rRateInfo.interlaced == pEntityBufferCur->Interlaced))
            {
                return TRUE;
            }
            pEntityBufferCur++;
        }
     }

     return FALSE;
}    

//--------------------------------------------------------------------------
//  cbGetCustomizeTiming
//      This function inits the timing table according to device associate
//  timing (resolution  & refresh rate) supports in customize timing table 
//  found
//  IN :
//     dispDev : display device bit
//       H_Res : H resolution size
//       V_Res : V resolution size
//   rRateInfo : refresh rate info (refresh rate x 100 & interlaced)
//  OUT :
//    pTimingTbl : timing table returned 
//      function return status  
//--------------------------------------------------------------------------
BOOL cbGetCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL;
    ULONG i;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // search in customize timing table
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
            && (H_Res == pEntityBufferCur->H_Res)
            && (V_Res == pEntityBufferCur->V_Res)
            && (rRateInfo.rRateX100 == pEntityBufferCur->rRateX100)
            && (rRateInfo.interlaced == pEntityBufferCur->Interlaced))
            {
                cbTransCustomizeTiming(pEntityBufferCur, pTimingTbl);
                return TRUE;
            }
            pEntityBufferCur++;
        }
     }

     return FALSE;
}

//--------------------------------------------------------------------------
//  cbGetMaxResInCustomizeTiming
//      This function gets the biggest resolution which customize timing can support
//  according to device type. The Max customize timing should be filterd by Panel native
//  mode (MAX EDID resolution).
//  IN :
//     dispDev  : display device bit
// EDIDMaxRes_H : Max EDID H size (Panel H size)
// EDIDMaxRes_V : Max EDID V size (Panel V size)
//
//  OUT :
//       pH_Res : H resolution size pointer
//       pV_Res : V resolution size pointer
//       function return status  
//--------------------------------------------------------------------------
BOOL cbGetMaxFitResInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD EDIDMaxRes_H,
    IN DWORD EDIDMaxRes_V,
    OUT PDWORD pH_Res,
    OUT PDWORD pV_Res)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL;
    ULONG i;
    DWORD H_Res = 0, V_Res = 0;
    
    if (!pH_Res || !pV_Res)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    // search in customize timing table
    // to find the biggest resolution customize timing 
    // can support
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)             
            && (EDIDMaxRes_H >= pEntityBufferCur->H_Res)
            && (EDIDMaxRes_V >= pEntityBufferCur->V_Res)
            && (H_Res <= pEntityBufferCur->H_Res)
            && (V_Res <= pEntityBufferCur->V_Res))
            {
                H_Res = pEntityBufferCur->H_Res;
                V_Res = pEntityBufferCur->V_Res;
            }
            pEntityBufferCur++;
        }
     }

     if (H_Res == 0 || V_Res == 0)
     {
        return FALSE;
     }
     else
     {
        *pH_Res = H_Res;
        *pV_Res = V_Res;
        return TRUE;
     }
}

//--------------------------------------------------------------------------
//  cbGetClosestCustomizeTimingResolution
//      This function finds the closest resolution in customize timing as 
//  the given mode's target Mode. If no customize mode bigger than given mode 
//  also return FALSE.
//
//  IN :
//     dispDev  : display device bit
//       H_Res  : Mode H Resolution
//       V_Res  : Mode V Resolution
//
//  OUT :
//       pCusTargetHRes : nearest customize mode H resolution size pointer
//       pCusTargetVRes : nearest customize mode V resolution size pointer
//       function return status  
//--------------------------------------------------------------------------
BOOL cbGetClosestCustomizeTimingResolution(    
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT PDWORD pCusTargetHRes,
    OUT PDWORD pCusTargetVRes)
{
    DWORD CusTargetHRes = MAX_H_RES, CusTargetVRes = MAX_V_RES;
    PCustomizeTimingEntity pEntityBufferCur;
    ULONG i;
    
    if (!pCusTargetHRes || !pCusTargetVRes)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;

        // get the nearest targetmode in customize timing
        for (i = 0; i < pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
            && (pEntityBufferCur->H_Res >= H_Res)
            && (pEntityBufferCur->V_Res >= V_Res)
            && (pEntityBufferCur->H_Res <= CusTargetHRes)
            && (pEntityBufferCur->V_Res <= CusTargetVRes))
            {
                CusTargetHRes = pEntityBufferCur->H_Res;
                CusTargetVRes = pEntityBufferCur->V_Res;
            }
            pEntityBufferCur++;
        }
    }
    if (CusTargetHRes != MAX_H_RES)
    {
        *pCusTargetHRes = CusTargetHRes;
        *pCusTargetVRes = CusTargetVRes;
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


//--------------------------------------------------------------------------
//  cbGetRefreshRateBufferInCustomizeTiming
//      This function fills all the supported refresh rate( including refresh
//  according to resolution
//  and device type which customize timing can support
//  IN :
//     dispDev : display device bit
//       H_Res : H resolution size
//       V_Res : V resolution size
//     BufSize : pRRatesInfoBuf length
//  OUT :
//   pRRatesInfoBuf : refresh rate buffer to fill
//      pRefreshNum : whole refresh rates of customertiming
//  function return : status
//--------------------------------------------------------------------------
BOOL cbGetRefreshRateBufferInCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD BufSize,
    OUT PDWORD pRefreshNum)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL;
    DWORD rrNum = 0, i;

    if (!pRefreshNum)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        BufSize = 0;
    }

    // search in customize timing table
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
                && (H_Res == pEntityBufferCur->H_Res)
                && (V_Res == pEntityBufferCur->V_Res))
            {
                //Is buffer size enough for saving next refresh rate?
                if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= (BufSize) )
                {
                    // if enough space in the buffer, fill in
                    pRRatesInfoBuf[rrNum].rRateX100 = pEntityBufferCur->rRateX100;
                    // ATT_I bit0 : 1 interlace , 0 progressive
                    pRRatesInfoBuf[rrNum].interlaced = pEntityBufferCur->Interlaced;
                }
                rrNum++;   // report EDID detail timing rrate additionally
            }
            pEntityBufferCur++;
        }

        *pRefreshNum = rrNum; 
        return TRUE;
    }

    return FALSE;
}

//-------------------------------------------------------------------------
//  cbGetMaxTimingFromCustomizeTiming
//      This function returns the Max Customize timing which can support 
//  given resolution
//  IN : 
//      XRes  : X resolution
//      YRes  : Y resolution
//  rRateInfo : refresh rate information
//  OUT :
//   pTimingTbl  : timing after tranformation
//-------------------------------------------------------------------------
BOOL cbGetMaxTimingFromCustomizeTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD XRes, 
    IN DWORD YRes,
    IN RefreshRateInfo rRateInfo, 
    OUT PGFXTimingTable pTimingTbl)
{
    PCustomizeTimingEntity pEntityBufferCur = NULL, pEntityBufferMax = NULL;
    ULONG i;
    DWORD HMaxRes = XRes, VMaxRes = YRes;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // search in customize timing table
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            if((dispDev == pEntityBufferCur->dispDev)
            && (rRateInfo.rRateX100 == pEntityBufferCur->rRateX100)
            && (rRateInfo.interlaced == pEntityBufferCur->Interlaced))
            {
                if ((HMaxRes <= pEntityBufferCur->H_Res)
                && (VMaxRes <= pEntityBufferCur->V_Res))
                {   
                    // save current Max resolution buffer addr & size
                    HMaxRes = pEntityBufferCur->H_Res;
                    VMaxRes = pEntityBufferCur->V_Res;
                    pEntityBufferMax = pEntityBufferCur;
                }
            }
            pEntityBufferCur++;
        }
     }

     if (pEntityBufferMax != NULL)
     {
        return cbTransCustomizeTiming(pEntityBufferMax, pTimingTbl);
     }
     else
     {
        return FALSE;
     }
}

//--------------------------------------------------------------------------
//  cbTransCustomizeTiming
//      This function inits the timing table to set according to 
//  device associate timing (resolution  & refresh rate) supports in 
//  customize timing table entity
//  IN :
//     pEntityBufferCur : customize timing table entity
//  OUT :
//        pTimingTbl : general timing table returned
//      function return status  
//--------------------------------------------------------------------------
BOOL cbTransCustomizeTiming(
    IN PCustomizeTimingEntity pEntityBufferCur,
    OUT PGFXTimingTable pTimingTbl)
{
    if (!pEntityBufferCur || !pTimingTbl)
    {
        ASSERT(FALSE);
        return FALSE;
    }
    
    // horizontal
    pTimingTbl->HTotal        = pEntityBufferCur->HTotal;
    pTimingTbl->HDisEnd       = pEntityBufferCur->HDisEnd;
    pTimingTbl->HBlankStart   = pEntityBufferCur->HBlankStart;
    pTimingTbl->HSyncStart    = pEntityBufferCur->HSyncStart;
    pTimingTbl->HSyncEnd      = pEntityBufferCur->HSyncEnd;
    pTimingTbl->HBlankEnd     = pEntityBufferCur->HBlankEnd;

    // vertical
    pTimingTbl->VTotal        = pEntityBufferCur->VTotal;
    pTimingTbl->VDisEnd       = pEntityBufferCur->VDisEnd;
    pTimingTbl->VBlankStart   = pEntityBufferCur->VBlankStart;
    pTimingTbl->VSyncStart    = pEntityBufferCur->VSyncStart;
    pTimingTbl->VSyncEnd      = pEntityBufferCur->VSyncEnd;
    pTimingTbl->VBlankEnd     = pEntityBufferCur->VBlankEnd;

    // refresh rate info
    // interlace or progressive 
    pTimingTbl->vPLL          = pEntityBufferCur->vPLL;
    pTimingTbl->rRateX100     = pEntityBufferCur->rRateX100;
    pTimingTbl->HPolarity     = pEntityBufferCur->HPolarity;
    pTimingTbl->VPolarity     = pEntityBufferCur->VPolarity;
    pTimingTbl->Interlaced    = pEntityBufferCur->Interlaced;
    
    // aspect ratio default set to zero
    pTimingTbl->AspectRatio   = CBIOS_NONE;
    // only HDMI interlace timing support V sync offset
    if (pTimingTbl->Interlaced == INTERLACE 
    && pEntityBufferCur->dispDev == S3_HDMI)
    {
        // V sync offset value is half of the H total (in pixel clock form)
        pTimingTbl->VSyncOffset = pTimingTbl->HTotal / 2;
    }
    else
    {
        pTimingTbl->VSyncOffset = 0;
    }           

    return TRUE;
}

//--------------------------------------------------------------------------
//  cbGetCustomizeTimingResolution
//      This function fills suitable Customerize timing resolution into resolution
//  buffer. since we need to filter customize timing using device panel size, so function offer two parameter for EDIDMaxRes_H, 
//  EDIDMaxRes_V.Since in customize mode , there will be two different refresh
//  rates for one resolution, we should filter them and just report the resolution 
//  once.
//  
//  IN :
//     dispDev      : display device bit 
//     EDIDMaxRes_H : Max EDID resolution H  
//     EDIDMaxRes_V : Max EDID resolution V 
//                    they are used to filter customize timing table since customize
//                    timing tbl can not be bigger than EDID panel size
//      BufSize     : resolution buffer total size 
//
//  OUT :
//      pResBuf     : resolution buffer pointer
//      pResNum     : Real Resolution Num in customize timing table (not care buffer size)
//     Function status
//--------------------------------------------------------------------------
BOOL cbGetCustomizeTimingResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN DWORD EDIDMaxRes_H,
    IN DWORD EDIDMaxRes_V,
    OUT DWORD *pResBuf,
    IN  DWORD BufSize,
    OUT PDWORD pResNum)
{
    BOOL IsSameResExist = FALSE;
    PCustomizeTimingEntity pEntityBuffer = NULL;
    PCustomizeTimingEntity pEntityBufferCur = NULL;    
    DWORD i, j, xyNum;

    if (!pResNum)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (NULL == pResBuf)
    {
        // NULL == pResBuf meas we need not fill buf, set size = 0 for later logic use
        BufSize = 0;
    }
    
    // There will be different refresh rates for one resolution in customize
    // timing. We should filter them and report the resolution only once.
    if (pcbe->pCustomizeTimingHead != NULL)
    {
        pEntityBufferCur = pcbe->pCustomizeTimingEntityBuf;
        xyNum = 0;
        
        for (i = 0; i<pcbe->pCustomizeTimingHead->timingNum; i++)
        {
            // if EDID mode exists we can not report customize mode 
            // bigger then Max EDID Resolution size , since different size device
            // may change(hotplug) during runtime so that we need to 
            // guarantee customize mode can be show on different device 
            if ((dispDev == pEntityBufferCur->dispDev)           
              && ( pEntityBufferCur->Interlaced == PROGRESSIVE ||
                  (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
              && (EDIDMaxRes_H >= pEntityBufferCur->H_Res)
              && (EDIDMaxRes_V >= pEntityBufferCur->V_Res))
            {
                pEntityBuffer = pcbe->pCustomizeTimingEntityBuf;
                IsSameResExist = FALSE;
                // if same Resolution timing table exist only
                // report once
                for (j = 0; j<i; j++)
                {
                    // find if it is a same resolution timing
                    if((dispDev == pEntityBuffer->dispDev)
                    && ( pEntityBuffer->Interlaced == PROGRESSIVE ||
                        (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                    && (pEntityBuffer->H_Res == pEntityBufferCur->H_Res)
                    && (pEntityBuffer->V_Res == pEntityBufferCur->V_Res))
                    {
                        IsSameResExist = TRUE;
                        break;
                    }
                    pEntityBuffer++;
                }
                // no same resolution exists before
                if (IsSameResExist == FALSE)
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= BufSize)
                    {
                        // if enough space in the buffer, save mode into it
                        pResBuf[xyNum]   = pEntityBufferCur->H_Res;
                        pResBuf[xyNum+1] = pEntityBufferCur->V_Res;
                    }
                    xyNum += 2;
                }
            }
            pEntityBufferCur++;
        }

        // fill in resolution num
        *pResNum = xyNum >> 1;
        return TRUE;
    }

    return FALSE;
}

//--------------------------------------------------------------------------
//  cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode
//      This function filles all fresh rate for Maxmized Target mode H / V resolution 
//  from 
//      1. customize timing
//      2. EDID timing
//      Max target timing comes from customize timing which is less than
//  EDID max timing (panel size) & EDID timing. 
//  If there is same refresh rate in EDID and customize timing, report them all
//
//  IN :
//     dispDev      : display device bit 
//     bufSize       : buffer size of pRRatesInfoBuf
//     
//  OUT :
//    pRRatesInfoBuf: buffer for the found refresh rates
//    pBufSize      : buffer size of whole Max Target Mode Refresh Rates
//  
//     Function status
//--------------------------------------------------------------------------
BOOL cbGetMaxTargetModeRefreshRatesFromEDIDandCusMode(  
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    // max target mode resolution
    DWORD MAXTargetRes_H, MAXTargetRes_V;
    // max customize timing res & EDID detailed timing res
    DWORD CustomRes_H, CustomRes_V, EDIDRes_H, EDIDRes_V;
    DWORD CusRRNum, EDIDRRNum, RRNum;
    BOOL  Cus_Status, EDID_Status;
    RefreshRateInfo *pCurRRInfoBuf = NULL;
    DWORD leftBufSize = 0;

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0; 
    }

    // 1. get Max EDID timing 
    // EDID  timing need to to be filter by Panel size since it is just the panel size
    if ((EDID_Status = cbGetMaxResolutionFromEDIDTiming(pcbe,
                                                        &(pEDID->EDIDInfo), 
                                                        &EDIDRes_H, 
                                                        &EDIDRes_V)) == FALSE)
    {
        // EDID error do not filter customize mode
        EDIDRes_H = EDIDRes_V = MAX_H_RES;
    }

    // 2. get max fit Customize Timing 
    Cus_Status = cbGetMaxFitResInCustomizeTiming(pcbe, 
                                                 dispDev,
                                                 EDIDRes_H,
                                                 EDIDRes_V,
                                                 &CustomRes_H, 
                                                 &CustomRes_V); 

    // 3. get Max Target timing from customize timing or EDID timing
    // EDID timing valid 
    // EDID panel size will be the biggest target timing
    MAXTargetRes_H = EDIDRes_H;
    MAXTargetRes_V = EDIDRes_V;
    if (EDID_Status == FALSE)
    {   
        if (Cus_Status == TRUE)
        {
            // only EDID failed case we use Max customize timing as Max centered 
            // base timing
            MAXTargetRes_H = CustomRes_H;
            MAXTargetRes_V = CustomRes_V;
        }
        else
        {
            // get EDID detailed timing && Customize timing Max size fail
            // we can not find Max Target mode
            return FALSE;
        }
    }

    // 4. get refresh rate num of the Max target timing from customize timing 
    // & EDID timing table if there are the same refresh rate in customize and
    // EDID timing report them all
    if (!cbGetRefreshRateBufferInCustomizeTiming(pcbe, 
                                                 dispDev,
                                                 MAXTargetRes_H,
                                                 MAXTargetRes_V,
                                                 pRRatesInfoBuf,
                                                 bufSize,
                                                 &CusRRNum))
    {
        CusRRNum = 0;    
    }

    // move buffer point and calc buffer size left
    if (NULL == pRRatesInfoBuf)
    {
        pCurRRInfoBuf = NULL;
    }
    else
    {
        pCurRRInfoBuf = pRRatesInfoBuf + CusRRNum;
    }
    if (bufSize > CusRRNum * sizeof(RefreshRateInfo))
    {
        leftBufSize = bufSize - CusRRNum * sizeof(RefreshRateInfo);
    }
    else
    {
        leftBufSize = 0;
    }

    if (!cbGetRefreshRateBufferInEDIDTiming(pcbe,
                                            dispDev,
                                            &(pEDID->EDIDInfo), 
                                            MAXTargetRes_H,
                                            MAXTargetRes_V,
                                            pCurRRInfoBuf,
                                            leftBufSize,
                                            &EDIDRRNum))
    {
        EDIDRRNum = 0;    
    }

    RRNum = CusRRNum + EDIDRRNum;

    // check if this resolution has refresh rate
    if (RRNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = RRNum * sizeof(RefreshRateInfo); 
        }
        return TRUE;
    }
}

//--------------------------------------------------------------------------
//  cbGetMaxTarTimingFromEDIDandCusTiming
//      This function gets the real timing table for Maxmized Target timing
//      1. customize timing
//      2. EDID timing
//      Max target timing comes from customize timing which is less than
//  EDID max timing (panel size) & EDID timing. 
//      customize timing will take first priority
//
//  IN :
//     dispDev      : display device bit 
//     RRateInfo    : resolution refresh rate info
//  OUT :
//    pTimingTbl    : UMA set mode timing table
//     Function status
//--------------------------------------------------------------------------
BOOL cbGetMaxTarTimingFromEDIDandCusTiming(  
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev, 
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    // max target mode resolution
    DWORD MAXTargetRes_H, MAXTargetRes_V;
    // max customize timing res & EDID detailed timing res
    DWORD CustomRes_H, CustomRes_V, EDIDRes_H, EDIDRes_V;
    BOOL  Cus_Status, EDID_Status, bReduceBlk = FALSE;
    
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // 1. get Max EDID timing 
    // EDID  timing need to to be filter by Panel size since it is just the panel size
    if ((EDID_Status = cbGetMaxResolutionFromEDIDTiming(pcbe,
                                                        &(pEDID->EDIDInfo), 
                                                        &EDIDRes_H, 
                                                        &EDIDRes_V)) == FALSE)
    {
        // EDID error do not filter customize mode
        EDIDRes_H = EDIDRes_V = MAX_H_RES;
    }
    
    // 2. get max fit Customize Timing 
    Cus_Status = cbGetMaxFitResInCustomizeTiming(pcbe, 
                                                 dispDev,
                                                 EDIDRes_H,
                                                 EDIDRes_V,
                                                 &CustomRes_H, 
                                                 &CustomRes_V); 

    // 3. get Max Target timing from customize timing or EDID timing
    // EDID timing valid 
    // EDID panel size will be the biggest target timing
    MAXTargetRes_H = EDIDRes_H;
    MAXTargetRes_V = EDIDRes_V;
    if (EDID_Status == FALSE)
    {   
        if (Cus_Status == TRUE)
        {
            // only EDID failed case we use Max customize timing as Max centered 
            // base timing
            MAXTargetRes_H = CustomRes_H;
            MAXTargetRes_V = CustomRes_V;
        }
        else
        {
            // get EDID detailed timing && Customize timing Max size fail
            // we can not find Max Target mode
            return FALSE;
        }
    }

    // 4. first check if can be centered on customize timing
    // since customize timing takes first priority
    if (!cbGetCustomizeTiming(pcbe, dispDev, MAXTargetRes_H, MAXTargetRes_V, RRateInfo, pTimingTbl))
    {
        if (dispDev & (S3_DVI | S3_DVI2 | S3_DP | S3_DP2))
        {
            bReduceBlk = TRUE;
        }
        // do centering on EDID timing
        if (!cbGetTimingFromEDID(pcbe, &(pEDID->EDIDInfo), MAXTargetRes_H, MAXTargetRes_V, RRateInfo, bReduceBlk, pTimingTbl))
        {
            // EDID invalid and no customize timing 
            return FALSE;
        }
    }

    return TRUE;
}    


//------------------------------------------------------------------------
// cbGetCenterTiming
//    This function calculate real timing table from Source Mode & Target Mode
//  IN :
//    SRC_H_Res : source mode H resolution
//    SRC_V_Res : source mode V resolution
//  IN OUT :
//   pTimingTbl : target timing table to be centered  
//------------------------------------------------------------------------
BOOL cbGetCenterTiming(
    IN DWORD SRC_H_Res,
    IN DWORD SRC_V_Res,
    IN OUT PGFXTimingTable pTargetTimingTbl)
{
    if (!pTargetTimingTbl)
    {
        ASSERT(FALSE);
        return FALSE;
    }

    // if interlace mode all V elemeent / 2
    if (pTargetTimingTbl->Interlaced == INTERLACE)
    {
        SRC_V_Res /= 2;
    }
    
    // if SRC_H_Res >= pTargetTimingTbl->HDisEnd or SRC_V_Res > pTargetTimingTbl->VDisEnd
    // do not modify target timing just return
    if (SRC_H_Res < pTargetTimingTbl->HDisEnd) 
    {
        WORD HGaps = (WORD)(pTargetTimingTbl->HDisEnd - SRC_H_Res) / 2;
        pTargetTimingTbl->HDisEnd  = (WORD)SRC_H_Res;
        pTargetTimingTbl->HBlankStart -= HGaps;
        pTargetTimingTbl->HBlankEnd   -= HGaps;
        pTargetTimingTbl->HSyncStart  -= HGaps;
        pTargetTimingTbl->HSyncEnd    -= HGaps;
    }
    
    if (SRC_V_Res < pTargetTimingTbl->VDisEnd) 
    {
        WORD VGaps = (WORD)(pTargetTimingTbl->VDisEnd - SRC_V_Res) / 2;
        pTargetTimingTbl->VDisEnd  = (WORD)SRC_V_Res;
        pTargetTimingTbl->VBlankStart -= VGaps;
        pTargetTimingTbl->VBlankEnd   -= VGaps;
        pTargetTimingTbl->VSyncStart  -= VGaps;
        pTargetTimingTbl->VSyncEnd    -= VGaps;
    }

    return TRUE;
}

//------------------------------------------------------------------------
// cbGetShiftTiming
//    This function calculate real timing table for View size shift on Dest Mode
//  IN :
//    SRC_H_Res : source mode H resolution
//    SRC_V_Res : source mode V resolution
//  IN OUT :
//   pTimingTbl : target timing table to be shifted
//------------------------------------------------------------------------
BOOL cbGetShiftTiming(
    IN PCBiosViewSizeParams pView,
    IN OUT PGFXTimingTable pTargetTimingTbl)
{
    WORD YRes;
    WORD YShift;

    if (NULL == pView || NULL == pTargetTimingTbl)
    {
        ASSERT(FALSE);
        return FALSE;
    }

    // do X shift
    if (pView->XRes < pTargetTimingTbl->HDisEnd) 
    {
        pTargetTimingTbl->HDisEnd  = pView->XRes;
        pTargetTimingTbl->HBlankStart -= pView->XShift;
        pTargetTimingTbl->HBlankEnd   -= pView->XShift;
        pTargetTimingTbl->HSyncStart  -= pView->XShift;
        pTargetTimingTbl->HSyncEnd    -= pView->XShift;
    }

    // if interlace mode all V elemeent / 2
    if (INTERLACE == pTargetTimingTbl->Interlaced)
    {
        YRes   = pView->YRes / 2;
        YShift = pView->YShift / 2;
    }
    else
    {
        YRes   = pView->YRes;
        YShift = pView->YShift;
    }
    // do Y shift
    if (YRes < pTargetTimingTbl->VDisEnd) 
    {
        pTargetTimingTbl->VDisEnd  = YRes;
        pTargetTimingTbl->VBlankStart -= YShift;
        pTargetTimingTbl->VBlankEnd   -= YShift;
        pTargetTimingTbl->VSyncStart  -= YShift;
        pTargetTimingTbl->VSyncEnd    -= YShift;
    }

    return TRUE;
}

//----------------------------------------------------------------------------
// cbGetIGAScaleFactor
//     This function caculates H / V scaling factor according to source mode timing
// and target mode timing.
//  IN :
//      SRC_H_Res : Source mode H resolution
//      SRC_V_Res : Source mode V resolution
//      DES_H_Res : Destionation timing H 
//      DES_V_Res : Destionation timing V
//      Interlaced: is dest timing interlaced (means dest V timing = dest V / 2)
//  OUT :
//      pScaleFactor : output scaling factor
//----------------------------------------------------------------------------
BOOL cbGetIGAScaleFactor(
    IN PCBIOS_EXTENSION pcbe, 
    IN DWORD SRC_H_Res,
    IN DWORD SRC_V_Res, 
    IN DWORD DES_H_Res, 
    IN DWORD DES_V_Res,
    IN BYTE  Interlaced,
    OUT PScaleFactor pScaleFactor)
{
    if (!pScaleFactor || !DES_H_Res || !DES_V_Res)
    {
        ASSERT(FALSE);
        return FALSE;
    }

    // init value
    pScaleFactor->HScaleFactor = 0;
    pScaleFactor->VScaleFactor = 0;
    // if interlaced timing, dest V must * 2 to recover real dest V
    if (INTERLACE == Interlaced)
    {
        DES_V_Res *= 2;
    }

    if (SRC_H_Res < DES_H_Res) //pMode->HDisEnd equ LCD physical Hsize
    {
        pScaleFactor->HScaleFactor = cbGetExpandScalingFactor((WORD)SRC_H_Res, (WORD)DES_H_Res, H_SCALING_FACTOR);
    }
    if (SRC_V_Res < DES_V_Res) //pMode->VDisEnd equ LCD physical Vsize
    {
        pScaleFactor->VScaleFactor = cbGetExpandScalingFactor((WORD)SRC_V_Res, (WORD)DES_V_Res, V_SCALING_FACTOR);
    }

    if (pcbe->ChipCaps.IGA12_Support_Downscale)
    {
        // the priority of upscaling is higher than downscaling
        if (pScaleFactor->HScaleFactor == 0 && pScaleFactor->VScaleFactor == 0)
        {
            if (SRC_H_Res > DES_H_Res) //pMode->HDisEnd equ LCD physical Hsize
            {
                pScaleFactor->HScaleFactor = cbGetDownScalingFactor((WORD)SRC_H_Res, (WORD)DES_H_Res, H_SCALING_FACTOR);
            }
            if (SRC_V_Res > DES_V_Res) //pMode->VDisEnd equ LCD physical Vsize
            {
                pScaleFactor->VScaleFactor = cbGetDownScalingFactor((WORD)SRC_V_Res, (WORD)DES_V_Res, V_SCALING_FACTOR);
            }
        }
    }

    return TRUE;
}

//----------------------------------------------------------------------------
// cbGetKeepAspectRatioExpTiming
//     This function caculates centering timing after expantion & H / V scaling factor
// when keep aspect ratio of source mode.
//  IN :
//      SRC_H_Res : Source mode H resolution
//      SRC_V_Res : Source mode V resolution
//  IN OUT :
//      pTimingTbl   : target timing table to be scaled then centered  
//  OUT :
//      pScaleFactor : output scaling factor
//----------------------------------------------------------------------------
BOOL cbGetKeepAspectRatioExpTiming(
    IN PCBIOS_EXTENSION pcbe,
    IN DWORD srcH,
    IN DWORD srcV,
    IN OUT PGFXTimingTable pTargetTimingTbl,
    OUT PScaleFactor pScaleFactor)
{
    DWORD dstH, dstV;
    DWORD realV;

    // if timing is interlaced, V disp end  = real V / 2
    if (INTERLACE == pTargetTimingTbl->Interlaced)
    {
        realV = pTargetTimingTbl->VDisEnd * 2;
    }
    else
    {
        realV = pTargetTimingTbl->VDisEnd;
    }

    // calculate dest view size
    if (srcH * realV < srcV * pTargetTimingTbl->HDisEnd)
    {
        // it means srcH/srcV < dstH/dstV, V can expansion to max
        dstH = srcH * realV / srcV;
        dstV = realV;
    }
    else
    {
        // it means srcH/srcV > dstH/dstV, H can expansion to max
        dstH = pTargetTimingTbl->HDisEnd;
        dstV = srcV * pTargetTimingTbl->HDisEnd / srcH;
    }

    // scale source buffer to destination view
    cbGetIGAScaleFactor(pcbe, srcH, srcV, dstH, dstV, PROGRESSIVE, pScaleFactor);
    // center destination view on device
    cbGetCenterTiming(dstH, dstV, pTargetTimingTbl);

    return TRUE;
}

//--------------------------------------------------------------------------
//  cbGetCRTTypeResolutionsBuffer
//      this function fills resolution buffer according to CRT type resoltion
//  timing policy. The policy based on below logic
//      1. timing(Resolution & refresh rate) based on VBIOS VESAVPIT
//      2. timing(Resolution & refresh rate) based on EDID detailed timing
//      if VESAVPIT has conflict with EDID we use EDID detailed timing
//      we will not consider Ext / Std timing stored in EDID in CRT timing type
//      case              
//
//          if VCP is null we will use CBIOS VESAVPIT timing while do not use EDID
//      detailed timing 
//
//  IN :
//      dispDev : display device passed to get EDID
//  IN OUT :
//      pResBuf : total buffer used to fill resolutions 
//      bufSize : buffer size of pResBuf used to fill resolutions
//      pBufSize : real buffer size of whole CRT Type resolutions
//      function status
//-------------------------------------------------------------------------
BOOL cbGetCRTTypeResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{
    DWORD xyNum = 0, ResNum = 0;
    PVESA_INFO pVESA_Info = NULL;
    PVESA_INFO_CBIOS pVESA_Info_CBIOS = NULL;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    ULONG i;

    if (NULL == pResBuf)
    {
        // not need fill buffer, set buf size = 0 for later logic
        bufSize = 0;
    }

    // when VCP is null just use CBIOS table 
    // do not use EDID timing table and customize timing table
    // only use CBIOS VESAVPIT data structure
    if (pcbe->pVCPInfo != NULL)
    {
        // 1. ---------------- customize timing first priority ---------------------
        // get all supported resolutions in customize timing
        // for CRT timing type we need not to filter customize timing with Max edid 
        // resolution so just pass 0xFFFF, 0xFFFF
        if ( cbGetCustomizeTimingResolution(pcbe, 
                                            dispDev, 
                                            0xFFFF,
                                            0xFFFF,
                                            pResBuf,
                                            bufSize,
                                            &ResNum) )
        {
            // customize xy num =customize resolution num * 2
            xyNum = ResNum * 2;
        }

        
        // 2. ----------------- EDID timing second priority -----------------------
        // search in EDID resolutions
        if (NULL != pEDID)
        {
            // search in detail timing
            for (i=0; i < 4; i++)
            {
                // check in customize timing tbl, do not report twice
                if (pEDID->EDIDInfo.DtlTimings[i].Valid
                && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                         dispDev, 
                                                         pEDID->EDIDInfo.DtlTimings[i].XResolution, 
                                                         pEDID->EDIDInfo.DtlTimings[i].YResolution))
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                    {
                        // if enough space in the buffer, fill res in
                        pResBuf[xyNum]   = pEDID->EDIDInfo.DtlTimings[i].XResolution; // XResolution
                        pResBuf[xyNum+1] = pEDID->EDIDInfo.DtlTimings[i].YResolution; // YResolution
                    }

                    xyNum += 2;
                }
            }
        }// EDID available

        // 3. ---------------------- VESAVPIT third priority ----------------------
        pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);
        // search mode table first
        while (pVESA_Info->HSize != INVALID_H_SIZE)
        {
            if(cbIsModeAvailable(pcbe, dispDev, pVESA_Info))
            {
                // check in Customize timing & EDID detailed timing tbl, do not report twice
                if (!cbIsResolutionExistInCustomizeTiming(pcbe, dispDev, pVESA_Info->HSize, pVESA_Info->VSize)
                 && (pEDID != NULL)
                 && !cbIsResolutionExistInEDIDDetailedTiming(pcbe, &(pEDID->EDIDInfo), pVESA_Info->HSize, pVESA_Info->VSize))
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                    {
                        // if enough space in the buffer, fill res in
                        pResBuf[xyNum]   = pVESA_Info->HSize; // XResolution
                        pResBuf[xyNum+1] = pVESA_Info->VSize; // YResolution
                    }

                    xyNum += 2;
                }
            } // if mode available
            pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
        } // mode table
    }
    // Search in CBIOS VESAVPIT
    else
    {
        pVESA_Info_CBIOS = MODE_TABLE_CBIOS;
        // search mode table first
        for(i = 0; i < CBIOS_GENRIC_MODESUPPORT_NUM; i++)
        {
            // found VESA mode info from CBIOS
            if( cbIsModeAvailable(pcbe, dispDev, &pVESA_Info_CBIOS[i].vesainfo) )
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                {
                    // if enough space in the buffer, fill res in
                    pResBuf[xyNum]   = pVESA_Info_CBIOS[i].vesainfo.HSize; // XResolution
                    pResBuf[xyNum+1] = pVESA_Info_CBIOS[i].vesainfo.VSize; // YResolution
                }
                
                xyNum += 2; 
            } // if mode available
        }
    }

    // if this resolution supported for CRT type device
    if (xyNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = xyNum * sizeof(DWORD);
        }
        return TRUE;
    }
}

//*****************************************************************************
//
//  cbGetCRTTypeRefreshRatesForResolution
//
//  This function fills the size of refresh rate information memory buffer for CRT
//  type resolution.
//      we offer CRT type refresh rate according to rule below
//   CRT refresh rate
//      1. timing(Resolution & refresh rate) based on VBIOS VESAVPIT
//      2. timing(Resolution & refresh rate) based on EDID detailed timing
//
//      we report all the refreshrate for one resolution. since same refreshrate
//      for one resolution is acceptable, so report all the refresh rate in customertiming
//      EDID detailed timing and VESAVPIT
//
//  Parameters:
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf: refresh rate buffer for CBIOS to fill in
//      bufSize:        buffer size of pRRatesInfoBuf
//      pBufSize:       returns the whole CRT Type Refresh Rate buffer size required in bytes
//                      for the specified device and resolution
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetCRTTypeRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN DWORD bufSize,
    OUT DWORD *pBufSize)
{
    PVESA_INFO pVESA_Info = NULL;
    PVESA_INFO_CBIOS pVESA_Info_CBIOS = NULL;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD rrNum = 0;
    RefreshRateInfo rRateInfo;
    DWORD i;

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0; 
    }

    // when VCP is null just use CBIOS table 
    // do not use EDID timing table and customize timing table
    // only use CBIOS VESAVPIT data structure
    if (pcbe->pVCPInfo != NULL)
    {
        // 1. ---------- customize timing refresh rate first priority --------------
        if (!cbGetRefreshRateBufferInCustomizeTiming(pcbe, 
                                                     dispDev,
                                                     H_Res,
                                                     V_Res,
                                                     pRRatesInfoBuf,
                                                     bufSize,
                                                     &rrNum))
        {
            rrNum = 0;
        }

        // 2. ---------- device EDID timing refresh rate second priority -----------
        // check in EDID
        if (NULL != pEDID)
        {
            // check in detail timing
            for (i = 0; i < EDID1X_BLOCK0_MAX_DTD_NUM; i++)
            {
                if ( (pEDID->EDIDInfo.DtlTimings[i].Valid)
                    && ( pEDID->EDIDInfo.DtlTimings[i].XResolution == H_Res )
                    && ( pEDID->EDIDInfo.DtlTimings[i].YResolution == V_Res ) )
                {
                    rRateInfo.rRateX100 = pEDID->EDIDInfo.DtlTimings[i].rRateX100;
                    rRateInfo.interlaced = pEDID->EDIDInfo.DtlTimings[i].Interlaced;
                    // refresh rate exist in EDID while not in Customize timing
                    //Is buffer size enough for saving next refresh rate?
                    if ( (NULL != pRRatesInfoBuf) && ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                    {
                        // if enough space in the buffer, fill in
                        pRRatesInfoBuf[rrNum].rRateX100 = pEDID->EDIDInfo.DtlTimings[i].rRateX100;
                        pRRatesInfoBuf[rrNum].interlaced = pEDID->EDIDInfo.DtlTimings[i].Interlaced ;
                    }
                    rrNum++;   // report EDID detail timing rrate additionally
                }
            }
        } // if EDID available


        // 3. ---------------------- VESAVPIT third priority ----------------------
        // Check VBIOS timing table   
        if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
        {
            PVESA_VPIT pVESA_VPIT = (PVESA_VPIT)(pVESA_Info + 1);                

            // fill all refresh rate in buf
            for (i=0; i<pVESA_Info->RRateCount; i++)
            {
                rRateInfo.rRateX100 = pVESA_VPIT->RRate *100;
                rRateInfo.interlaced = (pVESA_VPIT->Attribute & ATT_I) ? INTERLACE : PROGRESSIVE;
                // if refresh rate exists in EDID or customize timing 
                // also report the refreshrate in VESAVPIT (duplication is acceptable)
                if(!(pVESA_VPIT->Attribute & ATT_DISABLE))
                {
                    //Is buffer size enough for saving next refresh rate?
                    if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                    {
                        // if enough space in the buffer, fill in
                        pRRatesInfoBuf[rrNum].rRateX100 = pVESA_VPIT->RRate * 100;
                        pRRatesInfoBuf[rrNum].interlaced = pVESA_VPIT->Attribute & ATT_I;
                    }
                    rrNum++;
                }
                pVESA_VPIT++; // += sizeof(VESA_VPIT);
            } // for RRateCount
        }
    }
    // CBIOS VESAVPIT
    else if (cbGetCBIOSVesaInfo(pcbe, H_Res, V_Res, MODE_TABLE_CBIOS, CBIOS_GENRIC_MODESUPPORT_NUM, &pVESA_Info_CBIOS))
    {
        // check CBIOS timing table
        for (i=0; i < pVESA_Info_CBIOS->vesainfo.RRateCount; i++)
        {
            //Is buffer size enough for saving next refresh rate?
            if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
            {
                // if enough space in the buffer, fill in
                pRRatesInfoBuf[rrNum].rRateX100 = pVESA_Info_CBIOS->pvesavpit[i].RRate * 100;
                pRRatesInfoBuf[rrNum].interlaced = pVESA_Info_CBIOS->pvesavpit[i].Attribute & ATT_I;
            }
            rrNum++;
        }
    }

    if (rrNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = rrNum * sizeof(RefreshRateInfo);
        }
        return TRUE;
    }
}    

//*****************************************************************************
//
//  cbGetCRTTypeTimingTbl
//
//    This function gets CRT type timing table according to H, V resolution , and 
//  refresh rate
//    query CRT timing logic 
//      1. find in EDID detailed timing 
//      2. find in all valid VESAVPIT timing table
//  IN :
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//  RRateInfo:          refresh rate information 
//                      (refreshrate & interlaced) 
//                      for the specified device and resolution
//  OUT :
//      pTimingTbl :    general timing table to be filled
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetCRTTypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    BOOL status;
    GFXTimingTable tmpTimingTbl;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD curH = MAX_H_RES, curV= MAX_V_RES;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // get closest VESA VPIT
    if (pcbe->pVCPInfo != NULL)
    {
        // get closest timing from VBIOS table
        if (dispDev & (S3_DVI | S3_DVI2))
        {
            // For DVI, first get reduce blanking timing, if not exist, get vesa vpit table
            if(cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, TRUE, pTimingTbl) &&
               H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart)
            {
                status = TRUE;
            }
            else
            {
                status = cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl);
            }
        }
        else
        {
            status = cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl);
        }
    }
    else
    {
        // get closest timing table in CBIOS 
        status = cbGetCBIOSVesaTimingTable(pcbe, H_Res, V_Res, RRateInfo, MODE_TABLE_CBIOS, CBIOS_GENRIC_MODESUPPORT_NUM, pTimingTbl);
    }

    // find closest timing in EDID SVD & DTD
    if (NULL != pEDID)
    {
        if (cbGetEDIDSVDandDTDTiming(pcbe, &(pEDID->EDIDInfo), (WORD)H_Res, (WORD)V_Res, RRateInfo, &tmpTimingTbl))
        {
            if ( !status ||
                (tmpTimingTbl.HBlankStart <= pTimingTbl->HBlankStart &&
                tmpTimingTbl.VBlankStart <= pTimingTbl->VBlankStart) )
            {
                // if get VESA VPIT not ok, or EDID timing smaller than VPIT, use EDID timing
                memcpy(pTimingTbl, &tmpTimingTbl, sizeof(GFXTimingTable));
            }
            status = TRUE;
        }
    }

    // find closest timing in customize timing
    if (cbGetClosestCustomizeTimingResolution(pcbe, dispDev, H_Res, V_Res, &curH, &curV))
    {
        if ( !status || (curH <= pTimingTbl->HBlankStart && curV <= pTimingTbl->VBlankStart) )
        {
            // if not get available timing, or customize timing smaller than before timing, use customize timing
            cbGetCustomizeTiming(pcbe, dispDev, curH, curV, RRateInfo, pTimingTbl);
            status = TRUE;
        }
    }

    // if can't get corresponding timing, calc it
    if (!status)
    {
        status = cbGetCVTTiming(pcbe, H_Res, V_Res, RRateInfo, FALSE, pTimingTbl);
        if(!status)
        {
            status = cbGetGTFTiming(pcbe, H_Res, V_Res, RRateInfo, FALSE, FALSE, pTimingTbl);
            if(!status)
            {
                cbDbgPrint(0, "cbGetCRTTypeTimingTbl: can't get target timing!\n");
                return FALSE;
            }
        }
    }

    return status;
}

//*****************************************************************************
//
//  cbGetHDMITypeTimingTbl---This function is obsoleted after adding all ceat timing suppport
//
//    This function gets CEA timing table according to H, V resolution , and 
//  refresh rate
//    query CEA timing logic 
//       find in all valid CEAVPIT timing table
//  IN :
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//  RRateInfo:          refresh rate information 
//                      (refreshrate & interlaced) 
//                      for the specified device and resolution
//  OUT :
//      pMode:          pMode points to the real timing table to fill
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetHDMITypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    // customize timing occupies top priority

    // search timing table in CBIOS 
    if (!cbGetCBIOSCEATimingTable(pcbe, H_Res, V_Res, RRateInfo, pTimingTbl))          
    {
        return FALSE;
    }
       
    
    return TRUE;
}

//--------------------------------------------------------------------------
//  cbGetEDIDResolutionsBuffer
//      this function fills resolution buffer according to EDID timing policy.
//  The policy based on below logic
//      if EDID valid
//          for resolution H / V which is less than EDID max panel size 
//          if Est / Std mode == Detailed timing
//          we will report only once as detailed timing
//      
//
//     Filled buffer length will be set in pBufSize
//  IN :
//      dispDev : display device passed to get EDID
//      bufSize : buffer size of pResBuf to fill resolutions
//
//  OUT :
//      pResBuf : total buffer used to fill resolutions 
//      pBufSize : real buffer size of whole EDID resolutions
//      function status
//-------------------------------------------------------------------------
BOOL cbGetEDIDResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    IN OUT DWORD *pBufSize)
{   
    PVESA_INFO pVESA_Info = NULL;
    DWORD PanelHRes, PanelVRes;                          // Panel H / V size
    DWORD xyNum = 0, resolutionNum = 0;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    ULONG i, j;
    BOOL IsSameResExist;

    if (NULL == pResBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0;
    }

    // 1. ---------------- customize timing refresh rate first priority --------------------
    // get all supported resolutions in customize timing
    // for EDID timing type we need to filter customize timing with Max edid resolution
    // get panel size from EDID. if EDID is broken we will use customize timing as the device's
    // EDID detailed timing
    // find Max resolution in EDID as monitor size 
    if (cbGetMaxResolutionFromEDIDTiming(pcbe, &(pEDID->EDIDInfo), &PanelHRes, &PanelVRes) == FALSE)
    {
        PanelHRes = PanelVRes = MAX_H_RES;
    }
    if (FALSE == cbGetCustomizeTimingResolution(pcbe, 
                                                dispDev, 
                                                PanelHRes,
                                                PanelVRes,
                                                pResBuf,
                                                bufSize,
                                                &resolutionNum))
    {
        xyNum = 0;
    }
    else
    {
        // customize xy num = customize resolution num * 2
        xyNum += resolutionNum << 1;
    }           

    // if EDID broken and no Customize timing table 
    // just return FALSE
    if (PanelHRes == MAX_H_RES && resolutionNum == 0)
    {
        return FALSE;
    }
    else if (PanelHRes == MAX_H_RES && resolutionNum != 0)
    {
        // if has customize timing & EDID broken 
        // change Max panel size to customize timing
        cbGetMaxFitResInCustomizeTiming(pcbe, 
                                        dispDev,
                                        PanelHRes,
                                        PanelVRes,
                                        &PanelHRes,
                                        &PanelVRes);
    }


    // 2. ------------------- EDID SVD DTD timing check --------------------------
    // 2.1 ---------------- EDID CEA extension block check ----------------------
    // CEA extension block EDID 
    if (pEDID->EDIDInfo.CEABlock_1.CEAExtBlockTag == EDID_CEAEXTENSION_TAG)
    {
        // 2.1.1 --- if EDID extension block version 1.3 or above check SVDS ---
        if (pEDID->EDIDInfo.CEABlock_1.CEA861MiscAttrib.RevisionNumber >= 0x03)
        {
            for (i = 0; i < CEAEXT_MAX_SVD_NUM; i++)
            {
                BYTE SVDIndex = pEDID->EDIDInfo.CEABlock_1.ShortVideoDescriptor[i].SVD;
                if(SVDIndex != 0)
                {
                    if ( cbIsDClkOverLimit(pcbe, dispDev, CEA861_FormatTimingTbl[SVDIndex-1].PLL_SEED) )
                    {
                        continue;
                    }

                    if(!pcbe->ChipCaps.HDMI_SUPPORT_DUPLICATE_MODE)
                    {
                        if(cbIsDuplicateMode(pcbe, SVDIndex))
                            continue;
                    }
                }

                if (SVDIndex != 0
                    && ( CEA861_FormatTbl[SVDIndex-1].Interlaced == PROGRESSIVE ||
                        (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                    && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                             dispDev, 
                                                             CEA861_FormatTbl[SVDIndex-1].XRes, 
                                                             CEA861_FormatTbl[SVDIndex-1].YRes))
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                    {
                        // if enough space in the buffer, fill in
                        pResBuf[xyNum]   = CEA861_FormatTbl[SVDIndex - 1].XRes; // XResolution
                        pResBuf[xyNum+1] = CEA861_FormatTbl[SVDIndex - 1].YRes; // YResolution
                    }
                    xyNum += 2;
                }
            }
        }

        // 2.1.2 ----------------- check DTDs in Ext block ----------------------
        for (i=0; i<CEAEXT_MAX_DTD_NUM; i++)
        {
            if (pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].Valid)
            {
                if( cbIsDClkOverLimit(pcbe, dispDev,
                                       cbCalcClkFromDWORDMRN(pcbe, pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].PLL_MRN) ) )
                {
                    continue;
                }
            }

            if ((pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].Valid)
                && ( pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].Interlaced == PROGRESSIVE ||
                    (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
                && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                         dispDev, 
                                                         pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].XResolution, 
                                                         pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].YResolution)
                && !cbIsResolutionExistInSVD(pcbe,
                                             &(pEDID->EDIDInfo),
                                             pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].XResolution,
                                             pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].YResolution))
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                {
                    // if enough space in the buffer, fill in
                    pResBuf[xyNum]   = pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].XResolution; // XResolution
                    pResBuf[xyNum+1] = pEDID->EDIDInfo.CEABlock_1.DtlTimings[i].YResolution; // YResolution
                }
                xyNum += 2;
            }
        }
    }

    // 2.2.----------------------- EDID base block check -----------------------------
    // search in detail timing
    for (i = 0; i < 4; i++)
    {
        if (pEDID->EDIDInfo.DtlTimings[i].Valid )
        {
            if(cbIsDClkOverLimit(pcbe, dispDev,
                                  cbCalcClkFromDWORDMRN(pcbe, pEDID->EDIDInfo.DtlTimings[i].PLL_MRN) ) )
            {
                continue;
            }

#if !LINUX_PLATFORM
            if(cbAD9389VesaModeFilter(pcbe, dispDev, pEDID->EDIDInfo.DtlTimings[i].XResolution, 
                pEDID->EDIDInfo.DtlTimings[i].YResolution, pEDID->EDIDInfo.DtlTimings[i].rRateX100))
            {
                continue;
            }
#endif
        }

        // check in Customize timing and CEA extension block, do not report twice
        if (pEDID->EDIDInfo.DtlTimings[i].Valid
            && ( pEDID->EDIDInfo.DtlTimings[i].Interlaced == PROGRESSIVE ||
                (pcbe->pVCPInfo->miscConfigure2 & HDMI_INTERLACE_MODE_SUPPORT) )
            && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                     dispDev, 
                                                     pEDID->EDIDInfo.DtlTimings[i].XResolution, 
                                                     pEDID->EDIDInfo.DtlTimings[i].YResolution)
            && !cbIsTimingExistInCEAExt(pcbe,
                                            &(pEDID->EDIDInfo),
                                            pEDID->EDIDInfo.DtlTimings[i].XResolution,
                                            pEDID->EDIDInfo.DtlTimings[i].YResolution,
                                            pEDID->EDIDInfo.DtlTimings[i].PLL_MRN))
        {
            //Is buffer size enough for saving next mode?
            if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
            {
                // if enough space in the buffer, fill in
                pResBuf[xyNum]   = pEDID->EDIDInfo.DtlTimings[i].XResolution; // XResolution
                pResBuf[xyNum+1] = pEDID->EDIDInfo.DtlTimings[i].YResolution; // YResolution
            }
            xyNum += 2;
        }
    }

    // search in STD timing
    for (i = 0; i < 8; i++)
    {
        // filter mode over TMDS link limitation
        // DVI/DVI2 use TMDS link
        if ( (S3_DVI | S3_DVI2) & dispDev )
        {
            if ( (pEDID->EDIDInfo.StdTimings[i].XResolution > 1920)
                || (pEDID->EDIDInfo.StdTimings[i].YResolution > 1200) )
            {
                continue; // simple func for filter mode big than 1920x1200
            }
        }
        
        if(pEDID->EDIDInfo.StdTimings[i].Valid)
        {
            GFXTimingTable TimingTbl;
            BOOL bReduceBlk = FALSE;

            if(dispDev & (S3_DVI | S3_DVI2 | S3_DP | S3_DP2))
                bReduceBlk = TRUE;

            cbGetSTDTiming(pcbe, bReduceBlk, pEDID->EDIDInfo.StdTimings[i].XResolution, pEDID->EDIDInfo.StdTimings[i].YResolution, pEDID->EDIDInfo.StdTimings[i].rrateX100, &TimingTbl);
                
            if(cbIsDClkOverLimit(pcbe, dispDev, (TimingTbl.HTotal * TimingTbl.VTotal * (TimingTbl.rRateX100 / 100))))
            {
                continue;
            }

#if !LINUX_PLATFORM
            if(cbAD9389VesaModeFilter(pcbe, dispDev, pEDID->EDIDInfo.StdTimings[i].XResolution, 
                pEDID->EDIDInfo.StdTimings[i].YResolution, pEDID->EDIDInfo.StdTimings[i].rrateX100))
            {
                continue;
            }
#endif
        }

        IsSameResExist = FALSE;
        if ( (pEDID->EDIDInfo.StdTimings[i].Valid)
            && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                     dispDev, 
                                                     pEDID->EDIDInfo.StdTimings[i].XResolution, 
                                                     pEDID->EDIDInfo.StdTimings[i].YResolution)
            && !cbIsResolutionExistInCEAExt(pcbe,
                                            &(pEDID->EDIDInfo),
                                            pEDID->EDIDInfo.StdTimings[i].XResolution,
                                            pEDID->EDIDInfo.StdTimings[i].YResolution)
            && !cbIsResolutionExistInEDIDDetailedTiming(pcbe,
                                                        &(pEDID->EDIDInfo),
                                                        pEDID->EDIDInfo.StdTimings[i].XResolution,
                                                        pEDID->EDIDInfo.StdTimings[i].YResolution))

        {
            // filte in STD timing to exclude duplication
            for (j = 0; j < i; j++)
            {
                if (pEDID->EDIDInfo.StdTimings[j].Valid
                    && pEDID->EDIDInfo.StdTimings[i].XResolution == pEDID->EDIDInfo.StdTimings[j].XResolution
                    && pEDID->EDIDInfo.StdTimings[i].YResolution == pEDID->EDIDInfo.StdTimings[j].YResolution)
                {
                    IsSameResExist = TRUE;
                    break;
                }   
            }

            if (IsSameResExist == FALSE)
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                {
                    // if enough space in the buffer, fill in
                    pResBuf[xyNum]   = pEDID->EDIDInfo.StdTimings[i].XResolution; // XResolution
                    pResBuf[xyNum+1] = pEDID->EDIDInfo.StdTimings[i].YResolution; // YResolution
                }
                xyNum += 2;
            }
        }
    }

    // search in EST timing
    for (i = 0; i < 16; i++)
    {
        IsSameResExist = FALSE;
#if !LINUX_PLATFORM
        if(cbAD9389VesaModeFilter(pcbe, dispDev, pEDID->EDIDInfo.EstTimings[i].XResolution,
            pEDID->EDIDInfo.EstTimings[i].YResolution, pEDID->EDIDInfo.EstTimings[i].rrateX100))
        {
            continue;
        }
#endif
        if ((pEDID->EDIDInfo.EstTimings[i].Valid)
            && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                     dispDev, 
                                                     pEDID->EDIDInfo.EstTimings[i].XResolution, 
                                                     pEDID->EDIDInfo.EstTimings[i].YResolution)
            && !cbIsResolutionExistInCEAExt(pcbe,
                                            &(pEDID->EDIDInfo),
                                            pEDID->EDIDInfo.EstTimings[i].XResolution,
                                            pEDID->EDIDInfo.EstTimings[i].YResolution)
            && !cbIsResolutionExistInEDIDDetailedTiming(pcbe,
                                                        &(pEDID->EDIDInfo),
                                                        pEDID->EDIDInfo.EstTimings[i].XResolution,
                                                        pEDID->EDIDInfo.EstTimings[i].YResolution)
            && !cbIsResolutionExistInEDIDSTDTiming(pcbe,
                                                   &(pEDID->EDIDInfo),
                                                   pEDID->EDIDInfo.EstTimings[i].XResolution,
                                                   pEDID->EDIDInfo.EstTimings[i].YResolution))
        {
            // filte in EST timing to exclude duplication
            for (j = 0; j < i; j++)
            {
                if (pEDID->EDIDInfo.EstTimings[j].Valid
                    && pEDID->EDIDInfo.EstTimings[i].XResolution == pEDID->EDIDInfo.EstTimings[j].XResolution
                    && pEDID->EDIDInfo.EstTimings[i].YResolution == pEDID->EDIDInfo.EstTimings[j].YResolution)
                {
                    IsSameResExist = TRUE;
                    break;
                }   
            }
            if (IsSameResExist == FALSE)
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                {
                    // if enough space in the buffer, fill in
                    pResBuf[xyNum]   = pEDID->EDIDInfo.EstTimings[i].XResolution; // XResolution
                    pResBuf[xyNum+1] = pEDID->EDIDInfo.EstTimings[i].YResolution; // YResolution
                }
                xyNum += 2;
            }
        }
    }    

    // 3 . --------------- VBIOS vesavpit third priority ----------------------
    //   3.1 Est / STD EDID mode 
    //   3.2 VESAVPIT which can center on nearest EDID timing(EST / STD / DETAILED)
    //      or customize timing, 
    //      Since customize timing will always less than EDID panel size so we use
    //   panel size to filter VESAVPIT
    // ------------------------------------------------------------------------
    if (pcbe->pVCPInfo != NULL)
    {
        pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);

        if(pcbe->devicetimingtype[cbGetLowestBitPos(dispDev)] == VESAVPIT_EDID_TIMING_TYPE)
        {
            // report all modes in VESAVPIT table
            PanelHRes = PanelVRes = MAX_H_RES;
        }

        // no EDID mode only caps, report VPIT mode
        // if no EDID monitor force use VPIT mode
        if((pcbe->ChipCaps.EDID_Mode_Only == 0) || (xyNum == 0))
        {
            // search VESAVPIT table
            while (pVESA_Info->HSize != INVALID_H_SIZE)
            {
                // check for VESAVPIT availabe & less than EDID panel size 
                // check in EDID detailed timing and customize timing, do not report twice
                if( cbIsModeAvailable(pcbe, dispDev, pVESA_Info)
                    && ((PanelHRes >= pVESA_Info->HSize) && (PanelVRes >= pVESA_Info->VSize))
                    && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                             dispDev, 
                                                             pVESA_Info->HSize, 
                                                             pVESA_Info->VSize)
                    && !cbIsResolutionExistInEDID(pcbe,
                                                  &(pEDID->EDIDInfo), 
                                                  pVESA_Info->HSize, 
                                                  pVESA_Info->VSize))
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= (bufSize) )
                    {
                        // if enough space in the buffer, fill in
                        pResBuf[xyNum]   = pVESA_Info->HSize; // XResolution
                        pResBuf[xyNum+1] = pVESA_Info->VSize; // YResolution
                    }
                    xyNum += 2;
                }
                pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
            } //while (pVESA_Info->HSize != INVALID_H_SIZE)
        }
    }

    // if now resolution supported for DVI / LCD monitor type device
    if (xyNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = xyNum * sizeof(DWORD);
        }
        return TRUE;
    }       
}

//*****************************************************************************
//
//  cbGetEDIDRefreshRatesForResolution
//
//      This function fills refresh rate information memory buffer for EDID timing
//  type type resolution.
//      we offer EDID timing type policy refresh rate according to the rule below
//   EDID refresh rate
//      1. If Detailed timing: report its refresh rate only;
//      2. If Est / STD timing smaller than EDID detailed timing: 
//         find in VESAVPIT , if find then report founded refresh rate. 
//         else using center on EDID detailed timing
//      3. if Est / STD timing bigger than EDID detailed timing:
//         find in VESAVPIT 
//         if Est / STD resolution == EDID detailed resolution
//         also add Est / STD timing & report them
//      EDID EST / STD timing table in VESAVPIT has been verified in EDID parser function
//      if no timing table exists, just invalidate the EST / STD timing
//      4. other resolution center on nearest target timing
//
//  Parameters:
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf  refresh rate buffer for CBIOS to fill in 
//      bufSize:        buffer size of the pRRatesInfoBuf
//      pBufSize:       returns the buffer size of whole EDID Refresh Rates
//                      for the specified device and resolution
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetEDIDRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{  
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD rrNum = 0;
    DWORD CustRRNum, EDIDRRNum;
    RefreshRateInfo *pCurRRInfoBuf = NULL;
    DWORD leftBufSize = 0;
    DWORD EDIDMaxRRate = 0xFFFFFFFF;    // assume a very large value

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0; 
    }

    // 1. ---------- customize timing refresh rate first priority --------------
    if (!cbGetRefreshRateBufferInCustomizeTiming(pcbe, 
                                                 dispDev,
                                                 H_Res,
                                                 V_Res,
                                                 pRRatesInfoBuf,
                                                 bufSize,
                                                 &CustRRNum))
    {
        CustRRNum = 0;
    }

    // move buffer point and calc buffer size left
    if (NULL == pRRatesInfoBuf)
    {
        pCurRRInfoBuf = NULL;
    }
    else
    {
        pCurRRInfoBuf = pRRatesInfoBuf + CustRRNum;
    }
    if (bufSize > CustRRNum * sizeof(RefreshRateInfo))
    {
        leftBufSize = bufSize - CustRRNum * sizeof(RefreshRateInfo);
    }
    else
    {
        leftBufSize = 0;
    }

    // 2. ------ device EDID EST / STD / detailed timing refresh rate second priority -------
    if (!cbGetRefreshRateBufferInEDIDTiming(pcbe,
                                            dispDev,
                                            &(pEDID->EDIDInfo), 
                                            H_Res,
                                            V_Res,
                                            pCurRRInfoBuf,
                                            leftBufSize,
                                            &EDIDRRNum))
    {
        EDIDRRNum = 0;
    }
    rrNum = CustRRNum + EDIDRRNum;

    // 2.0.1 --- sort EDID refresh rate ---
    if(pcbe->ChipCaps.Filter_EDID_RefreshRate)
    {
        if(pRRatesInfoBuf)
        {
            cbSortRefreshRateBuffer(pRRatesInfoBuf, &rrNum);
            if(rrNum == 0)
            {
                EDIDMaxRRate = 6000;    // if can't get this mode from EDID then only report 60Hz in default
            }
            else
            {
                EDIDMaxRRate = pRRatesInfoBuf[rrNum-1].rRateX100;
            }
        }
    }

    // 2.1 ---------------------- VESAVPIT third priority ----------------------
    // Add VBIOS refresh rate also
    // Check VBIOS timing table
    // HDMI skip it for EDID timing consistence
    if(!(dispDev & (S3_HDMI+S3_HDMI2)) || (pcbe->devicetimingtype[cbGetLowestBitPos(dispDev)] == VESAVPIT_EDID_TIMING_TYPE))
    {
        PVESA_INFO pVESA_Info = NULL;
        DWORD i;

        if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
        {
            PVESA_VPIT pVESA_VPIT = (PVESA_VPIT)(pVESA_Info + 1);                
            DWORD VPIT_RRate;

            // fill all refresh rate in buf
            for (i=0; i<pVESA_Info->RRateCount; i++)
            {
                if(cbIsDClkOverLimit(pcbe, dispDev,
                                     cbCalcClkFromDWORDMRN(pcbe, pVESA_VPIT->PLL) ) )
                {
                    continue;
                }

                VPIT_RRate = pVESA_VPIT->RRate*100;
                // only fill rrate inside edid
                if(VPIT_RRate < EDIDMaxRRate)
                {
                    // if refresh rate exists in EDID or customize timing 
                    // also report the refreshrate in VESAVPIT (duplication is acceptable)
                    if(!(pVESA_VPIT->Attribute & ATT_DISABLE))
                    {
                        //Is buffer size enough for saving next refresh rate?
                        if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                        {
                            // if enough space in the buffer, fill in
                            pRRatesInfoBuf[rrNum].rRateX100 = VPIT_RRate;
                            pRRatesInfoBuf[rrNum].interlaced = pVESA_VPIT->Attribute & ATT_I;
                        }
                        rrNum++;
                    }
                }
                pVESA_VPIT++; // += sizeof(VESA_VPIT);
            } // for RRateCount
        }
    }

    if(pcbe->ChipCaps.Filter_EDID_RefreshRate)
    {
        if(pRRatesInfoBuf)
        {
            cbSortRefreshRateBuffer(pRRatesInfoBuf, &rrNum); // sort it again
        }
    }

    // 3. ------------- Resoltion center on Target Timing Case ---------------
    // center other resolution on nearest customize timing or EDID timing
    if (rrNum == 0)
    {
        // all the mode except for Est / STD / Detailed timing & customize timing
        // should be centered on customize or EDID timing
        // first check if can be centered on nearest customize timing
        // since customize timing takes first priority
        DWORD CusTargetHRes, CusTargetVRes;
        DWORD EDIDTargetHRes, EDIDTargetVRes;
        DWORD TargetHRes, TargetVRes;        

        // 1. search in customize timing table
        if (FALSE == cbGetClosestCustomizeTimingResolution(pcbe, dispDev, H_Res, V_Res, &CusTargetHRes, &CusTargetVRes))
        {
            CusTargetHRes = CusTargetVRes = MAX_H_RES;
        }

        // 2. search in EDID timing
        // use EDID detailed timing or EST / STD timing as target mode 
        if (FALSE == cbGetClosestEDIDTimingResolution(pcbe, &(pEDID->EDIDInfo), H_Res, V_Res, &EDIDTargetHRes, &EDIDTargetVRes))
        {
            EDIDTargetHRes = EDIDTargetVRes = MAX_H_RES;
        }

        // 3. get the nearest target resolution
        if (CusTargetHRes <= EDIDTargetHRes && CusTargetVRes <= EDIDTargetVRes)
        {
            TargetHRes = CusTargetHRes;
            TargetVRes = CusTargetVRes;
        }
        else
        {
            TargetHRes = EDIDTargetHRes;
            TargetVRes = EDIDTargetVRes;
        }

        // 4. get refresh rate num from customize timing & EDID timing table
        // if there are the same refresh rate in customize and EDID timing
        // report them all
        if (!cbGetRefreshRateBufferInCustomizeTiming(pcbe, 
                                                     dispDev,
                                                     TargetHRes,
                                                     TargetVRes,
                                                     pRRatesInfoBuf,
                                                     bufSize,
                                                     &CustRRNum))
        {
            CustRRNum = 0;    
        }

        // move buffer point and calc buffer size left
        if (NULL == pRRatesInfoBuf)
        {
            pCurRRInfoBuf = NULL;
        }
        else
        {
            pCurRRInfoBuf = pRRatesInfoBuf + CustRRNum;
        }
        if (bufSize > CustRRNum * sizeof(RefreshRateInfo))
        {
            leftBufSize = bufSize - CustRRNum * sizeof(RefreshRateInfo);
        }
        else
        {
            leftBufSize = 0;
        }

        if (!cbGetRefreshRateBufferInEDIDTiming(pcbe,
                                                dispDev,
                                                &(pEDID->EDIDInfo), 
                                                TargetHRes,
                                                TargetVRes,
                                                pCurRRInfoBuf,
                                                leftBufSize,
                                                &EDIDRRNum))
        {
            EDIDRRNum = 0;    
        }
        rrNum = CustRRNum + EDIDRRNum;
    }

    if (rrNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = rrNum * sizeof(RefreshRateInfo);
        }
        return TRUE;
    }
}

//*****************************************************************************
//
//  cbGetEDIDTimingTbl
//
//    This function gets EDID timing type timing table according to H, V resolution 
//  and refresh rate
//      query EDID timing policy timing table logic
//      1. find in customize timing table
//      1. find in EDID detailed timing 
//      2. find in est /std timing & has timing table in VESAVPIT timing
//      3. else use closest customize timing or EDID timing as target timing
//      
//  IN:
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//  RRateInfo:          refresh rate information 
//                      (refreshrate & interlaced) 
//                      for the specified device and resolution
//  OUT :
//      pTimingTbl:      general timing table to be filled
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetEDIDTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD CusTargetHRes, CusTargetVRes;
    DWORD EDIDTargetHRes, EDIDTargetVRes;
    DWORD TargetHRes, TargetVRes;  
    BOOL  bReduceBlk = FALSE;


    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    
    if (dispDev & (S3_DVI | S3_DVI2 | S3_DP | S3_DP2))
    {
        bReduceBlk = TRUE;
    }
    // 1. get from customize timing first
    if (!cbGetCustomizeTiming(pcbe, dispDev, H_Res, V_Res, RRateInfo, pTimingTbl))
    {
        // 2. get timing from EDID Detailed timing 
        //    get Est / Std timing from VESAVPIT
        if (!cbGetTimingFromEDID(pcbe, &(pEDID->EDIDInfo), H_Res, V_Res, RRateInfo, bReduceBlk, pTimingTbl))
        {
            // 3. get modes center on nearest customize mode or EDID timing
            // all the mode except for Est / STD / Detailed timing & customize timing
            // should be centered on neastcustomize or EDID timing
            // 1. search in customize timing table
            if (FALSE == cbGetClosestCustomizeTimingResolution(pcbe, dispDev, H_Res, V_Res, &CusTargetHRes, &CusTargetVRes))
            {
                CusTargetHRes = CusTargetVRes = MAX_H_RES;
            }

            // 2. search in EDID timing
            // use EDID detailed timing or EST / STD timing as target mode 
            if (FALSE == cbGetClosestEDIDTimingResolution(pcbe, &(pEDID->EDIDInfo), H_Res, V_Res, &EDIDTargetHRes, &EDIDTargetVRes))
            {
                EDIDTargetHRes = EDIDTargetVRes = MAX_H_RES;
            }

            // 3. get the nearest target resolution
            if (CusTargetHRes <= EDIDTargetHRes && CusTargetVRes <= EDIDTargetVRes)
            {
                TargetHRes = CusTargetHRes;
                TargetVRes = CusTargetVRes;
            }
            else
            {
                TargetHRes = EDIDTargetHRes;
                TargetVRes = EDIDTargetVRes;
            }

            // first check if can be centered on nearest customize timing
            // since customize timing takes first priority
            if (!cbGetCustomizeTiming(pcbe, dispDev, TargetHRes, TargetVRes, RRateInfo, pTimingTbl))
            {
                // do centering on EDID timing
                if (!cbGetTimingFromEDID(pcbe, &(pEDID->EDIDInfo), TargetHRes, TargetVRes, RRateInfo, bReduceBlk, pTimingTbl))
                {
                    // EDID invalid and no customize timing 
                    return FALSE;
                }
            }
        } // if get EDID timing
    }// if get Customize timing
    
    return TRUE;
}    

//--------------------------------------------------------------------------
//  cbGetVESATimingFilterByEDIDTypeResolutionsBuffer
//      this function fills resolution buffer according to VESAVPIT timing filter
//  by panel size type resoltion. The policy based on below priority rule.
//
//      1. timing based on customize timing which is less than panel size
//      2. timing(Resolution & refresh rate) based on EDID detailed timing
//      3. timing(Resolution & refresh rate) based on VBIOS VESAVPIT which is less
//         than panel size
//
//  IN :
//      dispDev : display device passed to get EDID
//      bufSize : buffer size of pResBuf to used to fill resolutions
//  IN OUT :
//      pResBuf : total buffer used to fill resolutions 
//      pBufSize : real buffer size of whole VESA filter by EDID resolutions
//      function status
//-------------------------------------------------------------------------
BOOL cbGetVESATimingFilterByEDIDTypeResolutionsBuffer(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    OUT DWORD *pResBuf,
    IN  DWORD bufSize,
    IN OUT DWORD *pBufSize)
{
    DWORD xyNum = 0, ResNum = 0;
    PVESA_INFO pVESA_Info = NULL;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD PanelHRes, PanelVRes;    
    ULONG i;

    if (NULL == pResBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0;
    }

    // when VCP is null just use CBIOS table 
    // do not use EDID timing table and customize timing table
    if (pcbe->pVCPInfo != NULL)
    {
        // 1. ---------------- customize timing first priority ---------------------
        // get all supported resolutions in customize timing
        // for CRT timing filter  type we need to filter customize timing with Max edid 
        // resolution         
        // find Max resolution in EDID as monitor size 
        if (cbGetMaxResolutionFromEDIDTiming(pcbe, &(pEDID->EDIDInfo), &PanelHRes, &PanelVRes) == FALSE)
        {
            PanelHRes = PanelVRes = MAX_H_RES;
        }
        if (FALSE == cbGetCustomizeTimingResolution(pcbe, 
                                                    dispDev, 
                                                    PanelHRes,
                                                    PanelVRes,
                                                    pResBuf,
                                                    bufSize,
                                                    &ResNum))
        {
            xyNum = 0;
        }
        else
        {
            // customize xy num = customize resolution num * 2
            xyNum += ResNum << 1;
        }


        // 2. ----------------- EDID timing second priority -----------------------
        // search in EDID resolutions
        // search in detail timing
        for (i=0; i < 4; i++)
        {
            // filter mode over TMDS link limitation
            // DVI/DVI2 use TMDS link
            if (pEDID->EDIDInfo.DtlTimings[i].Valid && ( (S3_DVI | S3_DVI2) & dispDev ))
            {
                BYTE M = (BYTE)(pEDID->EDIDInfo.DtlTimings[i].PLL_MRN >> 16);
                BYTE R = (BYTE)(pEDID->EDIDInfo.DtlTimings[i].PLL_MRN >>  8);
                BYTE N = (BYTE)(pEDID->EDIDInfo.DtlTimings[i].PLL_MRN);
                if ( cbCalcClkFromMRN(pcbe, M, R, N) > TMDS_LINK_FREQUENCY )
                {
                    continue; // if pixel clock > TMDS link limitation, skip this mode
                }
            }

            // check in customize timing tbl, do not report twice
            if (pEDID->EDIDInfo.DtlTimings[i].Valid
                && !cbIsResolutionExistInCustomizeTiming(pcbe, 
                                                         dispDev, 
                                                         pEDID->EDIDInfo.DtlTimings[i].XResolution, 
                                                         pEDID->EDIDInfo.DtlTimings[i].YResolution))
            {
                //Is buffer size enough for saving next mode?
                if ( ((xyNum+2) * sizeof(DWORD)) <= bufSize )
                {
                    // if enough space in the buffer, fill in
                    pResBuf[xyNum]   = pEDID->EDIDInfo.DtlTimings[i].XResolution; // XResolution
                    pResBuf[xyNum+1] = pEDID->EDIDInfo.DtlTimings[i].YResolution; // YResolution
                }
                xyNum += 2;
            }
        }

        // 3. ---------------------- VESAVPIT third priority ----------------------
        pVESA_Info = (PVESA_INFO)(pcbe->RomData + pcbe->pVCPInfo->VESAVPITPtr);
        // search mode table first
        while (pVESA_Info->HSize != INVALID_H_SIZE)
        {
            if(cbIsModeAvailable(pcbe, dispDev, pVESA_Info))
            {
                // filter by panel size
                // check in customize timing & EDID detailed timing, do not report twice
                if ((PanelHRes >= pVESA_Info->HSize && PanelVRes >= pVESA_Info->VSize)
                    && !cbIsResolutionExistInCustomizeTiming(pcbe, dispDev, pVESA_Info->HSize, pVESA_Info->VSize)
                    && (pEDID != NULL)
                    && !cbIsResolutionExistInEDIDDetailedTiming(pcbe, &(pEDID->EDIDInfo), pVESA_Info->HSize, pVESA_Info->VSize))
                {
                    //Is buffer size enough for saving next mode?
                    if ( ((xyNum+2) * sizeof(DWORD)) <= bufSize )
                    {
                        // if enough space in the buffer, fill in
                        pResBuf[xyNum]   = pVESA_Info->HSize; // XResolution
                        pResBuf[xyNum+1] = pVESA_Info->VSize; // YResolution
                    }
                    xyNum += 2;
                }
            }
            pVESA_Info = (PVESA_INFO)((PBYTE)pVESA_Info + sizeof(VESA_INFO) + pVESA_Info->RRateCount * sizeof(VESA_VPIT));
        } // mode table
    }

    // if this resolution supported for CRT type device
    if (xyNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = xyNum * sizeof(DWORD);
        }
        return TRUE;
    }
}

//*****************************************************************************
//
//  cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution
//
//  This function fills the size of refresh rate information memory buffer for
//  VESAVPIT timing table filter by panel size type 
//      we offer refresh rate according to the priority rules below
//
//      1. timing based on customize timing which is less than panel size
//      2. timing(Resolution & refresh rate) based on EDID detailed timing
//      3. timing(Resolution & refresh rate) based on VBIOS VESAVPIT which is less
//         than panel size
//
//      we report all the refreshrate for one resolution. since same refreshrate
//      for one resolution is acceptable, so report all the refresh rate in customertiming
//      EDID detailed timing and VESAVPIT
//
//  Parameters:
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//      pRRatesInfoBuf  refresh rate buffer for CBIOS to fill in 
//      bufSize:        buffer size of pRRatesInfoBuf
//      pBufSize:       returns buf size of whole VESA Filter By EDID Type RefreshRates
//                      for the specified device and resolution
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetVESATimingFilterByEDIDTypeRefreshRatesForResolution(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    OUT RefreshRateInfo *pRRatesInfoBuf,
    IN  DWORD bufSize,
    OUT DWORD *pBufSize)
{
    PVESA_INFO pVESA_Info = NULL;
    PCBIOS_DEV_EDID pEDID = &( pcbe->devEDID[cbGetLowestBitPos(dispDev)] );
    DWORD rrNum = 0;
    RefreshRateInfo rRateInfo;
    ULONG i;

    if (NULL == pRRatesInfoBuf)
    {
        // not need fill buffer, set size = 0 for later logic
        bufSize = 0; 
    }

    // when VCP is null just use CBIOS table 
    // do not use EDID timing table and customize timing table
    if (pcbe->pVCPInfo != NULL)
    {
        // 1. ---------- customize timing refresh rate first priority --------------
        if (!cbGetRefreshRateBufferInCustomizeTiming(pcbe, 
                                                     dispDev,
                                                     H_Res,
                                                     V_Res,
                                                     pRRatesInfoBuf,
                                                     bufSize,
                                                     &rrNum))
        {
            rrNum = 0;
        }

        // 2. ---------- device EDID timing refresh rate second priority -----------
        // check in EDID
        // check in detail timing
        for (i=0; i<4; i++)
        {
            if (pEDID->EDIDInfo.DtlTimings[i].Valid )
            {
                if(cbIsDClkOverLimit(pcbe, dispDev,
                                      cbCalcClkFromDWORDMRN(pcbe, pEDID->EDIDInfo.DtlTimings[i].PLL_MRN) ) )
                {
                    continue;
                }
            }

            if ( (pEDID->EDIDInfo.DtlTimings[i].Valid)
                && ( pEDID->EDIDInfo.DtlTimings[i].XResolution == H_Res )
                && ( pEDID->EDIDInfo.DtlTimings[i].YResolution == V_Res ) )
            {
                rRateInfo.rRateX100 = pEDID->EDIDInfo.DtlTimings[i].rRateX100;
                rRateInfo.interlaced = pEDID->EDIDInfo.DtlTimings[i].Interlaced;
                //Is buffer size enough for saving next refresh rate?
                if ( (NULL != pRRatesInfoBuf) && ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                {
                    // if enough space in the buffer, fill in
                    pRRatesInfoBuf[rrNum].rRateX100 = pEDID->EDIDInfo.DtlTimings[i].rRateX100;
                    pRRatesInfoBuf[rrNum].interlaced = pEDID->EDIDInfo.DtlTimings[i].Interlaced ;
                }
                rrNum++;   // report EDID detail timing rrate additionally
            }
        }

        // 3. ---------------------- VESAVPIT third priority ----------------------
        // Check VBIOS timing table   
        if (cbGetVBIOSVesaInfo(pcbe, H_Res, V_Res, &pVESA_Info))
        {
            PVESA_VPIT pVESA_VPIT = (PVESA_VPIT)(pVESA_Info + 1);                

            // fill all refresh rate in buf
            for (i=0; i<pVESA_Info->RRateCount; i++)
            {
                if(cbIsDClkOverLimit(pcbe, dispDev,
                                      cbCalcClkFromDWORDMRN(pcbe, pVESA_VPIT->PLL) ) )
                {
                    continue;
                }

                rRateInfo.rRateX100 = pVESA_VPIT->RRate *100;
                rRateInfo.interlaced = (pVESA_VPIT->Attribute & ATT_I) ? INTERLACE : PROGRESSIVE;
                // if refresh rate exists in EDID or customize timing 
                // also report the refreshrate in VESAVPIT (duplication is acceptable)
                if(!(pVESA_VPIT->Attribute & ATT_DISABLE))
                {
                    //Is buffer size enough for saving next refresh rate?
                    if ( ((rrNum+1) * sizeof(RefreshRateInfo)) <= bufSize )
                    {
                        // if enough space in the buffer, fill in
                        pRRatesInfoBuf[rrNum].rRateX100 = pVESA_VPIT->RRate * 100;
                        pRRatesInfoBuf[rrNum].interlaced = pVESA_VPIT->Attribute & ATT_I;
                    }
                    rrNum++;
                }
                pVESA_VPIT++; // += sizeof(VESA_VPIT);
            } // for RRateCount
        }
    }

    if (rrNum == 0)
    {
        return FALSE;
    }
    else
    {
        if (pBufSize != NULL)
        {
            *pBufSize = rrNum * sizeof(RefreshRateInfo);
        }
        return TRUE;
    }
}    

//*****************************************************************************
//
//  cbGetVESATimingFilterByEDIDTypeTimingTbl
//
//    This function gets VESAVPIT timing filter by panel size type resoltion timing 
//  table according to H, V resolution , and refresh rate (refresh rate & interlace)
//    we offer the timing table according to the priority rules below
//
//      1. timing based on customize timing which is less than panel size
//      2. timing(Resolution & refresh rate) based on EDID detailed timing
//      3. timing(Resolution & refresh rate) based on VBIOS VESAVPIT which is less
//         than panel size
//
//  IN :
//      dispDev:        only one device bit can be set
//      H_Res:          Horizontal Resolution (pixel)
//      V_Res:          Vertical Resolution (pixel)
//  RRateInfo:          refresh rate information 
//                      (refreshrate & interlaced) 
//                      for the specified device and resolution
//  OUT :
//   pTimingTbl:        general timing table to be filled
//  Return Value:
//      CBIOS_STATUS
//
//*****************************************************************************
BOOL cbGetVESATimingFilterByEDIDTypeTimingTbl(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD dispDev,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo RRateInfo,
    OUT PGFXTimingTable pTimingTbl)
{
    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    if (pcbe->pVCPInfo == NULL)
    {
        // VCP == NULL we can not support VESA timing filter by panel size feature
        return FALSE;
    }

    // VESATimingFilterByEDIDType & CRTType differences:
    // 1. Report mode, VESATimingFilterByEDIDType only report mode smaller than EDID max
    // 2. Get timing table, VESATimingFilterByEDIDType check VCP != NULL
    if (cbGetMaxTarTimingFromEDIDandCusTiming(pcbe, dispDev, RRateInfo, pTimingTbl))
    {
        if (H_Res > pTimingTbl->HBlankStart || V_Res > pTimingTbl->VBlankStart)
        {
            // if wanted resolution bigger than max EDID resolution, just use max EDID resolution
            return TRUE;
        }
    }

    // find closest timing in EDID & VESA VPIT
    return cbGetCRTTypeTimingTbl(pcbe, dispDev, H_Res, V_Res, RRateInfo, pTimingTbl);
}

//-----------------------------------------------------------------------------
// cbGetCVTTiming
//     The function Calculate the detailed timing according to the CVT algrithm.
// All the expressions used comply with CVT standard V1 March 26, 2003. 
//
// Caution :
//      Now this function does not cover interlace timing case
//
//  IN :
//      H_Res : H resolution size
//      V_Res : V resolution size
//   rRateInfo: refresh rate info
//  IsReducedBlanking : whether reduced blanking or not
//
//  OUT :
//    pTimingTbl : reduced timing table 
//-----------------------------------------------------------------------------
#define    CPRIME                    30
#define    CLOCKSTEP                 25       // Muliplied by 100
#define    HSYNCPERCENT              8     
#define    MPRIME                    300
#define    MINVFPORCH                3
#define    MINVBPORCH                6
#define    MINVBLANKINGPERIOD        550      // unit is us
#define    REDUCEBLANKHORBLANK       160      // unit is pixel
#define    REDUCEHORSYNC             32       // unit is pixel
#define    REDUCEMINVBLANK           460
#define    REDUCEVFPORCH             3

#define    CELLGRAN                  8 

BOOL cbGetCVTTiming(PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res, 
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo, 
    IN BOOL  IsReducedBlanking,
    OUT PGFXTimingTable pTimingTbl)
    
{

    ULONG ReqestRefreshRateX100 = rRateInfo.rRateX100;
    ULONG HorPixels = H_Res;
    ULONG VerticalLines = V_Res;

    // result variable
    ULONG HorTotal;                   // unit is pixels
    ULONG HorBlanking;
    ULONG HorFrontPorch;
    ULONG HorSync;
    ULONG HorBackPorch;

    ULONG VerTotal;                   // unit is lines
    ULONG VerBlanking;
    ULONG VerFrontPorch;
    ULONG VerBackPorch;
    ULONG VerticalSyncWidth;

    ULONG HorFreqX100;                   // unit is kHz*100
    ULONG ActualVerFreqX100;
    ULONG PixelClockX100;

    // middle temporary variable
    ULONG HPeriodEstX100;                // unit is kHz 
    ULONG VSyncBP;
    ULONG Temp;
    ULONG IdealDutyCycleX100;

    // For recuced blanking middle temopary variable.
    ULONG VBILines;
    ULONG RBMINVBILines;
    ULONG ACTVBILines;

    if (!pTimingTbl)
    {
        cbDbgPrint(0, "Caution: NULL pointer!\n");
        ASSERT(FALSE);
        return FALSE;
    }
    if (INTERLACE == rRateInfo.interlaced)
    {
        cbDbgPrint(0, "Caution: can't support interlace in CVT!\n");
        return FALSE;
    }
    if (0 == H_Res || 0 == V_Res || 0 == rRateInfo.rRateX100)
    {
        cbDbgPrint(0, "cbGetCVTTiming: input resolution is 0!\n");
        ASSERT(FALSE);
        return FALSE;
    }

    // get the V Sync width
    VerticalSyncWidth = cbGetVsyncWidth(H_Res, V_Res);

    // Currently, CVT timing not support reduced blanking.
    IsReducedBlanking = FALSE;        

    // For standard CRT timing calculation
    if(!IsReducedBlanking)
    {    
         // Estimate the horizontal period that is multiplied by 100
         Temp = 100*1000000/ReqestRefreshRateX100 - MINVBLANKINGPERIOD;
         HPeriodEstX100 = cbRoundDown(Temp*100, VerticalLines + MINVBPORCH);

         // Find the number of lines in V sync + back porch
         VSyncBP = cbRoundDown(100*MINVBLANKINGPERIOD, HPeriodEstX100)+1;
         if(VSyncBP < (VerticalSyncWidth + MINVBPORCH))
         {
             VSyncBP = VerticalSyncWidth + MINVBPORCH;
         }
         // Find the number of lines in V back porch
         VerBackPorch = VSyncBP - VerticalSyncWidth;
         // Find the number of lines in V front porch
         VerFrontPorch = MINVFPORCH;
         // Find total number of lines in Vertical Field Period:
         VerTotal = VerticalLines + VSyncBP + MINVFPORCH;
         // Find the vertical blanking period
         VerBlanking = VerTotal - VerticalLines;
         // Find the ideal blanking duty cycle from the blanking duty cycle equation(%)
         IdealDutyCycleX100 = 100*CPRIME - MPRIME*HPeriodEstX100/1000;

         // Find the number of pixels in the horizontal blanking time to the nearest 
         // double character cell
         if(IdealDutyCycleX100 < 2000)
         {
             // IdealDutyCycle < 20%
             HorBlanking = cbRoundDown((HorPixels*2000)/(10000-2000), 2*CELLGRAN);
             HorBlanking = HorBlanking*2*CELLGRAN;
         }
         else
         {
             // IdealDutyCycle >= 20%
             HorBlanking = cbRoundDown((HorPixels*IdealDutyCycleX100)/(10000-IdealDutyCycleX100),2*CELLGRAN);
             HorBlanking = HorBlanking*2*CELLGRAN;
         }
         // Find the total number of pixels in a line
         HorTotal = HorPixels + HorBlanking;
         // Find the Horizontal Sync width, unit is character.
         HorSync = cbRoundDown(HorTotal*HSYNCPERCENT,CELLGRAN*100);
         // Convert the unit of H sync width to pixel unit
         HorSync = HorSync*CELLGRAN;
         // Find the Horizontal back porch
         HorBackPorch = HorBlanking/2;
         // Find the H front porch
         HorFrontPorch = HorBlanking-HorSync-HorBackPorch;
         
         // Find pixel clock frequency(MHz) 
         Temp = cbRoundDown(HorTotal*100*100,HPeriodEstX100);
         PixelClockX100 = cbRoundDown(Temp, CLOCKSTEP)*CLOCKSTEP;

         // Find actual Horizonal Frequency (kHz)
         HorFreqX100 = 1000*PixelClockX100 / HorTotal;
         // Find the actual refresh rate(Hz)
         ActualVerFreqX100 = 1000*HorFreqX100 / VerTotal;

         // CVT std CRT timing H : CBIOS_NEGATIVE  V : CBIOS_POSITIVE
         pTimingTbl->HPolarity = CBIOS_NEGATIVE;
         pTimingTbl->VPolarity = CBIOS_POSITIVE;
    }
    // For reduced blanking timing calculation
    else
    {
         // Estimate the Horizontal Period(Hz) multiplied by 100
         Temp = 100*1000000/ReqestRefreshRateX100 - REDUCEMINVBLANK;
         HPeriodEstX100 = cbRoundDown(Temp*100,VerticalLines);
         
         // Determine the number of lines in the vertical blanking interval
         VBILines = cbRoundDown(100*REDUCEMINVBLANK,HPeriodEstX100)+1;
         // Check vertical blanking is Sufficient
         RBMINVBILines = REDUCEVFPORCH+VerticalSyncWidth+MINVBPORCH;
         if(VBILines < RBMINVBILines)
         {
             ACTVBILines = RBMINVBILines;
         }
         else
         {
             ACTVBILines = VBILines;
         }
         // Find total number of vertical lines
         VerTotal = ACTVBILines + VerticalLines;
         // Find the vertical blanking period
         VerBlanking = ACTVBILines;
         // Find the number of lines in V front porch
         VerFrontPorch = REDUCEVFPORCH;
         // Find the number of lines in V back porch
         VerBackPorch = VerBlanking - VerticalSyncWidth - VerFrontPorch;

         // Find total number of vertical lines
         HorTotal = HorPixels + REDUCEBLANKHORBLANK;
         // Find the Horizontal sync width
         HorSync = REDUCEHORSYNC;
         // Find the number of pixels in the horizontal blanking time to the nearest 
         // double character cell
         HorBlanking = REDUCEBLANKHORBLANK;
         // Find the Horizontal back porch
         HorBackPorch = HorBlanking/2;
         // Find the H front porch
         HorFrontPorch = HorBlanking-HorSync-HorBackPorch;

         // Calculate pixel clock frequecy (MHz)
         Temp = ReqestRefreshRateX100*VerTotal*HorTotal / 1000000;
         PixelClockX100 = cbRoundDown(Temp, CLOCKSTEP) * CLOCKSTEP;

         // Find actual Horizonal Frequency (kHz)
         HorFreqX100 = 1000*PixelClockX100 / HorTotal;
         // Find the actual refresh rate(Hz)
         ActualVerFreqX100 = 1000*HorFreqX100 / VerTotal;

         // CVT reduced timing H : CBIOS_POSITIVE  V : CBIOS_NEGATIVE
         pTimingTbl->HPolarity = CBIOS_POSITIVE;
         pTimingTbl->VPolarity = CBIOS_NEGATIVE;
    }

    // Fill in the timing structure
    // H timing parameter
    pTimingTbl->HTotal = (WORD)HorTotal;
    pTimingTbl->HDisEnd = (WORD)HorPixels;
    pTimingTbl->HBlankStart = (WORD)HorPixels;
    pTimingTbl->HBlankEnd = (WORD)HorTotal;  
    pTimingTbl->HSyncStart = (WORD)(HorPixels + HorFrontPorch); 
    pTimingTbl->HSyncEnd = (WORD)(pTimingTbl->HSyncStart + HorSync);   

    // V timing parameter
    pTimingTbl->VTotal = (WORD)VerTotal;
    pTimingTbl->VDisEnd = (WORD)VerticalLines;
    pTimingTbl->VBlankStart = (WORD)VerticalLines;
    pTimingTbl->VBlankEnd = (WORD)(VerticalLines+VerBlanking);
    pTimingTbl->VSyncStart = (WORD)(VerticalLines+VerFrontPorch);
    // hardware limitation:VSyncEnd <= VTotal
    Temp = VerticalLines+VerFrontPorch+VerticalSyncWidth;
    pTimingTbl->VSyncEnd = (WORD)((Temp > pTimingTbl->VTotal) ? pTimingTbl->VTotal : Temp);
    // set V sync offset to 0
    pTimingTbl->VSyncOffset = 0;
    
    pTimingTbl->rRateX100 = ReqestRefreshRateX100;
    pTimingTbl->Interlaced = PROGRESSIVE;
    
    // get PLL value from pixel clock (Hz)
    // transfer PixelClock from MHz to Hz
    pTimingTbl->vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, (DWORD)PixelClockX100*10000);
    
    return TRUE;
}


//-----------------------------------------------------------------------------
// cbGetGTFTiming
//     The function Calculate the detailed timing according to the GTF algrithm.
// All the expressions used comply with GTF standard V1 December 18, 1996. 
//
// Caution :
//      Now this function does not cover interlace timing case
//
//  IN :
//      H_Res : H resolution size
//      V_Res : V resolution size
//      rRateInfo: refresh rate info
//      bHmargin: whether there is margin in horizontal direction or not.
//      bVmargin: whether there is margin in vertical direction or not.
//  //
//  OUT :
//    pTimingTbl : reduced timing table 
//------------------------------------------------------------------------

#define     GTF_MARGIN            18                // 1.8% The size of the top and bottom overscan margin as a percentage of the active vertical image
#define     GTF_MINPORCH          1                 //The minimum front porch in lines (vertical) and character cells (horizontal)
#define     GTF_VSYNCRQD          3                 //The width of the V sync in lines
#define     GTF_HSYNC             8                 //%The width of the H sync as a percentage of the total line period
#define     GTF_MINVSYNCBP        550               //Minimum time of vertical sync + back porch interval (us)   

#define     GTF_CELLGRAN          8
#define     GTF_M                 600               //Gradient constant in Horizontal Blanking Formula
#define     GTF_C                 40                //Offset  constant in Horizontal Blanking Formula
#define     GTF_K                 128               //Blank timing scaling factor
#define     GTF_J                 20                //scaling factor weighting 
BOOL cbGetGTFTiming(
    PCBIOS_EXTENSION pcbe, 
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN RefreshRateInfo rRateInfo,
    IN BOOL  bHmargin,
    IN BOOL  bVmargin,
    OUT PGFXTimingTable pTimingTbl)
{
    //temple middle variable
   
    ULONG hres;
    ULONG vres;
    ULONG Mact;                                                 //Actual use M
    ULONG Cact;                                                 //Aactual use C
    ULONG Vfeildraterqdx100;                                    //the frame rate required
    ULONG MINPORCHRND;
    ULONG VSYNCRND;
    ULONG Totalactivepixels;                                    //total number of active pixels in image and left and right margins    
    ULONG  inter;
    ULONG PixelClockX100;

    ULONG HperiodestX100;                                       //Estimate the Horizontal period
    ULONG Vfieldrateest;                                        //Estimate the Vertical field frequency
    ULONG HperiodX100;                                          //the actual horizontal period
    ULONG IdealDutyCycleX100;                                   //the ideal blanking duty cycle from the blanking duty cycle equation
    ULONG  Pixelfreq;                                           // pixel clock frequency  
    ULONG Vfieldrate;                                           //the actual Vertical field frequency
    ULONG Vframerate;                                           //the Vertical frame frequency
    ULONG Hfreq;                                                //horizontal frequency

    //output variable
    //Horizontal
    ULONG HTotalpixels;                                        //total number of pixels in H direction
    ULONG HPixelsRND;
    ULONG Leftmargin;                                          //number of pixels in left margin;
    ULONG Rightmargin;                                         //number of pixels in right margin;
    ULONG Hblank;                                              //the number of pixels in the blanking time to the nearest double character cell
    ULONG Hfrontporch;                                         //the number of pixels in the horizontal front porch period
    ULONG Hbackporch;                                          //the number of pixels in the horizontal back porch period
    ULONG Hsync;                                               //the number of pixels in the horizontal sync period

    //vertical
    ULONG Vtotallines;
    ULONG VlinesRND;
    ULONG VTopmargin;
    ULONG VBotmargin;  
    ULONG VSyncbp;                                            //Find the number of lines in V sync + back porch
    ULONG Vbackporch;                                         //Find the number of lines in V back porch alone

    //others
    ULONG ReqestRefreshRateX100 ;

    if (pTimingTbl == NULL||V_Res%2!=0)
    {
        return FALSE;
    }
    //initial 
    Cact=((GTF_C-GTF_J)*GTF_K/256)+GTF_J;
    Mact=GTF_K*GTF_M/256;
    hres=H_Res;
    vres=V_Res;
    Leftmargin=0;
    Rightmargin=0;
    VTopmargin=0;
    VBotmargin=0;
   
    MINPORCHRND=cbRoundDown(GTF_MINPORCH*100,100);
    VSYNCRND=cbRoundDown(GTF_VSYNCRQD*100,100);

    ReqestRefreshRateX100 = rRateInfo.rRateX100;
   
    HPixelsRND=((cbRoundDown(100* hres/GTF_CELLGRAN ,100))*GTF_CELLGRAN );
   

    //wethwer interlaced or not

    if (rRateInfo.interlaced == PROGRESSIVE)   // Progressive,not interlaced

    {
        VlinesRND=vres;
        Vfeildraterqdx100=rRateInfo.rRateX100;
        inter=0;
    }
    else                                                             // interlaced
    {
        VlinesRND=vres/2 ;
        Vfeildraterqdx100=2*rRateInfo.rRateX100;
        inter=1;
    }

    //wether there is margin or not  in vertical direction
  
    if (!bVmargin)                 //  no vertical margin 
    {
        VBotmargin=VTopmargin=0;
    }
    else                                     // calculate vtopmargin and vbotmargin
    {
        VBotmargin=VTopmargin=cbRoundDown(100*VlinesRND*GTF_MARGIN/1000,100);
    }

    //wether there is margin or not  in horizontal direction

    if(!bHmargin)         
    {                                             //  no Horizontal margin
        Rightmargin=Leftmargin  =0;
    }
    else	
    {
        Rightmargin=Leftmargin  =cbRoundDown( (100*HPixelsRND*GTF_MARGIN/1000/GTF_CELLGRAN),100)*GTF_CELLGRAN;
    }

    //calculate Estimate of  the Horizontal periodX100	 (us)
    HperiodestX100=100*((1000000*100/Vfeildraterqdx100)-GTF_MINVSYNCBP)*2/(VlinesRND*2+(2*VTopmargin)*2+MINPORCHRND*2+inter);

     //calculate  the number of lines in V sync + back porch	 
    VSyncbp=cbRoundDown((ULONG)(100*100*GTF_MINVSYNCBP/HperiodestX100 ),100);
	
    //the number of lines in V back porch alone; 	 
    Vbackporch = VSyncbp-VSYNCRND;      // VSYNCRND is in initial part 
     
    //calculate Vtotallines
    //MINPORCHRND is the front porch, so MINPORCHRND+VSYNCBP is Vblank time.
    Vtotallines=VlinesRND+VTopmargin+VBotmargin+MINPORCHRND+VSyncbp+inter/2;


    //calculate Vfield rate est
    // 1/Hperiodest is HFrequency, HFrequency/Vtotallines is Vfieldrateest , HFrequency's unite is MHz ,so *1000000
    Vfieldrateest =1000000*100/HperiodestX100/Vtotallines;
   
    //calculate Hperiod
    //Vfieldrateest/Vfeildraterqdx100=(1/Vfeildraterqdx100)/(1/Vfieldrateest) =Vperiod/Vperiodest  (us)
    HperiodX100=HperiodestX100*Vfieldrateest*100/Vfeildraterqdx100;

    //calculate Vfieldrate :the actual Vertical field frequency
  
    Vfieldrate=100*1000000/HperiodX100/Vtotallines;
  
    //calculate Vframerate
    if (rRateInfo.interlaced == PROGRESSIVE)
    {
        Vframerate=Vfieldrate;
    }
    else
    {
        Vframerate=Vfieldrate/2;
    }

    Totalactivepixels=HPixelsRND+Leftmargin+Rightmargin;

    //calculate ideal duty cycle %
    //100*100*Mact*HperiodX100/100/1000=Mact*HperiodX100/10
    IdealDutyCycleX100=cbRoundDown((100*100*Cact-(Mact*HperiodX100/10)),100);

    //calculate H Blank time
    //IdealDutyCycle/(100-IdealDutyCycle)=IdealDutyCyclex100/100/(100-IdealDutyCyclex100/100)
    // = IdealDutyCyclex100/(10000-IdealDutyCyclex100)   
    Hblank=(cbRoundDown((ULONG)( 100*Totalactivepixels*IdealDutyCycleX100/(10000-IdealDutyCycleX100)/(2*GTF_CELLGRAN)),100))*(2*GTF_CELLGRAN);

    //calculate HTotalpixels (htt)
    HTotalpixels=Totalactivepixels+Hblank;

    Pixelfreq=100*HTotalpixels/HperiodX100;

    Hfreq=100*1000/HperiodX100;  //kHz

    //calculate Hsync	 
    //HSYNC : %The width of the H sync as a percentage of the total line period
    Hsync=(cbRoundDown((ULONG)(100*GTF_HSYNC/100*HTotalpixels/GTF_CELLGRAN),100))*GTF_CELLGRAN;

    Hfrontporch=(Hblank/2)-Hsync;
    Hbackporch=Hfrontporch+Hsync;
    PixelClockX100=cbRoundDown((ULONG)(10*Hfreq*100*HTotalpixels/1000),10);

    // Fill in the timing structure
    // H timing parameter
    pTimingTbl->HTotal           =(WORD) HTotalpixels;             
    pTimingTbl->HDisEnd          =(WORD) HPixelsRND;
    pTimingTbl->HBlankStart      =(WORD) (HPixelsRND+Rightmargin);
    pTimingTbl->HBlankEnd        =(WORD) (HPixelsRND+Rightmargin+Hblank);
    pTimingTbl->HSyncStart       =(WORD) (HPixelsRND+Rightmargin+Hfrontporch);
    pTimingTbl->HSyncEnd         =(WORD) (HPixelsRND+Rightmargin+Hfrontporch+Hsync);
    
    //V timing parameter
    pTimingTbl->VTotal           = (WORD)Vtotallines;
    pTimingTbl->VDisEnd          = (WORD)VlinesRND;
    pTimingTbl->VBlankStart      = (WORD)(VlinesRND+VBotmargin);
    pTimingTbl->VBlankEnd        = (WORD)(Vtotallines-VTopmargin);
    pTimingTbl->VSyncStart       = (WORD)(Vtotallines-VTopmargin-VSyncbp-inter/2);
    pTimingTbl->VSyncEnd         = (WORD)(Vtotallines-VTopmargin-inter/2-Vbackporch);

    //set V sync offset to 0
    pTimingTbl->VSyncOffset = 0;

    pTimingTbl->rRateX100    = ReqestRefreshRateX100;
    pTimingTbl->Interlaced   =(BYTE) rRateInfo.interlaced;

    //GFT  reduced timing H : CBIOS_NEGATIVE   V :CBIOS_POSITIVE
    pTimingTbl->HPolarity = CBIOS_NEGATIVE;
    pTimingTbl->VPolarity = CBIOS_POSITIVE;
	 
    //get PLL value from pixel clock (Hz)
    //transfer PixelClock from MHz to Hz
    pTimingTbl->vPLL = cbGetMRN_UMA(pcbe->ChipCaps.PLL_USE_409_FORMULA, (DWORD)PixelClockX100*10000);
		   
    return TRUE;

}

BOOL cbGetSTDTiming(
    PCBIOS_EXTENSION pcbe, 
    IN BOOL  bReduceBlk,
    IN DWORD H_Res,
    IN DWORD V_Res,
    IN DWORD rRateX100,
    OUT PGFXTimingTable pTimingTbl)
{
    BOOL                status = FALSE;
    RefreshRateInfo     rRateInfo;

    rRateInfo.interlaced = PROGRESSIVE;
    rRateInfo.rRateX100 = rRateX100;

    // first use VESAVPIT or reduce blanking to UMA timing tbl
    if (bReduceBlk && cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, rRateInfo, TRUE, pTimingTbl)
        && H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart )
    {
        // get exact timing from VBIOS, not closest bigger timing
        status = TRUE;
    }
    // If not or no reduce blanking, get vesa vpit table
    else if (cbGetVBIOSVesaTimingTable(pcbe, H_Res, V_Res, rRateInfo, FALSE, pTimingTbl)
        && H_Res == pTimingTbl->HBlankStart && V_Res == pTimingTbl->VBlankStart )
    {
        // get exact timing from VBIOS, not closest bigger timing
        status = TRUE;
    }
    else
    {
        // use CVT to calcualte timing table
        if(cbGetGTFTiming(pcbe, H_Res, V_Res, rRateInfo, FALSE, FALSE, pTimingTbl))
            status = TRUE;
    }
    return status;
}


