/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_ttm.h"
#include "via_chrome9_dmablit.h"
#include "via_chrome9_object.h"
#include "via_chrome9_fence.h"

extern unsigned char *mmio_map_base;
extern spinlock_t vga_reg_read_lock;

struct drm_device *drm_dev_v4l;
static void via_chrome9_init_2d(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int i;

	for (i = 0x04; i < 0x5c; i += 4)
		VIA_CHROME9_WRITE(i, 0x0);

	/* For 410 chip*/
	if (dev->pci_device == VX900_DEVICE)
		VIA_CHROME9_WRITE(0x60, 0x0);

}

static void via_chrome9_init_3d(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int i;
	unsigned long stage_of_texture;

	VIA_CHROME9_WRITE(0x43C, 0x00010000);
	for (i = 0; i <= 0x9A; i++)
		VIA_CHROME9_WRITE(0x440, i << 24);
    /* guardband clipping default setting */
	VIA_CHROME9_WRITE(0x440, (0x88 << 24) | 0x00001ed0);
	VIA_CHROME9_WRITE(0x440, (0x89 << 24) | 0x00000800);

	/* Initial Texture Stage Setting*/
	for (stage_of_texture = 0; stage_of_texture <= 0xf;
		stage_of_texture++) {
		VIA_CHROME9_WRITE(0x43C, (0x00020000 | 0x00000000 |
			(stage_of_texture & 0xf) << 24));
		for (i = 0 ; i <= 0x30 ; i++)
			VIA_CHROME9_WRITE(0x440, i << 24);
	}

	/* Initial Texture Sampler Setting*/
	for (stage_of_texture = 0; stage_of_texture <= 0xf;
		stage_of_texture++) {
		VIA_CHROME9_WRITE(0x43C, (0x00020000 | 0x20000000 |
			(stage_of_texture & 0xf) << 24));
		for (i = 0 ; i <= 0x36 ; i++)
			VIA_CHROME9_WRITE(0x440, i << 24);
	}

	VIA_CHROME9_WRITE(0x43C, (0x00020000 | 0xfe000000));
	for (i = 0 ; i <= 0x13 ; i++)
		VIA_CHROME9_WRITE(0x440, i << 24);

	/* degamma table*/
	VIA_CHROME9_WRITE(0x43C, (0x00030000 | 0x15000000));
	VIA_CHROME9_WRITE(0x440, (0x40000000 | (30 << 20) | (15 << 10) | (5)));
	VIA_CHROME9_WRITE(0x440, ((119 << 20) | (81 << 10) | (52)));
	VIA_CHROME9_WRITE(0x440, ((283 << 20) | (219 << 10) | (165)));
	VIA_CHROME9_WRITE(0x440, ((535 << 20) | (441 << 10) | (357)));
	VIA_CHROME9_WRITE(0x440, ((119 << 20) | (884 << 20) | (757 << 10) |
		(640)));

	/* gamma table*/
	VIA_CHROME9_WRITE(0x43C, (0x00030000 | 0x17000000));
	VIA_CHROME9_WRITE(0x440, (0x40000000 | (13 << 20) | (13 << 10) | (13)));
	VIA_CHROME9_WRITE(0x440, (0x40000000 | (26 << 20) | (26 << 10) | (26)));
	VIA_CHROME9_WRITE(0x440, (0x40000000 | (39 << 20) | (39 << 10) | (39)));
	VIA_CHROME9_WRITE(0x440, ((51 << 20) | (51 << 10) | (51)));
	VIA_CHROME9_WRITE(0x440, ((71 << 20) | (71 << 10) | (71)));
	VIA_CHROME9_WRITE(0x440, (87 << 20) | (87 << 10) | (87));
	VIA_CHROME9_WRITE(0x440, (113 << 20) | (113 << 10) | (113));
	VIA_CHROME9_WRITE(0x440, (135 << 20) | (135 << 10) | (135));
	VIA_CHROME9_WRITE(0x440, (170 << 20) | (170 << 10) | (170));
	VIA_CHROME9_WRITE(0x440, (199 << 20) | (199 << 10) | (199));
	VIA_CHROME9_WRITE(0x440, (246 << 20) | (246 << 10) | (246));
	VIA_CHROME9_WRITE(0x440, (284 << 20) | (284 << 10) | (284));
	VIA_CHROME9_WRITE(0x440, (317 << 20) | (317 << 10) | (317));
	VIA_CHROME9_WRITE(0x440, (347 << 20) | (347 << 10) | (347));
	VIA_CHROME9_WRITE(0x440, (373 << 20) | (373 << 10) | (373));
	VIA_CHROME9_WRITE(0x440, (398 << 20) | (398 << 10) | (398));
	VIA_CHROME9_WRITE(0x440, (442 << 20) | (442 << 10) | (442));
	VIA_CHROME9_WRITE(0x440, (481 << 20) | (481 << 10) | (481));
	VIA_CHROME9_WRITE(0x440, (517 << 20) | (517 << 10) | (517));
	VIA_CHROME9_WRITE(0x440, (550 << 20) | (550 << 10) | (550));
	VIA_CHROME9_WRITE(0x440, (609 << 20) | (609 << 10) | (609));
	VIA_CHROME9_WRITE(0x440, (662 << 20) | (662 << 10) | (662));
	VIA_CHROME9_WRITE(0x440, (709 << 20) | (709 << 10) | (709));
	VIA_CHROME9_WRITE(0x440, (753 << 20) | (753 << 10) | (753));
	VIA_CHROME9_WRITE(0x440, (794 << 20) | (794 << 10) | (794));
	VIA_CHROME9_WRITE(0x440, (832 << 20) | (832 << 10) | (832));
	VIA_CHROME9_WRITE(0x440, (868 << 20) | (868 << 10) | (868));
	VIA_CHROME9_WRITE(0x440, (902 << 20) | (902 << 10) | (902));
	VIA_CHROME9_WRITE(0x440, (934 << 20) | (934 << 10) | (934));
	VIA_CHROME9_WRITE(0x440, (966 << 20) | (966 << 10) | (966));
	VIA_CHROME9_WRITE(0x440, (996 << 20) | (996 << 10) | (996));

	/* Initialize INV_ParaSubType_TexPa*/
	VIA_CHROME9_WRITE(0x43C, (0x00030000 | 0x00000000));
	for (i = 0; i < 16; i++)
		VIA_CHROME9_WRITE(0x440, 0x00000000);

	/* Initialize INV_ParaSubType_4X4Cof */
	VIA_CHROME9_WRITE(0x43C, (0x00030000 | 0x11000000));
	for (i = 0; i < 32; i++)
		VIA_CHROME9_WRITE(0x440, 0x00000000);

	/* Initialize INV_ParaSubType_StipPal */
	VIA_CHROME9_WRITE(0x43C, (0x00030000 | 0x14000000));
	for (i = 0; i < (5 + 3); i++)
		VIA_CHROME9_WRITE(0x440, 0x00000000);

	/* primitive setting & vertex format*/
	VIA_CHROME9_WRITE(0x43C, (0x00040000));
	for (i = 0; i <= 0x62; i++)
		VIA_CHROME9_WRITE(0x440, (i << 24));
    /* c2s clamping value for screen coordinate */
	VIA_CHROME9_WRITE(0x440, (0x50 << 24) | 0x00000000);
	VIA_CHROME9_WRITE(0x440, (0x51 << 24) | 0x00000000);
	VIA_CHROME9_WRITE(0x440, (0x52 << 24) | 0x00147fff);

	/*ParaType 0xFE - Configure and Misc Setting*/
	VIA_CHROME9_WRITE(0x43C, (0x00fe0000));
	for (i = 0; i <= 0x47; i++)
		VIA_CHROME9_WRITE(0x440, (i << 24));

	/*ParaType 0x11 - Frame Buffer Auto-Swapping and Command Regulator*/
	VIA_CHROME9_WRITE(0x43C, (0x00110000));
	for (i = 0; i <= 0x20; i++)
		VIA_CHROME9_WRITE(0x440, (i << 24));

	VIA_CHROME9_WRITE(0x43C, 0x00fe0000);
	VIA_CHROME9_WRITE(0x440, 0x4000840f);
	VIA_CHROME9_WRITE(0x440, 0x47000404);
	VIA_CHROME9_WRITE(0x440, 0x44000000);
	VIA_CHROME9_WRITE(0x440, 0x46000005);
	/* setting Misconfig*/
	VIA_CHROME9_WRITE(0x43C, 0x00fe0000);
	VIA_CHROME9_WRITE(0x440, 0x00001004);
	VIA_CHROME9_WRITE(0x440, 0x08000249);
	VIA_CHROME9_WRITE(0x440, 0x0a0002c9);
	VIA_CHROME9_WRITE(0x440, 0x0b0002fb);
	VIA_CHROME9_WRITE(0x440, 0x0c000000);
	VIA_CHROME9_WRITE(0x440, 0x0d0002cb);
	VIA_CHROME9_WRITE(0x440, 0x0e000009);
	VIA_CHROME9_WRITE(0x440, 0x10000049);
	VIA_CHROME9_WRITE(0x440, 0x110002ff);
	VIA_CHROME9_WRITE(0x440, 0x12000008);
	VIA_CHROME9_WRITE(0x440, 0x130002db);

}

void via_chrome9_init_vq(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	unsigned long  vq_start_addr, vq_end_addr;
	unsigned long  vqlen, vqstartl, vqendl, vqstart_endh;

	/*if we set vram's gpu_offset is 0,
	this offset is offset to vram start */
	vq_start_addr = p_priv->vq->bo.offset;
	vq_end_addr = vq_start_addr + DEV_VQ_MEMORY - 1;
	vqstartl = 0x70000000 | (vq_start_addr & 0xFFFFFF);
	vqendl = 0x71000000 | (vq_end_addr & 0xFFFFFF);
	vqstart_endh = 0x72000000 | ((vq_start_addr & 0xFF000000) >> 24) |
		((vq_end_addr & 0xFF000000) >> 16);
	vqlen = 0x73000000 | (DEV_VQ_MEMORY >> 3);

	VIA_CHROME9_WRITE(0x41c, 0x00100000);
	VIA_CHROME9_WRITE(0x420, vqstart_endh);
	VIA_CHROME9_WRITE(0x420, vqstartl);
	VIA_CHROME9_WRITE(0x420, vqendl);
	VIA_CHROME9_WRITE(0x420, vqlen);
	VIA_CHROME9_WRITE(0x420, 0x74301001);
	VIA_CHROME9_WRITE(0x420, 0x00000000);
}

void via_chrome9_vq_disable(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	VIA_CHROME9_WRITE(0x43c, 0x00fe0000);
	VIA_CHROME9_WRITE(0x440, 0x00000004);
	VIA_CHROME9_WRITE(0x440, 0x40008c0f);
	VIA_CHROME9_WRITE(0x440, 0x44000000);
	VIA_CHROME9_WRITE(0x440, 0x45080c04);
	VIA_CHROME9_WRITE(0x440, 0x46800408);
}

/**
 * Release the vq resource
 */
static void via_chrome9_vq_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	via_chrome9_buffer_object_kunmap(p_priv->vq);
	via_chrome9_buffer_object_unref(&p_priv->vq);
	p_priv->vq = NULL;
}

static int get_fbsize(struct drm_device *dev)
{
	unsigned long   configid, deviceid, fbsize = 0;
	int   videomemsize;
	int   devicefound = false;

	for (configid = 0x80000000; configid < 0x80010800; configid += 0x100) {
		outl(configid, (unsigned long)0xCF8);
		 deviceid = (inl((unsigned long)0xCFC) >> 16) & 0xffff;

		switch (deviceid) {
		/* Found device id */
		case VX800_FUNCTION3:
		case VX855_FUNCTION3:
		case VX900_FUNCTION3:
			outl(configid + 0xA0, (unsigned long)0xCF8);
			fbsize = inl((unsigned long)0xCFC);
			devicefound = true;
			break;
		default:
			break;
		}
		if (devicefound) {
			/* Found device id, so exit for loop */
			break;
		}
	}
	fbsize = fbsize & 0x00007000;
	switch (fbsize) {
	case 0x00001000:
		/* 8M */
		videomemsize = (8 << 20);
		break;
	case 0x00002000:
		/* 16M */
		videomemsize = (16 << 20);
		break;
	case 0x00003000:
		/* 32M */
		videomemsize = (32 << 20);
		break;
	case 0x00004000:
		/* 64M */
		videomemsize = (64 << 20);
		break;
	case 0x00005000:
		/* 128M */
		videomemsize = (128 << 20);
		break;
	case 0x00006000:
		/* 256M */
		videomemsize = (256 << 20);
		break;
	case 0x00007000:
		/* 512M */
		videomemsize = (512 << 20);
		break;
	default:
		/* 32M */
		videomemsize = (32 << 20);
		break;
	}
	return videomemsize;
}

/* Detect VRAM: return 0 if successful; return -EINVAL if failed */
static int via_chrome9_detect_vram(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	/* 0x7122 mean the VT3410 */
	if (dev->pci_device == VX900_DEVICE) {
		dev_priv->vram_start = (unsigned int) pci_resource_start(
			dev->pdev, 2);
	} else {
		dev_priv->vram_start = (unsigned int) pci_resource_start(
			dev->pdev, 0);
	}
	dev_priv->vram_size = get_fbsize(dev);
	/* Add an MTRR for the VRAM */
	if (drm_core_has_MTRR(dev)) {
		dev_priv->vram_mtrr = mtrr_add(dev_priv->vram_start,
						dev_priv->vram_size,
						MTRR_TYPE_WRCOMB, 1);
	}
	return 0;
}

/**
 * mtrr delete the vram region
 */
static void via_chrome9_vram_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int retcode;

	if (drm_core_has_MTRR(dev) && (dev_priv->vram_mtrr >= 0)) {
		retcode = mtrr_del(dev_priv->vram_mtrr, dev_priv->vram_start,
			dev_priv->vram_size);
		DRM_DEBUG("mtrr_del=%d\n", retcode);
	}
}

static inline int via_chrome9_detect_pcie(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	dev_priv->pcie_mem_size = DEV_PCIE_MEMORY;
	return 0;
}

static int via_chrome9_setup_mmio(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	unsigned long mmio_start;
	unsigned long mmio_len;

	mmio_start = pci_resource_start(dev->pdev, 1);
	mmio_len = pci_resource_len(dev->pdev, 1);
	dev_priv->mmio_map = ioremap_nocache(mmio_start, mmio_len);
	if (dev_priv->mmio_map == NULL) {
		DRM_ERROR("Failed mapping graphics controller registers.\n");
		return -ENOMEM;
	}
	mmio_mb1 = dev_priv->mmio_map;
	mmio_map_base = dev_priv->mmio_map + 0x8000;
	KMS_DEBUG("mmio_map_base : %p .\n", mmio_map_base);
	return 0;
}

/**
 * unmap the mmio
 */
static void via_chrome9_mmio_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	iounmap(dev_priv->mmio_map);
	mmio_mb1 = mmio_map_base = dev_priv->mmio_map = NULL;
}

static int via_chrome9_init_irq(struct drm_device *dev)
{
	int r;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int num_crtc = 2;

	if (drm_core_check_feature(dev, DRIVER_MODESET)) {
		dev_priv->irq.installed = true;
		r = drm_irq_install(dev_priv->ddev);
		if (r) {
			KMS_DEBUG("KMS:irq init failed. return=%d\n", r);
			dev_priv->irq.installed = false;
			return r;
		}
		r = drm_vblank_init(dev, num_crtc);
		if (r) {
			KMS_DEBUG(
				"KMS:vblank interrupt init failed. return=%d\n",
				r);
			return r;
		}
		KMS_DEBUG("KMS:irq initialized ok.\n");
	} else {
		via_chrome9_irq_preinstall_nonKMS(dev_priv);
		r = request_irq(dev->pdev->irq,
			via_chrome9_driver_irq_handler_nonKMS,
			IRQF_SHARED, "via_chrome9", dev_priv);
		if (r) {
			DRM_DEBUG("irq initialized failed! r = %d.\n", r);
			return r;
		}
		via_chrome9_irq_postinstall_nonKMS(dev_priv);
		DRM_DEBUG("irq initialized ok.\n");
	}

	return 0;

}

static void via_chrome9_irq_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (drm_core_check_feature(dev, DRIVER_MODESET)) {
		if (dev_priv->irq.installed) {
			drm_irq_uninstall(dev_priv->ddev);
			dev_priv->irq.installed = false;
		}
	} else {
		via_chrome9_irq_uninstall_nonKMS(dev_priv);
		free_irq(dev->pdev->irq, dev_priv);
	}

}

/* This function do things below:
 * 1. Command buffer allocation
 * 2. hw engine intialization:2D;3D;VQ
 * 3. Ring Buffer mechanism setup
 */
static int via_chrome9_init_exec(struct drm_device *dev)
{
	int ret;

	/* allocate the exec bo: VQ, ring buffer and gart table */
	ret = via_chrome9_allocate_basic_bo(dev);
	drm_dev_v4l = dev;
	if (unlikely(ret))
		return ret;

	via_chrome9_init_2d(dev);
	via_chrome9_init_3d(dev);
	via_chrome9_init_vq(dev);

	/* pcie gart table setup */
	via_chrome9_init_gart_table(dev);

	/* ring buffer mechanism setup */
	via_chrome9_init_dma(dev);

	return 0;
}

int via_chrome9_resume_exec(struct drm_device *dev)
{
	via_chrome9_init_2d(dev);
	via_chrome9_init_3d(dev);

	via_chrome9_drm_restore_bos(dev);
	via_chrome9_init_gart_table(dev);
	via_chrome9_resume_dma(dev);

	return 0;
}
static void via_chrome9_exec_fini(struct drm_device *dev)
{
	via_chrome9_vq_fini(dev);
	via_chrome9_dma_fini(dev);
	via_chrome9_gart_table_fini(dev);
}
int via_chrome9_suspend_exec(struct drm_device *dev)
{
	via_chrome9_suspend_dma(dev);
	return 0;
}

static void via_chrome9_init_engine_ops(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	switch (dev->pci_device) {
	case VX800_DEVICE:
	case VX855_DEVICE:
		p_priv->engine_ops.cmdbuffer_ops.kickoff_dma_ring =
			via_chrome9_kickoff_dma_ring;
		p_priv->engine_ops.cmdbuffer_ops.execute_branch_buffer =
			execute_branch_buffer_h6;
		p_priv->engine_ops.fence_ops.fence_emit =
			via_chrome9_fence_emit_h6;
		p_priv->engine_ops.fence_ops.fence_signaled =
			via_chrome9_fence_signaled_h6;
		p_priv->engine_ops.fence_ops.fence_wait =
			via_chrome9_fence_wait_h6;
		p_priv->engine_ops.instert_sync_cmd =
			via_chrome9_instert_sync_cmd_h6;
		break;
	case VX900_DEVICE:
		p_priv->engine_ops.cmdbuffer_ops.kickoff_dma_ring =
			via_chrome9_kickoff_dma_ring;
		p_priv->engine_ops.cmdbuffer_ops.execute_branch_buffer =
			execute_branch_buffer_h5s2vp1;
		p_priv->engine_ops.fence_ops.fence_emit =
			via_chrome9_fence_emit_h5s2vp1;
		p_priv->engine_ops.fence_ops.fence_signaled =
			via_chrome9_fence_signaled_h5s2vp1;
		p_priv->engine_ops.fence_ops.fence_wait =
			via_chrome9_fence_wait_h6;
		/*via_chrome9_fence_wait_h5s2vp1; */
		p_priv->engine_ops.instert_sync_cmd =
			via_chrome9_instert_sync_cmd_h5s2vp1;
		break;
	default:
		DRM_ERROR("Chip ID =0x%x Not supported",
			dev->pci_device);
	}
}

int via_chrome9_driver_load(struct drm_device *dev,
	unsigned long chipset)
{
	struct drm_via_chrome9_private *drv_ptr;
	int ret = 0;

	/* Allocate driver specific data structure for management */
	drv_ptr = kzalloc(sizeof(struct drm_via_chrome9_private), GFP_KERNEL);
	if (!drv_ptr)
		return -ENOMEM;
	dev->dev_private = (void *)drv_ptr;
	drv_ptr->ddev = dev;

	/* setup workqueue */
	drv_ptr->wq = create_workqueue("via_chrome9");
	if (drv_ptr->wq == NULL) {
		KMS_DEBUG("create_workqueue failed !\n");
		goto out_err0;
	}
	spin_lock_init(&vga_reg_read_lock);
	ret = via_chrome9_setup_mmio(dev);
	if (ret)
		goto out_err0;

	ret = via_chrome9_detect_vram(dev);
	if (ret)
		goto out_err1;

	ret = via_chrome9_detect_pcie(dev);
	if (ret)
		goto out_err1;

	via_chrome9_init_engine_ops(dev);

	/* Initialize ttm part stuffs */
	ret = via_chrome9_init_ttm(dev);
	if (ret)
		goto out_err1;

	/* setup environment for DMA engine */
	via_chrome9_init_dmablit(dev);

	/* register interrupt handler stuffs */
	via_chrome9_init_irq(dev);

#if VIA_CHROME9_ENABLE_KMS
	/* Init kernal mode setting */
	ret = via_chrome9_mode_set_init(dev);
	if (ret)
		goto out_err5;
#endif
	/* setting up environment for executing command */
	ret = via_chrome9_init_exec(dev);
	if (ret)
		goto out_err2;

	/* fence mechanism setup */
	ret = via_chrome9_fence_mechanism_init(dev);
	if (ret)
		goto out_err3;

	ret = via_chrome9_sg_move_init(dev);
	if (ret)
		goto out_err4;
#if VIA_CHROME9_VERIFY_ENABLE
	/* Init command verification */
	ret = via_chrome9_command_verifier_init(dev);
#endif
	if (ret)
		goto out_err5;
	
	return 0;

out_err5:
#if VIA_CHROME9_VERIFY_ENABLE
	via_chrome9_command_verifier_fini(dev);
#endif
out_err4:
	via_chrome9_sg_move_fini(dev);
out_err3:
	via_chrome9_exec_fini(dev);
out_err2:
	via_chrome9_irq_fini(dev);
	via_chrome9_dmablit_fini(dev);
	via_chrome9_ttm_fini(dev);
out_err1:
	via_chrome9_mmio_fini(dev);
out_err0:
	kfree(drv_ptr);
	dev->dev_private = NULL;

	return ret;
}

/**
 * Clean up all the works done in via_chrome9_driver_load function
 * release all the resource occupied by our modules
 */
int via_chrome9_driver_unload(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

#if VIA_CHROME9_ENABLE_KMS
	via_chrome9_mode_set_fini(dev);
#endif
	/* irp mechanism teardown */
	via_chrome9_irq_fini(dev);
	/* dma mechanism teardown */
	via_chrome9_dmablit_fini(dev);
	/*cloes command verification*/
#if VIA_CHROME9_VERIFY_ENABLE
	via_chrome9_command_verifier_fini(dev);
#endif
	/* fence mechanism teardown */
	via_chrome9_fence_mechanism_fini(dev);
	/*destory sg for DMA move*/
	via_chrome9_sg_move_fini(dev);
	/* vq/ring buffer/gart table mechanism teardown */
	via_chrome9_exec_fini(dev);
	/* mtrr delete the vram */
	via_chrome9_vram_fini(dev);
	/* unmap the mmio */
	via_chrome9_mmio_fini(dev);
	/* destroy work queue. */
	destroy_workqueue(dev_priv->wq);
	/* ttm mechanism tear down */
	via_chrome9_ttm_fini(dev);
	kfree(dev_priv->hdmi_cts_renew);
	dev_priv->hdmi_cts_renew = NULL;
	kfree(dev_priv);
	dev->dev_private = NULL;

	return 0;
}
