/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_DRV_H_
#define _VIA_CHROME9_DRV_H_

#include <linux/wait.h>
#include <linux/workqueue.h>
#include <linux/interrupt.h>
#include "drm_sman.h"
#include "drm_crtc.h"
#include "via_chrome9_verifier.h"
#include "ttm/ttm_bo_api.h"
#include "ttm/ttm_bo_driver.h"
#include "ttm/ttm_placement.h"
#include "ttm/ttm_module.h"
#include "ttm/ttm_memory.h"
#include "via_chrome9_mode.h"
#include "via_chrome9_fb.h"
#include "via_chrome9_cursor.h"
#include "via_chrome9_fence.h"
#include <linux/fb.h>
#include "via_chrome9_cbios.h"

#define DRIVER_AUTHOR	"VIA"

#define DRIVER_NAME		"via_chrome9"
#define DRIVER_DESC		"VIA_CHROME9 Pro"
#define DRIVER_DATE		"20091016"

#define DRIVER_MAJOR		1
#define DRIVER_MINOR		1
#define DRIVER_PATCHLEVEL	0

#define ENABLE_CBIOS_CODE 1

/* VT3353 chipset*/
#define VX800_FUNCTION3  0x3353
#define VX800_DEVICE  0x1122
/* VT3409 chipset*/
#define VX855_FUNCTION3  0x3409
#define VX855_DEVICE  0x5122
/* VT3410 chipset*/
#define VX900_FUNCTION3  0x3410
#define VX900_DEVICE  0x7122

#define VX800_INDEX  (0x1 << 0)
#define VX855_INDEX  (0x1 << 1)
#define VX900_INDEX  (0x1 << 2)

/* For VT3353 */
/* There is no need to focus on 353 A now, thus not specify the revison for A*/
#define REVISION_VX800_A   0x3530f
#define REVISION_VX800_B0  0x35310
#define REVISION_VX800_B1  0x35311
#define REVISION_VX800_B2  0x35312

/* For VT3409 */
#define REVISION_VX855_A0  0x40900
#define REVISION_VX855_A1  0x40901
#define REVISION_VX855_A2  0x40902

/* For VT3410 */
#define REVISION_VX900_A0  0x41000
#define REVISION_VX900_A1  0x41001
#define REVISION_VX900_A2  0x41002
#define REVISION_VX900_A3  0x41003

#define DRM_FILE_PAGE_OFFSET (0x100000000ULL >> PAGE_SHIFT)
#define DEV_VQ_MEMORY (256 * 1024)
#define DEV_COMMAND_BUFFER_MEMORY (16 * 1024 * 1024)
#define DEV_PCIE_MEMORY (512 * 1024 * 1024UL)
#define VIA_CHROME9_ENABLE_KMS 1
#define VIA_CHROME9_KMS_DEBUG 0

/* mmio 0x1280 IRQ enabe and status bits. */
#define    VIA_IRQ_DP1_EN    (1 << 24)
#define    VIA_IRQ_DP2_EN    (1 << 26)
#define    VIA_IRQ_IN_TMDS_EN    (1 << 30)
#define    VIA_IRQ_DP1_STS    (1 << 11)
#define    VIA_IRQ_DP2_STS    (1 << 13)
#define    VIA_IRQ_IN_TMDS_STS    (1 << 9)

/* mmio 0x200 IRQ enabe and status bits.  */
#define    VIA_IRQ_ALL_EN    (1 << 31)
#define    VIA_IRQ_DVP1_EN    (1 << 30)
#define    VIA_IRQ_IGA1_VSYNC_EN    (1 << 19)
#define    VIA_IRQ_IGA2_VSYNC_EN    (1 << 17)
#define    VIA_IRQ_DVP1_STS    (1 << 27)
#define    VIA_IRQ_TMDS_STS    (1 << 0)
#define    VIA_IRQ_IGA1_VSYNC_STS    (1 << 3)
#define    VIA_IRQ_IGA2_VSYNC_STS    (1 << 15)
#define    VIA_IRQ_DMA1TransIntStatus  (1<<7)
#define    VIA_IRQ_DMA0TransIntStatus   (1<<5)
#define    Intterupt_Status_Mask \
		~(VIA_IRQ_DMA1TransIntStatus| \
		VIA_IRQ_DMA0TransIntStatus|VIA_IRQ_IGA1_VSYNC_STS| \
		VIA_IRQ_IGA2_VSYNC_STS|VIA_IRQ_TMDS_STS)

/* mmio 0xc500 IRQ enabe and status bits.  */
#define    VIA_IRQ_HDAC1_EN    (1 << 4)
#define    VIA_IRQ_HDAC2_EN    (1 << 5)
#define    VIA_IRQ_HDAC1_STS    (1 << 0)
#define    VIA_IRQ_HDAC2_STS    (1 << 1)

/* HDMI Left/Right/Top/Bottom border Properties setting. */
#define MAX_SUPPORTED_HOR_BORDER  80
#define MAX_SUPPORTED_VER_BORDER  60
#define HDMI_LEFT_BORDER_NAME  "LeftBorder"
#define HDMI_RIGHT_BORDER_NAME  "RightBorder"
#define HDMI_TOP_BORDER_NAME  "TopBorder"
#define HDMI_BOTTOM_BORDER_NAME  "BottomBorder"

#define TV_TYPE_NUM	6
#define TV_TYPE_NAME	"Type"
/*TV PosH*/
#define TV_POSH_NAME	"PosH"
/*TV PosV*/
#define TV_POSV_NAME	"PosV"
#define TV_SIGNAL_NUM	4
#define TV_SIGNAL_NAME	"Signal"
#define TV_SCAN_TYPE_NUM	3
#define TV_SCAN_TYPE_NAME	"Scan"
#define TV_DOTCRAWL_NUM	2
#define TV_DOTCRAWL_NAME	"DotCrawl"
#define TV_BRIGHTNESS_NAME	"Brightness"
#define TV_CONTRAST_NAME	"Contrast"
#define TV_SATURATION_NAME	"Saturation"
#define TV_HUE_NAME	"Hue"
#define TV_AFFLITER_VALUE	"AFFilterValue"
#define TV_FFLITER_NAME_NUM	3
#define TV_FFLITER_NAME	"FFilter"
#define TV_FFLITER_VALUE	"FFilterValue"

#define SIGNAL_FORMAT_NAME "SignalFormat"
#define SIGNAL_FORMAT_NUM 11

#define CONNECTOR_TYPE_NAME "ConnectorType"
#define CONNECTOR_TYPE_NUM 15


#define CRT_POLL_HOT_PLUG 0

/* PLL types.*/
#define VIA_PLL_TYPE_PLL_3_NEW    2
#define VIA_PLL_TYPE_PLL_3_ADV    3

struct drm_prop_enum_list {
	int type;
	char *name;
};

struct via_prop_enum_combine_list {
	int type;
	int num;
	struct drm_prop_enum_list *prop_enum_list;
};

struct via_chrome9_object {
	struct ttm_buffer_object bo;
	struct ttm_bo_kmap_obj kmap;
	void *ptr;
	bool iomem;
	u32 placements[3];
	u32 busy_placements[3];
	struct ttm_placement placement;
	struct ttm_placement busy_placement;
	/*who grab this BO*/
	struct drm_file *owner_file;
	struct drm_file *reserved_by;
	unsigned long flags;
	/* memory domains*/
	uint32_t read_domain;
	uint32_t write_domain;
	/* new read write domains*/
	uint32_t pending_read_domain;
	uint32_t pending_write_domain;
	/* for multi-level branch buffer */
	uint32_t access_engine_type;
	/*
	 * GPU cache snoop(cpu cache) enable
	 * only 410 support cache snoop
	 */
	bool cache_snoop;
	struct list_head snoop_list;
	/*for mutex lock*/
	struct drm_device *dev;

	spinlock_t lock;
};

struct drm_via_chrome9_shadow_map {
	struct drm_local_map  *shadow;
	unsigned int   shadow_size;
	unsigned int   *shadow_handle;
};

struct acpi_backup {
	unsigned char gti_backup[13];
	unsigned char eng_clk_backup[3];
	unsigned char sr_regs[256];
	unsigned char cr_regs[256];
	struct via_chrome9_object *agp_gart_shadow;
};

struct via_chrome9_irq_info {
	bool installed;
	bool irq_all;

	bool dp_sense_int[2];
	bool dvp1_sense_int;
	bool internal_tmds_sense_int;
};

struct via_chrome9_engine_ops {
	/* flush command ops */
	struct via_chrome9_cmdbuffer_ops {
		void (*kickoff_dma_ring)(struct drm_device *dev);
		int (*execute_branch_buffer)(struct drm_device *dev,
			struct via_chrome9_object *vbo, uint32_t cmd_size);
	} cmdbuffer_ops;
	/* cache coherence ops */
	struct via_chrome9_coherence_ops {
		void (*enable_bo_cache_snoop)(struct ttm_buffer_object *bo);
		void (*disable_bo_cache_snoop)(struct ttm_buffer_object *bo);
		void (*flush_3d_cache)(struct drm_device *ddev);
	} cache_coherence_ops;
	struct via_chrome9_fence_ops {
		int (*fence_emit)(struct drm_via_chrome9_private *p_priv,
			struct via_chrome9_fence_object *p_fence_object);
		bool (*fence_signaled)(struct via_chrome9_fence_object *p_fence,
			void *arg);
		int (*fence_wait)(struct via_chrome9_fence_object *p_fence,
			void *sync_arg, bool lazy, bool interruptible);
	} fence_ops;
	void (*instert_sync_cmd)(struct drm_device *dev,
		unsigned int wait_engines, unsigned int cmd_type);
};

enum via_shrink_state {
	SHRINK_STATE_NONE = 0x0,
	SHRINK_STATE_3DSTRETCH = 0x1,
	SHRINK_STATE_PANNING = 0x2,
	SHRINK_STATE_DOWNSCALE = 0x4,
	SHRINK_STATE_CENTER = 0x8,
	SHRINK_STATE_UPSCALE = 0x10,
	SHRINK_STATE_TEMPBLOCK = 0x80000000,
};

struct disp_iga_info {
	int   disp_dev;
	struct drm_display_mode mode;
	struct drm_display_mode adjusted_mode;
	int iga_scale_status;
};

struct hdmi_cts_renew {
	ULONG  counter;
	ULONG  interval;
	ULONG  feedback;
	ULONG  increaser;
	ULONG  cts;

	bool  is_hdmi_cts_timer_on;
	u32  debug_counter;
	struct timer_list cts_renew_timer;
};

struct drm_via_chrome9_private {
	struct ttm_bo_global_ref        bo_global_ref;
	struct drm_global_reference	mem_global_ref;
	struct ttm_bo_device bdev;
	struct drm_device *ddev;

	/* vram physical bus address */
	uint64_t vram_start;
	/* M byte */
	uint64_t vram_size;
	int vram_mtrr;
	/* Byte */
	uint64_t ring_buffer_size;
	/* Byte */
	uint64_t pcie_mem_size;
	/* offset from vram */
	uint64_t pcie_gart_start;

	u8 __iomem *mmio_map;
	/* kernel virtual address for accessing gart */
	u32 *pcie_gart_map;
	/* kernel virtual address for accessing ringbuffer */
	u32 *pcie_ringbuffer_map;
	bool need_dma32;
	struct via_chrome9_object *vq;
	struct via_chrome9_object *agp_gart;
	struct via_chrome9_object *agp_ringbuffer;
	/* a pointer to manage the AGP ring buffer */
	struct drm_via_chrome9_dma_manager *dma_manager;
	/* fence stuff */
	struct via_chrome9_fence_pool *p_fence;
	struct via_chrome9_sg_move_manager *sg_manager;
	/*for shadow & event tag*/
	struct drm_via_chrome9_shadow_map shadow_map;
	struct drm_clb_event_tag_info *event_tag_info;
#if VIA_CHROME9_VERIFY_ENABLE
	struct drm_via_chrome9_state hc_state;
#endif
	int *verify_buff;
	int gart_valid;
	/*save GTI registers here when suspend*/
	struct acpi_backup pm_backup;
	/* via graphic chip ops */
	struct via_chrome9_engine_ops  engine_ops;
	/* list of bo need to unsnoop */
	struct list_head snoop_list;
	/*kms related*/
	int num_crtc; /* number of crtcs */
	u32 chip_caps;
	u32 pseudo_chip_revision;
	struct via_chrome9_mode_info mode_info;

	struct via_chrome9_irq_info irq;
	struct workqueue_struct *wq;
	struct work_struct hotplug_work;
	struct fb_info *fb_info;
	/* record last engine type */
	uint32_t prev_cmd_type;

	void * crt_1_info;
	void * crt_2_info;
	void * dvi_1_info;
	void * dvi_2_info;
	void * lcd_1_info;
	void * lcd_2_info;
	void * tv_1_info;
	void * hdtv_1_info;
	void * hdmi_1_info;
	void * hdmi_2_info;
	void * dp_1_info;
	void * dp_2_info;
	struct disp_iga_info disp_iga_info[2];
	unsigned int supported_devices;
	unsigned int hdmi_tx_irq_type;
	ULONG hpd_mm200;
	ULONG hpd_mm1280;

	struct hdmi_cts_renew *hdmi_cts_renew;

	u32 via_chrome9_pll_type;
	bool is_mode_line_exist;
};


struct pll_mrn_value {
	u32 pll_m;
	u32 pll_r;
	u32 pll_n;
	u32 diff_clk;
	u32 pll_fout;
};

enum via_chrome9_family {
	/* Baseline */
	VIA_CHROME9_OTHER = 0,
	/* Another video engine and DMA commands */
	VIA_CHROME9_PRO_GROUP_A,
	VIA_CHROME9_DX9_0,
	VIA_CHROME9_PCIE_GROUP
};

/* VIA_CHROME9 MMIO register access */
#define VIA_CHROME9_READ(reg)		\
	ioread32((u32 *)(p_priv->mmio_map + (reg)))
#define VIA_CHROME9_WRITE(reg, val)	\
	iowrite32(val, (u32 *)(p_priv->mmio_map + (reg)))
#define VIA_CHROME9_READ8(reg)		\
	ioread8(p_priv->mmio_map + (reg))
#define VIA_CHROME9_WRITE8(reg, val)	\
	iowrite8(val, p_priv->mmio_map + (reg))

#if VIA_CHROME9_KMS_DEBUG
#define KMS_DEBUG(fmt, arg...) \
	printk(KERN_INFO "%s " fmt , __func__ , ##arg)
#else
#define KMS_DEBUG(fmt, arg...)	do { } while (0)
#endif

extern void via_chrome9_hpd_init(struct drm_device *dev);
extern void via_chrome9_hpd_fini(struct drm_device *dev);
extern void via_chrome9_send_unsolicited_response(
		struct drm_connector *connector);

extern unsigned int via_chrome9_connector_to_cbios_device(
		unsigned int connector_id);
extern bool  via_chrome9_cbios_help_device_detect (
		struct drm_device *dev, unsigned int detect_dev);
extern u32 via_chrome9_get_mrn(u32 pll_type, u32 frequency);
extern enum drm_mode_status via_chrome9_mode_valid_helper(
		struct drm_connector *connector, 
		struct drm_display_mode *mode, int device);
extern void via_chrome9_set_disp_dev_power_state(
		unsigned int disp_dev, unsigned int  power_state);

typedef int (*thread_func_t)(void *data);

#endif
