/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_TTM_H_
#define _VIA_CHROME9_TTM_H_
#define DMA_DEBUG 0

extern int
via_chrome9_ttm_global_init(struct drm_via_chrome9_private *dev_priv);
extern int via_chrome9_init_ttm(struct drm_device *dev);
extern void via_chrome9_ttm_fini(struct drm_device *dev);
extern struct ttm_backend *
via_chrome9_pcie_backend_init(struct drm_via_chrome9_private *p_priv);
extern int via_chrome9_bo_move(struct ttm_buffer_object *bo,
		bool evict, bool interruptible,  bool no_wait_reserve,
		bool no_wait_gpu, struct ttm_mem_reg *new_mem);
extern int via_chrome9_sg_move_init(struct drm_device *dev);
extern int via_chrome9_sg_move_fini(struct drm_device *dev);
extern void via_chrome9_set_gpu_domain(struct ttm_buffer_object *bo);
extern void via_chrome9_set_cpu_domain(struct ttm_buffer_object *bo,
		uint32_t domain);


struct chrome9_sg_info {
	struct chrome9_descriptor **chrome9_desc;
	int num_desc;
	int desc_per_page;
	uint32_t *dma_cmd_tmp;
	enum dma_data_direction direction;
	uint64_t chain_start;
};

struct via_chrome9_sg_obj {
	struct chrome9_sg_info via_chrome9_sg_info;
	struct list_head ddestory;
	spinlock_t lock;
	struct via_chrome9_fence_object *p_fence;
	struct drm_via_chrome9_private *dev_priv;
};

struct via_chrome9_sg_move_manager {
	struct list_head ddestory;
	struct delayed_work sg_wq;
	spinlock_t lock;
	struct drm_via_chrome9_private *dev_priv;

	struct via_chrome9_object *sg_fence[4]; /*DMA fence src*/
	uint32_t *sg_fence_vaddr[4]; /*virtual address of fence in VRAM*/
	/*dest of fence blit by DMA*/
	uint32_t *sg_sync_vaddr; /*virtual address*/
	uint32_t *sg_sync_vaddr_align; /*aligned to 16, HW limitation*/
	dma_addr_t  sg_sync_bus_addr; /*BUS address, used by DAM engine*/
	uint64_t  sg_sync_bus_addr_align;
	bool initialized;
};

struct chrome9_descriptor {
	uint32_t mem_addr_l;
	uint32_t mem_addr_h;
	uint32_t dev_addr;
	uint32_t size;
	uint32_t tile_mode;
	uint32_t next_l;
	uint32_t next_h;
	/*Chrome9_descriptor needs 16 byte align, use this field to fill*/
	uint32_t null;
};


#endif
