/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
#include "via_chrome9_cbios.h"
#include "via_chrome9_drv.h"
#include <linux/kthread.h>
#include "cbios_uma.h"
#include "cbios_sub_func.h"
#include "cbios_cea_timing.h"

typedef CBIOS_STATUS (*PFN_CBiosSetTiming)(PVOID pvcbe, 
		IN PCBiosSetTimingParams pTimingParams);
typedef CBIOS_STATUS (*PFN_CBiosSetInfoFrameData)(PVOID pvcbe, 
		IN PCBIOS_PARAM_INFOFRAME pInfoFrameData);
typedef CBIOS_STATUS (*PFN_CBiosSetHDAudioParameter)(PVOID pvcbe, 
		IN PCBIOS_PARAM_INFOFRAME pInfoFrameData);

/*    [24:16] disp types BIOS supports */
#define VIA_DISP_SPT_TYPE_1	0x017F0000
/*    [25:16] disp types BIOS supports */
#define VIA_DISP_SPT_TYPE_2     0xA37F0000 

#define VIA_CHROME9_ADD_ALL_MODES 0

PVOID pcbe = NULL;
PVOID fn_cbios_set_timing = NULL;
PVOID fn_cbios_get_fake_edid = NULL;
PVOID fn_cbios_pwm_control = NULL;
PVOID fn_set_info_frame_data = NULL;
PVOID fn_set_hd_audio_parameter = NULL;
extern bool hdtv_enabled;
extern bool hdtv_1080i_enabled;
extern bool no_device_connect;
extern bool dp1_force_connect;
extern bool dp2_force_connect;
extern u8 tv_regional_standard;
static u32 conf_connect_device=ACTIVE_TYPE_NONE;
static u32 conf_connect_value=0xff;


extern void via_chrome9_dump_mem(void *tb, unsigned int len);

VOID via_chrome9_debug_print_ex(IN ULONG level, IN LPSTR message, ...)
{
#if VIA_CHROME9_KMS_DEBUG
	va_list args;
	char prefix[] = "S3CBIOS: ";

	printk(KERN_INFO "%s", prefix);
	va_start(args, message);
	vprintk(message, args);
	va_end(args);
#endif
	return;
}

UCHAR via_chrome9_cb_read8(PUCHAR reg_port)
{
	return readb(reg_port);
}

VOID via_chrome9_cb_write8(PUCHAR reg_port, UCHAR value)
{
	writeb(value, reg_port);
}

USHORT via_chrome9_cb_read16(PUSHORT reg_port)
{
	return readw(reg_port);
}

VOID via_chrome9_cb_write16(PUSHORT reg_port, USHORT value)
{
	writew(value, reg_port);
} 

VOID via_chrome9_delay_micro_seconds(ULONG microseconds)
{
	udelay(microseconds);
}

struct via_cb_connector_info *via_chrome9_get_device_info_pointer(
		struct drm_via_chrome9_private *p_priv, ULONG disp_dev)
{
	struct via_cb_connector_info *dev_info = NULL;

	switch(disp_dev) {
	case ACTIVE_TYPE_CRT:
		dev_info = p_priv->crt_1_info;
		break;
	case ACTIVE_TYPE_CRT2:
		dev_info = p_priv->crt_2_info;
		break;
	case ACTIVE_TYPE_DVI:
		dev_info = p_priv->dvi_1_info;
		break;
	case ACTIVE_TYPE_DVI2:
		dev_info = p_priv->dvi_2_info;
		break;
	case ACTIVE_TYPE_PANEL:
		dev_info = p_priv->lcd_1_info;
		break;
	case ACTIVE_TYPE_PANEL2:
		dev_info = p_priv->lcd_2_info;
		break;
	case ACTIVE_TYPE_TV:
		dev_info = p_priv->tv_1_info;
		break;
	case ACTIVE_TYPE_HDTV:
		dev_info = p_priv->hdtv_1_info;
		break;
	case ACTIVE_TYPE_HDMI:
		dev_info = p_priv->hdmi_1_info;
		break;
	case ACTIVE_TYPE_HDMI2:
		dev_info = p_priv->hdmi_2_info;
		break;
	case ACTIVE_TYPE_DP:
		dev_info = p_priv->dp_1_info;
		break;
	case ACTIVE_TYPE_DP2:
		dev_info = p_priv->dp_2_info;
		break;
	default:
		KMS_DEBUG("via_chrome9_get_device_info_pointer failed!\n");
		break;
	}

	return dev_info;
}

/* parse customize timing for record Mode Lines, prepare for add Flags to pModeTalbe. */
void via_chrome9_parse_customize_timing_pkg(struct drm_device *dev, 
		u8 *cust_tm_buf_ptr, u32 *cust_tm_aux_info_ptr, 
		uint32_t cust_tm_aux_info_len)
{
	PCustomizeTimingHead head_ptr = NULL;
	struct via_cb_connector_info *dev_info = NULL;
	PCustomizeTimingEntity ml_pkg_ptr  = NULL;
	PCustomizeTimingEntity ml_pkg_head  = NULL;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	u32 *tmp_cust_tm_aux_info_ptr = NULL;
	u32 *disp_dev_cnt = NULL;
	u32 *disp_dev_ml_cnt = NULL;
	u8 ml_num = 0;
	u8 ml_set_dev_num = 0;
	u8 i, j;

	/* get customize timing package pointer head. */
	head_ptr = (PCustomizeTimingHead)cust_tm_buf_ptr;
	/* get mode line timings total(all dispDevs) number */
	ml_num = head_ptr->timingNum;

	if(0 == ml_num) {
		/* if non-modeline, Do not need to parse package. */
		p_priv->is_mode_line_exist = false;
		return;
	} else {
		p_priv->is_mode_line_exist = true;
	}

	tmp_cust_tm_aux_info_ptr = cust_tm_aux_info_ptr;
	/* get total device number which set modelines. */
	ml_set_dev_num = cust_tm_aux_info_len / (2* sizeof(uint32_t)) ;

	disp_dev_cnt = (u32 *)kmalloc(2 * ml_set_dev_num * sizeof(uint32_t),  GFP_KERNEL);
	if(NULL == disp_dev_cnt) {
		return ;
	}
	disp_dev_ml_cnt = (u32 *)(disp_dev_cnt) + ml_set_dev_num;

	ml_pkg_head = 
		(PCustomizeTimingEntity)(cust_tm_buf_ptr+sizeof(CustomizeTimingHead));

	for(i = 0; i < ml_set_dev_num ; i++) {
		disp_dev_cnt[i] = *tmp_cust_tm_aux_info_ptr;
		disp_dev_ml_cnt[i] = *(tmp_cust_tm_aux_info_ptr+1);
		tmp_cust_tm_aux_info_ptr += 2;
	}

	/* collect mode lines resolutions divide by dispDev. */
	for(i = 0; i < ml_set_dev_num; i++) {
		struct via_cb_vid_pn_mode *mode_line_table_tmp = NULL;
		ml_pkg_ptr = ml_pkg_head;

		dev_info = via_chrome9_get_device_info_pointer(
				p_priv, disp_dev_cnt[i]);
		dev_info->mode_line_num = disp_dev_ml_cnt[i];

		KMS_DEBUG("device 0x%x mode line num %d.\n", 
				disp_dev_cnt[i], dev_info->mode_line_num);

		/* free pModeTable because we need to update it later. */
		kfree(dev_info->modes_table);
		dev_info->modes_table = NULL;

		/* free mode lines, add new mode lines. */
		kfree(dev_info->mode_line_table);
		dev_info->mode_line_table = NULL;

		dev_info->mode_line_table = (struct via_cb_vid_pn_mode *)kmalloc(
		sizeof(struct via_cb_vid_pn_mode)*dev_info->mode_line_num, GFP_KERNEL);
		if(NULL == dev_info->mode_line_table){
			KMS_DEBUG("ERROR: malloc for dev_info->mode_line_table fails.\n");
			continue;
		}
		mode_line_table_tmp = dev_info->mode_line_table;
		/* list all mode lines */
		for(j = 0; j < head_ptr->timingNum; j++, ml_pkg_ptr++) {
			if(disp_dev_cnt[i] != ml_pkg_ptr->dispDev)
				/* if not current device. */
				continue;

			mode_line_table_tmp->x_res = ml_pkg_ptr->H_Res;
			mode_line_table_tmp->y_res = ml_pkg_ptr->V_Res;
			mode_line_table_tmp->rrate_x100 = ml_pkg_ptr->rRateX100;
			/* interlaced variable fit here? */
			mode_line_table_tmp->is_interlaced = ml_pkg_ptr->Interlaced;

			mode_line_table_tmp++;
		}
	}

	kfree(disp_dev_cnt);
	disp_dev_cnt = NULL;
	disp_dev_ml_cnt = NULL;
}

CBIOS_STATUS via_chrome9_get_dev_mode_tb_from_multi_mem(
		struct drm_via_chrome9_private *p_priv,
		ULONG  vid_pn_target_id,
		struct via_cb_mode_table **dev_mode_tb,
		PULONG  num_of_dev_mode_tb_acquired)
{
	struct via_cb_connector_info *dev_info = NULL;

	if(MORE_THAN_1BIT(vid_pn_target_id)) {
		KMS_DEBUG("failed 1!\n");
		return CBIOS_ER_NOT_YET_IMPLEMENTED;
	}

	dev_info = via_chrome9_get_device_info_pointer(p_priv, vid_pn_target_id);
	if (!dev_info) {
		KMS_DEBUG("failed 2!\n");
		return CBIOS_ER_NOT_YET_IMPLEMENTED;
	}

	*dev_mode_tb = dev_info->modes_table;
	*num_of_dev_mode_tb_acquired = dev_info->used_mode_table_num;

	if (NULL == *dev_mode_tb || 0 == *num_of_dev_mode_tb_acquired) {
		KMS_DEBUG("failed 3!\n");
		return CBIOS_ER_NOT_YET_IMPLEMENTED;
	}

	return CBIOS_OK;
}

CBIOS_STATUS via_chrome9_get_device_mode_table(
		struct drm_via_chrome9_private *p_priv,
		ULONG vid_pn_target_id, 
		struct via_cb_mode_table **dev_mode_tb,
		PULONG  num_of_dev_mode_tb_acquired)
{
	CBIOS_STATUS status = CBIOS_OK;

	/* parameters check */
	if((vid_pn_target_id == 0) || (MORE_THAN_1BIT(vid_pn_target_id))) {
		KMS_DEBUG("failed 1!\n");
		status = CBIOS_ER_NOT_YET_IMPLEMENTED;
		goto S3GetDeviceModeTable_exit;
	}

	status = via_chrome9_get_dev_mode_tb_from_multi_mem(p_priv,
				vid_pn_target_id,  dev_mode_tb,
				num_of_dev_mode_tb_acquired);

	if((NULL == *dev_mode_tb) || (0 == *num_of_dev_mode_tb_acquired)
			|| (status != CBIOS_OK))
		KMS_DEBUG("failed 2!\n");

S3GetDeviceModeTable_exit:
	return status;
}

int via_chrome9_re_init_cbios(struct drm_device *dev)
{
	int ret = 0;
	ret = CBiosInitialization(pcbe, S3);
	return ret;
}

void via_chrome9_bios_query_vbe_info(struct drm_device *dev)
{
	VIDEO_X86_BIOS_ARGUMENTS bios_args;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	/* set up for BIOS calls */
	memset (&bios_args,0,  sizeof(VIDEO_X86_BIOS_ARGUMENTS));

	/* Query the VBE information */
	bios_args.Ebx = S3_VBE_INFO;
	bios_args.Eax = S3_EXTBIOS_INFO;

	VBE_4F14_0000_QueryChipInfo_UMA(pcbe, &bios_args);

	/*
	 *  Initialize chip devices capability -- at least partially.  These
	 *  ESI bits tell us if the video BIOS supports these devices.  We have
	 *  other bits we'll need to check to see if the actual hardware in use
	 *  supports these devices.
	 */
	if(bios_args.Esi & BIT23) {
		p_priv->supported_devices =
				(bios_args.Ecx & VIA_DISP_SPT_TYPE_2) >> 16;
	} else {
		p_priv->supported_devices =
				(bios_args.Esi & VIA_DISP_SPT_TYPE_1) >> 16;
	}

	/* for 410 temporary aid */
	if(p_priv->supported_devices & ACTIVE_TYPE_DP)
			p_priv->supported_devices |= ACTIVE_TYPE_DP2;

	KMS_DEBUG("S3: Video Bios Version dword: 0x%x\n",   bios_args.Ebx);
	KMS_DEBUG("S3: Bios Device Support byte: 0x%08x.\n", 
			p_priv->supported_devices);
}

/* CBios initialization */
int via_chrome9_init_cbios(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
			(struct drm_via_chrome9_private *)dev->dev_private;
	PVOID rom_image = NULL;
	bool is_sys_bios_info_valid = false;
	CBIOS_EXT_INFO cbios_ext_info;
	CBIOS_CALLBACK_FUNCTIONS fn_call_back;
	CBIOS_EXTENSION_INIT_PARAM cbios_ext_init_par;
	DWORD status;

	memset(&cbios_ext_info, 0, sizeof(CBIOS_EXT_INFO));
	if (pcbe == NULL) {
		status = CBiosGetCBiosExtInfo(&cbios_ext_info);
		if ((status != CBIOS_OK) || (cbios_ext_info.pcbeSize == 0))
			return -EPERM;

		pcbe = kmalloc(cbios_ext_info.pcbeSize, GFP_KERNEL);
		if (!pcbe)
			return -ENOMEM;

		memset(pcbe, 0, cbios_ext_info.pcbeSize);
	}

	/* First set cbios call back functions */
	memset(&fn_call_back, 0, sizeof(CBIOS_CALLBACK_FUNCTIONS));
	fn_call_back.pFnDelayMicroSeconds = (void*)via_chrome9_delay_micro_seconds;
	fn_call_back.pFnSleepMicroSeconds = (void*)via_chrome9_delay_micro_seconds;
	fn_call_back.pFnDbgPrint = (void*)via_chrome9_debug_print_ex;
	fn_call_back.pFnReadUchar = (void*)via_chrome9_cb_read8;
	fn_call_back.pFnWriteUchar = (void*)via_chrome9_cb_write8;
	fn_call_back.pFnReadUshort = (void*)via_chrome9_cb_read16;
	fn_call_back.pFnWriteUshort = (void*)via_chrome9_cb_write16;

	if (CBIOS_OK != CBiosSetCallBackFunctions(pcbe, &fn_call_back)) {
		KMS_DEBUG("CBIOS_INIT: CBiosSetCallBackFunctions is failed!\n");
		return -EPERM;
	}

	/* get rom image */
	{
		PSYSBIOSInfo sys_info = NULL;
		ULONG fb_size = 0;
		int reg_sr39 = 0;
		BYTE length = 0;
		PBYTE byte_ptr = NULL;
		ULONG ck_sum = 0x00;
		uint64_t rom_image_phy_addr = 0;

		outb(0x39, 0x3C4);
		reg_sr39 = inb(0x3C5);
		fb_size = (reg_sr39<< 22);
		/* Use a fix VCP size */
		rom_image_phy_addr = p_priv->vram_start + 
				fb_size - SHADOW_VBIOS_SIZE; 
		rom_image = ioremap_nocache(rom_image_phy_addr, SHADOW_VBIOS_SIZE);
		KMS_DEBUG("CBIOS_INIT: Sr39  0x%x\n", reg_sr39);
		KMS_DEBUG("CBIOS_INIT: fb_size:  0x%x\n", fb_size);
		KMS_DEBUG("CBIOS_INIT: vram_start: 0x%lx\n", 
				(unsigned long int)p_priv->vram_start);
		KMS_DEBUG("CBIOS_INIT: rom_image_phy_addr 0x%lx\n", 
				(unsigned long int)rom_image_phy_addr);
		KMS_DEBUG("CBIOS_INIT: rom_image %p\n", rom_image);

		if (rom_image != NULL) {
			/* Check the System BIOS info is valid or not. */
			sys_info = (PSYSBIOSInfo)((PBYTE)rom_image+ROM_SCAN_SIZE);
			length = sys_info->Header.Length;
			byte_ptr = (PBYTE)sys_info;
			ck_sum = 0x00;

			KMS_DEBUG("CBIOS_INIT: rom_image length: 0x%x\n", length);

			if(length > 0) {
				while(length-- > 0) {
					ck_sum += *byte_ptr;
					byte_ptr++;
				}
				/* the little 8bit should be zero, and sum should not be zero */
				if((ck_sum != 0) && ((ck_sum & 0xff) == 0)) {
					is_sys_bios_info_valid = true;
				} else {
					rom_image = NULL;
					KMS_DEBUG("CBIOS_INIT: ck_sum fail\n");
				}
			}
		}
		if (is_sys_bios_info_valid) {
			KMS_DEBUG("SysBIOSInfo is Valid!\n");
			KMS_DEBUG("Version=0x%x\n", sys_info->Header.Version);
			KMS_DEBUG("BootUpDev=0x%x\n", sys_info->BootUpDev);
			KMS_DEBUG("HDTV_TV_Config=0x%x\n", sys_info->HDTV_TV_Config);
			KMS_DEBUG("FBStartingAddr=0x%x\n", sys_info->FBStartingAddr);
			KMS_DEBUG("LCDPanelID=0x%x\n", sys_info->LCDPanelID);
			KMS_DEBUG("FBSize=0x%x\n", sys_info->FBSize);
			KMS_DEBUG("DRAMDataRateIdx=0x%x\n", sys_info->DRAMDataRateIdx);
			KMS_DEBUG("DualMemoCtrl=0x%x\n", sys_info->DualMemoCtrl);
			KMS_DEBUG("AlwaysLightOnDev=0x%x\n", sys_info->AlwaysLightOnDev);
			KMS_DEBUG("AlwaysLightOnDevMask=0x%x\n", 
				sys_info->AlwaysLightOnDevMask);
			KMS_DEBUG("EngineClockModify=0x%x\n", sys_info->EngineClockModify);
			KMS_DEBUG("LCD2PanelID =0x%x\n", sys_info->LCD2PanelID);
			KMS_DEBUG("TVLayOut=0x%x\n", sys_info->TVLayOut);
			KMS_DEBUG("SSCCtrl=0x%x\n", sys_info->SSCCtrl);
			KMS_DEBUG("ChipCapability=0x%x\n", sys_info->ChipCapability);
			KMS_DEBUG("LowTopAddress	   =0x%x\n", sys_info->LowTopAddress);
			KMS_DEBUG("RemapStartAddress   =0x%x\n", 
				sys_info->RemapStartAddress);
			
			if(sys_info->BootUpDev&S3_HDTV)
				hdtv_enabled =true;	
			if(((sys_info->HDTV_TV_Config & (BIT16+BIT17+BIT18)) >> 16)==HDTV1080I)
				hdtv_1080i_enabled =true;		
		} else {
			/* use C000 to get VBIOS */
			rom_image = ioremap_nocache(0xC0000, ROM_SCAN_SIZE);
			KMS_DEBUG("SysBIOSInfo is Invalid!\n");
			KMS_DEBUG("Get rom_image from C0000!\n");
		}
	}
	/* Call CBios init function before any CBios calls */
	memset(&cbios_ext_init_par, 0, sizeof(CBIOS_EXTENSION_INIT_PARAM));
	cbios_ext_init_par.RomImage = rom_image;
	cbios_ext_init_par.RomImageLength = ROM_SCAN_SIZE;
	if (is_sys_bios_info_valid) 
		cbios_ext_init_par.pSysInfo = (PVOID)((PBYTE)rom_image+ROM_SCAN_SIZE);
	else 
		cbios_ext_init_par.pSysInfo = NULL;

	cbios_ext_init_par.MmioBase = (PUCHAR)p_priv->mmio_map;
	cbios_ext_init_par.VGAMmioBase = (PUCHAR)(p_priv->mmio_map + 0x8000);
	switch (dev->pci_device) {
	case VX800_DEVICE:
		cbios_ext_init_par.PCIDeviceID = PCI_ID_VT3353;
		break;
	case VX855_DEVICE:
		cbios_ext_init_par.PCIDeviceID = PCI_ID_VT3409P;
		break;
	case VX900_DEVICE:
		cbios_ext_init_par.PCIDeviceID = PCI_ID_VT3410;
		break;
	default:
		cbios_ext_init_par.PCIDeviceID = PCI_ID_VT3410;
		break;
	}
	cbios_ext_init_par.ChipRevision = p_priv->pseudo_chip_revision;
	cbios_ext_init_par.CBiosBasicInfoLength = sizeof(cbios_ext_init_par);
	cbios_ext_init_par.CBiosBasicInfoVer = CBIOS_BASIC_INFO_VERSION;

	if (CBiosInitCbiosExtParam(pcbe, &cbios_ext_init_par) != CBIOS_OK)
		KMS_DEBUG("CBiosInitCbiosExtParam may be failed!\n");

	/* when primary adapter init pcbe info here */
	if(CBIOS_ER_LACKOFVCPDATA == CBiosInitialization(pcbe, OSstart))
		KMS_DEBUG("CBIOS_INIT: CBIOS is failed to Initialize!\n");
	else
		KMS_DEBUG("CBIOS_INIT: CBIOS is Initialized!\n");

	/* get cbios func points */  
	{
		CBIOSPROC cbios_fn;

		if (CBIOS_OK == CBiosGetProcAddress(pcbe, 
				"CBiosSetTiming", &cbios_fn)) {
			fn_cbios_set_timing  = (PVOID)cbios_fn;
		} else {
			fn_cbios_set_timing  = NULL;
			KMS_DEBUG("CBIOS_INIT: Init fpn CBiosSetTiming fail!");
		}

		if (CBIOS_OK == CBiosGetProcAddress(pcbe, 
				"CBiosGetFakeEdid", &cbios_fn)) {
			fn_cbios_get_fake_edid  = (PVOID)cbios_fn;
		} else {
			fn_cbios_get_fake_edid  = NULL;
		KMS_DEBUG("CBIOS_INIT: Init fpnCBiosGetFakeEdid fail!");
		}

		if (CBIOS_OK == CBiosGetProcAddress(pcbe, 
				"CBiosPWMControl", &cbios_fn)) {
			fn_cbios_pwm_control = (PVOID)cbios_fn;
		} else {
			fn_cbios_pwm_control = NULL;
			KMS_DEBUG("CBIOS_INIT: Init fpnCBiosPWMControl fail!");
		}

		if(CBIOS_OK == CBiosGetProcAddress(pcbe, 
				"CBiosSetInfoFrameData", &cbios_fn)) {
			fn_set_info_frame_data = (PVOID)cbios_fn;
		} else {
			fn_set_info_frame_data = NULL;
			KMS_DEBUG("CBIOS_INIT: Init fn_set_info_frame_data fail!");
		}

		if(CBIOS_OK == CBiosGetProcAddress(pcbe, 
				"CBiosSetHDAudioParameter",  &cbios_fn)) {
			fn_set_hd_audio_parameter = (PVOID)cbios_fn;
		}
		else {
			fn_set_hd_audio_parameter = NULL;
			KMS_DEBUG("CBIOS_INIT: Init fn_set_hd_audio_parameter fail!");
		}
	}

	iounmap(rom_image);
	return 0;
}

void via_chrome9_cbios_set_power_state(unsigned int powerState)
{
	CBiosSetS3Powerstate(pcbe, powerState);
}

void via_chrome9_set_disp_dev_power_state(unsigned int disp_dev,
		unsigned int  powerState)
{
	unsigned int screenState = S3PM_ON;

	if(powerState == true)
		screenState = S3PM_ON;
	else
		screenState = S3PM_OFF;

	KMS_DEBUG("Device: 0x%x, screenState: 0x%x\n", disp_dev, screenState);
	CBiosSetDisplayDevicePowerState(pcbe, disp_dev, screenState);
}

unsigned int via_chrome9_connector_to_cbios_device(unsigned int connector_id)
{
	unsigned int cbios_dev = 0;

	switch(connector_id) {
	case VIA_CHROME9_DEVICE_CONNECTOR_CRT:
		cbios_dev = ACTIVE_TYPE_CRT;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_CRT_2:
		cbios_dev = ACTIVE_TYPE_CRT2;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_LCD:
		cbios_dev = ACTIVE_TYPE_PANEL;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DVI_D:
		cbios_dev = ACTIVE_TYPE_DVI;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DVI_D_2:
		cbios_dev = ACTIVE_TYPE_DVI2;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DP_1:
		cbios_dev = ACTIVE_TYPE_DP;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_DP_2:
		cbios_dev = ACTIVE_TYPE_DP2;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_TV:
		cbios_dev = ACTIVE_TYPE_TV;
		if(hdtv_enabled == true)
			cbios_dev = ACTIVE_TYPE_HDTV;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_HDMI:
		cbios_dev = ACTIVE_TYPE_HDMI;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_HDMI_2:
		cbios_dev = ACTIVE_TYPE_HDMI2;
		break;
	case VIA_CHROME9_DEVICE_CONNECTOR_LCD_2:
		cbios_dev = ACTIVE_TYPE_PANEL2;
		break;
	default:
		KMS_DEBUG("unknown device!!\n");
		break;
	}

	return cbios_dev;
}

bool via_chrome9_set_iga_screen_on_off(int iga_path, unsigned int status)
{
	KMS_DEBUG("Iga %d screen on/off state: 0x%x!!!!\n", iga_path, status);
	CBiosSetIgaScreenOnOffState(pcbe, iga_path, status);
	return true;
}

int via_chrome9_update_hd_audio_par(DWORD device, ULONG hdmi_connect_format,
		DWORD *cts, DWORD *cts_interval)
{
	CBIOS_PARAM_INFOFRAME InfoFrameData;
	CBIOS_STATUS Status = CBIOS_ER_NOT_SUPPORT;

	KMS_DEBUG("enter\n");
	if(!fn_set_hd_audio_parameter) {
		KMS_DEBUG("unsupported\n");
		return Status;
	}

	if(dp1_force_connect||dp2_force_connect){
		KMS_DEBUG("hd_audio unsupported if DP force connect.\n");
		return Status;
	}

	InfoFrameData.CEAModeNumber = hdmi_connect_format;
	InfoFrameData.DisplayDeviceDWord = device;

	if(fn_set_hd_audio_parameter) {
		((PFN_CBiosSetHDAudioParameter)fn_set_hd_audio_parameter)(pcbe, 
				&InfoFrameData);
		KMS_DEBUG("cts=0x%x, cts_interval=0x%x\n", 
				InfoFrameData.CTS, InfoFrameData.CTSInterval);
		*cts = InfoFrameData.CTS;
		*cts_interval = InfoFrameData.CTSInterval;
	}
	return CBIOS_OK;
}

void via_chrome9_cbios_init_device_info(struct drm_via_chrome9_private *p_priv)
{
	struct via_cb_connector_info *dev_info = NULL;

	p_priv->crt_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->crt_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->crt_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->crt_2_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->crt_2_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->crt_2_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->dvi_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->dvi_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->dvi_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->dvi_2_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->dvi_2_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->dvi_2_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->lcd_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->lcd_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->lcd_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->lcd_2_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->lcd_2_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->lcd_2_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->tv_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->tv_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->tv_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->hdtv_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->hdtv_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->hdtv_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->hdmi_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->hdmi_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->hdmi_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->hdmi_2_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->hdmi_2_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->hdmi_2_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->dp_1_info = kmalloc(sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->dp_1_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->dp_1_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));

	p_priv->dp_2_info = kmalloc (sizeof(struct via_cb_connector_info), GFP_KERNEL);
	memset(p_priv->dp_2_info, 0, sizeof(struct via_cb_connector_info));
	dev_info = p_priv->dp_2_info;
	dev_info->parsed_edid_info =
		kmalloc(sizeof(CBIOS_EDID_STRUCTURE_DATA), GFP_KERNEL);
	memset(dev_info->parsed_edid_info, 0, sizeof(CBIOS_EDID_STRUCTURE_DATA));
}

/*
 * insert new resolution to mode table
 * sort the mode table according resolution ascending(1. according XRes, 2. according YRes)
 */
static struct via_cb_mode_table *via_chrome9_add_resolution_to_mode_table(
		struct via_cb_mode_table *mode_table_head,
		ULONG used_table_num, ULONG x_res, ULONG y_res)
{
	struct via_cb_mode_table *tmp = NULL;
	ULONG index = 0;
	struct via_cb_mode_table *mode_table_added = NULL;

	if (used_table_num == 0) {
		mode_table_head->x_res = x_res;
		mode_table_head->y_res = y_res;
		mode_table_added = mode_table_head;
		goto EXIT;
	}

	/*
	 * Skip Same Resolution
	 * Get the last Mode table
	 */
	tmp = mode_table_head + used_table_num - 1; 
	for (index = 0; index < used_table_num; index++, --tmp) {
		if ((tmp->x_res == x_res) && (tmp->y_res == y_res)) {
			mode_table_added = NULL;
			goto EXIT;
		}
	}

	/* Get the last Mode table */
	tmp = mode_table_head + used_table_num - 1;

	for (index = 0; index < used_table_num; index++, --tmp) {
		if ((tmp->x_res < x_res ||
				(tmp->x_res == x_res && tmp->y_res < y_res))) {
			(tmp+1)->x_res = x_res;
			(tmp+1)->y_res = y_res;
			(tmp+1)->rrate_cnt = 0;
			(tmp+1)->rrate_x100_ptr = NULL;
			(tmp+1)->y_total_size_ptr = NULL;
			(tmp+1)->x_total_size_ptr = NULL;
			(tmp+1)->is_interlaced_ptr = NULL;
			mode_table_added = tmp+1;
			goto EXIT;
		} else {
			memcpy(tmp+1, tmp, sizeof(struct via_cb_mode_table));
		}
	}

	/* The resolution added is the smallest */
	if (index == used_table_num) {
		mode_table_head->x_res = x_res;
		mode_table_head->y_res = y_res;
		mode_table_head->rrate_cnt = 0;
		mode_table_head->rrate_x100_ptr = NULL;
		mode_table_head->y_total_size_ptr = NULL;
		mode_table_head->x_total_size_ptr = NULL;
		mode_table_head->is_interlaced_ptr = NULL;
		mode_table_added = mode_table_head;
		goto EXIT;
	}

EXIT:
	return mode_table_added;
}

PCBIOS_EDID_STRUCTURE_DATA via_chrome9_get_parsed_device_edid_info(
		struct drm_via_chrome9_private *p_priv, ULONG dev)
{
	PCBIOS_EDID_STRUCTURE_DATA parsed_edid_info = NULL;
	struct via_cb_connector_info *dev_info = NULL;

	dev_info = via_chrome9_get_device_info_pointer(p_priv, dev);
	if(dev_info)
		parsed_edid_info = 
			(PCBIOS_EDID_STRUCTURE_DATA)dev_info->parsed_edid_info;

	return parsed_edid_info;
}

/*
 * insert new refreshrate/XTotal/YTotal/IsInterlaced to mode table
 * sort the mode table according refreshrate ascending
 *     (1. RefreshRate 2. Progressive prior to Interlaced)
 */
VOID via_chrome9_add_rrate_to_mode_table(struct via_cb_mode_table *mode_table,
		PRefreshRateInfo rrate_info, ULONG new_x_total_size, 
		ULONG new_y_total_size, ULONG s3_mode_flag)
{
	ULONG rrate_index = 0;
	PULONG rrate_buf = NULL;
	PULONG x_total_buf = NULL;
	PULONG y_total_buf = NULL;
	PULONG is_interlaced = NULL;
	PULONG tmp_mode_flag = NULL;
	ULONG num = 0;
	bool  copy_here = false;
	ULONG  pre_mode_flag, pre_interlaced, pre_rrate;

	rrate_buf = mode_table->rrate_x100_ptr;
	x_total_buf = mode_table->x_total_size_ptr;
	y_total_buf = mode_table->y_total_size_ptr;
	is_interlaced = mode_table->is_interlaced_ptr;
	tmp_mode_flag = mode_table->mode_flags_ptr;
	num = mode_table->rrate_cnt;

	if (0 == num) {
		*rrate_buf = rrate_info->rRateX100;
		*x_total_buf = new_x_total_size;
		*y_total_buf = new_y_total_size;
		*is_interlaced = rrate_info->interlaced;
		*tmp_mode_flag = s3_mode_flag;
		if(*rrate_buf != 0)
			mode_table->rrate_cnt++;
		return ;
	}

	/* Skip Same RefreshRate */
	for (rrate_index = 0; rrate_index < num; rrate_index++) {
		if(*(rrate_buf + num - rrate_index - 1) ==  rrate_info->rRateX100 &&
			*(is_interlaced + num - rrate_index - 1) == rrate_info->interlaced) {
			*tmp_mode_flag |= s3_mode_flag;
			return ;
		}
	}

	for (rrate_index = 0; rrate_index < num; rrate_index++) {
		copy_here = true;
		pre_mode_flag = *(tmp_mode_flag + num - rrate_index -1);
		pre_interlaced = *(is_interlaced + num - rrate_index -1);
		pre_rrate = *(rrate_buf + num - rrate_index - 1);

		/* only additional mode and not cbios support, move to bottom of list */
		if(pre_mode_flag == ModeFlag_Win7Additional)  
			copy_here = false;

		/* progressive first, interlace later */
		if(pre_interlaced > rrate_info->interlaced)
			copy_here = false;

		/* small refresh rate first */
		if (pre_rrate > rrate_info->rRateX100)
			copy_here = false;

		if (copy_here == false) {
			/* move previous rrate down */
			*(rrate_buf + num - rrate_index) =
				*(rrate_buf + num - rrate_index - 1);
			*(x_total_buf + num - rrate_index) =
				*(x_total_buf + num - rrate_index - 1);
			*(y_total_buf + num - rrate_index) =
				*(y_total_buf + num - rrate_index - 1);
			*(is_interlaced + num - rrate_index) =
				*(is_interlaced + num - rrate_index - 1);
			*(tmp_mode_flag + num - rrate_index) =
				*(tmp_mode_flag + num - rrate_index - 1);
		} else {
			/* copy */
			*(rrate_buf + num - rrate_index) = rrate_info->rRateX100;
			*(x_total_buf + num - rrate_index) = new_x_total_size;
			*(y_total_buf + num - rrate_index) = new_y_total_size;
			*(is_interlaced + num - rrate_index) = rrate_info->interlaced;
			*(tmp_mode_flag + num - rrate_index) = s3_mode_flag;
			mode_table->rrate_cnt++;
			return ;
		}
	}

	/* The refreshrate added is the smallest */
	if (num == rrate_index) {
		*rrate_buf = rrate_info->rRateX100;
		*x_total_buf = new_x_total_size;
		*y_total_buf = new_y_total_size;
		*is_interlaced = rrate_info->interlaced;
		*tmp_mode_flag = s3_mode_flag;
		mode_table->rrate_cnt++;
		return ;
	}
}

struct via_cb_mode_table *via_chrome9_del_res_from_mode_table(
		struct via_cb_mode_table *mode_table_head,
		ULONG used_table_num, ULONG x_res, ULONG y_res)
{
	ULONG index_0 = 0, index_1 = 0;
	bool is_need_delete = false;
	struct via_cb_mode_table *mode_table_delete = NULL;

	if(used_table_num == 0) {
		mode_table_head->x_res = 0;
		mode_table_head->y_res = 0;
		mode_table_delete = mode_table_head;
		return mode_table_delete;
	}

	for(index_0 = used_table_num + 1; index_0 > 0; index_0--) {
		if((mode_table_head + index_0 - 1)->x_res== x_res &&
			(mode_table_head + index_0 - 1)->y_res== y_res) {
			mode_table_delete = mode_table_head + index_0 - 1;
			is_need_delete = true;
			break;
		}
	}

	if(index_0 == 0)
		KMS_DEBUG("can not find resolution from mode table\n");

	if(is_need_delete) {
		/* if the mode to be deleted is the last one. */
		if(index_0 == used_table_num + 1) {
			memset(mode_table_head + index_0 - 1, 
				0, sizeof(struct via_cb_mode_table));
		} else {
			/* if not the last one , we should adjust the list order. */
			for(index_1 = index_0; index_1 < used_table_num+1; index_1++) {
				*(mode_table_head + index_1 - 1) =
					*(mode_table_head + index_1);
				memset(mode_table_head + index_1, 
					0, sizeof(struct via_cb_mode_table));
			}
		}
	}
	return mode_table_delete;
}

VOID via_chrome9_free_mode_table(struct via_cb_mode_table **mode_table, 
		ULONG used_mode_table_cnt)
{
	struct via_cb_mode_table *mode_table_head = *mode_table;
	ULONG res_index = 0;

	if (NULL == mode_table || *mode_table == NULL)
		return ;

	for (res_index =0; res_index<used_mode_table_cnt; res_index++) {
		if ((*mode_table)->x_total_size_ptr != NULL) {
			kfree((*mode_table)->x_total_size_ptr);
			(*mode_table)->x_total_size_ptr = NULL;
		}

		if ((*mode_table)->y_total_size_ptr != NULL) {
			kfree((*mode_table)->y_total_size_ptr);
			(*mode_table)->y_total_size_ptr = NULL;
		}

		if ((*mode_table)->rrate_x100_ptr!= NULL) {
			kfree((*mode_table)->rrate_x100_ptr);
			(*mode_table)->rrate_x100_ptr= NULL;
		}

		if ((*mode_table)->is_interlaced_ptr != NULL) {
			kfree((*mode_table)->is_interlaced_ptr);
			(*mode_table)->is_interlaced_ptr= NULL;
		}

		if ((*mode_table)->mode_flags_ptr != NULL) {
			kfree((*mode_table)->mode_flags_ptr);
			(*mode_table)->mode_flags_ptr= NULL;
		}

		(*mode_table)++;
	}
	kfree(mode_table_head);
	*mode_table = NULL;
}

bool via_chrome9_check_mode_in_edid_section(
		struct via_cb_vid_pn_mode *vid_pn_mode, 
		PCBIOS_EDID_STRUCTURE_DATA dev_edid_info,
		ULONG vid_pn_mode_type, bool is_ignore_rrate)
{
	bool is_type_match = false;
	ULONG i = 0;

	if((is_type_match == false) && (vid_pn_mode_type & EdidMode_Detail)) {
		for(i = 0; i< 4; i++) {
			if((vid_pn_mode->x_res ==
				dev_edid_info->DtlTimings[i].XResolution)
			   && (vid_pn_mode->y_res ==
			   	dev_edid_info->DtlTimings[i].YResolution)
			   && ((vid_pn_mode->rrate_x100 ==
			   	dev_edid_info->DtlTimings[i].rRateX100) || is_ignore_rrate)
			   && (dev_edid_info->DtlTimings[i].Valid)) {
				is_type_match = true;
				break;
			}
		}

		if(dev_edid_info->CEABlock_1.CEAExtBlockTag ==  0x02) {
			/* Extend EDID spec */
			PEDID_DETAILEDTIMING_INFO pDTLInfo = NULL;
			for(i = 0; i< CEAEXT_MAX_DTD_NUM; i++) {
				pDTLInfo = &dev_edid_info->CEABlock_1.DtlTimings[i];

				if(pDTLInfo->Valid == 0)
					break;
			
				if((vid_pn_mode->x_res == pDTLInfo->XResolution)
				   && (vid_pn_mode->y_res == pDTLInfo->YResolution)
				   && ((vid_pn_mode->rrate_x100 == pDTLInfo->rRateX100) 
				   	|| is_ignore_rrate)
				   && (pDTLInfo->Valid)) {
					is_type_match = true;
					break;
				}
			}
		}
	}

	if((is_type_match == false) && (vid_pn_mode_type & EdidMode_Standard)) {
		for(i = 0; i< 8; i++) {
			if((vid_pn_mode->x_res ==
				dev_edid_info->StdTimings[i].XResolution)
			   && (vid_pn_mode->y_res ==
			   	dev_edid_info->StdTimings[i].YResolution)
			   && ((vid_pn_mode->rrate_x100 ==
			   	dev_edid_info->StdTimings[i].rrateX100) || is_ignore_rrate)
			   && (dev_edid_info->StdTimings[i].Valid)) {
				is_type_match = true;
				break;
			}
		}
	}

	if((is_type_match == false) && (vid_pn_mode_type & EdidMode_Establish)) {
		for(i = 0; i< 16; i++) {
			if((vid_pn_mode->x_res ==
				dev_edid_info->EstTimings[i].XResolution)
			   && (vid_pn_mode->y_res ==
			   	dev_edid_info->EstTimings[i].YResolution)
			   && ((vid_pn_mode->rrate_x100 ==
			   	dev_edid_info->EstTimings[i].rrateX100) || is_ignore_rrate)
			   && (dev_edid_info->EstTimings[i].Valid)) {
				is_type_match = true;
				break;
			}
		}
	}

	if((is_type_match == false) && (vid_pn_mode_type & ModeFlag_CEATiming)) {
		BYTE  svd_num = 0;
		extern CEA_861_Timing_Tbl 
			CEA861_FormatTimingTbl[CEA861_FORMAT_NUM];
		ULONG vdisp_end, hdisp_end, rrate_x100, is_interlace;

		/* Extend EDID spec */
		if(dev_edid_info->CEABlock_1.CEAExtBlockTag ==  0x02) {
			for(i = 0; i< CEAEXT_MAX_SVD_NUM; i++) {
				if(dev_edid_info->CEABlock_1.ShortVideoDescriptor[i].SVD == 0)
					break;

				/* cbios table start from 0, so -1 here.*/
				svd_num = 
					dev_edid_info->CEABlock_1.ShortVideoDescriptor[i].SVD - 1;

				is_interlace = CEA861_FormatTimingTbl[svd_num].Interlaced;
				vdisp_end = CEA861_FormatTimingTbl[svd_num].VDisEnd*
							(is_interlace ? 2:1);
				hdisp_end = CEA861_FormatTimingTbl[svd_num].HDisEnd;
				rrate_x100 = CEA861_FormatTimingTbl[svd_num].rRateX100;

				if((vid_pn_mode->x_res == hdisp_end)
				   && (vid_pn_mode->y_res == vdisp_end)
				   && ((vid_pn_mode->rrate_x100 == rrate_x100) 
				   	|| is_ignore_rrate)
				   && ((vid_pn_mode->is_interlaced == is_interlace) 
				   	|| is_ignore_rrate)) {
					is_type_match = true;
					break;
				}
			}
		}
	}

	return is_type_match;
}

static bool via_chrome9_check_mode_in_modeline_section(
			struct via_cb_vid_pn_mode *vid_pn_mode,
			struct drm_via_chrome9_private *p_priv,
			ULONG disp_dev,
			bool  is_ignore_rrate)
{
	struct via_cb_connector_info *dev_info = NULL;
	struct via_cb_vid_pn_mode *mode_line_res_tmp = NULL;
	bool is_type_match = false;
	ULONG i;

	if(p_priv->is_mode_line_exist == false)
		return false;

	dev_info = via_chrome9_get_device_info_pointer(p_priv, disp_dev);

	mode_line_res_tmp = dev_info->mode_line_table;

	/* also can check IsInterlaced if need here. */
	for(i = 0; i < dev_info->mode_line_num; i++) {
		if((vid_pn_mode->x_res == mode_line_res_tmp->x_res)
		   && (vid_pn_mode->y_res == mode_line_res_tmp->y_res)
		   && ((vid_pn_mode->rrate_x100 == mode_line_res_tmp->rrate_x100) 
		   || is_ignore_rrate)) {
			is_type_match = true;
			break;
		}
		mode_line_res_tmp++;
	}

	return is_type_match;
}

static bool via_chrome9_add_timing_flag_in_mode_tb(
			struct drm_via_chrome9_private *p_priv, ULONG disp_dev,
			CBIOS_EDID_STRUCTURE_DATA* edid_timing_info)
{
	struct via_cb_mode_table *mode_table = NULL;
	ULONG mode_table_num = 0;
	ULONG index = 0;
	ULONG rrate_index = 0;
	struct via_cb_vid_pn_mode vid_pn_mode = {0};

	via_chrome9_get_device_mode_table(p_priv, 
				disp_dev,  &mode_table,  &mode_table_num);

	if((NULL == mode_table) || (!mode_table_num))
		return false;

	for (index=0; index<mode_table_num; index++, mode_table++) {
		vid_pn_mode.x_res = mode_table->x_res;
		vid_pn_mode.y_res = mode_table->y_res;
		
		for (rrate_index=0; rrate_index<mode_table->rrate_cnt; rrate_index++) {
			vid_pn_mode.rrate_x100 = mode_table->rrate_x100_ptr[rrate_index];
			vid_pn_mode.is_interlaced = mode_table->is_interlaced_ptr[rrate_index];

			if(true == via_chrome9_check_mode_in_edid_section(
				&vid_pn_mode, edid_timing_info, ModeFlag_CEATiming, false)) {
				mode_table->mode_flags_ptr[rrate_index] |= ModeFlag_CEATiming;
				KMS_DEBUG("Device : 0x%x mode %dx%d@%d is CEA timing.\n", 
					disp_dev, vid_pn_mode.x_res, 
					vid_pn_mode.y_res, vid_pn_mode.rrate_x100);
			}
			if(true == via_chrome9_check_mode_in_edid_section(
				&vid_pn_mode, edid_timing_info, EdidMode_Establish, false)) {
				mode_table->mode_flags_ptr[rrate_index] |= EdidMode_Establish;
				KMS_DEBUG("Device : 0x%x mode %dx%d@%d is Est timing.\n", 
					disp_dev, vid_pn_mode.x_res, 
					vid_pn_mode.y_res, vid_pn_mode.rrate_x100);
			}
			if(true == via_chrome9_check_mode_in_edid_section(
				&vid_pn_mode, edid_timing_info, EdidMode_Standard, false)) {
				mode_table->mode_flags_ptr[rrate_index] |= EdidMode_Standard;
				KMS_DEBUG("Device : 0x%x mode %dx%d@%d is Std timing.\n", 
					disp_dev, vid_pn_mode.x_res, 
					vid_pn_mode.y_res, vid_pn_mode.rrate_x100);
			}
			if(true == via_chrome9_check_mode_in_edid_section(
				&vid_pn_mode, edid_timing_info, EdidMode_Detail, false)) {
				mode_table->mode_flags_ptr[rrate_index] |= EdidMode_Detail;
				KMS_DEBUG("Device : 0x%x mode %dx%d@%d is Dtl timing.\n", 
					disp_dev, vid_pn_mode.x_res, 
					vid_pn_mode.y_res, vid_pn_mode.rrate_x100);
			}
			if(true == via_chrome9_check_mode_in_modeline_section(
				&vid_pn_mode, p_priv, disp_dev, false)) {
				mode_table->mode_flags_ptr[rrate_index] |= ModeFlag_ModeLineTiming;
				KMS_DEBUG("Device : 0x%x mode %dx%d@%d is ModeLine timing.\n", 
					disp_dev, vid_pn_mode.x_res, 
					vid_pn_mode.y_res, vid_pn_mode.rrate_x100);
			}
		}
	}
	return true;
}

static int via_chrome9_construct_device_mode_table(
		struct drm_via_chrome9_private *p_priv, ULONG device)
{
	CBIOS_STATUS status = CBIOS_OK;
	PULONG res_buf = NULL;
	DWORD buffer_size = 0;
	ULONG buffer_size_2 = 0;
	ULONG res_num = 0;
	ULONG rrate_num = 0;
	ULONG valid_res_num = 0;
	ULONG res_index = 0;
	ULONG rrate_index = 0;
	struct via_cb_mode_table *mode_table = NULL;
	struct via_cb_mode_table *mode_table_head = NULL;
	struct via_cb_mode_table *merged_mode_table_head = NULL;
	ULONG merged_valid_res_num = 0;
	PULONG res_buf_head = NULL;
	ULONG x_total = 0, y_total = 0;
	PRefreshRateInfo rrate_info_buf = NULL;
	PRefreshRateInfo rrate_info_buf_head = NULL;
	CBIOS_STATUS cbios_status = CBIOS_OK;
	GFXTimingTable   target_timing;
	struct via_cb_connector_info *device_info = NULL;

	device_info = via_chrome9_get_device_info_pointer(p_priv, device);

	/* Get Resolution Buffer Size */
	CBiosGetDeviceResolutionsBufferSize(pcbe, device, &buffer_size);
	if (0 == buffer_size) {
		status = CBIOS_ER_NOT_YET_IMPLEMENTED;
		goto CleanUp;
	}

	res_buf = (PULONG)kmalloc (buffer_size, GFP_KERNEL);
	if (NULL == res_buf) {
		status = CBIOS_ER_NOT_YET_IMPLEMENTED;
		goto CleanUp;
	}
	res_num = buffer_size/(2*sizeof(ULONG));
	mode_table = kmalloc((res_num + RESOLUTIONNUM_FOR_CUSTOMER)*
			sizeof(struct via_cb_mode_table), GFP_KERNEL);
	if (NULL == mode_table) {
		status = CBIOS_ER_NOT_YET_IMPLEMENTED;
		goto CleanUp;
	}
	memset(mode_table, 0, (res_num + RESOLUTIONNUM_FOR_CUSTOMER)*
			sizeof(struct via_cb_mode_table));

	/* Get resolution info */
	buffer_size_2 = buffer_size;
	cbios_status = 
		CBiosGetDeviceResolutions(pcbe, device, res_buf, &buffer_size_2);
	if (CBIOS_OK != cbios_status) {
		if (CBIOS_ER_NOT_YET_IMPLEMENTED == cbios_status) {
			KMS_DEBUG("CBiosGetDeviceResolutions is not implemented"
				" for device: %d.\n", device);
			status = CBIOS_ER_NOT_YET_IMPLEMENTED;
			goto CleanUp;
		}
		else {
			KMS_DEBUG("1.cbios return status is %d\n", cbios_status);
		}
	}

	if (buffer_size != buffer_size_2)
		KMS_DEBUG("1. buffer_size %d, buffer_size_2 %d.\n", buffer_size, 
					buffer_size_2);

	mode_table_head = mode_table;
	res_buf_head = res_buf;

	/* Fill every mode info table */
	for (res_index = 0; res_index<res_num; res_index++) {
		mode_table = via_chrome9_add_resolution_to_mode_table(mode_table_head, 
					valid_res_num, *res_buf, *(res_buf+1));
		if (NULL == mode_table) {
			res_buf += 2;
			continue;
		}

		res_buf += 2;

		KMS_DEBUG("mode %dx%d add!\n",
			mode_table->x_res, mode_table->y_res);


		/* Get RefreshRate buffer size */
		cbios_status = CBiosGetRefreshRatesBufferSizeForDeviceResolution(pcbe, 
		device, mode_table->x_res, mode_table->y_res, &buffer_size);
		if (CBIOS_OK != cbios_status) {
			if (CBIOS_ER_NOT_YET_IMPLEMENTED == cbios_status) {
				KMS_DEBUG("S3gConstructDeviceModeTable():"
				"CBiosGetRefreshRatesBufferSizeForDeviceResolution is "
				"not implemented for Resolution: H:%d V: %d.\n", 
				mode_table->x_res, mode_table->y_res);
			   continue;
			} else {
				KMS_DEBUG("2.cbios return status is %d\n", cbios_status);
			}
		}
		if (0 == buffer_size)
			KMS_DEBUG("buffer_size is 0\n");

		rrate_num = buffer_size/sizeof(RefreshRateInfo);

		rrate_info_buf = (PRefreshRateInfo)kmalloc(buffer_size, GFP_KERNEL);
		mode_table->rrate_x100_ptr = 
			(PULONG)kmalloc(rrate_num*sizeof(ULONG), GFP_KERNEL);
		mode_table->x_total_size_ptr = 
			(PULONG)kmalloc(rrate_num*sizeof(ULONG), GFP_KERNEL);
		mode_table->y_total_size_ptr = 
			(PULONG)kmalloc(rrate_num*sizeof(ULONG), GFP_KERNEL);
		mode_table->is_interlaced_ptr = 
			(PULONG)kmalloc(rrate_num*sizeof(ULONG), GFP_KERNEL);
		mode_table->mode_flags_ptr = 
			(PULONG)kmalloc(rrate_num*sizeof(ULONG), GFP_KERNEL);

		if ( NULL == mode_table->rrate_x100_ptr || 
			NULL == rrate_info_buf ||
			NULL == mode_table->x_total_size_ptr || 
			NULL == mode_table->y_total_size_ptr) {
			status = CBIOS_ER_NOT_YET_IMPLEMENTED;
			goto CleanUp;
		}
		memset(rrate_info_buf, 0, buffer_size);
		memset(mode_table->rrate_x100_ptr, 0, rrate_num*sizeof(ULONG));
		memset(mode_table->x_total_size_ptr, 0, rrate_num*sizeof(ULONG));
		memset(mode_table->y_total_size_ptr, 0,  rrate_num*sizeof(ULONG));
		memset(mode_table->is_interlaced_ptr, 0, rrate_num*sizeof(ULONG));

		/* Get RefreshRate Info */
		buffer_size_2 = buffer_size;
		
		cbios_status = CBiosGetRefreshRatesForDeviceResolution(
						pcbe,  device, 
						mode_table->x_res,  mode_table->y_res, 
						rrate_info_buf,  &buffer_size_2);

		if (CBIOS_OK != cbios_status) {
			if (CBIOS_ER_NOT_YET_IMPLEMENTED == cbios_status) {
				KMS_DEBUG("CBiosGetRefreshRatesBufferSizeForDeviceResolution"
						"is not implemented for device: %d.\n", device);
				kfree(mode_table->rrate_x100_ptr);
				kfree(mode_table->x_total_size_ptr);
				kfree(mode_table->y_total_size_ptr);
				kfree(mode_table->is_interlaced_ptr);
				kfree(mode_table->mode_flags_ptr);
				kfree(rrate_info_buf);
				continue;
			} else {
				KMS_DEBUG("3.cbios return status is %d\n", cbios_status);
			}
		}

		if (buffer_size_2 == 0) {
			kfree(mode_table->rrate_x100_ptr);
			kfree(mode_table->x_total_size_ptr);
			kfree(mode_table->y_total_size_ptr);
			kfree(mode_table->is_interlaced_ptr);
			kfree(mode_table->mode_flags_ptr);
			kfree(rrate_info_buf);

			/* delete un-support resolution from mode table list. */
			if(mode_table == via_chrome9_del_res_from_mode_table(
					mode_table_head, valid_res_num,  
					mode_table->x_res, mode_table->y_res))
				continue;
		}
		else if(buffer_size_2 < buffer_size) {
			/* calculate rrate_num again if the refresh rate are filtered. */
			rrate_num = buffer_size_2 / sizeof(RefreshRateInfo);
		}
		else if(buffer_size_2 != buffer_size) {
			KMS_DEBUG("2. buffer_size %d, buffer_size_2 %d.\n", buffer_size, 
						buffer_size_2);
		}
		
		rrate_info_buf_head = rrate_info_buf;
		
		/* Fill RefreshRate/XTotalSize/YTotalSize info */
		for (rrate_index = 0; rrate_index < rrate_num; 
				rrate_index++, rrate_info_buf++) {
			if (device != ACTIVE_TYPE_HDMI &&
				device != ACTIVE_TYPE_HDMI2 &&
				device != ACTIVE_TYPE_DVI  &&
				device != ACTIVE_TYPE_DVI2  &&
				device != ACTIVE_TYPE_HDTV &&
				device != ACTIVE_TYPE_DP &&
				device != ACTIVE_TYPE_DP2) {
				if (rrate_info_buf->interlaced == TRUE)
					continue;
			}

			if (CBIOS_OK != CBIOSGetDeviceModeTargetTiming(pcbe, device, 
					mode_table->x_res,  mode_table->y_res, 
					*rrate_info_buf, &target_timing)) {
				x_total = mode_table->x_res;
				y_total = mode_table->y_res;
			} else {
				x_total = target_timing.HTotal;
				y_total = target_timing.VTotal;
			}

			/* sort the RefreshRate ascending */
			via_chrome9_add_rrate_to_mode_table(mode_table, rrate_info_buf, 
						x_total, y_total, ModeFlag_CbiosSupport);
		}
		kfree(rrate_info_buf_head);

		if (0 == mode_table->rrate_cnt) {
			kfree(mode_table->rrate_x100_ptr);
			mode_table->rrate_x100_ptr = NULL;
			kfree(mode_table->x_total_size_ptr);
			mode_table->x_total_size_ptr = NULL;
			kfree(mode_table->y_total_size_ptr);
			mode_table->y_total_size_ptr = NULL;
			kfree(mode_table->is_interlaced_ptr);
			mode_table->is_interlaced_ptr = NULL;
			kfree(mode_table->mode_flags_ptr);
			mode_table->mode_flags_ptr = NULL;
			continue;
		}

		valid_res_num++;
	}

	if (0 == valid_res_num)
		goto CleanUp;

	merged_mode_table_head = mode_table_head;
	merged_valid_res_num = valid_res_num;

	if(device_info) {
		device_info->modes_table = merged_mode_table_head;
		device_info->used_mode_table_num = merged_valid_res_num;
	}

	{
		PCBIOS_EDID_STRUCTURE_DATA pDevEdidInfo = NULL;
		pDevEdidInfo = via_chrome9_get_parsed_device_edid_info(p_priv, device);
		via_chrome9_add_timing_flag_in_mode_tb(p_priv, device, pDevEdidInfo);
	}

CleanUp:
	kfree(res_buf_head);
	res_buf_head = NULL;

	if (CBIOS_OK != status)
		via_chrome9_free_mode_table(&mode_table_head, valid_res_num);

	return status;   
}

static bool via_chrome9_fake_establish_timing_section(
		unsigned int device,struct via_cb_edid_block_data *edid_info, 
		unsigned int fake_res, unsigned int fake_rrate)
{
	if((fake_res == RES_720_400) && (fake_rrate == 70))
		edid_info->est_timing[0] |= BIT7;
	else if((fake_res == RES_720_400) && (fake_rrate == 88))
		edid_info->est_timing[0] |= BIT6;
	else if((fake_res == RES_640_480) && (fake_rrate == 60))
		edid_info->est_timing[0] |= BIT5;
	else if((fake_res == RES_640_480) && (fake_rrate == 67))
		edid_info->est_timing[0] |= BIT4;
	else if((fake_res == RES_640_480) && (fake_rrate == 72))
		edid_info->est_timing[0] |= BIT3;
	else if((fake_res == RES_640_480) && (fake_rrate == 75))
		edid_info->est_timing[0] |= BIT2;
	else if((fake_res == RES_800_600) && (fake_rrate == 56))
		edid_info->est_timing[0] |= BIT1;
	else if((fake_res == RES_800_600) && (fake_rrate == 60))
		edid_info->est_timing[0] |= BIT0;
	else if((fake_res == RES_800_600) && (fake_rrate == 72))
		edid_info->est_timing[1] |= BIT7;
	else if((fake_res == RES_800_600) && (fake_rrate == 75))
		edid_info->est_timing[1] |= BIT6;
	else if((fake_res == RES_832_624) && (fake_rrate == 75))
		edid_info->est_timing[1] |= BIT5;
	else if((fake_res == RES_1024_768) && (fake_rrate == 87))
		edid_info->est_timing[1] |= BIT4;
	else if((fake_res == RES_1024_768) && (fake_rrate == 60))
		edid_info->est_timing[1] |= BIT3;
	else if((fake_res == RES_1024_768) && (fake_rrate == 70))
		edid_info->est_timing[1] |= BIT2;
	else if((fake_res == RES_1024_768) && (fake_rrate == 75))
		edid_info->est_timing[1] |= BIT1;
	else if((fake_res == RES_1280_1024) && (fake_rrate == 75))
		edid_info->est_timing[1] |= BIT0;
	else if((fake_res == RES_1152_864) && (fake_rrate == 75))
		edid_info->est_timing[2] |= BIT7;
	else
		/* 
		 * if none of above is match, return false, means fake in
		 * establish fail, try to fake in other edid section.
		 */
		return false; 

	return true;
}


static bool via_chrome9_fake_standard_timing_section(
		unsigned int device,struct via_cb_edid_block_data *edid_info, 
		unsigned int res, unsigned int fake_rrate)
{
	PUCHAR standard_blk;
	DWORD width;
	DWORD height;
	DWORD blk_index = 0;
	bool  is_find_empty_blk = false;
	bool  is_meet_fake_requirement = false;
	unsigned int tmp_ratio_rate = 0;

	width = (res >> 16) & 0xFFFF;
	height = res & 0xFFFF;

	/*
	 * standard timing limitation
	 *  1. width can be align by 8
	 *  2. aspect ratio is 16:10 or 4:3 or 5:4 or 16:9
	 *  3. refreshrate between 60-123 hz
	 */
	if(((width & 0x07) == 0) && (width > 256) && (width < 2288) 
			&& (fake_rrate >= 60) && (fake_rrate <= 123)) {
		if((width * 10) ==(height * 16)) {
			tmp_ratio_rate = (0 | (fake_rrate - 60));
			is_meet_fake_requirement = true;
		}
		if((width * 3) == (height * 4)) {
			tmp_ratio_rate = (BIT6 | (fake_rrate - 60));
			is_meet_fake_requirement = true;
		}
		if((width * 4) == (height * 5)) {
			tmp_ratio_rate = (BIT7 | (fake_rrate - 60));
			is_meet_fake_requirement = true;
		}
		if((width * 9) == (height * 16)) {
			tmp_ratio_rate = ((BIT7|BIT6) | (fake_rrate - 60));
			is_meet_fake_requirement = true;
		}
	}

	if (!is_meet_fake_requirement)
		return false;

	/* if meet fake requirement, we find an empty slot to put this data */
	for(blk_index = 0; blk_index < 8; blk_index ++) {
		/* standard timing each block 2 Bytes */
		standard_blk = edid_info->std_timing_ids + blk_index * 2;

		if((standard_blk[0] == 0x01) && (standard_blk[1] == 0x01))  {   
			is_find_empty_blk = true;
			break;
		}
	}

	if (!is_find_empty_blk)
		return false;

	/* edid spec defined */
	standard_blk[0] = (UCHAR)(width / 8 - 31);
	standard_blk[1] = (UCHAR)tmp_ratio_rate;

	return true;
}

static bool via_chrome9_fake_detail_timing_section(unsigned int device,
		struct via_cb_edid_block_data *edid_info, unsigned int device_size, 
		unsigned int fake_rrate, bool is_interlaced)
{
	PUCHAR detail_blk;
	DWORD display_width;
	DWORD display_height;
	DWORD h_blank;
	DWORD v_blank;
	DWORD dot_clock;
	DWORD blk_index = 0;
	bool  is_find_empty_blk = false;
	GFXTimingTable target_timing = {0};
	RefreshRateInfo rrate_info = {0};
	unsigned int hsync_offset = 0;
	unsigned int  vsync_offset = 0;
	unsigned int  hsync_pulse_width = 0;
	unsigned int  vsync_pulse_width = 0;
	
	for(blk_index = 0; blk_index < 4; blk_index ++) {
		/* detail timing each block 18 2 Bytes */
		detail_blk = edid_info->detail_timing + blk_index * 18;

		if((detail_blk[0] == 0) && (detail_blk[2] == 0) && (detail_blk[3] == 0))  {
			/* take it for granted that this slot is empty */
			is_find_empty_blk = true;
			break;
		}
	}

	if (!is_find_empty_blk)
		return false;

	display_width = (device_size >> 16) & 0xFFFF;
	display_height = device_size & 0xFFFF;
	/* can be set what ever you like, here we use /4 */
	h_blank = display_width>>2;
	v_blank = display_height>>2;

	rrate_info.rRateX100 = fake_rrate;
	rrate_info.interlaced = (is_interlaced == true)?1:0;
	if (CBIOS_OK ==CBIOSGetDeviceModeTargetTiming(pcbe, device, 
				display_width, display_height, rrate_info, &target_timing)) {
		h_blank = target_timing.HTotal - target_timing.HBlankStart;
		v_blank = target_timing.VTotal - target_timing.VBlankStart;

		hsync_offset = target_timing.HSyncStart - target_timing.HBlankStart;
		vsync_offset = target_timing.VSyncStart - target_timing.VBlankStart;

		hsync_pulse_width = target_timing.HSyncEnd - target_timing.HSyncStart;
		vsync_pulse_width = target_timing.VSyncEnd - target_timing.VSyncStart;

	} else {
		KMS_DEBUG("CBIOSGetDeviceModeTargetTiming fail!!!\n");
		return false;
	}

	/*
	 * scale the dot clock for saving
	 * add 10000Hz just to make sure that we round up a little
	 */
	dot_clock =
		(display_width + h_blank) * (display_height + v_blank) * fake_rrate;
	if(fake_rrate != 60)
		dot_clock = (dot_clock / 10000) + 1; 
	else
		/* CBIOS will handle 59.99 to 60HZ, so add 1 for 60HZ is meaningless */
		dot_clock = (dot_clock / 10000);

	/* pixel clock LSB */
	*(detail_blk + 0) = (BYTE)(dot_clock & 0xff);
	/* pixel clock MSB */
	*(detail_blk + 1) = (BYTE)((dot_clock >> 8) & 0xff);
	/* Horizontal Pixels lsb */
	*(detail_blk + 2) = (BYTE)(display_width & 0xff);
	/* Horizontal blanking LSB */
	*(detail_blk + 3) = (BYTE)(h_blank &0xff);
	/* upper 4 bits Horizontal active, lower 4 bits Horizontal blanking */
	*(detail_blk + 4) = 
		(BYTE)(((display_width >> 4) & 0xf0) + ((h_blank >> 8) & 0x0f)); 
	/* Vertical active */
	*(detail_blk + 5) = (BYTE)(display_height & 0xff);
	/* Vertical blanking */
	*(detail_blk + 6) = (BYTE)(v_blank &0xff);

	/* upper 4 bits Vertical active, lower 4 bits Vertical blanking */
	*(detail_blk + 7) = 
		(BYTE)(((display_height >> 4) & 0xf0) + ((v_blank >> 8) & 0x0f));
	/* Horizontal Sync. Offset */
	*(detail_blk + 8) = (BYTE)(hsync_offset & 0xFF);
	/* Horizontal sync pulse width */
	*(detail_blk + 9) = (BYTE)(hsync_pulse_width & 0xFF);
	/* Vertical Sync Offset/Width */
	*(detail_blk + 10) =
		(BYTE)(((vsync_offset << 4) & 0xf0) + (vsync_pulse_width & 0x0f));
	*(detail_blk + 11) = (BYTE)(((hsync_offset >>2) & 0xc0) + 
			((hsync_pulse_width >>4) & 0x30) + ((vsync_offset >>2)& 0x0c) + 
			((vsync_pulse_width >>4) & 0x03));

	/* 
	 * this needs to be the ratio of Width/Height normally 4:3
	 * this is true for all the panels we support today
	 * but should be watched
	 * Non 4/3 panels please check 
	 */

	if ((device_size == RES_1280_768)||(device_size == RES_1280_720)||
		(device_size == RES_1920_1080)) {
		/* Horizontal Image Size */
		*(detail_blk + 12) = 50;
		/* Vertical Image Size */
		*(detail_blk + 13) = 30;
	}  else {
		/* Horizontal Image Size */
		*(detail_blk + 12) = 40;
		/* Vertical Image Size */
		*(detail_blk + 13) = 30;
	}

	return (blk_index != 0);
}

static bool via_chrome9_fake_detail_description_section(
		unsigned int device, struct via_cb_edid_block_data *edid_info, 
		PUCHAR description_data)
{
	PUCHAR detail_blk;
	DWORD blk_index = 0;
	bool is_find_empty_blk = false;
	unsigned int i;

	for(blk_index = 0; blk_index < 4; blk_index ++) {
		/* detail timing each block 18 UCHAR */
		detail_blk = edid_info->detail_timing + blk_index * 18;

		/* if this 3 uchar == 0, we take it for granted that this slot is empty. */
		if((detail_blk[0] == 0) && (detail_blk[2] == 0) && (detail_blk[3] == 0))  {
			is_find_empty_blk = true;
			break;
		}
	}

	if (!is_find_empty_blk)
		return false;

	detail_blk[0] = 0;
	detail_blk[1] = 0;
	detail_blk[2] = 0;
	/* ASCII  string */
	detail_blk[3] = 0xFC;
	detail_blk[4] = 0;

	for(i = 0; i < 13; i++) {
		detail_blk[5 + i] = description_data[i];
		if(description_data[i] == '\0') {
			break;
		}
	}

	return true;
}

unsigned int via_chrome9_construct_fake_edid_info (  
		struct drm_via_chrome9_private *p_priv,  
		struct via_cb_edid_block_data *edid_info,
		unsigned int data_length, unsigned int device_type, 
		bool  is_need_Fake_timing)
{  
	int ck_sum=0, x;
	DWORD display_width;
	DWORD display_height;
	DWORD dev_size = 0xFFFFFFFF;
	UINT8 serial_port;
	UCHAR dev_description[16] = {0};
	UINT8 tv_rRate;

	dev_size = 0;

	KMS_DEBUG("fake edid for device 0x%x\n", device_type);

	if (device_type == ACTIVE_TYPE_PANEL) {
		CBiosGetDisplayDeviceInformation(pcbe, 
			ACTIVE_TYPE_PANEL, &display_width, &display_height, &serial_port);
		dev_size = MAKE_RES(display_width, display_height);
		strcpy(dev_description, "DigitalPanel");
	} else if (device_type == ACTIVE_TYPE_PANEL2) {
		CBiosGetDisplayDeviceInformation(pcbe, 
			ACTIVE_TYPE_PANEL2, &display_width, &display_height, &serial_port);
		dev_size = MAKE_RES(display_width, display_height);
		strcpy(dev_description, "Digital Panel");
	} else if (device_type == ACTIVE_TYPE_TV) {
		CBiosGetDisplayDeviceInformation(pcbe, 
			ACTIVE_TYPE_TV, &display_width, &display_height, &serial_port);
		dev_size = MAKE_RES(display_width, display_height);
		strcpy(dev_description, "Generic TV");
	} else if (device_type == ACTIVE_TYPE_HDTV) {
		/*  HDTV, set to maximum resolution */
		CBiosGetDisplayDeviceInformation(pcbe, 
			ACTIVE_TYPE_HDTV, &display_width, &display_height, &serial_port);
		dev_size = MAKE_RES(display_width, display_height);
		strcpy(dev_description, "Generic HDTV");
	} else if (device_type == ACTIVE_TYPE_CRT) {
		strcpy(dev_description, "S3FakeEdidCRT");
	} else if (device_type == ACTIVE_TYPE_CRT2) {
		strcpy(dev_description, "S3FakeEdidCRT");
	} else if (device_type == ACTIVE_TYPE_DVI) {
		strcpy(dev_description, "S3FakeEdidDVI");
	} else if (device_type == ACTIVE_TYPE_DVI2) {
		strcpy(dev_description, "S3FakeEdidDVI");
	} else if (device_type == ACTIVE_TYPE_DP) {
		strcpy(dev_description, "S3FakeEdidDP");
	} else if (device_type == ACTIVE_TYPE_DP2) {
		strcpy(dev_description, "S3FakeEdidDP2");
	} else if (device_type == ACTIVE_TYPE_HDMI) {
		strcpy(dev_description, "FakeEdidHDMI");
	} else if (device_type == ACTIVE_TYPE_HDMI2) {
		strcpy(dev_description, "FakeEdidHDMI2");
	}

	if (data_length < EDID_BLOCK_SIZE)
		return 0;

	/* check to see if a device is attached, if it is not then return  */
	/* an error and no EDID info */
	if (dev_size == 0xffffffff)
		/* no panel attached */
		return 0;  

	memset(edid_info, 0, data_length);

	/*   Note that if field is to be "set" to 0, the assignment is commented out, */
	/*   but left in for documentation.  All fields were initialized to 0. */

	/* edid_info->Header[0] = 0; */
	edid_info->header[1] = 0xff;
	edid_info->header[2] = 0xff;
	edid_info->header[3] = 0xff;
	edid_info->header[4] = 0xff;
	edid_info->header[5] = 0xff;
	edid_info->header[6] = 0xff;
	/* edid_info->Header[7] = 0; */

	/*  Vendor/Product ID: 10 bytes - Offset 08h-11h */
	if ((device_type == ACTIVE_TYPE_PANEL) ||
		(device_type == ACTIVE_TYPE_PANEL2)) {
		/*   ID Manufacturer Name */
		/*   Compressed ASCII.  Expands to 'VIA' */
		edid_info->vendor_pid[0] = 0x59;
		edid_info->vendor_pid[1] = 0x21;

		switch (dev_size){
		case RES_640_480:
			edid_info->vendor_pid[2] = 0x01;
			break;
		case RES_800_600:
			edid_info->vendor_pid[2] = 0x02;
			break;
		case RES_1024_768:
			edid_info->vendor_pid[2] = 0x03;
			break;
		case RES_1152_864:
			edid_info->vendor_pid[2] = 0x04;
			break;
		case RES_1280_768:
			/* not 4/3 aspect ratio! */
			/* see special handling below */
			edid_info->vendor_pid[2] = 0x00;
			break;
		case RES_1280_800:
			/* not 4/3 aspect ratio! */
			/* see special handling below */
			edid_info->vendor_pid[2] = 0x00; 
			break;
		case RES_1280_1024:
			edid_info->vendor_pid[2] = 0x05;
			break;
		case RES_1366_768:
			edid_info->vendor_pid[2] = 0x00;
			break;
		case RES_1440_900:
			edid_info->vendor_pid[2] = 0x00;
			break;
		case RES_1400_1050:
			edid_info->vendor_pid[2] = 0x00;
			break;
		case RES_1600_1200:
			edid_info->vendor_pid[2] = 0x06;
			break;
		case RES_1680_1050:
			edid_info->vendor_pid[2] = 0x00;
			break;
		case RES_1920_1200:
			edid_info->vendor_pid[2] = 0x00;
			break;
		default:
			/*  Vista don't like the unknow bit. Make it just display plug and play monitor */
			edid_info->vendor_pid[2] = 0x00;
		}

	   /*  ID Product Code */
	   /*  edid_info->VendorPID[3] = 0x00; */
	} else if (device_type == ACTIVE_TYPE_TV) {
		/*   ID Manufacturer Name */
		/*   Compressed ASCII.  Expands to 'VIA' */
		edid_info->vendor_pid[0] = 0x59;
		edid_info->vendor_pid[1] = 0x21;

		/*   ID Product Code */
		edid_info->vendor_pid[2] = 0xFE;
		edid_info->vendor_pid[3] = 0x09;

	} else if (device_type == ACTIVE_TYPE_HDTV) {
		/*   ID Manufacturer Name */
		/*   Compressed ASCII.  Expands to 'VIA' */
		edid_info->vendor_pid[0] = 0x59;
		edid_info->vendor_pid[1] = 0x21;

		/*   ID Product Code */
		edid_info->vendor_pid[2] = 0xFF;
		edid_info->vendor_pid[3] = 0x09;
	}else if (device_type == ACTIVE_TYPE_HDMI) {
		/*   ID Manufacturer Name */
		/*   Compressed ASCII.  Expands to 'VIA' */
		edid_info->vendor_pid[0] = 0x59;
		edid_info->vendor_pid[1] = 0x21;

		/*   ID Product Code */
		edid_info->vendor_pid[2] = 0xFF;
		edid_info->vendor_pid[3] = 0x09;
	} else if (device_type == ACTIVE_TYPE_HDMI2) {
		/*   ID Manufacturer Name */
		/*   Compressed ASCII.  Expands to 'VIA' */
		edid_info->vendor_pid[0] = 0x59;
		edid_info->vendor_pid[1] = 0x21;

		/*   ID Product Code */
		edid_info->vendor_pid[2] = 0xFF;
		edid_info->vendor_pid[3] = 0x09;
	}
   
	/*   ID Serial Number (4 bytes) */
	/*  edid_info->VendorPID[4] = 0x00; */
	/*  edid_info->VendorPID[5] = 0x00; */
	/*  edid_info->VendorPID[6] = 0x00; */
	/*  edid_info->VendorPID[7] = 0x00; */

	/*   Week and Year (2 bytes) */
	/*  week of mfg: 1 (0 - 53, 0 means unused) */
	edid_info->vendor_pid[8] = 1;
	/*  year of mfg: 1990 + xx = year. */
	edid_info->vendor_pid[9] = 10;

	/*   EDID Structure Version/Revision : 2 bytes - Offset 12h-13h */
	/*  must be 1 (EDID version 1) */
	edid_info->edid_version[0] = 1;
	/*  Revision 3 */
	edid_info->edid_version[1] = 3;

	/* Display Parameters and Features : 5 bytes - Offset 14h-18h */
	if((device_type==ACTIVE_TYPE_PANEL) || (device_type == ACTIVE_TYPE_PANEL2) 
		|| (device_type==ACTIVE_TYPE_HDTV) || (device_type==ACTIVE_TYPE_HDMI) 
		|| (device_type==ACTIVE_TYPE_HDMI2) || (device_type==ACTIVE_TYPE_DVI)
		|| (device_type==ACTIVE_TYPE_DVI2))
		/*  signal-related : Digital */
		edid_info->display_par[0] = 0x80;
	else
		/*  signal-related : Analog */
		edid_info->display_par[0] = 0x00;

	if ((dev_size == RES_1280_768)||(dev_size == RES_1280_720)
		 ||(dev_size == RES_1280_800)||(dev_size == RES_1920_1080)) {
		/*  Max. Horizontal Image Size, cm */
		edid_info->display_par[1] = 50;
		/*  Max. Vertical Image Size, cm */
		edid_info->display_par[2] = 30;
	} else {
		/*  Max. Horizontal Image Size, cm  */
		edid_info->display_par[1] = 40;
		/*  Max. Vertical Image Size, cm  */
		edid_info->display_par[2] = 30;
	}

	/* Display Transfer (gamma)  */
	edid_info->display_par[3] = 0;

	/*  Bit[7] Standby */
	/*  Bit[6] Suspend,   */
	/*  Bit[5] Active Off  */
	/*  Bit[4:3] = 01 : RGB color display  */
	/*  Bit[1] = 1: Preferred Timing is indicated in the first detailed timing block. */
	edid_info->display_par[4] = 0xEA;

	/*   Color Characteristics : 10 bytes - Offset 19h-22h  */
	edid_info->color_characters[0] = 0x78;
	edid_info->color_characters[1] = 0xA0;
	edid_info->color_characters[2] = 0x56;
	edid_info->color_characters[3] = 0x48;
	edid_info->color_characters[4] = 0x9A;
	edid_info->color_characters[5] = 0x26;
	edid_info->color_characters[6] = 0x12;
	edid_info->color_characters[7] = 0x48;
	edid_info->color_characters[8] = 0x4c;
	edid_info->color_characters[9] = 0xff;

	/* if not use, clear standard timing to 0, 1, 0, 1......  */
	{
		unsigned int i;
		for(i = 0; i< 16; i ++)
			edid_info->std_timing_ids[i] = 0x01;
	}

	if(is_need_Fake_timing == true) {
		if(device_type == ACTIVE_TYPE_TV) {
			// tv_regional_standard get from pcbe->sPad_8.TV_Type
			switch(tv_regional_standard){
			case PAL:
			case PALN:
			case PALNc:
			case PALI:
			case PALD:
			    // only support one refresh rate of 50Hz
			    tv_rRate = 50; 
			    break;
			case NTSC:
			case NTSCJP:
			case PALM:                      // PALM is base on NTSC to adjust
			default:
			    // only support one refresh rate of 60Hz
			    tv_rRate = 60; 
			    break;
			}
			
			/* prefer mode */
			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info, RES_1024_768, tv_rRate, false);
			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info, RES_800_600, tv_rRate, false);
			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info, RES_720_480, tv_rRate, false);
			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info, RES_640_480, tv_rRate, false);
		} else if(device_type == ACTIVE_TYPE_HDTV) {
			/*  800*600@60 + 640*480@60  */
			edid_info->est_timing[0]=0x21; 
			/*  1024*768@60  */
			edid_info->est_timing[1]=0x08; 
			edid_info->est_timing[2]=0x00;

			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info,  RES_1280_720, 60, false);

			if(hdtv_1080i_enabled){
				/*  800*600@60 + 640*480@60  */
				edid_info->est_timing[0]=0x21; 
				/*  1024*768@60  */
				edid_info->est_timing[1]=0x08; 
				via_chrome9_fake_standard_timing_section(device_type, 
					edid_info, RES_1280_720, 60);
				via_chrome9_fake_detail_timing_section(device_type, 
					edid_info,  RES_1920_1080, 50, true);
			}
		} else if((device_type == ACTIVE_TYPE_PANEL) || 
				(device_type == ACTIVE_TYPE_PANEL2)) {
			/* this is prefer mode */
			via_chrome9_fake_detail_timing_section(device_type, 
					edid_info, dev_size, 60, false); 
		} else {
			/* if no key or key no data, put on 640*480@60 and 800*600@60  */
			via_chrome9_fake_establish_timing_section(device_type, 
					edid_info, RES_640_480, 60);
			via_chrome9_fake_establish_timing_section(device_type, 
					edid_info, RES_1024_768, 60);
			via_chrome9_fake_standard_timing_section(device_type, 
					edid_info, RES_1280_1024, 60);
			 /* this is prefer mode */
			via_chrome9_fake_detail_timing_section(device_type, 
				edid_info, RES_800_600, 60, false);
		}
	}

	via_chrome9_fake_detail_description_section(device_type, 
			edid_info, dev_description);

	if(data_length>=EDID_BLOCK_SIZE)
		for (x=0; x<EDID_BLOCK_SIZE; x++)
			ck_sum += ((UCHAR *)edid_info)[x];

	if (0x00 != (ck_sum & 0xFF))
		edid_info->ck_sum = (UCHAR)(0x100 - (ck_sum & 0xFF));

	return EDID_BLOCK_SIZE;
}


char* via_chrome9_connector_get_conf_edid_device(unsigned int device)
{
	char* conf_edid_device;

	switch(device) {
	case ACTIVE_TYPE_CRT:
		conf_edid_device = "crt_fake_edid";
		break;
	case ACTIVE_TYPE_CRT2:
		conf_edid_device = "crt2_fake_edid";
		break;
	case ACTIVE_TYPE_PANEL:
		conf_edid_device = "lcd_fake_edid";
		break;
	case ACTIVE_TYPE_DVI:
		conf_edid_device = "dvi_fake_edid";
		break;
	case ACTIVE_TYPE_DVI2:
		conf_edid_device = "dvi2_fake_edid";
		break;
	case ACTIVE_TYPE_DP:
		conf_edid_device = "dp_fake_edid";
		break;
	case ACTIVE_TYPE_DP2:
		conf_edid_device = "dp2_fake_edid";
		break;
	case ACTIVE_TYPE_TV:
		conf_edid_device = "tv_fake_edid";
		break;
	case ACTIVE_TYPE_HDMI:
		conf_edid_device = "hdmi_fake_edid";
		break;
	case ACTIVE_TYPE_HDMI2:
		conf_edid_device = "hdmi2_fake_edid";
		break;
	case ACTIVE_TYPE_PANEL2:
		conf_edid_device = "lcd2_fake_edid";
		break;
	default:
		conf_edid_device = NULL;
		break;
	}

	return conf_edid_device;
}

struct edid * via_chrome9_connector_get_edid(
	struct drm_connector *connector, unsigned int connector_id)
{
	struct edid *edid;
	CBIOS_PARAM_GET_EDID cb_get_edid;
	unsigned int device = 0;
	struct drm_device *dev = connector->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	edid = kmalloc(128 * (4 + 1), GFP_KERNEL);
	if (edid == NULL) {
		KMS_DEBUG("Failed to allocate EDID\n\n");
		return NULL;
	}
	memset(edid, 0, 128 * (4 + 1));

	device = via_chrome9_connector_to_cbios_device(connector_id);

	cb_get_edid.EdidBuffer = (BYTE*)edid;
	cb_get_edid.DisplayDeviceDWord = device;
	cb_get_edid.EdidBufferLen = 256;
	cb_get_edid.type = 0; 

	if (CBIOS_OK == CBiosGetEdid(pcbe, &cb_get_edid)) {
		KMS_DEBUG("device 0x%x EDID successful get.\n", device);
		connector->display_info.raw_edid = (char *)edid;
	} else {
		KMS_DEBUG("device 0x%x EDID get fail. construct fake edid.\n", device);
		{
			PCHAR conf_edid_device_name=via_chrome9_connector_get_conf_edid_device(device);
			PCHAR ConfFile = "/etc/X11/via_kernel.conf";  
			UINT8 temp_string[3] ;
			UINT32 test_ed=0;
			UINT32 conf_edid_size=0;
			UINT8 device_fake_edid[520]={0};
			UINT32 k=0;
		                
			/* get fake edid from configure file */
			if(CBIOS_OK == CBiosGetEdidConfInfo(pcbe, ConfFile, conf_edid_device_name, device_fake_edid)){
				temp_string[2]='\0';
				if(strlen(device_fake_edid)>=512)
					conf_edid_size=256;
				else
					conf_edid_size=128;

				for(k=0;k<conf_edid_size;k++ ){
					strncpy( temp_string, device_fake_edid+k*2, 2);
					sscanf(temp_string, "%2x", &test_ed);
					device_fake_edid[k]=(UINT8)test_ed;
				}
				memcpy(edid, device_fake_edid, conf_edid_size);
				connector->display_info.raw_edid = (char *)edid;	
				KMS_DEBUG("%s get configure edid done!\n", conf_edid_device_name);

				cb_get_edid.EdidBufferLen = conf_edid_size;
				CBiosSetEdid(pcbe, &cb_get_edid);
			} else {/* get fake edid from hard code */
				via_chrome9_construct_fake_edid_info(p_priv,
					(struct via_cb_edid_block_data *)(cb_get_edid.EdidBuffer),
					EDID_BLOCK_SIZE, device, true);
				connector->display_info.raw_edid = (char *)edid;
			}
		}
	}

	return edid;
}

void via_chrome9_get_child_descriptor_by_device(
	struct drm_via_chrome9_private *p_priv, ULONG device)
{
	CBIOS_PARAM_GET_EDID cb_get_edid;
	ULONG got_edid_status = EdidGotState_None;
	ULONG edid_preferred_mode = 0;
	ULONG supported_timing_type;
	PCBIOS_EDID_STRUCTURE_DATA parsed_edid_info;
	struct via_cb_connector_info *dev_info = NULL;

	/* get edid buffer */
	dev_info = via_chrome9_get_device_info_pointer(p_priv, device);
	if(dev_info)
		cb_get_edid.EdidBuffer = dev_info->edid_info;

	cb_get_edid.DisplayDeviceDWord = device;
	cb_get_edid.EdidBufferLen = 256;

	got_edid_status = EdidGotState_None;
	if (CBIOS_OK == CBiosGetEdid(pcbe, &cb_get_edid)) {
		got_edid_status = EdidGotState_Correct;
		KMS_DEBUG("device 0x%x EDID successful get.\n", device);
	} else {
		got_edid_status = EdidGotState_None;
	}

	if(got_edid_status == EdidGotState_None) {
		unsigned int k = 0;
		UINT8 device_fake_edid[520]={0};
		UINT8 temp_string[3] ;
		UINT32 test_ed=0;
		UINT32 conf_edid_size=0;
		PCHAR conf_edid_device_name=via_chrome9_connector_get_conf_edid_device(device);
		PCHAR ConfFile = "/etc/X11/via_kernel.conf";  
		
		/* get fake edid from configure file */
		if(CBIOS_OK == CBiosGetEdidConfInfo(pcbe, ConfFile, conf_edid_device_name, device_fake_edid)){
			temp_string[2]='\0';
			if(strlen(device_fake_edid)>=512)
				conf_edid_size=256;
			else
				conf_edid_size=128;

			for(k=0;k<conf_edid_size;k++ ){
				strncpy( temp_string, device_fake_edid+k*2, 2);
				sscanf(temp_string, "%2x", &test_ed);
				device_fake_edid[k]=(UINT8)test_ed;
			}
			memcpy(cb_get_edid.EdidBuffer, device_fake_edid, conf_edid_size);
			KMS_DEBUG("%s get conf edid done!\n", conf_edid_device_name);
		} else {/* get fake edid from hard code */
			KMS_DEBUG("device 0x%x EDID get fail. construct fake edid.\n", device);
			via_chrome9_construct_fake_edid_info(p_priv,
				(struct via_cb_edid_block_data *)(cb_get_edid.EdidBuffer),
				EDID_BLOCK_SIZE, device, true);
		}
	}

	if(dev_info)
		dev_info->got_edid_status = got_edid_status;

	parsed_edid_info = 
		via_chrome9_get_parsed_device_edid_info(p_priv, device);
	CBiosParserEdid(pcbe, cb_get_edid.EdidBuffer, 256, parsed_edid_info);

	switch(device) {
	case ACTIVE_TYPE_CRT:
	case ACTIVE_TYPE_CRT2:
	case ACTIVE_TYPE_DVI:
	case ACTIVE_TYPE_DVI2:  
		if((CBIOS_OK == CBiosGetSupDeviceTimingType(pcbe, 
				device, &supported_timing_type)) &&
				(edid_preferred_mode & supported_timing_type)) {
			dev_info->edid_preferred_mode = edid_preferred_mode;
			/* Notify CBIOS the device's timing type */
			CBiosSetDeviceTimingType(pcbe, device, edid_preferred_mode);
		}
		break;
	case ACTIVE_TYPE_DP:
	case ACTIVE_TYPE_DP2:
	case ACTIVE_TYPE_HDMI:
	case ACTIVE_TYPE_HDMI2:
		edid_preferred_mode = EDID_ENABLEDEVSCALING_TIMING_TYPE;
		dev_info->edid_preferred_mode = edid_preferred_mode;
		CBiosSetDeviceTimingType(pcbe, device, edid_preferred_mode);
		break;
	case ACTIVE_TYPE_PANEL:
	case ACTIVE_TYPE_PANEL2:
	case ACTIVE_TYPE_TV:
	case ACTIVE_TYPE_HDTV:
	default:
		break;
	}

	/* construct mode table, some device we not care edid. */
	via_chrome9_construct_device_mode_table(p_priv, device);
}

/*
 * For ad9389b or ad9889b, 
 * do not select 800x600 timing as target timing.
 */
static bool via_chrome9_is_ad9389_8x6(int device, 
		struct drm_display_mode *mode)
{
	u8 tx_type = 0;

	if ((ACTIVE_TYPE_HDMI == device) || (ACTIVE_TYPE_HDMI2 == device)) {
		/* get HDMI associated tx_type */
		if (cbGetDITXtype(pcbe, &tx_type, device) == FALSE) {
			/* KMS_DEBUG("get transmiter type failed!\n"); */
			return false;
		}
		if (tx_type == AD9389B) {
			if ((mode->hdisplay == 800) && (mode->vdisplay == 600)) {
				return true;
			}
		}
	}
	return false;
}

/*
 * get current iga support upscale or not.
 * if get pass, reture true, or will return false.
 */
static bool via_chrome9_get_mode_select_method(
		struct drm_encoder *encoder,  enum mode_select  *method,
		int device,  struct drm_display_mode *mode)
{
	bool is_ad9389b_8x6 = false;

	if (NULL == mode) {
		return false;
	}

	/* 
	 * no matter 410 or 409/353:
	 * if ad9389b/ad9889b 800x600 mode, 
	 * think it not support upscale.
	 */
	is_ad9389b_8x6 = via_chrome9_is_ad9389_8x6(device, mode);
	if (true == is_ad9389b_8x6) {
		*method = MODE_BIGGER;
		return true;
	}
	return true;
}

/**
 * return:
 * true  :  find mode in list HxV bigger than source mode
 *                and refresh rate(and interlace) are the same
 * false :  couldn't find.
 * 
 * set selection mechanism:
 * if LCD, find in EDID detail only, non-EDID LCD also has faked edid and detail timing.
 * else monitors, if has faked edid, 
 * find in xorg.conf Modeline first preferred, faked edid secondary.
 *				if has real edid, find in edid mode list only.
 */
static bool via_chrome9_find_popular_mode_from_list(
	ULONG  device, struct via_cb_vid_pn_mode source_mode,
	bool is_need_equal, ULONG mode_table_num,
	struct via_cb_mode_table *mode_table,
	struct via_cb_vid_pn_mode *find_best_vid_pn_mode,
	struct via_cb_connector_info *dev_info)
{
	ULONG  mode_table_index = 0;
	ULONG  rrate_index = 0;
	ULONG  find_res_target_rule = 0;
	bool  is_find = false, is_faked_edid_need_re_check = false;

	if (((device == ACTIVE_TYPE_PANEL) || (device == ACTIVE_TYPE_PANEL2))) {
		find_res_target_rule = EdidMode_Detail;
	} else if ((EdidGotState_None | EdidGotState_Wrong) & 
			dev_info->got_edid_status) {
		/*
		 *  if edid is faked, first we will select ModeLine as preferred
		 *      instead of to select faked edid modes. 
		 */
		find_res_target_rule = ModeFlag_ModeLineTiming;
		is_faked_edid_need_re_check = true;
	} else {
		/*
		 * we select in edid modes 
		 * we only select in edid modes because they are safety,
		 */
		find_res_target_rule = EdidMode_All;
	}

#if VIA_CHROME9_ADD_ALL_MODES
	/*aid for xrandr add mode case: mode is valid if only cbios support */
	if(source_mode.mode_flags == 0x06)
		find_res_target_rule = find_res_target_rule|ModeFlag_CbiosSupport;	
#endif

RE_CHECK_LOOP:

	for(mode_table_index = 0; mode_table_index < mode_table_num; 
			mode_table_index++) {
		
		if(true == is_need_equal) {
			if((source_mode.x_res != 
					mode_table[mode_table_index].x_res)
				|| (source_mode.y_res != 
					mode_table[mode_table_index].y_res)) {
				continue;
			}
		} else {
			if((source_mode.x_res >= 
					mode_table[mode_table_index].x_res)
				|| (source_mode.y_res >= 
					mode_table[mode_table_index].y_res)) {
				continue;
			}
		}
		for(rrate_index = 0; rrate_index < mode_table[mode_table_index].rrate_cnt; 
				rrate_index++) {
					
#if VIA_CHROME9_ADD_ALL_MODES					
			/* modeLine mode may not safety, but they are always valid*/
			if(mode_table[mode_table_index].mode_flags_ptr[rrate_index] & ModeFlag_ModeLineTiming) {
				find_best_vid_pn_mode->x_res = 
					mode_table[mode_table_index].x_res;
				find_best_vid_pn_mode->y_res = 
					mode_table[mode_table_index].y_res;
				find_best_vid_pn_mode->is_interlaced = 
					mode_table[mode_table_index].is_interlaced_ptr[rrate_index];
				find_best_vid_pn_mode->rrate_x100 = 
					mode_table[mode_table_index].rrate_x100_ptr[rrate_index];
				find_best_vid_pn_mode->mode_flags = 
					mode_table[mode_table_index].mode_flags_ptr[rrate_index];
				return true;
			}
#endif

			if(mode_table[mode_table_index].mode_flags_ptr[rrate_index] 
					& find_res_target_rule) {
				/*aid for HDTV 1920x1080i mode*/					
				if((device ==0x08)&&(hdtv_1080i_enabled)){
					mode_table[mode_table_index].is_interlaced_ptr[rrate_index] = 
						source_mode.is_interlaced;
				}

#if VIA_CHROME9_ADD_ALL_MODES					
				/*aid for xrandr add mode case: mode is valid if only cbios support */
				if(find_res_target_rule & ModeFlag_CbiosSupport)
					source_mode.is_interlaced = mode_table[mode_table_index].is_interlaced_ptr[rrate_index];
#endif

				if(mode_table[mode_table_index].is_interlaced_ptr[rrate_index] == 
						source_mode.is_interlaced) {
					ULONG mode_table_rrate = 
						mode_table[mode_table_index].rrate_x100_ptr[rrate_index];
					/* example: if vrefresh rate is 84.9Hz, think it is equal to 85Hz.  */
					if(source_mode.rrate_x100 > mode_table_rrate){
						if((source_mode.rrate_x100 - mode_table_rrate) <= 50) {
							is_find = true;
						}
					}else {
						if((mode_table_rrate - source_mode.rrate_x100) <= 50) {
							is_find = true;
						}
					}
				}

				if(true ==is_find) {
					find_best_vid_pn_mode->x_res = 
						mode_table[mode_table_index].x_res;
					find_best_vid_pn_mode->y_res = 
						mode_table[mode_table_index].y_res;
					find_best_vid_pn_mode->is_interlaced = 
						mode_table[mode_table_index].is_interlaced_ptr[rrate_index];
					find_best_vid_pn_mode->rrate_x100 = 
						mode_table[mode_table_index].rrate_x100_ptr[rrate_index];
					find_best_vid_pn_mode->mode_flags = 
						mode_table[mode_table_index].mode_flags_ptr[rrate_index];
					return true;
				}
			}
		}
	}

	/* if device use faked edid, and no mode line, we need to re-check by faked edid. */
	if((true == is_faked_edid_need_re_check) && (is_find == false)) {
		is_faked_edid_need_re_check = false;
		find_res_target_rule = EdidMode_All;
		KMS_DEBUG("dev 0x%x, faked edid and no mode line, "
			"try to select mode in faked edid mode list.\n", device);
		goto RE_CHECK_LOOP;
	}

	return false;
}

void via_chrome9_dump_cbios_mode_table(struct via_cb_mode_table *mode_table,
		ULONG  mode_table_num, int device)
{
	ULONG  mode_table_index = 0;
	ULONG  rrate_index = 0;
	for(mode_table_index = 0; mode_table_index < mode_table_num; 
			mode_table_index++) {
		KMS_DEBUG("Dev %d, Mode %dx%d,  %d RRates,\n", 
			device,
			mode_table[mode_table_index].x_res,
			mode_table[mode_table_index].y_res,
			mode_table[mode_table_index].rrate_cnt);
		for(rrate_index = 0; rrate_index < mode_table[mode_table_index].rrate_cnt;
				rrate_index++) {
			KMS_DEBUG("        %d. RRate %dHz, Interlace 0x%d,"
				" ModeFlags 0x%x, XYTotalSize=%dx%d\n", 
				rrate_index,
				mode_table[mode_table_index].rrate_x100_ptr[rrate_index],
				mode_table[mode_table_index].is_interlaced_ptr[rrate_index],
				mode_table[mode_table_index].mode_flags_ptr[rrate_index],
				mode_table[mode_table_index].x_total_size_ptr[rrate_index],
				mode_table[mode_table_index].y_total_size_ptr[rrate_index]);
		}
	}
}

bool via_chrome9_mode_fixup_helper(
	struct drm_encoder *encoder, struct drm_display_mode *mode,
	struct drm_display_mode *adjusted_mode, int device)
{
	struct drm_crtc *crtc = encoder->crtc ;
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_cb_connector_info *dev_info = NULL;
	struct via_cb_vid_pn_mode  source_mode, tmp_vid_pn_mode;
	struct via_cb_mode_table *mode_table;
	ULONG  mode_table_num;
	CBIOS_STATUS  status = CBIOS_OK;
	bool is_find = false;
	enum mode_select method = MODE_EQUAL + MODE_BIGGER;

	dev_info = via_chrome9_get_device_info_pointer(p_priv, device);
	if(dev_info->modes_table == NULL)
		via_chrome9_get_child_descriptor_by_device(p_priv, device);

	memset(&source_mode, 0, sizeof(struct via_cb_vid_pn_mode));
	source_mode.x_res = mode->hdisplay;
	source_mode.y_res = mode->vdisplay;
	source_mode.color_depth = 4;

	/* we need to confirm fresh rate value accuracy from calculate. */
	source_mode.rrate_x100 = 
		(((1000 * mode->clock)  / mode->htotal) * 100) / mode->vtotal;
	if (adjusted_mode->flags & DRM_MODE_FLAG_INTERLACE) {
		source_mode.is_interlaced = 1;
	} else {
		source_mode.is_interlaced = 0;
	}

	status = via_chrome9_get_device_mode_table(p_priv,
		device, &mode_table,  &mode_table_num);

	if (false == via_chrome9_get_mode_select_method(
			encoder, &method, device, mode)) {
		/* if any points NULL, consider as not support upscale */
		method = MODE_EQUAL;
	}
	KMS_DEBUG("mode select method is 0x%x\n", (int)method);

	if (method & MODE_EQUAL) {
		/* find exactly same HxV mode. */
		is_find = via_chrome9_find_popular_mode_from_list(device, 
						source_mode, true, mode_table_num, 
						mode_table, &tmp_vid_pn_mode, dev_info);
	}

	if ((is_find == false) && (method & MODE_BIGGER)) {
		/* find mode HxV bigger than source_mode. */
		is_find = via_chrome9_find_popular_mode_from_list(device, 
						source_mode, false, mode_table_num, 
						mode_table, &tmp_vid_pn_mode, dev_info);
	}

	/* expend TV 640x480 mode */
	if((device==0x04)&&(mode->hdisplay==640)&&(mode->vdisplay==480)){
		/* find mode HxV bigger than source_mode. */
		is_find = via_chrome9_find_popular_mode_from_list(device, 
						source_mode, false, mode_table_num, 
						mode_table, &tmp_vid_pn_mode, dev_info);
	}

	if(true == is_find) {
		/* update adjusted_mode parameters CBIOS needed. */
		adjusted_mode->hdisplay = (WORD)tmp_vid_pn_mode.x_res;
		adjusted_mode->vdisplay = (WORD)tmp_vid_pn_mode.y_res;
		adjusted_mode ->private_flags = (WORD)tmp_vid_pn_mode.rrate_x100;
		if(tmp_vid_pn_mode.is_interlaced) {
			adjusted_mode ->private_flags |= 0x80000000;
		}
	} else {
		adjusted_mode ->private_flags = (WORD)source_mode.rrate_x100;
	}

	KMS_DEBUG("Device:0x%x %s,  souce:%dx%d@%d interlace:%d,"
				" target:%dx%d@%d interlace:%d\n", 
				device, 
				(true == is_find) ? "" : " FAIL to find target",
				mode->hdisplay, 
				mode->vdisplay,
				source_mode.rrate_x100,
				source_mode.is_interlaced,
				adjusted_mode->hdisplay, 
				adjusted_mode->vdisplay, 
				(true == is_find) ? tmp_vid_pn_mode.rrate_x100 : 
						adjusted_mode ->private_flags,
				tmp_vid_pn_mode.is_interlaced);

	return true;
}

/*
 *  if there is a mode H>h, V>v in CBIOS mode list, 
 *  Interlace and VRefreshRate is equal to this mode, think it valid.  
 *  LCD only check by (faked) EDID detail mode. 
 */
enum drm_mode_status via_chrome9_mode_valid_helper(
		struct drm_connector *connector, 
		struct drm_display_mode *mode,
		int device)
{
	struct drm_device *dev = connector->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_cb_connector_info *dev_info = NULL;
	struct via_cb_vid_pn_mode  source_mode;
	struct via_cb_mode_table *mode_table;
	ULONG  mode_table_num;
	struct via_cb_vid_pn_mode  tmp_vid_pn_mode;
	CBIOS_STATUS  status = CBIOS_OK;
	enum drm_mode_status ret = MODE_BAD;
	enum mode_select method = MODE_EQUAL + MODE_BIGGER;
	bool is_find = false;

	if(connector_status_disconnected == connector->status) {
		/* we don't allow modes list on xrandr when disconnected. */
		ret = MODE_BAD;
		goto S3CBIOS_mode_valid_helper_exit;
	}

	if (mode->hdisplay == 0) {
		KMS_DEBUG("Error here, mode = %dx%d\n", 
					mode->hdisplay, mode->vdisplay);
		ret = MODE_BAD;
		goto S3CBIOS_mode_valid_helper_exit;
	}

	/* get cbios mode table from cbios here. */
	dev_info = via_chrome9_get_device_info_pointer(p_priv, device);
	if(dev_info->modes_table == NULL) 
		via_chrome9_get_child_descriptor_by_device(p_priv, device);

	memset(&source_mode, 0, sizeof(struct via_cb_vid_pn_mode));
	source_mode.x_res = mode->hdisplay;
	source_mode.y_res = mode->vdisplay;
	source_mode.color_depth = 4;
	source_mode.mode_flags = mode->flags;

	/* we need to confirm fresh rate value accuracy from calculate. */
	source_mode.rrate_x100 = 
		(((1000 * mode->clock)  / mode->htotal) * 100) / mode->vtotal;
	if (mode->flags & DRM_MODE_FLAG_INTERLACE) {
		source_mode.is_interlaced = 1;
	} else {
		source_mode.is_interlaced = 0;
	}

	status = via_chrome9_get_device_mode_table(p_priv,
				device, &mode_table,  &mode_table_num);

	if (false == via_chrome9_get_mode_select_method(
			connector->encoder, &method, device, mode)) {
		/* if any points NULL, consider as not support upscale */
		method = MODE_EQUAL;
	}

	if (method & MODE_EQUAL) {
		/* find exactly same HxV mode. */
		is_find = via_chrome9_find_popular_mode_from_list(device, 
						source_mode, true, mode_table_num, 
						mode_table, &tmp_vid_pn_mode, dev_info);
	}

	if ((is_find == false) && (method & MODE_BIGGER)) {
		/* find mode HxV bigger than source_mode. */
		is_find = via_chrome9_find_popular_mode_from_list(device, 
						source_mode, false, mode_table_num, 
						mode_table, &tmp_vid_pn_mode, dev_info);
	}

	if (is_find == true) {
		KMS_DEBUG("Device %d, source: %dx%d@%d,find in CBIOS mode table"
			" target :%dx%d@%d  flag 0x%x \n", device, 
			source_mode.x_res, source_mode.y_res, 
			source_mode.rrate_x100, 
			tmp_vid_pn_mode.x_res, tmp_vid_pn_mode.y_res, 
			tmp_vid_pn_mode.rrate_x100, tmp_vid_pn_mode.mode_flags);
		ret = MODE_OK;
	} else {
		ret = MODE_BAD;
	}

S3CBIOS_mode_valid_helper_exit:
	return ret;
}
	
bool  via_chrome9_cbios_help_device_detect (struct drm_device *dev,
		unsigned int detected_device)
{
	CBIOS_STATUS status = CBIOS_OK;
	bool is_connected = false;
	BOOL is_attached = FALSE;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	char* ConfName = "fake_connect_device";
	char* ConfFile = "/etc/X11/via_kernel.conf";

	if(p_priv->supported_devices & detected_device) {
		status = CBiosNonDestructiveDeviceDetect(pcbe, 
			detected_device, &is_attached);
		if(status == CBIOS_OK) {
			if(is_attached)
				is_connected = true;
			else
				is_connected = false;
		} else {
			is_connected = false;
		}

		if(is_connected == false) {
			status = CBiosDestructiveDeviceDetect(pcbe, 
				detected_device, &is_attached);

			if(status == CBIOS_OK) {
				if(is_attached)
					is_connected = true;
				else
					is_connected = false;
			} else {
				is_connected = false;
			}
		}
	}

	if(conf_connect_value==0xff){
		if(CBIOS_OK == CBiosGetConfFileInfo(pcbe, ConfFile, ConfName, &conf_connect_value)){
	    		switch(conf_connect_value){
			    case 0:
			        conf_connect_device=ACTIVE_TYPE_CRT;
			        break;
			    case 1:
			        conf_connect_device=ACTIVE_TYPE_CRT2;
			        break;
			    case 2:
			        conf_connect_device=ACTIVE_TYPE_DVI;
			        break;
			    case 3:
			        conf_connect_device=ACTIVE_TYPE_DVI2;
			        break;
			    case 4:
			        conf_connect_device=ACTIVE_TYPE_DP;
			        break;
			    case 5:
			        conf_connect_device=ACTIVE_TYPE_DP2;
			        break;
			    case 6:
			        conf_connect_device=ACTIVE_TYPE_HDMI;
			        break;
			    case 7:
			        conf_connect_device=ACTIVE_TYPE_HDMI2;
			        break;
			    case 8:
			        conf_connect_device=ACTIVE_TYPE_HDTV;
			        break;
			    default:
			        conf_connect_device=ACTIVE_TYPE_NONE;;
			        break;
			}   
		}	
		
		KMS_DEBUG("configure force connect device: 0x%x.\n", conf_connect_device);
	}

	if(detected_device==conf_connect_device){
		is_connected = true;
	}          

	KMS_DEBUG("MbSupport:0x%x,  device :0x%x, connect: 0x%x.\n", 
		p_priv->supported_devices, detected_device, is_connected);

	return is_connected;
}

int via_chrome9_set_active_disp_dev_config(struct drm_crtc *crtc,
		unsigned int  set_device)
{
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	CBIOS_STATUS status = CBIOS_OK;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	int iga_path = via_chrome9_crtc->crtc_id;
	int another_iga = 1 - iga_path;
	DWORD dev_on_iga1 = 0;
	DWORD dev_on_iga2 = 0;

	if(iga_path == IGA1)
		dev_on_iga1 = set_device;

	if(iga_path == IGA2)
		dev_on_iga2 = set_device;

	KMS_DEBUG("iga_path: 0x%d, IGA1: 0x%x, IGA2: 0x%x \n", 
			iga_path, dev_on_iga1, dev_on_iga2);

	if(p_priv->disp_iga_info[another_iga].disp_dev == 0) {
		if (another_iga == IGA2)
			p_priv->disp_iga_info[another_iga].disp_dev = 
					((PCBIOS_EXTENSION)pcbe)->IGA2Info.dispDev;
		else
			p_priv->disp_iga_info[another_iga].disp_dev = 
					((PCBIOS_EXTENSION)pcbe)->IGA1Info.dispDev;
	}

	if(p_priv->disp_iga_info[another_iga].disp_dev & set_device) {
		/* clear another iga device to 0, if it is same with current one. */
		status = CBiosSetActiveDisplayDeviceConfiguration_linux(pcbe, 
				dev_on_iga1, dev_on_iga2, another_iga);
		p_priv->disp_iga_info[iga_path].disp_dev = 0;
		memset(&p_priv->disp_iga_info[iga_path].mode, 
			0, sizeof(struct drm_display_mode));
		memset(&p_priv->disp_iga_info[iga_path].adjusted_mode, 
			0, sizeof(struct drm_display_mode));
		p_priv->disp_iga_info[iga_path].iga_scale_status = SHRINK_STATE_NONE;
	}
	
	status = CBiosSetActiveDisplayDeviceConfiguration_linux(pcbe, 
			dev_on_iga1, dev_on_iga2, iga_path);
	if(status != CBIOS_OK)
		KMS_DEBUG("failed!!\n");

	return status;
}


bool via_chrome9_update_info_frame_date(
	struct drm_via_chrome9_private *p_priv, ULONG disp_dev,
	ULONG h_res, ULONG v_res, RefreshRateInfo rrate_info)
{
	bool ret = true;
	CBIOS_PARAM_INFOFRAME info_frame_data;
	CBIOSPROC fn_cbios;
	PFN_CBiosSetInfoFrameData fn_set_info_frame_data = NULL;

	info_frame_data.DisplayDeviceDWord = disp_dev;
	info_frame_data.H_Res = h_res;
	info_frame_data.V_Res = v_res;
	info_frame_data.RRateInfo = rrate_info;

	if(CBIOS_OK == CBiosGetProcAddress(pcbe, "CBiosSetInfoFrameData", &fn_cbios)) {
		fn_set_info_frame_data  = (PFN_CBiosSetInfoFrameData)fn_cbios;
		fn_set_info_frame_data(pcbe, &info_frame_data);
		ret = true;
	} else {
		KMS_DEBUG("call CBiosSetInfoFrameData fail!");
		ret= false;
	}

	if(disp_dev == ACTIVE_TYPE_HDMI) {
		struct via_cb_connector_info *dev_info = 
			(struct via_cb_connector_info *)(p_priv->hdmi_1_info);
		dev_info->hdmi_conn_fmt = info_frame_data.CEAModeNumber;
	}

	return ret;
}

bool via_chrome9_cbios_set_mode(struct drm_crtc *crtc,
			struct drm_display_mode *mode,
			struct drm_display_mode *adjusted_mode,
			unsigned long color_depth)
{
	CBIOS_STATUS status = CBIOS_OK;
	bool ret = false;
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	int iga_path = via_chrome9_crtc->crtc_id;
	CBiosSetTimingParams timing_par;
	unsigned int device = 0;
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int iga_scale_type = SHRINK_STATE_NONE;
	int another_iga = 1 - iga_path;
	struct via_chrome9_connector* via_chrome9_connector = NULL;

	via_chrome9_connector = to_via_chrome9_connector(
			via_chrome9_crtc->currentActiveConnector);

	device = via_chrome9_connector_to_cbios_device(
			via_chrome9_connector->connector_id);

	//turn off TV clock path if display device is not TV/HDTV
	if((device!=0x08)&&(device!=0x04))
		cbSetTVCLK_PATH_UMA(pcbe, iga_path, OFF);

	if(!fn_cbios_set_timing)
		return ret;

	timing_par.srcMode.XRes = (WORD)mode->hdisplay;
	timing_par.srcMode.YRes = (WORD)mode->vdisplay;
	timing_par.srcMode.colorDepth = color_depth;

	timing_par.destTiming.XRes = (WORD)adjusted_mode->hdisplay;
	timing_par.destTiming.YRes = (WORD)adjusted_mode->vdisplay;
	timing_par.destTiming.rRateInfo.rRateX100 = 
		(adjusted_mode ->private_flags) & 0xFFFF;

	if (adjusted_mode ->private_flags & 0x80000000)
		timing_par.destTiming.rRateInfo.interlaced = INTERLACE;
	else 
		timing_par.destTiming.rRateInfo.interlaced = PROGRESSIVE;

	/* if another display use downscale,current use center. */
	if((p_priv->disp_iga_info[another_iga].disp_dev)
		&& (p_priv->disp_iga_info[another_iga].iga_scale_status == 
			SHRINK_STATE_DOWNSCALE)
		&& ((timing_par.srcMode.XRes != timing_par.destTiming.XRes)
			|| (timing_par.srcMode.YRes != timing_par.destTiming.YRes))) {
		timing_par.viewSize.XRes = (WORD)timing_par.srcMode.XRes;
		timing_par.viewSize.YRes = (WORD)timing_par.srcMode.YRes;
		timing_par.viewSize.XShift = (WORD)((timing_par.destTiming.XRes - 
			timing_par.viewSize.XRes) / 2);
		timing_par.viewSize.YShift = (WORD)((timing_par.destTiming.YRes - 
			timing_par.viewSize.YRes) / 2);
		KMS_DEBUG("another display use downscale,current use center.!!\n");
	} else {
	    switch (dev->pci_device) {
            case VX800_DEVICE:
            case VX855_DEVICE:
                if (0 == iga_path) {
                    /* do center on VX800 and VX855 IGA1 */
                    timing_par.viewSize.XRes = timing_par.srcMode.XRes;
                    timing_par.viewSize.YRes = timing_par.srcMode.YRes;
                    timing_par.viewSize.XShift = (timing_par.destTiming.XRes - timing_par.srcMode.XRes) / 2;
                    timing_par.viewSize.YShift = (timing_par.destTiming.YRes - timing_par.srcMode.YRes) / 2;
                } else {
                    timing_par.viewSize.XRes = timing_par.destTiming.XRes;
                    timing_par.viewSize.YRes = timing_par.destTiming.YRes;
                    timing_par.viewSize.XShift = 0;
                    timing_par.viewSize.YShift = 0;
                }
                break;
                
            case VX900_DEVICE:                
                timing_par.viewSize.XRes = timing_par.destTiming.XRes;
                timing_par.viewSize.YRes = timing_par.destTiming.YRes;
                timing_par.viewSize.XShift = 0;
                timing_par.viewSize.YShift = 0;
                break;
        }
	}

	if(device == ACTIVE_TYPE_HDMI) {
		struct via_hdmi_options *via_hdmi_options = NULL;
		via_hdmi_options = (struct via_hdmi_options *)
			via_chrome9_connector->options;
		
		timing_par.viewSize.XShift  = 
			(via_hdmi_options->left_border + via_hdmi_options->right_border)/2;
		timing_par.viewSize.YShift  = 
			(via_hdmi_options->top_border +via_hdmi_options->bottom_border)/2;
		timing_par.viewSize.XRes = timing_par.destTiming.XRes - 
			via_hdmi_options->left_border - via_hdmi_options->right_border;
		timing_par.viewSize.YRes = timing_par.destTiming.YRes - 
			via_hdmi_options->top_border - via_hdmi_options->bottom_border;

		/* another display use upscale,disable downscale!! */
		if((p_priv->disp_iga_info[another_iga].disp_dev)
			&& (p_priv->disp_iga_info[another_iga].iga_scale_status == 
				SHRINK_STATE_UPSCALE)
			&&((timing_par.srcMode.XRes == timing_par.destTiming.XRes)
			|| (timing_par.srcMode.XRes == timing_par.destTiming.XRes))) {
			timing_par.viewSize.XShift  = 0;
			timing_par.viewSize.YShift  = 0;
			timing_par.viewSize.XRes = timing_par.destTiming.XRes;
			timing_par.viewSize.YRes = timing_par.destTiming.YRes;
			KMS_DEBUG("another display use upscale,disable downscale!!\n");
		}
	}

	timing_par.IGAIndex = iga_path;
	timing_par.flag = TIMING_PARA_FULL_UPDATE;
	timing_par.size = sizeof(CBiosSetTimingParams);
	/* 
	 * the mode with H V different scale were not supported
	 * and filtered by mode valid function
	 * all the modes to be set were compatible with the hardware scale capability 
	 */
	if((timing_par.srcMode.XRes < timing_par.destTiming.XRes) 
		|| (timing_par.srcMode.YRes < timing_par.destTiming.YRes)) {
		if((timing_par.viewSize.XRes == timing_par.srcMode.XRes) 
			&& (timing_par.viewSize.YRes == timing_par.srcMode.YRes))
			iga_scale_type = SHRINK_STATE_CENTER;
		else
			iga_scale_type = SHRINK_STATE_UPSCALE;
	} else if((timing_par.srcMode.XRes == timing_par.destTiming.XRes) 
		&& (timing_par.srcMode.YRes == timing_par.destTiming.YRes)) {
		if((timing_par.viewSize.XRes < timing_par.destTiming.XRes) 
			&& (timing_par.viewSize.YRes < timing_par.destTiming.YRes))
			iga_scale_type = SHRINK_STATE_DOWNSCALE;
		else
			iga_scale_type = SHRINK_STATE_NONE;
	} else {
		iga_scale_type = SHRINK_STATE_DOWNSCALE;
	}

	KMS_DEBUG(" ===========mode set info start=====================\n");
	KMS_DEBUG(" iga: %01d Source Mode=%dx%d %dbpp\n", 
			iga_path, timing_par.srcMode.XRes, timing_par.srcMode.YRes, 
			timing_par.srcMode.colorDepth);
	KMS_DEBUG(" device: 0x%x target Mode=%dx%d @%d , Interlaced: %d\n", 
			device, timing_par.destTiming.XRes, timing_par.destTiming.YRes, 
			timing_par.destTiming.rRateInfo.rRateX100, 
			timing_par.destTiming.rRateInfo.interlaced);
	KMS_DEBUG(" ===========mode set info end=====================\n\n");

	status = ((PFN_CBiosSetTiming)fn_cbios_set_timing)(pcbe, &timing_par);

	if(status != CBIOS_OK) {
		KMS_DEBUG("via_chrome9_cbios_set_mode failed!!\n");
		ret = false;
	} else {
		p_priv->disp_iga_info[iga_path].disp_dev = device;
		memcpy(&p_priv->disp_iga_info[iga_path].mode, 
				&mode, sizeof(struct drm_display_mode));
		memcpy(&p_priv->disp_iga_info[iga_path].adjusted_mode, 
				&adjusted_mode, sizeof(struct drm_display_mode));
		p_priv->disp_iga_info[iga_path].iga_scale_status = iga_scale_type;
		ret = true;
	}

	if((ACTIVE_TYPE_HDMI + ACTIVE_TYPE_HDMI2 + ACTIVE_TYPE_DP + 
			ACTIVE_TYPE_DP2) & device)
		via_chrome9_update_info_frame_date(p_priv, device, 
			timing_par.destTiming.XRes, timing_par.destTiming.YRes, 
			timing_par.destTiming.rRateInfo);

	if(device & (ACTIVE_TYPE_HDMI | ACTIVE_TYPE_DP)) {
		u32 cts = 0, cts_interval = 0;
		struct via_cb_connector_info *dev_info = NULL;
		ULONG cea_mode_num = 0;

		/* Here device is the real target device type. */
		if(device == ACTIVE_TYPE_HDMI) {
			dev_info = p_priv->hdmi_1_info;
			cea_mode_num = dev_info->hdmi_conn_fmt;
		} else {
			dev_info = p_priv->dp_1_info;
		}

		via_chrome9_update_hd_audio_par(device, cea_mode_num, 
				&cts, &cts_interval);

		if(device == ACTIVE_TYPE_HDMI) {
			p_priv->hdmi_cts_renew->counter = 0;
			p_priv->hdmi_cts_renew->interval = cts_interval; 
			p_priv->hdmi_cts_renew->feedback = 0;
			p_priv->hdmi_cts_renew->increaser = 0;
			p_priv->hdmi_cts_renew->cts = cts;
		}
	}

	return ret;
}

bool  via_chrome9_force_hdmi_to_dvi_mode(unsigned char is_dvi_mode)
{
	BYTE in_buf, out_buf;
	CBIOS_STATUS status = CBIOS_OK;
	in_buf = is_dvi_mode;
	out_buf = 0;

	status = CBiosPatchHW(pcbe, HW_PATCH_FORCE_HDMI_TO_DVI_MODE, 
			&in_buf, sizeof(in_buf), &out_buf, sizeof(out_buf));

	if (CBIOS_OK != status) {
		return false;
	}

	return true;
}

void *via_chrome9_create_thread(thread_func_t func, void *data)
{
	struct task_struct* thread;

	thread = (struct task_struct*)kthread_run(func, data, "s3g_kthread");
	return (void*)thread;
}

void via_chrome9_init_hdmi_1_irq(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	DWORD di_port_int;
	union via_cb_irq_mask_200 reg_current_int;

	KMS_DEBUG(" enter \n");

	p_priv->hdmi_tx_irq_type = 0;
	/* If only support HDMI, we query this first */
	if(CBIOS_OK == CBiosGetDeviceHotPlugInterruptSetting(pcbe,
			ACTIVE_TYPE_HDMI, &di_port_int)) {
		if(0 != di_port_int)
			p_priv->hdmi_tx_irq_type |= di_port_int;  
	} else {
		/*353 hdmi-1 default enable LVDSinterupt. */
		if(VX800_DEVICE == dev->pci_device)
			p_priv->hdmi_tx_irq_type |= USING_LVDS_HPD_INTERRUPT;
		else
			p_priv->hdmi_tx_irq_type |= USING_TMDS_HPD_INTERRUPT;
	}

	reg_current_int.uint = MMIO_RD(VID_INT_1);

	if(p_priv->hdmi_tx_irq_type & USING_TMDS_HPD_INTERRUPT) {
		/*  DVP0 interrupt */
		reg_current_int.dvp0_sense_enable= 1;
		/* Initial AD9389 interrupt function by DVP0 */
		reg_current_int.interrupt_enable = 1;
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp0_sense_status = 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint);
	}
	else if(p_priv->hdmi_tx_irq_type & USING_LVDS_HPD_INTERRUPT) {
		/*  DVP1 interrupt */
		reg_current_int.dvp1_sense_enable = 1;
		/* Initial AD9389 interrupt function by DVP1 */
		reg_current_int.interrupt_enable = 1;
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp1_sense_status = 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint); 
	} else if(p_priv->hdmi_tx_irq_type & USING_DP_HPD_INTERRUPT) {
		/*  enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP1 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT11));
	}

	if(p_priv->hdmi_tx_irq_type & USING_HDAUDIO_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/*  clear/enable HDAudio interrupt */
		MMIO_WR(0xC500, (MMIO_RD(0xC500) | (BIT4+BIT0)));
	}
}

void via_chrome9_init_hdmi_2_irq(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	DWORD di_port_int;
	union via_cb_irq_mask_200 reg_current_int;

	KMS_DEBUG(" enter \n");

	/* If only support HDMI2, we query this first */
	if(CBIOS_OK == CBiosGetDeviceHotPlugInterruptSetting(pcbe,
			ACTIVE_TYPE_HDMI2, &di_port_int)){
		if(0 != di_port_int)
			p_priv->hdmi_tx_irq_type |= di_port_int;  
	}

	reg_current_int.uint = MMIO_RD(VID_INT_1);

	if(p_priv->hdmi_tx_irq_type & USING_TMDS_HPD_INTERRUPT) {
		/* DVP0 interrupt */
		reg_current_int.dvp0_sense_enable = 1;
		/* Initial AD9389 interrupt function by DVP0 */
		reg_current_int.interrupt_enable = 1;
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp0_sense_status = 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint);   
	} else if(p_priv->hdmi_tx_irq_type & USING_LVDS_HPD_INTERRUPT) {
		/* DVP1 interrupt */
		reg_current_int.dvp1_sense_enable = 1;
		/* Initial AD9389 interrupt function by DVP1 */
		reg_current_int.interrupt_enable = 1; 
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp1_sense_status = 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint); 
	} else if(p_priv->hdmi_tx_irq_type & USING_DP_HPD_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP1 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT11));
	}

	if(p_priv->hdmi_tx_irq_type & USING_HDAUDIO_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear/enable HDAudio interrupt */
		MMIO_WR(0xC500, (MMIO_RD(0xC500) | (BIT1+BIT0)));
	}
}

void via_chrome9_init_dp_1_irq(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	DWORD dp_interrupt = 0;
	union via_cb_irq_mask_200 reg_current_int;
	union via_cb_irq_mask_1280  reg_current_int_mm1280;
	struct via_cb_connector_info *dev_info = p_priv->dp_1_info;

	KMS_DEBUG(" enter \n");

	dev_info->dvi_irq_type = 0;

	reg_current_int.uint = MMIO_RD(VID_INT_1);
	reg_current_int_mm1280.uint = MMIO_RD(VID_INT_3);

	if(CBIOS_OK == CBiosGetDeviceHotPlugInterruptSetting(pcbe,
			ACTIVE_TYPE_DP,  &dp_interrupt)) {
		if (0 != dp_interrupt)
			dev_info->dvi_irq_type = dp_interrupt;
	}

	if(dev_info->dvi_irq_type & USING_DP_HPD_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP1 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT11));
	}

	if(dev_info->dvi_irq_type & USING_DP2_HPD_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP1 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT13));
	}

	if(dev_info->dvi_irq_type & USING_HDAUDIO_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear/enable HDAudio interrupt */
		MMIO_WR(0xC500, (MMIO_RD(0xC500) | (BIT4+BIT0)));
	}
}

void via_chrome9_init_dp_2_irq(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	DWORD dp2_int = 0;
	union via_cb_irq_mask_200 reg_current_int;
	union via_cb_irq_mask_1280  reg_current_int_mm1280;
	struct via_cb_connector_info *dev_info = p_priv->dp_2_info;

	KMS_DEBUG(" enter \n");

	dev_info->dvi_irq_type = 0;

	reg_current_int.uint = MMIO_RD(VID_INT_1);
	reg_current_int_mm1280.uint = MMIO_RD(VID_INT_3);
	
	if(CBIOS_OK == CBiosGetDeviceHotPlugInterruptSetting(pcbe,
			ACTIVE_TYPE_DP2,  &dp2_int)) {
		if (0 != dp2_int)
			dev_info->dvi_irq_type = dp2_int;
	}

	if(dev_info->dvi_irq_type & USING_DP2_HPD_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP2 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT13));
	}

	if(dev_info->dvi_irq_type & USING_HDAUDIO_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear/enable HDAudio interrupt */
		MMIO_WR(0xC500, (MMIO_RD(0xC500) | (BIT4+BIT0)));
	}
}

void via_chrome9_init_dvi_irq(struct drm_device *dev, DWORD disp_dev)
{
	struct drm_via_chrome9_private *p_priv =
			(struct drm_via_chrome9_private *)dev->dev_private;
	DWORD di_port_interrupt = 0;
	DWORD mm_1280= 0, mm_200=0;
	union via_cb_irq_mask_200 reg_current_int;
	union via_cb_irq_mask_1280  reg_current_int_mm1280;
	struct via_cb_connector_info *dev_info = NULL;

	KMS_DEBUG("enter \n");

	reg_current_int.uint = MMIO_RD(VID_INT_1);
	reg_current_int_mm1280.uint = MMIO_RD(VID_INT_3);

	dev_info = via_chrome9_get_device_info_pointer(p_priv, disp_dev);

	/* If only support HDMI2, we query this first */
	if(CBIOS_OK == CBiosGetDeviceHotPlugInterruptSetting(
			pcbe,disp_dev, &di_port_interrupt)) {
		if(0 != di_port_interrupt)
			KMS_DEBUG("Find DIPort for Interrupt, di_port_interrupt = 0x%x\n", 
				di_port_interrupt);
	} else {
		di_port_interrupt = USING_LVDS_HPD_INTERRUPT;
	}

	dev_info->dvi_irq_type = di_port_interrupt;

	if(di_port_interrupt & USING_TMDS_HPD_INTERRUPT) {
		/* DVP0 interrupt */
		reg_current_int.dvp0_sense_enable= 1;
		reg_current_int.interrupt_enable = 1; 
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp0_sense_status = 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint);
	} else if(di_port_interrupt & USING_LVDS_HPD_INTERRUPT)  {
		/* DVP1 interrupt */
		reg_current_int.dvp1_sense_enable = 1;
		reg_current_int.interrupt_enable = 1; 
		reg_current_int.uint &=  VID_INT_1_ALL_EN_MASK;
		reg_current_int.dvp1_sense_status= 1;
		MMIO_WR(VID_INT_1,reg_current_int.uint); 
	} else if(di_port_interrupt & USING_DP_HPD_INTERRUPT) {
		/* enable GFX interrupt mm.200[31] */
		MMIO_WR(VID_INT_1, (MMIO_RD(VID_INT_1) | BIT31));
		/* clear DP1 interrupt */
		MMIO_WR(VID_INT_3, (MMIO_RD(VID_INT_3) | BIT11));
	}

	if(p_priv->irq.internal_tmds_sense_int == true) {
		/* VX800 DVI-1 IRQ init */
		mm_200 = MMIO_RD(VID_INT_1);
		mm_1280 = MMIO_RD(VID_INT_3);
		mm_1280 |= VIA_IRQ_IN_TMDS_EN;
		mm_1280 |= VIA_IRQ_IN_TMDS_STS;

		MMIO_WR(VID_INT_3, mm_1280);
		MMIO_WR(VID_INT_1, mm_200);
	}
	KMS_DEBUG("DVI-%d hotplug init. \n", (disp_dev == ACTIVE_TYPE_DVI)? 1: 2);
}

void via_chrome9_init_interrupt_devices(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	KMS_DEBUG(" via_chrome9_init_interrupt_devices  \n");

	if (p_priv->supported_devices & ACTIVE_TYPE_HDMI)
		via_chrome9_init_hdmi_1_irq(dev);

	if (p_priv->supported_devices & ACTIVE_TYPE_HDMI2)
		via_chrome9_init_hdmi_2_irq(dev);

	if (p_priv->supported_devices & ACTIVE_TYPE_DP)
		via_chrome9_init_dp_1_irq(dev);

	if (p_priv->supported_devices & ACTIVE_TYPE_DP2)
		via_chrome9_init_dp_2_irq(dev);

	if (p_priv->supported_devices & ACTIVE_TYPE_DVI)
		via_chrome9_init_dvi_irq(dev, ACTIVE_TYPE_DVI);

	if (p_priv->supported_devices & ACTIVE_TYPE_DVI2)
		via_chrome9_init_dvi_irq(dev, ACTIVE_TYPE_DVI2);
}

void via_chrome9_hpd_interrupt_routine(ULONG irq_flags_1, ULONG irq_flags_3)
{
	CBIOS_INTERRUPT  hw_interrupt;
	memset(&hw_interrupt, 0, sizeof(CBIOS_INTERRUPT));
	hw_interrupt.InterruptControlReg1 = irq_flags_1;
	/* we do not consider 0x204 interrupts. */
	hw_interrupt.InterruptControlReg2 = 0;
	hw_interrupt.InterruptControlReg3 = irq_flags_3;
	/* porting from win drv, cbios do not use Size section now. */
	hw_interrupt.Size = 16;
	CBiosInterruptRoutine(pcbe, &hw_interrupt);
}
