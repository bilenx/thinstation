/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_init.h"
#include "via_chrome9_object.h"
#include <linux/console.h>
#include <linux/module.h>

#if ! defined(LINUX_VERSION_CODE)  
#include <linux/version.h>
#endif
#define RING_BUFFER_INIT_FLAG 1
#define RING_BUFFER_CLEANUP_FLAG 2

void via_chrome9_cbios_set_power_state(unsigned int powerState);
extern int via_chrome9_re_init_cbios(struct drm_device *dev);


int via_chrome9_drm_get_pci_id(struct drm_device *dev,
	void *data, struct drm_file *file_priv)
{
	unsigned int *reg_val = data;
	outl(0x8000002C, 0xCF8);
	*reg_val = inl(0xCFC);
	outl(0x8000012C, 0xCF8);
	*(reg_val+1) = inl(0xCFC);
	outl(0x8000022C, 0xCF8);
	*(reg_val+2) = inl(0xCFC);
	outl(0x8000052C, 0xCF8);
	*(reg_val+3) = inl(0xCFC);

	return 0;
}

int via_chrome9_dma_init(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{

	return 0;
}

struct drm_ioctl_desc via_chrome9_ioctls[] = {
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_CREATE,
		via_chrome9_ioctl_gem_create, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_USER_CREATE,
		via_chrome9_ioctl_gem_user_create, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_MMAP,
		via_chrome9_ioctl_gem_mmap, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_PREAD,
		via_chrome9_ioctl_gem_pread, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_PWRITE,
		via_chrome9_ioctl_gem_pwrite, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_SET_DOMAIN,
		via_chrome9_ioctl_gem_set_domain, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_FLUSH,
		via_chrome9_ioctl_gem_flush, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_WAIT,
		via_chrome9_ioctl_gem_wait, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_SHADOW_INIT,
		via_chrome9_ioctl_shadow_init, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_ALLOCATE_EVENT_TAG,
		via_chrome9_ioctl_alloc_event, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_FREE_EVENT_TAG,
		via_chrome9_ioctl_free_event, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_WAIT_CHIP_IDLE,
		via_chrome9_ioctl_wait_chip_idle, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_CPU_GRAB,
		via_chrome9_ioctl_cpu_grab, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_CPU_RELEASE,
		via_chrome9_ioctl_cpu_release, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_PIN,
		via_chrome9_ioctl_gem_pin, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_UNPIN,
		via_chrome9_ioctl_gem_unpin, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GEM_CHIPINFO,
		via_chrome9_ioctl_chipinfo_gem, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_XORG_OPTIONS,
		via_chrome9_ioctl_xorg_options, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GET_CRTC_ID,
		via_chrome9_ioctl_get_crtc_id, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GET_BO_INFO,
	    via_chrome9_ioctl_get_bo_info, DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_SET_EDID,
		via_chrome9_ioctl_set_edid, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_OUTPUT_MODE_VALID,
		via_chrome9_ioctl_output_mode_valid, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_CRTC_DPMS,
		via_chrome9_ioctl_crtc_dpms, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_GET_CUSTOMIZE_TIMING_INFO,
		via_chrome9_ioctl_get_customize_timing_info, DRM_UNLOCKED|DRM_AUTH),
	DRM_IOCTL_DEF_DRV(VIA_CHROME9_PASS_MODE_LINE,
		via_chrome9_ioctl_pass_customize_timing, DRM_UNLOCKED|DRM_AUTH),
        DRM_IOCTL_DEF_DRV(VIA_CHROME9_HELPER_SET_MODE,
                via_chrome9_ioctl_helper_set_mode, DRM_UNLOCKED|DRM_AUTH),
        DRM_IOCTL_DEF_DRV(VIA_CHROME9_GET_CLOCKS,
                via_chrome9_ioctl_get_clocks, DRM_UNLOCKED|DRM_AUTH),
        DRM_IOCTL_DEF_DRV(VIA_CHROME9_GET_TV_CONFIGURE,
                via_chrome9_ioctl_get_tv_configure, DRM_UNLOCKED|DRM_AUTH)                
};

int via_chrome9_max_ioctl = DRM_ARRAY_SIZE(via_chrome9_ioctls);

DEFINE_PCI_DEVICE_TABLE(pciidlist) = {
	{0x1106, VX800_DEVICE, PCI_ANY_ID, PCI_ANY_ID, 0, 0,
		VIA_CHROME9_PCIE_GROUP},
	{0x1106, VX855_DEVICE, PCI_ANY_ID, PCI_ANY_ID, 0, 0,
		VIA_CHROME9_PCIE_GROUP},
	{0x1106, VX900_DEVICE, PCI_ANY_ID, PCI_ANY_ID, 0, 0,
		VIA_CHROME9_PCIE_GROUP},
	{0, 0, 0}
};

#if VIA_CHROME9_ENABLE_KMS
static struct drm_driver driver;

static int __devinit
via_chrome9_pci_probe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
	return drm_get_pci_dev(pdev, ent, &driver);
}

static void
via_chrome9_pci_remove(struct pci_dev *pdev)
{
	struct drm_device *dev = pci_get_drvdata(pdev);
	drm_put_dev(dev);
}

static int
via_chrome9_pci_suspend(struct pci_dev *pdev, pm_message_t state)
{
	struct drm_device *dev = pci_get_drvdata(pdev);
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (dev == NULL || dev->dev_private == NULL)
		return -ENODEV;

	/* wait all engine idle */
	waitchipidle_inv(p_priv);

	/*disable vq*/
	via_chrome9_vq_disable(dev);

	if (state.event == PM_EVENT_PRETHAW)
		return 0;

	via_chrome9_drm_save_bos(dev);
	via_chrome9_suspend_gart_table(dev);

	pci_save_state(pdev);

	via_chrome9_suspend_exec(dev);
	via_chrome9_suspend_mode_set(dev);

	via_chrome9_cbios_set_power_state(false);

	/* for vx800 nano platform, when S1, system can't back */
	if (dev->pci_device != VX800_DEVICE) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
		console_lock();
#else
		acquire_console_sem();
#endif
		fb_set_suspend(p_priv->fb_info, 1);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
		console_unlock();
#else
		release_console_sem();
#endif
	}

	return 0;
}

static int
via_chrome9_pci_resume(struct pci_dev *pdev)
{
	struct drm_device *dev = pci_get_drvdata(pdev);
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
	console_lock();
#else 
	acquire_console_sem();
#endif
	pci_set_power_state(pdev, PCI_D0);
	pci_restore_state(pdev);
	if (pci_enable_device(pdev)) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
		console_unlock();
#else
		release_console_sem();
#endif
		return -1;
	}
	pci_set_master(pdev);

	/* cbios re-init */
	via_chrome9_re_init_cbios(dev);

	if (dev->pci_device != VX800_DEVICE)
		fb_set_suspend(p_priv->fb_info, 0);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
	console_unlock();
#else
	release_console_sem();
#endif

	via_chrome9_resume_mode_set(dev);
	via_chrome9_resume_exec(dev);

	return 0;
}
#endif

#if (LINUX_VERSION_CODE >= 0x030000)
static struct pci_driver pcidriver = {
		 .name = DRIVER_NAME,
		 .id_table = pciidlist,
#if VIA_CHROME9_ENABLE_KMS
		 .probe = via_chrome9_pci_probe,
		 .remove = via_chrome9_pci_remove,
		 .suspend = via_chrome9_pci_suspend,
		 .resume = via_chrome9_pci_resume,
#endif
};
#endif
static struct drm_driver driver = {
	.driver_features =
		DRIVER_HAVE_DMA | DRIVER_FB_DMA | DRIVER_USE_MTRR | DRIVER_GEM |
		DRIVER_HAVE_IRQ | DRIVER_IRQ_SHARED,
	.load = via_chrome9_driver_load,
	.preclose = via_chrome9_preclose,
	.lastclose = via_chrome9_lastclose,
	.unload = via_chrome9_driver_unload,
	.suspend = via_chrome9_drm_suspend,
	.resume = via_chrome9_drm_resume,
	.irq_preinstall = via_chrome9_driver_irq_preinstall,
	.irq_postinstall = via_chrome9_driver_irq_postinstall,
	.irq_uninstall = via_chrome9_driver_irq_uninstall,
	.irq_handler = via_chrome9_driver_irq_handler,
	.get_vblank_counter = drm_vblank_count,
	.enable_vblank = via_chrome9_enable_vblank,
	.disable_vblank = via_chrome9_disable_vblank,
	.reclaim_buffers = drm_core_reclaim_buffers,
	.gem_init_object = via_chrome9_gem_object_init,
	.gem_free_object = via_chrome9_gem_object_free,
	.ioctls = via_chrome9_ioctls,
	.fops = {
		 .owner = THIS_MODULE,
		 .open = drm_open,
		 .release = drm_release,
		 .unlocked_ioctl = drm_ioctl,
		 .mmap = via_chrome9_mmap,
		 .poll = drm_poll,
		 .fasync = drm_fasync,
		 .read = drm_read,
		 .llseek = noop_llseek,
#ifdef CONFIG_COMPAT
		 .compat_ioctl = via_chrome9_compat_ioctl,
#endif
	},

#if !(LINUX_VERSION_CODE >= 0x030000)
	.pci_driver = {
		 .name = DRIVER_NAME,
		 .id_table = pciidlist,
#if VIA_CHROME9_ENABLE_KMS
		 .probe = via_chrome9_pci_probe,
		 .remove = via_chrome9_pci_remove,
		 .suspend = via_chrome9_pci_suspend,
		 .resume = via_chrome9_pci_resume,
#endif
	},
#endif

	.name = DRIVER_NAME,
	.desc = DRIVER_DESC,
	.date = DRIVER_DATE,
	.major = DRIVER_MAJOR,
	.minor = DRIVER_MINOR,
	.patchlevel = DRIVER_PATCHLEVEL,
};

static int __init via_chrome9_init(void)
{
#if VIA_CHROME9_ENABLE_KMS
	driver.driver_features |= DRIVER_MODESET;
#endif
	driver.num_ioctls = via_chrome9_max_ioctl;
#if (LINUX_VERSION_CODE >= 0x030000)
	return drm_pci_init(&driver, &pcidriver);
#else
	return drm_init(&driver);
#endif
}

static void __exit via_chrome9_exit(void)
{

#if (LINUX_VERSION_CODE >= 0x030000)
	return drm_pci_exit(&driver, &pcidriver);
#else
	drm_exit(&driver);
#endif
}

module_init(via_chrome9_init);
module_exit(via_chrome9_exit);

MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL and additional rights");
MODULE_DEVICE_TABLE(pci, pciidlist);
MODULE_VERSION("5.76.52.92-126076");
