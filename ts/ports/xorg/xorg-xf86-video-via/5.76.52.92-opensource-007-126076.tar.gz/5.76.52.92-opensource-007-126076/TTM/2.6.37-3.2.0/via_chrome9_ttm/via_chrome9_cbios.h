/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
 
#ifndef _VIA_CHROME9_CBIOS_H
#define _VIA_CHROME9_CBIOS_H

#include <linux/fb.h>
#include <linux/delay.h>

#include "cbios_uma.h"

/* 128k */
#define SHADOW_VBIOS_SIZE  0x20000

#define RESOLUTIONNUM_FOR_CUSTOMER  10

enum via_cb_mode_flags {
	EdidMode_None = 0x1,
	EdidMode_Establish = 0x2,
	EdidMode_Standard = 0x4,
	EdidMode_Detail = 0x8,
	ModeFlag_CbiosSupport  = 0x10,
	ModeFlag_Win7Additional = 0x20,
	ModeFlag_CEATiming = 0x40,
	ModeFlag_ModeLineTiming = 0x80,
};

#define EdidMode_All \
	(EdidMode_Establish|EdidMode_Standard|EdidMode_Detail|ModeFlag_CEATiming) 

enum via_cb_active_type {
	ACTIVE_TYPE_NONE = 0x00,
	ACTIVE_TYPE_CRT = 0x01,
	ACTIVE_TYPE_PANEL = 0x02,
	ACTIVE_TYPE_TV = 0x04,
	ACTIVE_TYPE_HDTV = 0x08,
	ACTIVE_TYPE_DVI2 = 0x10,
	ACTIVE_TYPE_DVI = 0x20,
	ACTIVE_TYPE_CRT2 = 0x40,
	ACTIVE_TYPE_PANEL2 = 0x100, 
	ACTIVE_TYPE_HDMI = 0x200,
	ACTIVE_TYPE_HDMI2 = 0x2000,
	ACTIVE_TYPE_DP = 0x8000,
	ACTIVE_TYPE_DP2 = 0x10000,
};

enum mode_select{
	MODE_NULL = 0x0,
	MODE_EQUAL = 0x1,
	MODE_BIGGER = 0x2,
	MODE_SMALLER = 0x04,
};

/* Direct X small modes */
#define RES_320_200         0x014000C8
#define RES_320_240         0x014000F0
#define RES_400_300         0x0190012C
#define RES_512_384         0x02000180
#define RES_640_400         0x02800190

/* Standard Desktop modes */
#define RES_640_480         0x028001E0
#define RES_800_600         0x03200258
#define RES_1024_768        0x04000300
#define RES_1280_960        0x050003C0
#define RES_1280_1024       0x05000400
#define RES_1600_1200       0x064004B0
#define RES_1920_1440       0x078005A0
#define RES_2048_1536       0x08000600

/* DVI/Panel wide modes */
#define RES_800_480         0x032001E0
#define RES_848_480         0x035001E0
#define RES_1280_600        0x05000258
#define RES_1280_768        0x05000300
#define RES_1280_800        0x05000320
#define RES_1360_768        0x05500300
#define RES_1366_768        0x05560300
#define RES_1400_1050       0x0578041A
#define RES_1440_900        0x05A00384
#define RES_1680_1050       0x0690041A
#define RES_1920_1200       0x078004B0

/* HDTV 16:9 sub modes */
#define RES_624_416         0x027001A0
#define RES_672_448         0x02A001C0
#define RES_720_480         0x02D001E0
#define RES_1104_624        0x04500270
#define RES_1200_672        0x04B002A0
/* also a DVI/Panel wide mode */
#define RES_1280_720        0x050002D0
#define RES_1648_928        0x067003A0
#define RES_1792_1008       0x070003F0
#define RES_1920_1080       0x07800438

/* TV viewport size only */
#define RES_928_704         0x03A002C0      
/* MS MCE required mode for PAL */
#define RES_720_540         0x02D0021C

/* Modes always be pruned */
#define RES_720_576         0x02D00240
#define RES_1152_864        0x04800360
#define RES_1152_870        0x04800366    

/* Special modes */
#define RES_960_600         0x03C00258
#define RES_720_400         0x02D00190
#define RES_832_624         0x03400270


#define MAKE_RES(x,y) ((((ULONG)x) << 16) + ((ULONG)y))

#define  VID_INT_1  0x200
#define  VID_INT_3  0x1280

#define  VID_INT_1_ALL_EN_MASK    0xF7FF0C00

/* mmio 0x200 register */
union via_cb_irq_mask_200 {
	struct {
		DWORD dvp0_sense_status:  1;
		DWORD vblank_status:  1;
		DWORD mc_complete_frame_status:   1;
		DWORD iga1_vsync_irq_status:  1;
		DWORD dma0_descriptor_status:  1;
		DWORD dma0_transfer_status:  1;
		DWORD dma1_descriptor_status:  1;
		DWORD dma1_transfer_status:  1;

		DWORD capture1_active_status:  1;
		DWORD first_hqv_status:  1;
		DWORD second_hqv_status:  1;
		DWORD second_hqv_enable:  1;
		DWORD capture0_active_status:  1;
		DWORD capture0_vbi_status:  1;
		DWORD capture1_vbi_status:  1;
		DWORD iga2_vsync_irq_status:  1;

		DWORD dvp0_sense_enable:  1;
		DWORD iga2_vsync_irq_enable:  1;
		DWORD mc_complete_frame_enable:  1;
		DWORD iga1_vsync_irq_enable:  1;
		DWORD dma0_descriptor_enable:  1;
		DWORD dma0_transfer_enable:  1;
		DWORD dma1_descriptor_enable:  1;
		DWORD dma1_transfer_enable:  1;

		DWORD capture1_active_enable:  1;
		DWORD first_hqv_enable:   1;
		DWORD capture1_vbi_enable:   1;
		DWORD dvp1_sense_status:  1;
		DWORD capture0_active_enable:  1;
		DWORD capture0_vbi_enable:  1;
		DWORD dvp1_sense_enable:  1;
		DWORD interrupt_enable:  1;
	};
	DWORD uint;
};

/* mmio 0x1280 register */
union via_cb_irq_mask_1280 {
	struct {
		DWORD dma2_descriptor_done_irq_status:  1;
		DWORD dma2_transfer_done_irq_status:  1;
		DWORD dma3_descriptor_done_irq_status :  1;
		DWORD dma3_transfer_done_irq_status:  1;
		DWORD crt_sense_irq_status:  1;
		DWORD i2c_no_good_status:  1;
		DWORD i2c_tran_done_status:  1;
		DWORD i2c_data_tran_status:  1;

		DWORD tv_irq_status:  1;
		DWORD inside_dvi_irq_status:  1;
		DWORD codec_irq_0_done_status:  1;
		DWORD dp_1_irq_status:  1;
		DWORD codec_irq_1_done_status:  1;
		DWORD dp_2_irq_status:  1;
		DWORD msvd_irq_done_status:  1;
		DWORD reserved:  1;

		DWORD dma2_descriptor_done_irq_enable:  1;
		DWORD dma2_transfer_done_irq_enable:  1;
		DWORD dma3_descriptor_done_irq_enable:  1;
		DWORD dma3_transfer_done_irq_enable:  1;
		DWORD crt_int_enable:  1;
		DWORD i2c_reg_int_enable:  1;
		DWORD tv_irq_enable:  1;
		DWORD hdac_1_irq_enable:  1;

		DWORD dp_1_irq_enable:  1;
		DWORD hdac_2_irq_enable:  1;
		DWORD dp_2_irq_enable:  1;
		DWORD reserved2:  3;
		DWORD inside_dvi_irq_enable:  1;
		DWORD msi_pending_irq_reTrigger_bit:  1;
	};
	DWORD uint;
};

struct via_cb_mode_table {
	ULONG y_res;
	ULONG x_res;
	/* the count of RefreshRate in rrate_x100_ptr */
	ULONG rrate_cnt;
	PULONG rrate_x100_ptr;
	PULONG y_total_size_ptr;
	PULONG x_total_size_ptr;
	PULONG is_interlaced_ptr;
	PULONG mode_flags_ptr;
};

enum {
	EdidGotState_None = 0x1,
	EdidGotState_Correct  = 0x2,
	EdidGotState_Wrong = 0x4,
};

struct via_cb_edid_block_data {
	UCHAR header[8];
	UCHAR vendor_pid[10];
	UCHAR edid_version[2];
	UCHAR display_par[5];
	UCHAR color_characters[10];
	UCHAR est_timing[3];
	UCHAR std_timing_ids[16];
	UCHAR detail_timing[72];
	UCHAR ext_flag;
	UCHAR ck_sum;
	UCHAR ext_blk[128];
};

/*  256 bytes in main EDID block */
#define EDID_BLOCK_SIZE     256 

struct via_cb_vid_pn_mode {
	ULONG y_res;
	ULONG x_res;
	ULONG y_total_size;
	ULONG x_total_size;
	ULONG rrate_x100;
	/*  1==8bpp, 2==16bpp, 3==24bpp, 4==32bpp */
	ULONG color_depth;
	ULONG rotation;
	ULONG pitch;
	ULONG is_interlaced;
	ULONG mode_flags;
};

struct via_cb_connector_info { 
	ULONG got_edid_status;
	UCHAR edid_info[256];
	PVOID parsed_edid_info;
	/* Flag for device timing switch  */
	ULONG edid_preferred_mode;
	struct via_cb_mode_table *modes_table;
	/* count of struct via_cb_mode_table that has been filled in modes_table */
	ULONG used_mode_table_num;
	ULONG dvi_irq_type;
	/* only use by HDMI */
	/*  640x480, 720x480, 128x720, 1920x1080 */
	ULONG hdmi_conn_fmt;
	/*  RGB, YCbCr4:4:4. YCbCr4:2:2 */
	ULONG hdmi_conn_type;

	BYTE mode_line_num;
	struct via_cb_vid_pn_mode *mode_line_table;
};

extern void via_chrome9_hpd_interrupt_routine(
		ULONG irq_flags_1, ULONG irq_flags_3);

#endif
