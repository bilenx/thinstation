/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_init.h"
#include "via_chrome9_object.h"
#include "via_chrome9_display_common.h"
#include "via_chrome9_fence.h"

#define HOTPLUG_ENABLE  1

extern bool hdmi_force_connect;

extern void via_chrome9_init_interrupt_devices(struct drm_device *dev);
extern int via_chrome9_update_hd_audio_par(DWORD dwDevice, 
	ULONG HDMIConnectFormat, DWORD *CTS, DWORD *CTSInterval);
	
/* fence IRQ handle function. */
static irqreturn_t via_chrome9_fence_irq_handler(
		struct drm_via_chrome9_private *dev_priv)
{
	int interrupt_status2 = 0;
	interrupt_status2 = getmmioregister(dev_priv->mmio_map,
		INTERRUPTCTLREG2);
	if (interrupt_status2 & CR_INT_STATUS) {
		setmmioregister(dev_priv->mmio_map, INTERRUPTCTLREG2,
			interrupt_status2 | CR_INT_STATUS);
		/* must read these registers,
		read fence id high 8 and low 24 bits */
		getmmioregister(dev_priv->mmio_map, 0x494);
		getmmioregister(dev_priv->mmio_map, 0x49c);
		queue_work(dev_priv->p_fence->fence_wq,
			&dev_priv->p_fence->fence_work);
		return IRQ_HANDLED;
	}
	return IRQ_NONE;
}

/* vblank IRQ handle function. */
static irqreturn_t via_chrome9_vblank_irq_handler(
		struct drm_via_chrome9_private *dev_priv)
{
	int interrupt_status = 0;
	int ret = 0;

	interrupt_status = getmmioregister(dev_priv->mmio_map,
		INTERRUPT_CONTROL_REG);
	if (interrupt_status & VIA_IRQ_IGA1_VSYNC_STS) {
		setmmioregister(dev_priv->mmio_map, INTERRUPT_CONTROL_REG,
			(interrupt_status & Intterupt_Status_Mask)
			| VIA_IRQ_ALL_EN | VIA_IRQ_IGA1_VSYNC_STS);
		drm_handle_vblank(dev_priv->ddev, 0);
		ret = 1;
	}
	if (interrupt_status & VIA_IRQ_IGA2_VSYNC_STS) {
		setmmioregister(dev_priv->mmio_map, INTERRUPT_CONTROL_REG,
			(interrupt_status & Intterupt_Status_Mask)
			|VIA_IRQ_ALL_EN | VIA_IRQ_IGA2_VSYNC_STS);
		drm_handle_vblank(dev_priv->ddev, 1);
		ret = 1;
	}

	if (ret) {
		return IRQ_HANDLED;
	}
	return IRQ_NONE;
}

/**
 * when we set the irq mask enable bit, the irq status bit will be set by 1,
 * whether the device was connected or not,so then trigger interrupt right now.
 * so we should write 1 to clear the status bit when enable irq mask.
 */
static void via_chrome9_hpd_irq_set(struct drm_device *dev)
{    
    struct drm_via_chrome9_private *p_priv =
	(struct drm_via_chrome9_private *)dev->dev_private;
    
	if (true == p_priv->irq.irq_all)
	/* enable GFX interrupt mm200[31] */
	MMIO_WR(INTERRUPT_CONTROL_REG, 
		(MMIO_RD(INTERRUPT_CONTROL_REG) | BIT31));
	via_chrome9_init_interrupt_devices(dev);
}

void via_chrome9_hpd_init(struct drm_device *dev)
{

#if HOTPLUG_ENABLE
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	KMS_DEBUG("HOTPLUG ENABLED.\n");

	dev_priv->irq.irq_all = true;

	/* DVP1.  */
	dev_priv->irq.dvp1_sense_int = true;
	/* DP1.  */
	dev_priv->irq.dp_sense_int[0] = true;
	/* DP2.  */
	dev_priv->irq.dp_sense_int[1] = true;

	/* Internal DVI */
	if (VX800_DEVICE == dev->pci_device)
		dev_priv->irq.internal_tmds_sense_int = true;

	if (dev_priv->irq.installed)
		via_chrome9_hpd_irq_set(dev);
#endif

	KMS_DEBUG("hpd initialized.\n");
}

void via_chrome9_hpd_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	dev_priv->irq.irq_all = false;
}

static irqreturn_t via_chrome9_hpd_irq_process(
		struct drm_via_chrome9_private *dev_priv)
{
	irqreturn_t ret = IRQ_NONE;
	bool queue_hotplug = false;
	int queue_work_status;
	u32 mm_200, mm_1280;
	u32 mm_c730, mm_c7b0;
	int pci_device = dev_priv->ddev->pci_device;

	/* bak 0x3c4 (SR_REG index) */
	u8 reg_3c4_save = STANDVGA_R8(REG_ZSR);
	/* bak 0x3d4 (CR_REG index) */
	u8 reg_3d4_save = STANDVGA_R8(REG_ZCR);

	mm_200 = MMIO_RD(0x200);
	mm_1280 = MMIO_RD(0x1280);

	/* bak IRQ variables for Interrupt Routine.*/
	dev_priv->hpd_mm200 = mm_200;
	dev_priv->hpd_mm1280 = mm_1280;

	KMS_DEBUG("************  mm_200 = 0x%x, mm_1280 = 0x%x  "
		"************\n", mm_200, mm_1280);

	/**
	 * only when 0x200[31] = 1, these IRQs can be triggered.
	 * we handler devices hotplug IRQs only.
	 */

	/* DP1 or Internal HDMI sense */
	if (VIA_IRQ_DP1_EN & mm_1280) {
		if (VIA_IRQ_DP1_STS & mm_1280) {
			mm_c730 = MMIO_RD(0xc730);
			switch (mm_c730 & 0xC0000000) {
			case VIA_IRQ_DP_HOT_IRQ:
				KMS_DEBUG("VIA_IRQ_DP1_HOT_IRQ!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_HOT_UNPLUG:
				KMS_DEBUG("VIA_IRQ_DP1(HDMI)_HOT_UNPLUG!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_HOT_PLUG:
				KMS_DEBUG("VIA_IRQ_DP1(HDMI)_HOT_PLUG!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_NO_INT:
				KMS_DEBUG("VIA_IRQ_DP1_NO_INT!\n");
				break;
			}
			ret = IRQ_HANDLED;
		}
	}

	/* DP2 sense */
	if (VIA_IRQ_DP2_EN & mm_1280) {
		if (VIA_IRQ_DP2_STS & mm_1280) {
			mm_c7b0 = MMIO_RD(0xc7b0);
			switch (mm_c7b0 & 0xC0000000) {
			case VIA_IRQ_DP_HOT_IRQ:
				KMS_DEBUG("VIA_IRQ_DP2_HOT_IRQ!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_HOT_UNPLUG:
				KMS_DEBUG("VIA_IRQ_DP2_HOT_UNPLUG!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_HOT_PLUG:
				KMS_DEBUG("VIA_IRQ_DP2_HOT_PLUG!\n");
				queue_hotplug = true;
				break;
			case VIA_IRQ_DP_NO_INT:
				KMS_DEBUG("VIA_IRQ_DP2_NO_INT!\n");
				break;
			}
			ret = IRQ_HANDLED;
		}
	}

	/* internal TMDS  sense */
	if (VX800_DEVICE == pci_device) {
		if (VIA_IRQ_IN_TMDS_EN & mm_1280) {
			if (VIA_IRQ_IN_TMDS_STS & mm_1280) {
				if (BIT5 & via_chrome9_read_vga_io(REG_SR3E))
					KMS_DEBUG("VIA_IRQ_INTERNAL_DVI_IRQ: connected!\n");
				else
					KMS_DEBUG("VIA_IRQ_INTERNAL_DVI_IRQ: disconnected!\n");

				KMS_DEBUG("SR3E=%x\n",
					via_chrome9_read_vga_io(REG_SR3E));
				queue_hotplug = true;
				ret = IRQ_HANDLED;
			}
		}
	}

	if(IRQ_HANDLED == ret) {
		/* clear interrupt status on 0x1280. */
		MMIO_WR(0x1280, mm_1280);
	}

	/* DVP1 device sense */
	if (VIA_IRQ_DVP1_EN & mm_200) {
		if (VIA_IRQ_DVP1_STS & mm_200) {
			KMS_DEBUG("VIA_IRQ_DVP1_SENSE_IRQ!\n");
			queue_hotplug = true;
			/* clear interrupt status on 0x200. */
			MMIO_WR(0x200, mm_200);
			ret = IRQ_HANDLED;
		}
	}

	/*Ignore hotplug if HDMI force connected */
	if(hdmi_force_connect)
	    queue_hotplug = 0;

	if (queue_hotplug) {		
		if (!work_pending(&dev_priv->hotplug_work)) {
			queue_work_status = queue_work(dev_priv->wq,
				&dev_priv->hotplug_work);
			KMS_DEBUG("queue work request %s !\n",
				(queue_work_status == 0) ? "failed" : "passed");
		} else {
			KMS_DEBUG("queue work list pending !\n");
		}
	}

	KMS_DEBUG("############  mm_200 = 0x%x," "mm_1280 = 0x%x  ############\n",
		MMIO_RD(0x200), MMIO_RD(0x1280));

	/* restore the SR_REG index */
	STANDVGA_W8(REG_ZSR, reg_3c4_save);
	/* restore the CR_REG index */
	STANDVGA_W8(REG_ZCR, reg_3d4_save);
	return ret;
}

static irqreturn_t via_chrome9_hdac_irq_process(
		struct drm_via_chrome9_private *dev_priv)
{
	u32 mm_c500 = MMIO_RD(0xC500);
	struct via_cb_connector_info *dev_info = dev_priv->hdmi_1_info;
	ULONG hdmi_conn_fmt = 0;
	u32 cts, cts_interval;

	if(NULL != dev_info)
		hdmi_conn_fmt = dev_info->hdmi_conn_fmt;

	/* hdac irq handler*/
	if (VIA_IRQ_HDAC1_EN & mm_c500) {
		if (VIA_IRQ_HDAC1_STS & mm_c500) {
			KMS_DEBUG("VIA_HDAC_IRQ!\n");
			/* clear hdac irq first. */
			MMIO_WR(0xC500, mm_c500);
			/**
			 *  Because of we couldn't get device type in IRQ process   
			 *  function, we pass dwDevice = 0 when call this function.
			 *  CBIOS will detect the device type when dwDevice = 0.
			 */
			via_chrome9_update_hd_audio_par(0, 
					hdmi_conn_fmt, &cts, &cts_interval);
			dev_priv->hdmi_cts_renew->interval = cts_interval;
			dev_priv->hdmi_cts_renew->cts = cts;
			dev_priv->hdmi_cts_renew->counter = 0;
			dev_priv->hdmi_cts_renew->feedback = 0;
			dev_priv->hdmi_cts_renew->increaser = 0;

			return IRQ_HANDLED;
		}
	}
	return IRQ_NONE;
}

void via_chrome9_connector_hotplug(struct drm_connector *connector)
{
	via_chrome9_send_unsolicited_response(connector);
}

void via_chrome_restore_previous_vsync(unsigned int mmio200_int_old)
{
    unsigned int mmio200_int_new = 0;
	/*
	 * aid for startx xserver can't full enter. 
	 * vsync only enable once, since cbios will re-init it to off, 
	 * dirver should save/restore it.
	 */
	KMS_DEBUG("mmio 200 old :0x%x",mmio200_int_old);

	mmio200_int_old &=(VIA_IRQ_IGA1_VSYNC_EN | VIA_IRQ_IGA1_VSYNC_STS |
		VIA_IRQ_IGA2_VSYNC_EN | VIA_IRQ_IGA2_VSYNC_STS);

	mmio200_int_new = MMIO_RD(INTERRUPT_CONTROL_REG);
	mmio200_int_new &= ~(VIA_IRQ_IGA1_VSYNC_EN | VIA_IRQ_IGA1_VSYNC_STS |
		VIA_IRQ_IGA2_VSYNC_EN | VIA_IRQ_IGA2_VSYNC_STS);
	mmio200_int_new |= mmio200_int_old;
	MMIO_WR(INTERRUPT_CONTROL_REG, mmio200_int_new);

	KMS_DEBUG("mmio 200 restore use :0x%x",mmio200_int_new);
}

/*
 * Handle hotplug events outside the interrupt handler proper.
 */
static void via_chrome9_hotplug_work_func(struct work_struct *work)
{
	struct drm_via_chrome9_private *dev_priv = container_of(work,
		struct drm_via_chrome9_private, hotplug_work);
	struct drm_device *dev = dev_priv->ddev;
	struct drm_mode_config *mode_config = &dev->mode_config;
	struct drm_connector *connector;
	
	KMS_DEBUG("\n");

	/* do hpd interrupt routine for ad9389 and dp hotplug. */
	via_chrome9_hpd_interrupt_routine(
		dev_priv->hpd_mm200, dev_priv->hpd_mm1280);

	schedule_timeout_uninterruptible(msecs_to_jiffies(500));
	KMS_DEBUG("Done delay 500ms, prepare for HPD send event!\n");

	if (mode_config->num_connector) {
		list_for_each_entry(connector, &mode_config->connector_list, head)
		via_chrome9_connector_hotplug(connector);
	}
	/* handle it in fb and fire off a uevent and
	let userspace tell us what to do */
	drm_helper_hpd_irq_event(dev);
}

/*=== IRQ function define in KMS path ===*/
void via_chrome9_driver_irq_preinstall(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	u8 i;

	KMS_DEBUG("\n");
	INIT_WORK(&dev_priv->hotplug_work, via_chrome9_hotplug_work_func);
	/* Disable *all* interrupts */
	for (i = 0; i < 2; i++)
		dev_priv->irq.dp_sense_int[i] = false;
	dev_priv->irq.dvp1_sense_int = false;
	dev_priv->irq.internal_tmds_sense_int = false;

	via_chrome9_hpd_irq_set(dev);

#if HOTPLUG_ENABLE
	/* Clear bits */
	via_chrome9_hpd_irq_process(dev_priv);
#endif
}

int via_chrome9_driver_irq_postinstall(struct drm_device *dev)
{
	return 0;
}

void via_chrome9_driver_irq_uninstall(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	u8 i;

	if (dev_priv == NULL)
		return;

	/* Disable *all* interrupts */
	for (i = 0; i < 2; i++)
		dev_priv->irq.dp_sense_int[i] = false;

	dev_priv->irq.dvp1_sense_int = false;

	if (VX800_DEVICE == dev->pci_device)
		dev_priv->irq.internal_tmds_sense_int = false;

	via_chrome9_irq_uninstall_nonKMS(dev_priv);
	/* via_chrome9_hpd_irq_set(dev); */
}

irqreturn_t via_chrome9_driver_irq_handler(DRM_IRQ_ARGS)
{
	struct drm_device *dev = (struct drm_device *) arg;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (via_chrome9_fence_irq_handler(dev_priv) == IRQ_HANDLED)
		return IRQ_HANDLED;

	/* handle vblank irq */
	if (via_chrome9_vblank_irq_handler(dev_priv) == IRQ_HANDLED)
		return IRQ_HANDLED;

	/* handle hdac irq,  VX855&VX800 no need to handle hdac irq */
	if (VX900_DEVICE == dev->pci_device){
		if (via_chrome9_hdac_irq_process(dev_priv) == IRQ_HANDLED)
			return IRQ_HANDLED;
	}

	/* handle hotplug irq */
	return via_chrome9_hpd_irq_process(dev_priv);
}

int via_chrome9_enable_vblank(struct drm_device *dev, int crtc)
{
	u32 mm_200;

	if (crtc < 0 || crtc >= dev->num_crtcs) {
		DRM_ERROR("Invalid crtc %d\n", crtc);
		return -EINVAL;
	}

	mm_200 = MMIO_RD(INTERRUPT_CONTROL_REG);
	if (crtc == 0) {
		mm_200 |= VIA_IRQ_IGA1_VSYNC_EN | VIA_IRQ_IGA1_VSYNC_STS;
		via_chrome9_write_vga_io_bits(REG_CRF3, 0, BIT1);
		via_chrome9_write_vga_io_bits(REG_CR11, BIT4, BIT4);
	}
	if (crtc == 1) {
		mm_200 |= VIA_IRQ_IGA2_VSYNC_EN | VIA_IRQ_IGA2_VSYNC_STS;
		via_chrome9_write_vga_io_bits(REG_CRF3, 0, BIT1);
		via_chrome9_write_vga_io_bits(REG_CR11, BIT4, BIT4);
	}

	MMIO_WR(INTERRUPT_CONTROL_REG, mm_200);
	return 0;
}

void via_chrome9_disable_vblank(struct drm_device *dev, int crtc)
{
	u32 mm_200;

	if (crtc < 0 || crtc >= dev->num_crtcs) {
		DRM_ERROR("Invalid crtc %d\n", crtc);
		return;
	}

	mm_200 = MMIO_RD(INTERRUPT_CONTROL_REG);
	if (crtc == 0)
		mm_200 &= ~VIA_IRQ_IGA1_VSYNC_EN;
	if (crtc == 1)
		mm_200 &= ~VIA_IRQ_IGA2_VSYNC_EN;

	MMIO_WR(INTERRUPT_CONTROL_REG, mm_200);
}

/*=== IRQ function define in non-KMS path ===*/
void via_chrome9_irq_preinstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv)
{

}

void via_chrome9_irq_uninstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv)
{
	unsigned long interrupt_status;
	interrupt_status = getmmioregister(dev_priv->mmio_map,
		INTERRUPT_CONTROL_REG);
	/*if other interrupt enable bits are not set,
	then dsiable hw gfx's intertupt*/
	if (!(interrupt_status & INTERRUPT_ENABLE_MASK))
		setmmioregister(dev_priv->mmio_map, INTERRUPT_CONTROL_REG,
			interrupt_status & (~INTERRUPT_ENABLE));
}

void via_chrome9_irq_postinstall_nonKMS(
		struct drm_via_chrome9_private *dev_priv)
{
	unsigned long interrupt_status = 0;

	interrupt_status = getmmioregister(dev_priv->mmio_map,
		INTERRUPT_CONTROL_REG);
	if (!(interrupt_status & INTERRUPT_ENABLE))
		setmmioregister(dev_priv->mmio_map, INTERRUPT_CONTROL_REG,
			INTERRUPT_ENABLE);
}

irqreturn_t via_chrome9_driver_irq_handler_nonKMS(DRM_IRQ_ARGS)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)arg;
	u32 mm_1280;

	if (via_chrome9_fence_irq_handler(dev_priv) == IRQ_HANDLED)
		return IRQ_HANDLED;

	/* add dp(hdmi), dp-2 irq handle on non-KMS path. */
	mm_1280 = getmmioregister(dev_priv->mmio_map, 0x1280);
	if (0x2800 & mm_1280) {
		setmmioregister(dev_priv->mmio_map, 0x1280, mm_1280);
		return IRQ_HANDLED;
	}

	return IRQ_NONE;
}


