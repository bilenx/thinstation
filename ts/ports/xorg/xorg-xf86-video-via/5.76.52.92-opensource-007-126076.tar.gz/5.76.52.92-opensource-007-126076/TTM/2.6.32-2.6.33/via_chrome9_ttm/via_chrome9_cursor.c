/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_cursor.h"
#include "via_chrome9_object.h"

struct via_chrome9_cursor {
	struct drm_gem_object *cursor_bo;
	uint32_t cursor_addr;
	int cursor_width;
	int cursor_height;
	void *private;
};

static void via_chrome9_hide_cursor(struct drm_crtc *crtc)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	unsigned int hw_icon_control;

	switch (via_chrome9_crtc->crtc_id) {
	case IGA1:
		hw_icon_control = VIA_CHROME9_READ(PRIM_HI_CTRL);
		/* Turn hardware icon cursor off. */
		VIA_CHROME9_WRITE(PRIM_HI_CTRL, hw_icon_control & 0xFFFFFFFA);
		break;
	case IGA2:
		hw_icon_control = VIA_CHROME9_READ(HI_CONTROL);
		/* Turn hardware icon cursor off. */
		VIA_CHROME9_WRITE(HI_CONTROL, hw_icon_control & 0xFFFFFFFA);
		break;
	default:
		KMS_DEBUG("can not hide the cursor for crtc=%d\n",
			via_chrome9_crtc->crtc_id);
		break;
	}
}

static void via_chrome9_set_cursor(struct drm_crtc *crtc, uint64_t gpu_addr)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	u8 cr_a2, cr_fd;

	switch (via_chrome9_crtc->crtc_id) {
	case IGA1:
		VIA_CHROME9_WRITE(PRIM_HI_FBOFFSET, gpu_addr);

		/* Read IGA1 scaling setting */
		cr_fd = via_chrome9_read_vga_io(REG_CRFD);
		via_chrome9_write_vga_io_bits(REG_CRFD, BIT7, BIT7);
		cr_a2 = via_chrome9_read_vga_io(REG_CRA2);
		via_chrome9_write_vga_io(REG_CRFD, cr_fd);

		/* turn on Hardware icon Cursor */
		if (cr_a2 & (BIT3 + BIT7))  {
			/* enable IGA1 scaling. */
			VIA_CHROME9_WRITE(PRIM_HI_CTRL, 0x36000007);
		} else {
			VIA_CHROME9_WRITE(PRIM_HI_CTRL, 0x36000005);
		}

		break;
	case IGA2:
		VIA_CHROME9_WRITE(HI_FBOFFSET, gpu_addr);
		/* turn on Hardware icon Cursor */
		VIA_CHROME9_WRITE(HI_CONTROL, 0xB6000005);
		break;
	default:
		KMS_DEBUG("can not set the cursor for crtc=%d\n",
			via_chrome9_crtc->crtc_id);
		break;
	}
}

int via_chrome9_crtc_cursor_set(struct drm_crtc *crtc,
		struct drm_file *file_priv,
		uint32_t handle, uint32_t width, uint32_t height)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = via_chrome9_crtc->base.dev;
	struct drm_gem_object *obj;
	struct via_chrome9_object *vbo;
	uint64_t gpu_addr;
	int ret = 0;

	if (!handle) {
		/* turn off cursor */
		via_chrome9_hide_cursor(crtc);
		obj = NULL;
		goto unpin;
	}

	if ((width > CURSOR_WIDTH) || (height > CURSOR_HEIGHT)) {
		DRM_ERROR("bad cursor width or height %d x %d\n",
			width, height);
		return -EINVAL;
	}

	obj = drm_gem_object_lookup(crtc->dev, file_priv, handle);
	if (!obj) {
		DRM_ERROR("Cannot find cursor object %x for crtc %d\n",
			handle, via_chrome9_crtc->crtc_id);
		return -ENOENT;
	}

	/*pin this buffer*/
	vbo = obj->driver_private;
	ret = via_chrome9_bo_pin(vbo, TTM_PL_FLAG_VRAM, &gpu_addr);
	via_chrome9_set_cursor(crtc, gpu_addr);
unpin:
	if (via_chrome9_crtc->cursor_bo) {
		via_chrome9_bo_unpin(via_chrome9_crtc->cursor_bo->driver_private);
	     	mutex_lock(&dev->struct_mutex);
	      	drm_gem_object_unreference(via_chrome9_crtc->cursor_bo);
	      	mutex_unlock(&dev->struct_mutex);
	}

	via_chrome9_crtc->cursor_bo = obj;
	return ret;
}

/*Compute the cursor position*/
static void get_crtc_cursor_real_position(int x, int y, int *xpos, int *ypos,
		unsigned char *xoff, unsigned char *yoff)
{
	/*compute x*/
	if (x < 0) {
		*xpos = 0;
		*xoff = (-x) & 0xFF;
	} else {
		*xpos = x;
		*xoff = 0;
	}

	/*compute y*/
	if (y < 0) {
		*ypos = 0;
		*yoff = (-y) & 0xFF;
	} else {
		*ypos = y;
		*yoff = 0;
	}
}

int via_chrome9_crtc_cursor_move(struct drm_crtc *crtc, int x, int y)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);
	struct drm_device *dev = crtc->dev;
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int xpos, ypos;
	unsigned char xoff, yoff;

	/*1.Get IGA cursor position*/
	get_crtc_cursor_real_position(x, y, &xpos, &ypos, &xoff, &yoff);

	switch (via_chrome9_crtc->crtc_id) {
	case IGA1:
		VIA_CHROME9_WRITE(PRIM_HI_POSSTART,
			((xpos << 16) | (ypos & 0x07ff)));
		VIA_CHROME9_WRITE(PRIM_HI_CENTEROFFSET,
			((xoff << 16) | (yoff & 0x07ff)));
		break;
	case IGA2:
		VIA_CHROME9_WRITE(HI_POSSTART,
			((xpos << 16) | (ypos & 0x07ff)));
		VIA_CHROME9_WRITE(HI_CENTEROFFSET,
			((xoff << 16) | (yoff & 0x07ff)));
		break;
	default:
		KMS_DEBUG("can not set the cursor position for crtc=%d\n",
			via_chrome9_crtc->crtc_id);
		break;
	}

	return 0;
}

void via_chrome9_hw_cursor_init(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	unsigned int hw_icon_control;

	/* set 0 as transparent color key */
	VIA_CHROME9_WRITE(PRIM_HI_TRANSCOLOR, 0);
	VIA_CHROME9_WRITE(PRIM_HI_FIFO, 0x0D000D0F);
	VIA_CHROME9_WRITE(PRIM_HI_INVTCOLOR, 0X00FFFFFF);
	VIA_CHROME9_WRITE(V327_HI_INVTCOLOR, 0X00FFFFFF);

	/* set 0 as transparent color key */
	VIA_CHROME9_WRITE(HI_TRANSPARENT_COLOR, 0);
	VIA_CHROME9_WRITE(HI_INVTCOLOR, 0X00FFFFFF);
	VIA_CHROME9_WRITE(ALPHA_V3_PREFIFO_CONTROL, 0xE0000);
	VIA_CHROME9_WRITE(ALPHA_V3_FIFO_CONTROL, 0xE0F0000);
	hw_icon_control = VIA_CHROME9_READ(HI_CONTROL);

	/* Turn cursor off. */
	VIA_CHROME9_WRITE(HI_CONTROL, hw_icon_control & 0xFFFFFFFA);
}
