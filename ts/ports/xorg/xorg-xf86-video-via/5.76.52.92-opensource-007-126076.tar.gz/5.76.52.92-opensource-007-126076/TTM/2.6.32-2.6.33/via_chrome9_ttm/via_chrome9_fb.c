/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/string.h>

#include "via_chrome9_drv.h"
#include "drm_fb_helper.h"
#include "via_chrome9_fb.h"
#include "via_chrome9_gem.h"
#include "via_chrome9_object.h"
#include <video/vga.h>
#include <linux/fb.h>
#include <linux/vt.h>

struct via_chrome9_fbdev {
	struct drm_fb_helper helper;
	struct via_chrome9_framebuffer vfb;
	struct list_head fbdev_list;
	struct drm_device *ddev;
	struct vgastate state;
};

struct fb_cmd {
	char name[15];
	char val[15];
};

typedef void (*fb_parse)(struct fb_cmd *cmd_table, int num, void *ret_data);
struct parse_table {
	char name[10];
	fb_parse func;
};

static struct drm_fb_helper_funcs via_chrome9_fb_helper_funcs;
static struct fb_ops via_chrome9_fb_ops = {
	.owner = THIS_MODULE,
	.fb_check_var = drm_fb_helper_check_var,
	.fb_set_par = drm_fb_helper_set_par,
	.fb_setcolreg = drm_fb_helper_setcolreg,
	.fb_fillrect = cfb_fillrect,
	.fb_copyarea = cfb_copyarea,
	.fb_imageblit = cfb_imageblit,
	.fb_pan_display = drm_fb_helper_pan_display,
	.fb_blank = drm_fb_helper_blank,
	.fb_setcmap = drm_fb_helper_setcmap,
};

static void via_chrome9_user_framebuffer_destroy(struct drm_framebuffer *fb)
{
	struct via_chrome9_framebuffer *via_chrome9_fb =
		to_via_chrome9_framebuffer(fb);
	struct drm_device *dev = fb->dev;

	if (via_chrome9_fb->obj) {
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(via_chrome9_fb->obj);
		mutex_unlock(&dev->struct_mutex);
	}
	drm_framebuffer_cleanup(fb);
	kfree(via_chrome9_fb);
}

static int via_chrome9_user_framebuffer_create_handle(
		struct drm_framebuffer *fb,
		struct drm_file *file_priv,
		unsigned int *handle)
{
	struct via_chrome9_framebuffer *via_chrome9_fb =
		to_via_chrome9_framebuffer(fb);

	return drm_gem_handle_create(file_priv, via_chrome9_fb->obj, handle);
}

static const struct drm_framebuffer_funcs via_chrome9_fb_funcs = {
	.destroy = via_chrome9_user_framebuffer_destroy,
	.create_handle = via_chrome9_user_framebuffer_create_handle,
};

void via_chrome9_fb_gamma_set(struct drm_crtc *crtc, u16 red, u16 green,
		u16 blue, int regno)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);

	via_chrome9_crtc->lut_r[regno] = red >> 8;
	via_chrome9_crtc->lut_g[regno] = green >> 8;
	via_chrome9_crtc->lut_b[regno] = blue >> 8;
}

void via_chrome9_fb_gamma_get(struct drm_crtc *crtc, u16 *red, u16 *green,
		 u16 *blue, int regno)
{
	struct via_chrome9_crtc *via_chrome9_crtc = to_via_chrome9_crtc(crtc);

	*red = via_chrome9_crtc->lut_r[regno] << 8;
	*green = via_chrome9_crtc->lut_g[regno] << 8;
	*blue = via_chrome9_crtc->lut_b[regno] << 8;
}

static int via_chrome9_allocate_fb_object(struct via_chrome9_fbdev *vfbdev,
		int size, struct drm_gem_object **p_gobj)
{
	struct drm_device *ddev = vfbdev->ddev;
	struct drm_gem_object *gobj = NULL;
	struct via_chrome9_object *vbo = NULL;
	int ret;

	/* allocate fb bo */
	ret = via_chrome9_gem_object_create(ddev, size, 0, TTM_PL_FLAG_VRAM,
		true, true, &gobj);
	if (unlikely(ret)) {
		KMS_DEBUG("allocate the fb buffer error\n");
		return ret;
	}

	vbo = gobj->driver_private;

	/* pin this fb bo */
	ret = via_chrome9_bo_pin(vbo, TTM_PL_FLAG_VRAM, NULL);
	if (unlikely(ret)) {
		KMS_DEBUG("pin the fb buffer error\n");
		return ret;
	}

	/* map this fb bo */
	ret = via_chrome9_buffer_object_kmap(vbo, NULL);
	if (unlikely(ret)) {
		DRM_ERROR("kmap the fb buffer error");
		return ret;
	}

	*p_gobj = gobj;
	return 0;
}

void
via_chrome9_framebuffer_init(struct drm_device *dev,
		struct via_chrome9_framebuffer *vfb,
		struct drm_mode_fb_cmd *mode_cmd,
		struct drm_gem_object *obj)
{
	vfb->obj = obj;
	drm_framebuffer_init(dev, &vfb->base, &via_chrome9_fb_funcs);
	drm_helper_mode_fill_fb_struct(&vfb->base, mode_cmd);
	
}

struct drm_framebuffer *
via_chrome9_user_framebuffer_create(struct drm_device *dev,
		struct drm_file *file_priv,
		struct drm_mode_fb_cmd *user_mode)
{
	struct drm_gem_object *gobj;
	struct via_chrome9_framebuffer *via_chrome9_fb;

	gobj = drm_gem_object_lookup(dev, file_priv, user_mode->handle);
	if (gobj ==  NULL) {
		KMS_DEBUG("No FB object found handle= 0x%08X\n",
			user_mode->handle);
		return ERR_PTR(-ENOENT);
	}

	via_chrome9_fb = kzalloc(sizeof(*via_chrome9_fb), GFP_KERNEL);
	if (via_chrome9_fb == NULL)
		return ERR_PTR(-ENOMEM);

	/* fullfill the user mode to this fb */
	via_chrome9_framebuffer_init(dev, via_chrome9_fb, user_mode, gobj);

	return &via_chrome9_fb->base;
}

static int via_chrome9_fb_create(struct drm_device *ddev,
		    uint32_t fb_width, uint32_t fb_height,
		    uint32_t surface_width, uint32_t surface_height,
		    uint32_t surface_depth, uint32_t surface_bpp,
		    struct drm_framebuffer **fb_p)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)ddev->dev_private;
	struct fb_info *info;
	struct via_chrome9_fbdev *vfbdev = NULL;
	struct drm_framebuffer *fb = NULL;
	struct drm_mode_fb_cmd mode_cmd;
	struct drm_gem_object *gobj = NULL;
	struct via_chrome9_object *vbo = NULL;
	struct device *device = &ddev->pdev->dev;
	int size, ret;

	mode_cmd.width = surface_width;
	mode_cmd.height = surface_height;

	if (surface_bpp == 24)
		surface_bpp = 32;

	mode_cmd.bpp = surface_bpp;
	mode_cmd.depth = surface_depth;

	mode_cmd.pitch = mode_cmd.width * (mode_cmd.bpp >> 3);
	mode_cmd.pitch = roundup(mode_cmd.pitch, 16);
	mode_cmd.depth = surface_depth;

	size = mode_cmd.pitch * mode_cmd.height;
	size = roundup(size, PAGE_SIZE);


	mutex_lock(&ddev->struct_mutex);	
	info = framebuffer_alloc(sizeof(struct via_chrome9_fbdev), device);
	if (info == NULL) {
		ret = -ENOMEM;
		goto failure;
	}

	/*setup vfbdev*/
	vfbdev = info->par;
	vfbdev->ddev = ddev;

	ret = via_chrome9_allocate_fb_object(vfbdev, size, &gobj);
	via_chrome9_framebuffer_init(ddev, &vfbdev->vfb, &mode_cmd, gobj);
	vbo = gobj->driver_private;
	p_priv->mode_info.vfbdev = vfbdev;
	vfbdev->helper.funcs = &via_chrome9_fb_helper_funcs;

	fb = &vfbdev->vfb.base;
	list_add(&fb->filp_head, &ddev->mode_config.fb_kernel_list);
	*fb_p = fb;
	fb->fbdev = info;
	p_priv->fb_info = info;
	/* setup helper */
	vfbdev->helper.fb = fb;
	vfbdev->helper.dev = ddev;

	ret = drm_fb_helper_init_crtc_count(&vfbdev->helper,
			 p_priv->num_crtc,
			 VIA_CHROME9_CONNECTOR_LIMIT);
	if (ret) {
		KMS_DEBUG("drm_fb_helper_init_crtc_count error \n");
		goto failure;
	}

	/* memset the fb buffer default value */
	memset_io(vbo->ptr, 0x0, size);

	strcpy(info->fix.id, "viachrome9drmfb");

	/* disable the hw accel as the temp solution */
	info->flags = FBINFO_DEFAULT;
	info->fbops = &via_chrome9_fb_ops;

	/* fb buffer physical address */
	info->fix.smem_start = p_priv->vram_start + vbo->bo.offset;
	/* fb buffer size */
	info->fix.smem_len = size;
	/* fb buffer virtual address */
	info->screen_base = vbo->ptr;
	/* fb buffer size */
	info->screen_size = size;

	drm_fb_helper_fill_fix(info, fb->pitch, fb->depth);
	drm_fb_helper_fill_var(info, fb, fb_width, fb_height);

	info->aperture_base = p_priv->vram_start;
	info->aperture_size = p_priv->vram_size;

	info->fix.mmio_start = pci_resource_start(ddev->pdev, 1);
	info->fix.mmio_len = pci_resource_len(ddev->pdev, 1);
	info->pixmap.size = 64*1024;
	info->pixmap.buf_align = 8;
	info->pixmap.access_align = 32;
	info->pixmap.flags = FB_PIXMAP_SYSTEM;
	info->pixmap.scan_align = 1;

	if (info->screen_base == NULL) {
		ret = -ENOSPC;
		goto failure;
	}

	ret = fb_alloc_cmap(&info->cmap, 256, 0);
	if (ret) {
		ret = -ENOMEM;
		goto failure;
	}

	/* save the standard vga state */
	memset(&vfbdev->state, 0, sizeof(struct vgastate));
	vfbdev->state.flags = VGA_SAVE_MODE | VGA_SAVE_FONTS | VGA_SAVE_CMAP;
	vfbdev->state.vgabase = p_priv->mmio_map;
	save_vga(&vfbdev->state);

	mutex_unlock(&ddev->struct_mutex);
	KMS_DEBUG("fb width=%d  height=%d \n",mode_cmd.width, mode_cmd.height);
	KMS_DEBUG("fb start=0x%lx  length=0x%x \n",info->fix.smem_start, size);

	//vga_switcheroo_client_fb_set(ddev->pdev, info);
	
	return 0;

failure:
	KMS_DEBUG("fb probe error \n");
	if (fb && ret) {
		list_del(&fb->filp_head);
		drm_gem_object_unreference(gobj);
		drm_framebuffer_cleanup(fb);
		kfree(fb);
	}
	mutex_unlock(&ddev->struct_mutex);
	return ret;
	
}
int via_chrome9_fbdev_destroy(struct drm_device *dev,
	struct drm_framebuffer *fb)
{
	struct fb_info *info;
	struct via_chrome9_framebuffer *vfb = 
			to_via_chrome9_framebuffer(fb);
	struct via_chrome9_object *vbo = NULL;
	struct via_chrome9_fbdev *vfbdev = NULL;
	int ret = 0;

	if (!fb) 
		return -EINVAL;
	
	info = fb->fbdev;
	if (!info)
		return 0;
	vfbdev = info->par;
	unregister_framebuffer(info);
	if (info->cmap.len)
	fb_dealloc_cmap(&info->cmap);

	if (vfb->obj) {
		vbo = vfb->obj->driver_private;
		via_chrome9_buffer_object_kunmap(vbo);
		ret = via_chrome9_bo_unpin(vbo);
		if (ret) {
			KMS_DEBUG("unpin fb buffer error \n");
			return ret;
		}
		drm_fb_helper_free(&vfbdev->helper);
		drm_framebuffer_cleanup(fb);
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(vfb->obj);
		mutex_unlock(&dev->struct_mutex);
		vfb->obj = NULL;
	}
	
	list_del(&((vfb->base).filp_head));

	framebuffer_release(info);
	
	return 0;
}


void via_chrome9_fbdev_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_chrome9_fbdev *vfbdev = p_priv->mode_info.vfbdev;

	if (!vfbdev)
		return;
	via_chrome9_fbdev_destroy(dev, &(vfbdev->vfb.base));

	p_priv->mode_info.vfbdev = NULL;
	
}


static struct drm_fb_helper_funcs via_chrome9_fb_helper_funcs = {
	.gamma_set = via_chrome9_fb_gamma_set,
	.gamma_get = via_chrome9_fb_gamma_get,
};


int via_chrome9_fb_probe(struct drm_device *dev)
{
	int ret = 0;
	ret = drm_fb_helper_single_fb_probe(dev, 32, &via_chrome9_fb_create);
	return ret;
}

static void via_chrome9_lcd_parse(struct fb_cmd *cmd_table,
		int num, void *ret_data)
{
	struct via_lcd_options *lcd_opts = ret_data;
	char *c = NULL;
	int i;


	printk(KERN_DEBUG "enter %s\n", __func__);


	for (i = 0; i < num; i++) {
		if (!strcmp(cmd_table[i].name, "DualChannel")) {
			if (!strcmp(cmd_table[i].val, "True"))
				lcd_opts->dual_channel = 1;
			else
				lcd_opts->dual_channel = 0;
		}

		if (!strcmp(cmd_table[i].name, "Dithering")) {
			if (!strcmp(cmd_table[i].val, "True"))
				lcd_opts->no_dithering = 0;
			else
				lcd_opts->no_dithering = 1;
		}

		if (!strcmp(cmd_table[i].name, "Center")) {
			if (!strcmp(cmd_table[i].val, "True"))
				lcd_opts->center = 1;
			else
				lcd_opts->center = 0;
		}

		if (!strcmp(cmd_table[i].name, "MSB")) {
			if (!strcmp(cmd_table[i].val, "True"))
				lcd_opts->msb = 1;
			else
				lcd_opts->msb = 0;
		}

		if (!strcmp(cmd_table[i].name, "FixOnIGA1")) {
			if (!strcmp(cmd_table[i].val, "True"))
				lcd_opts->fix_on_iga1 = 1;
			else
				lcd_opts->fix_on_iga1 = 0;
		}

		if (!strcmp(cmd_table[i].name, "PanelSize")) {
			c = strchr(cmd_table[i].val, 'x');
			lcd_opts->physical_height = simple_strtol(c + 1, NULL, 10);
			lcd_opts->physical_width = 
				simple_strtol(cmd_table[i].val, NULL, 10);
			lcd_opts->panel_index = VIA_MAKE_ID(lcd_opts->physical_width,
						lcd_opts->physical_height);
		}
	}
}

static struct parse_table via_chrome9_fb_parse_table[] = {
	{"LCD1", via_chrome9_lcd_parse},
	{"LCD2", via_chrome9_lcd_parse},
	{"LCD3", via_chrome9_lcd_parse},
};
#define NUM_OF_VIA_CHROME9_FB_PARSE ARRAY_SIZE(via_chrome9_fb_parse_table)


static int via_chrome9_cmd_recurse_parse(struct fb_cmd *cmd_table,
		char *options, int len)
{
	char *a, *b;

	if (len == 0)
		return 0;
	a = strchr(options, ',');
	b = strchr(options, '=');

	if (a != NULL) {
		strncpy(cmd_table->name, options, b - options);
		strncpy(cmd_table->val, b + 1, a - (b + 1));
	} else {
		strncpy(cmd_table->name, options, b - options);
		strncpy(cmd_table->val, b + 1, len - (b - options));
		return 1;
	}

	return 1 + via_chrome9_cmd_recurse_parse(cmd_table + 1,
			a + 1, len - (a - options) - 1);
}

static int via_chrome9_cmd_parse(struct fb_cmd *cmd_table, char *options)
{
	int cmd_len;

	cmd_len = strlen(options);
	return via_chrome9_cmd_recurse_parse(cmd_table, options, cmd_len);
}

int via_chrome9_fb_cmd_parse(char *name, void *ret_data)
{
	char *options = NULL;
	struct fb_cmd *cmd_opt;
	int index;
	int num;
	int ret = 0;

	printk(KERN_DEBUG "enter %s\n", __func__);
	cmd_opt = kzalloc(sizeof(struct fb_cmd) * 10, GFP_KERNEL);
	if (cmd_opt == NULL)
		return -ENOMEM;
	fb_get_options(name, &options);
	if (options == NULL) {
		ret = -ENODEV;
		goto out_err;
	}
	printk(KERN_INFO "%s cmd options is %s\n", name, options);
	for (index = 0; index < NUM_OF_VIA_CHROME9_FB_PARSE; index++) {
		if (!strcmp(name, via_chrome9_fb_parse_table[index].name))
			break;
	}

	if (index == NUM_OF_VIA_CHROME9_FB_PARSE) {
		ret = -ENODEV;
		goto out_err;
	}

	num = via_chrome9_cmd_parse(cmd_opt, options);

	via_chrome9_fb_parse_table[index].func(cmd_opt, num, ret_data);
out_err:
	kfree(cmd_opt);
	return ret;
}

void via_chrome9_restore_vga(struct drm_device *dev)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_chrome9_fbdev *vfbdev =
		(struct via_chrome9_fbdev *)p_priv->fb_info->par;

	restore_vga(&(vfbdev->state));
}
