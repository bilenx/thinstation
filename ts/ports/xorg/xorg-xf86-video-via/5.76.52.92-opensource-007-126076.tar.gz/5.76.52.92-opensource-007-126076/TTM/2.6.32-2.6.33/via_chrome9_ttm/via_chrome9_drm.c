/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "drmP.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_drv.h"
#include "via_chrome9_mm.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_object.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_gem.h"
#include "via_chrome9_reloc.h"
#include <ttm/ttm_bo_api.h>

extern PVOID pcbe;

int via_chrome9_ioctl_gem_create(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_create *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	uint32_t handle;
	int ret;

	ret = via_chrome9_gem_object_create(dev, args->size, args->alignment,
		args->initial_domain, false, true, &gobj);
	if (ret) {
		DRM_ERROR("Failed to allocate a gem object ");
		return ret;
	}
	ret = drm_gem_handle_create(file_priv, gobj, &handle);
	if (ret) {
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
		return ret;
	}
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_handle_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);
	vobj = (struct via_chrome9_object *)gobj->driver_private;
	args->handle = handle;
	args->offset = vobj->bo.offset;

	return 0;
}

/* create BO from user space for read only */
int via_chrome9_ioctl_gem_user_create(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_user_create *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	uint32_t handle;
	int ret;

	ret = via_chrome9_gem_user_object_create(dev, args->size,
		args->alignment, (unsigned long)args->start_addr, true, &gobj);
	if (ret) {
		DRM_ERROR("Failed to allocate a gem object ");
		return ret;
	}
	ret = drm_gem_handle_create(file_priv, gobj, &handle);
	if (ret) {
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
		return ret;
	}
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_handle_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);
	vobj = (struct via_chrome9_object *)gobj->driver_private;
	args->handle = handle;
	args->offset = vobj->bo.offset;

	return 0;
}

int via_chrome9_ioctl_gem_mmap(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_mmap *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	int ret;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL)
		return -EINVAL;

	vobj = (struct via_chrome9_object *)gobj->driver_private;
	ret = via_chrome9_object_mmap(file_priv, vobj, args->size,
		&args->addr_ptr, &args->virtual);
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	return ret;
}

int via_chrome9_ioctl_gem_pread(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	return -1;
}

int via_chrome9_ioctl_gem_pwrite(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	return -1;
}

int via_chrome9_ioctl_gem_set_domain(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_set_domain *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	uint32_t domain = args->write_domain;

	int ret;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL)
		return -EINVAL;

	vobj = gobj->driver_private;

	vobj->pending_write_domain = args->write_domain &
			VIA_CHROME9_OBJ_DOMAIN_MASK;
	vobj->pending_read_domain = args->read_domains &
			VIA_CHROME9_OBJ_DOMAIN_MASK;

	if ((domain & VIA_CHROME9_OBJ_DOMAIN_MASK) == VIA_CHROME9_OBJ_DOMAIN_CPU)
		via_chrome9_object_wait(vobj, false);
	ret = via_chrome9_object_set_domain(vobj,
		domain & VIA_CHROME9_GEM_DOMAIN_MASK);
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	
	return ret;
}

int via_chrome9_ioctl_gem_wait(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_wait *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	bool no_wait;
	int ret;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL)
		return -EINVAL;

	no_wait = (args->no_wait != 0);
	vobj = gobj->driver_private;
	ret = via_chrome9_object_wait(vobj, no_wait);
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	return ret;
}

static inline void via_chrome9_get_cmd_type(
		struct via_chrome9_fence_object *fence, uint32_t  type)
{
	switch (type & VIA_CHROME9_CMD_MASK) {
	case VIA_CHROME9_CMD_2D:
		fence->type |= VIA_CHROME9_CMD_2D;
		break;
	case VIA_CHROME9_CMD_3D:
		fence->type |= VIA_CHROME9_CMD_3D;
		break;
	case VIA_CHROME9_CMD_VD:
		fence->type |= VIA_CHROME9_CMD_VD;
		break;
	case VIA_CHROME9_CMD_HQV0:
		fence->type |= VIA_CHROME9_CMD_HQV0;
		break;
	case VIA_CHROME9_CMD_HQV1:
		fence->type |= VIA_CHROME9_CMD_HQV1;
		break;
	case VIA_CHROME9_CMD_VIDEO:
		fence->type |= VIA_CHROME9_CMD_VIDEO;
		break;
	case VIA_CHROME9_CMD_DMA0:
		fence->type |= VIA_CHROME9_CMD_DMA0;
		break;
	case VIA_CHROME9_CMD_DMA1:
		fence->type |= VIA_CHROME9_CMD_DMA1;
		break;
	case VIA_CHROME9_CMD_DMA2:
		fence->type |= VIA_CHROME9_CMD_DMA2;
		break;
	case VIA_CHROME9_CMD_DMA3:
		fence->type |= VIA_CHROME9_CMD_DMA3;
		break;
	case VIA_CHROME9_CMD_GFX:
		if (!fence->type)
			fence->type |= VIA_CHROME9_CMD_GFX;
		break;
	default:
		BUG();
	}
}

#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
static void via_chrome9_engines_sync(
		struct drm_via_chrome9_gem_flush_parse *parse, uint32_t type)
{
	struct drm_via_chrome9_private *dev_priv = parse->fence->p_priv;


	if (!parse->wait_engines || parse->wait_engines ==
		VIA_CHROME9_OBJ_DOMAIN_VIDEO)
		return;

	if (parse->wait_engines & VIA_CHROME9_OBJ_DOMAIN_VIDEO)
		parse->wait_engines &= ~VIA_CHROME9_OBJ_DOMAIN_VIDEO;

	dev_priv->engine_ops.instert_sync_cmd(dev_priv->ddev,
		parse->wait_engines, type);
}
#if 0
static unsigned int
via_chrome9_get_domain_from_cmd_type(uint32_t type)
{
	switch (type & VIA_CHROME9_CMD_MASK) {
	case VIA_CHROME9_CMD_2D:
	case VIA_CHROME9_CMD_3D:
		return VIA_CHROME9_OBJ_DOMAIN_GFX;
	case VIA_CHROME9_CMD_VD:
		return VIA_CHROME9_OBJ_DOMAIN_VD;
	case VIA_CHROME9_CMD_HQV0:
		return VIA_CHROME9_OBJ_DOMAIN_HQV0;
	case VIA_CHROME9_CMD_HQV1:
		return VIA_CHROME9_OBJ_DOMAIN_HQV1;
	case VIA_CHROME9_CMD_VIDEO:
		return VIA_CHROME9_OBJ_DOMAIN_VIDEO;
	default:
		BUG();
	}
}
#endif
#endif

int via_chrome9_ioctl_gem_flush(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *) dev->dev_private;
	struct drm_via_chrome9_dma_manager *lpcmdmamanager =
		(struct drm_via_chrome9_dma_manager *) dev_priv->dma_manager;
	struct drm_via_chrome9_gem_flush *args = data;
	struct drm_via_chrome9_gem_flush_parse parse;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *cmd_vobj;
	int ret;

	memset(&parse, 0, sizeof(struct drm_via_chrome9_gem_flush_parse));

	mutex_lock(&lpcmdmamanager->command_flush_lock);
	ret = via_chrome9_parse_init(dev, file_priv, &parse, args);
	if (ret) {
		DRM_ERROR(" can not parse the exec buffer\n");
		via_chrome9_parse_fini(dev, file_priv, &parse, ret);
		mutex_unlock(&lpcmdmamanager->command_flush_lock);
		return -EFAULT;
	}

	ret = via_chrome9_parse_reloc(dev, file_priv, &parse);
	if (ret) {
		DRM_ERROR(" can not parse the reloc\n");
		via_chrome9_parse_fini(dev, file_priv, &parse, ret);
		mutex_unlock(&lpcmdmamanager->command_flush_lock);
		return -EFAULT;
	}
	/* add engines sync commands if necessary */
#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
	via_chrome9_engines_sync(&parse, args->flag);
#endif

	if (args->flag & VIA_CHROME9_FLUSH_BRANCH_BUFFER) {
		/* use branch buffer*/
		via_chrome9_get_cmd_type(parse.fence, args->flag);
		gobj = drm_gem_object_lookup(dev, file_priv,
			parse.exec_objects->cmd_bo_handle);
		if (!gobj) {
			mutex_lock(&dev->struct_mutex);
			drm_gem_object_unreference(gobj);
			mutex_unlock(&dev->struct_mutex);
			mutex_unlock(&lpcmdmamanager->command_flush_lock);
			return -EINVAL;
		}
		cmd_vobj = gobj->driver_private;
#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
		cmd_vobj->access_engine_type = args->flag &
			VIA_CHROME9_CMD_MASK;
#endif

		ret = via_chrome9_branchbuffer_flush(dev, cmd_vobj,
			parse.exec_objects->buffer_length, &parse);
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
	} else {
		if (args->flag & VIA_CHROME9_CMD_MASK)
			via_chrome9_get_cmd_type(parse.fence, args->flag);

		ret = via_chrome9_ringbuffer_flush(dev,
			(unsigned int *)(unsigned long)parse
			.exec_objects->buffer_ptr,
			parse.exec_objects->buffer_length, true, &parse);
	}
	if (ret) {
		DRM_ERROR(" can not flush the command\n");
		via_chrome9_parse_fini(dev, file_priv, &parse, ret);
		mutex_unlock(&lpcmdmamanager->command_flush_lock);
		return -EFAULT;
	}

	via_chrome9_parse_fini(dev, file_priv, &parse, ret);
	mutex_unlock(&lpcmdmamanager->command_flush_lock);

	return 0;
}

int via_chrome9_ioctl_cpu_grab(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_cpu_grab *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	int ret = 0;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL) {
		ret =  -EINVAL;
		goto out;
	}
	vobj = gobj->driver_private;

	if (vobj->owner_file) {
		/*process already grab this BO*/
		if (vobj->owner_file == file_priv) {
			goto out;
		} else { /*other process grab it, wait */
			ret = ttm_bo_wait_cpu(&vobj->bo, false);
			if (ret)
				goto out;
		}
	}
	/*If no process grab it, wait Idle & grab it*/
	ret = ttm_bo_synccpu_write_grab(&vobj->bo, false);
	if (!ret)
		vobj->owner_file = file_priv;

out:
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);
	
	
	return ret;

}


int via_chrome9_ioctl_cpu_release(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_cpu_release *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	int ret = 0;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL) {
		ret =  -EINVAL;
		goto out;
	}
	vobj = gobj->driver_private;

	if (vobj->owner_file) {
		/*If this process grab this BO, release it*/
		if (vobj->owner_file == file_priv) {
			ttm_bo_synccpu_write_release(&vobj->bo);
			vobj->owner_file = NULL;
		}
	}

out:
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);
	return ret;
}

int via_chrome9_ioctl_gem_pin(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_pin *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	int ret;

	/* Now only support bo pinned in the vram */
	if (!(args->location_mask & VIA_CHROME9_GEM_DOMAIN_VRAM)) {
		DRM_ERROR("via_chrome9_ioctl_gem_pin passed in error memory \
			type 0x%x", args->location_mask);
		return -EINVAL;
	}

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (!gobj) {
		ret = -EINVAL;
		goto out;
		
	}
	vobj = gobj->driver_private;

	ret = via_chrome9_bo_pin(vobj, args->location_mask, &args->offset);

out:
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	
	return ret;
}

int via_chrome9_ioctl_gem_unpin(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_gem_unpin *args = data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;
	int ret;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL) {
		ret = -EINVAL;
		goto out;
	}
	vobj = gobj->driver_private;

	ret = via_chrome9_bo_unpin(vobj);

out:
	mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	
	return ret;
}

/*Init Event tag*/
int via_chrome9_ioctl_shadow_init(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_shadow_init *init = data;
	struct drm_clb_event_tag_info *event_tag_info;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (init->shadow_size) {
		/* find apg shadow region mappings */
	dev_priv->shadow_map.shadow = drm_core_findmap(dev,
		init->shadow_handle);
	if (!dev_priv->shadow_map.shadow) {
		DRM_ERROR("could not find shadow map!\n");
		goto error;
	}
	dev_priv->shadow_map.shadow_size = init->shadow_size;
	dev_priv->shadow_map.shadow_handle =
		(unsigned int *)dev_priv->shadow_map.shadow->handle;
	}

	event_tag_info = vmalloc(sizeof(struct drm_clb_event_tag_info));
	if (!event_tag_info)
		return DRM_ERROR(" event_tag_info allocate error!");
	memset(event_tag_info, 0, sizeof(struct drm_clb_event_tag_info));

	event_tag_info->linear_address = dev_priv->shadow_map.shadow_handle;
	event_tag_info->event_tag_linear_address =
		event_tag_info->linear_address + 3;
	dev_priv->event_tag_info =  event_tag_info;

	return 0;
error:
	return -1;
}

int via_chrome9_ioctl_shadow_fini(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	if (!dev_priv->event_tag_info) {
		vfree(dev_priv->event_tag_info);
		dev_priv->event_tag_info = NULL;
	}
	return 0;
}
/*Allocate event tag for 3D*/
int via_chrome9_ioctl_alloc_event(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_event_tag *event_tag = data;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_clb_event_tag_info *event_tag_info =
		dev_priv->event_tag_info;
	unsigned int *event_addr = 0, i = 0;

	for (i = 0; i < NUMBER_OF_EVENT_TAGS; i++) {
		if (!event_tag_info->usage[i])
			break;
	}

	if (i < NUMBER_OF_EVENT_TAGS) {
		event_tag_info->usage[i] = 1;
		event_tag->event_offset = i;
		event_tag->last_sent_event_value.event_low = 0;
		event_tag->current_event_value.event_low = 0;
		event_addr = event_tag_info->linear_address +
		event_tag->event_offset * 4;
		*event_addr = 0;
		return 0;
	} else {
		return -7;
	}

	return 0;
}
/*Free event tag for 3D*/
int via_chrome9_ioctl_free_event(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_clb_event_tag_info *event_tag_info =
		dev_priv->event_tag_info;
	struct drm_via_chrome9_event_tag *event_tag = data;

	event_tag_info->usage[event_tag->event_offset] = 0;
	return 0;
}

int
waitchipidle_inv(struct drm_via_chrome9_private *dev_priv)
{
	unsigned int count = 50000;
	unsigned int eng_status;
	unsigned int engine_busy;

	do {
		eng_status =
			getmmioregister(dev_priv->mmio_map,
					INV_RB_ENG_STATUS);
		engine_busy = eng_status & INV_ENG_BUSY_ALL;
		count--;
	}
	while (engine_busy && count)
		;
	if (count && engine_busy == 0)
		return 0;
	return -1;
}
int
via_chrome9_ioctl_wait_chip_idle(struct drm_device *dev, void *data,
			 struct drm_file *file_priv)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *) dev->dev_private;

	waitchipidle_inv(dev_priv);
	/* maybe_bug here, do we always return 0 */
	return 0;
}

/*
 * save Bos by evict them to system memory
 */
void via_chrome9_drm_save_bos(struct drm_device *dev)
{
	int ret = 0;
    struct drm_crtc *crtc = NULL;
    struct via_chrome9_framebuffer *via_fb = NULL;
    struct drm_gem_object *obj = NULL;
    struct via_chrome9_object *vobj = NULL;
	struct ttm_buffer_object *bo = NULL;
    struct drm_via_chrome9_private *dev_priv =
                (struct drm_via_chrome9_private *)dev->dev_private;
    
    list_for_each_entry(crtc, &dev->mode_config.crtc_list, head) {
            if (!crtc->enabled)
                    continue;
            via_fb = to_via_chrome9_framebuffer(crtc->fb);
            obj = via_fb->obj;
            vobj = (struct via_chrome9_object *)obj->driver_private;
			bo = &vobj->bo;
			if((vobj->placements[0] & TTM_PL_FLAG_NO_EVICT) && (bo->mem.placement & TTM_PL_FLAG_NO_EVICT)){
                        ret = via_chrome9_bo_unpin(vobj);
                        if(ret)
                           DRM_ERROR("Failed bo unpin in via_chrome9_save_bos\n");

            }
    }

	/*evict VRAM BO*/
	via_chrome9_evict_vram(dev);
	/*backup gart-table*/
	memcpy(dev_priv->pm_backup.agp_gart_shadow->ptr,
		dev_priv->agp_gart->ptr, dev_priv->pcie_mem_size >> 10);

	dev_priv->gart_valid = false;

	return;
}
/*
 * Restore BOs
 * need do nothing except restore gart-table 
 */
void via_chrome9_drm_restore_bos(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (!dev_priv->gart_valid) {
		/*needs restore gart-table*/
		memcpy(dev_priv->agp_gart->ptr,
			dev_priv->pm_backup.agp_gart_shadow->ptr,
			dev_priv->pcie_mem_size >> 10);
	}
	dev_priv->gart_valid = true;
	
	
	return;
}
int  via_chrome9_drm_resume(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	unsigned int i;

	if (drm_core_check_feature(dev, DRIVER_MODESET))
		return 0;
	pci_set_power_state(dev->pdev, PCI_D0);
	pci_restore_state(dev->pdev);
	if (pci_enable_device(dev->pdev))
		return -1;
	pci_set_master(dev->pdev);

	setmmioregister(dev_priv->mmio_map, INV_REG_CR_TRANS, 0x00110000);
	setmmioregister(dev_priv->mmio_map, INV_REG_CR_BEGIN,
		0x06000000);
	setmmioregister(dev_priv->mmio_map, INV_REG_CR_BEGIN,
		0x07100000);
	setmmioregister(dev_priv->mmio_map, INV_REG_CR_TRANS,
		INV_PARATYPE_PRECR);
	setmmioregister(dev_priv->mmio_map, INV_REG_CR_BEGIN,
		INV_SUBA_HSETRBGID | INV_HSETRBGID_CR);

	/* Here restore SR66~SR6F SR79~SR7B */
	for (i = 0; i < 10; i++)
		via_chrome9_write_vga_io(0x166 + i,
			dev_priv->pm_backup.gti_backup[i]);

	for (i = 0; i < 3; i++)
		via_chrome9_write_vga_io(0x179 + i,
			dev_priv->pm_backup.gti_backup[10 + i]);

	return 0;
}

int  via_chrome9_drm_suspend(struct drm_device *dev,
	pm_message_t state)
{
	int i;
	unsigned char reg_tmp;
	struct pci_dev *pci = dev->pdev;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	if (drm_core_check_feature(dev, DRIVER_MODESET))
		return 0;
	pci_save_state(pci);

	/* Save registers from SR66~SR6F */
	for (i = 0; i < 10; i++) {
		dev_priv->pm_backup.gti_backup[i] =
			via_chrome9_read_vga_io(0x166 + i);
	}

	/* Save registers from SR79~SR7B */
	for (i = 0; i < 3; i++) {
		dev_priv->pm_backup.gti_backup[10 + i] =
			via_chrome9_read_vga_io(0x179 + i);
	}

	/* Close IGA channel and clear FIFO depth to avoid PCIE series S3 issue */
	/* Disable first display channel */
	reg_tmp = via_chrome9_read_vga_io(0x17);
	via_chrome9_write_vga_io(0x17, reg_tmp & 0x7f);

	/* Disable second display channel */
	reg_tmp = via_chrome9_read_vga_io(0x6A);
	via_chrome9_write_vga_io(0x6A, reg_tmp & 0x7f);

	/* First screen off */
	reg_tmp = via_chrome9_read_vga_io(0x101);
	via_chrome9_write_vga_io(0x101, reg_tmp | 0x20);

	/* Second screen off */
	reg_tmp = via_chrome9_read_vga_io(0x6B);
	via_chrome9_write_vga_io(0x6B, (reg_tmp | 0x04) & (~0x02));


	/* Clear IGA1 FIFO depth
	 * 3C5.17[7:0]=0
	 */
	via_chrome9_write_vga_io(0x117, 0x0);

	/* Clear IGA2 FIFO depth
	 * 3x5.68[7:4]=0, 3x5.94[7]=0, 3x5.95[7]=0
	 */
	reg_tmp = via_chrome9_read_vga_io(0x68);
	via_chrome9_write_vga_io(0x68, reg_tmp & 0x0f);


	reg_tmp = via_chrome9_read_vga_io(0x94);
	via_chrome9_write_vga_io(0x94, reg_tmp & 0x7f);


	reg_tmp = via_chrome9_read_vga_io(0x95);
	via_chrome9_write_vga_io(0x95, reg_tmp & 0x7f);

	/*stop ringbuffer*/
	set_agp_ring_buffer_stop(dev);

	return 0;
}

static int via_chrome9_gem_release_cpu(int id, void *ptr, void *data)
{
	struct drm_gem_object *gobj = ptr;
	struct via_chrome9_object *vobj = gobj->driver_private;

	if (vobj->owner_file) {
		/*If this process grab this BO, release it*/
		if (vobj->owner_file == data) {
			ttm_bo_synccpu_write_release(&vobj->bo);
			vobj->owner_file = NULL;
		}
	}
	return 0;
}

void via_chrome9_release_cpu_grab(struct drm_device *dev,
		struct drm_file *file_priv)
{
	/*release cpu grab of this process*/
	idr_for_each(&file_priv->object_idr,
	     &via_chrome9_gem_release_cpu, file_priv);
}

/* 
 * Called before enter another memory manager, which will allcate 
 * video memory by it self(e.g vesa fb driver),
 * so we must save video memory BOs.
 * */
int via_chrome9_ioctl_leave_gem(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	u8 sr6c;

	via_chrome9_drm_save_bos(dev);

	/* enable gti write */
	sr6c = via_chrome9_read_vga_io(0x16c);
	sr6c &= 0x7F;
	via_chrome9_write_vga_io(0x16c, sr6c);

	
	return 0;
}

/*
 *  Called when backto GEM memory manager
 *  we need do some restore here
 */
int via_chrome9_ioctl_enter_gem(struct drm_device *dev, void *data,
	struct drm_file *file_priv)
{
	via_chrome9_drm_restore_bos(dev);
	/*re-init gart-table & ringbuffer*/
	via_chrome9_init_gart_table(dev);
	set_agp_ring_cmd_inv(dev);

	
	return 0;
}


void via_chrome9_preclose(struct drm_device *dev, struct drm_file *file_priv)
{
	via_chrome9_release_cpu_grab(dev,file_priv);
}
void via_chrome9_lastclose(struct drm_device *dev)
{
	via_chrome9_ioctl_shadow_fini(dev);
}

int via_chrome9_ioctl_chipinfo_gem(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	struct drm_via_chip_info *chipinfo = (struct drm_via_chip_info *)data;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct pci_dev *pdev = dev->pdev;
	
	chipinfo->mmioHandle = pci_resource_start(dev->pdev, 1);
	chipinfo->shadowHandle = dev_priv->shadow_map.shadow->offset;
	chipinfo->shadowSize = (unsigned long)dev_priv->shadow_map.shadow_size;
	chipinfo->fbSize = (unsigned long)dev_priv->vram_size;
	chipinfo->vendor = pdev->vendor;
	chipinfo->device_id = pdev->device;
	chipinfo->subsystem_vendor = pdev->subsystem_vendor;
	chipinfo->subsystem_device_id = pdev->subsystem_device;
	return 0;
}

int via_chrome9_ioctl_xorg_options(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	int ret = 0;
	struct drm_mode_object *obj;
	struct drm_connector *connector;
	struct via_chrome9_connector *via_conn;
	struct drm_via_chrome9_xorg_options *args =
		(struct drm_via_chrome9_xorg_options *)data;

	obj = drm_mode_object_find(dev, args->connector_id,
				   DRM_MODE_OBJECT_CONNECTOR);
	if (!obj) {
		ret = -EINVAL;
		goto out;
	}
	connector = obj_to_connector(obj);
	via_conn = to_via_chrome9_connector(connector);
	if (via_conn->set_xorg_options) {
		via_conn->set_xorg_options(args->xorg_options,
				args->options_size, connector);
	} else {
		KMS_DEBUG(
			"There is no set_xorg_options function for this connector\n");
	}

out:
	return ret;
}

int via_chrome9_ioctl_get_crtc_id(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	struct drm_get_crtc_id_info *crtc_info =
		(struct drm_get_crtc_id_info *)data;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_mode_object *drmmode_obj;
	struct via_chrome9_crtc *crtc;

	if (!dev_priv) {
		DRM_ERROR("called with no drm initialization\n");
		return -EINVAL;
	}

	drmmode_obj = drm_mode_object_find(dev, crtc_info->crtc_id,
			DRM_MODE_OBJECT_CRTC);

	if (!drmmode_obj) {
		DRM_ERROR("no such CRTC id\n");
		return -EINVAL;
	}

	crtc = to_via_chrome9_crtc(obj_to_crtc(drmmode_obj));
	crtc_info->crtc_hw_id = crtc->crtc_id;

	return 0;
}

int via_chrome9_ioctl_get_bo_info(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	struct drm_get_bo_info *args = (struct drm_get_bo_info *)data;
	struct drm_gem_object *gobj;
	struct via_chrome9_object *vobj;

	gobj = drm_gem_object_lookup(dev, file_priv, args->handle);
	if (gobj == NULL) {
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(gobj);
		mutex_unlock(&dev->struct_mutex);
        return -EINVAL;
    }
    vobj = gobj->driver_private;

    args->offset = vobj->bo.offset;
    args->domains = vobj->bo.cur_placement;
    mutex_lock(&dev->struct_mutex);
	drm_gem_object_unreference(gobj);
	mutex_unlock(&dev->struct_mutex);

	return 0;
}

int via_chrome9_ioctl_set_edid(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	int ret = 0;
	struct drm_mode_object *obj;
	struct drm_connector *connector;
	struct via_chrome9_connector *via_conn;
	struct drm_via_chrome9_edid *args = (struct drm_via_chrome9_edid *)data;

	obj = drm_mode_object_find(dev, args->connector_id,
		DRM_MODE_OBJECT_CONNECTOR);
	if (!obj) {
		ret = -EINVAL;
		goto out;
	}
	connector = obj_to_connector(obj);
	via_conn = to_via_chrome9_connector(connector);
	if (via_conn->set_edid) {
		via_conn->set_edid(args->edid, args->edid_size, connector);
	} else {
		KMS_DEBUG(
			"There is no get_edid function for this connector %d\n",
			args->connector_id);
	}

out:
	return ret;
}


int via_chrome9_ioctl_crtc_dpms(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	struct drm_crtc_dpms_info *crtc_dpms_info =
		(struct drm_crtc_dpms_info *)data;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_mode_object *drmmode_obj;
	struct drm_crtc *crtc, *crtc_obj;
	struct drm_encoder *encoder;
	struct via_chrome9_crtc *via_crtc;

	if (!dev_priv) {
		DRM_ERROR("called with no drm initialization\n");
		return -EINVAL;
	}
	KMS_DEBUG("crtc_dpms_info->crtc_id=%u\n",crtc_dpms_info->crtc_id);
	drmmode_obj = drm_mode_object_find(dev, crtc_dpms_info->crtc_id,
			DRM_MODE_OBJECT_CRTC);

	if (!drmmode_obj) {
		DRM_ERROR("no such CRTC id\n");
		return -EINVAL;
	}

	crtc_obj = obj_to_crtc(drmmode_obj);
	via_crtc = to_via_chrome9_crtc(crtc_obj);

	list_for_each_entry(encoder, &dev->mode_config.encoder_list, head) {
		if ( crtc_obj == encoder->crtc ) {
			/* disconnector encoder from any connector */
			KMS_DEBUG("find crtc used by encoder, via_crtc->crtc_id=%u\n",
					via_crtc->crtc_id);
			encoder->crtc = NULL;

			/* disable unused crtc. */
			list_for_each_entry(crtc, &dev->mode_config.crtc_list, head) {
				struct drm_crtc_helper_funcs *crtc_funcs = crtc->helper_private;
				crtc->enabled = drm_helper_crtc_in_use(crtc);
				if (!crtc->enabled) {
					(*crtc_funcs->dpms)(crtc, DRM_MODE_DPMS_OFF);
					crtc->fb = NULL;
				}
			}
		}
	}
	return 0;
}

int via_chrome9_ioctl_get_customize_timing_info(
		struct drm_device *dev, 
		void *data,
		struct drm_file *file_priv)
{
	struct drm_via_chrome9_private *p_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct drm_mode_object *obj;
	struct drm_connector *connector;
	struct via_chrome9_connector *via_conn;
	struct drm_get_customize_timing_info *args =
		(struct drm_get_customize_timing_info *)data;
	int ret = 0;

	/* get args->dispDev */
	obj = drm_mode_object_find(dev, args->connector_id,
				   DRM_MODE_OBJECT_CONNECTOR);
	if (!obj) {
		ret = -EINVAL;
		return ret;
	}
	connector = obj_to_connector(obj);
	via_conn = to_via_chrome9_connector(connector);
	args->disp_dev = 
		via_chrome9_connector_to_cbios_device(via_conn->connector_id);

	/**
	 *  get args->colorDepth, 
	 *
	 *  we couldn't get crtc info when call this ioctl,
	 *  so we do not know its' bpp,
	 *  and CBIOS now do not use customize timing colorDepth.
	 *  so fix it to 0 now.
	 */
	args->color_depth = 0;

	/* get args->vPLL */
	args->v_pll = 
		via_chrome9_get_mrn(p_priv->via_chrome9_pll_type, args->pixel_clock);

	KMS_DEBUG("crtc_id(invalid)=0x%x, connector_id=0x%x, pixel_clock=%d, "
		"dispDev=%d, colorDepth=%d, vPLL=0x%x\n", 
		args->crtc_id, args->connector_id, args->pixel_clock,
		args->disp_dev, args->color_depth, args->v_pll);

	return ret;
}

void via_chrome9_dump_mem(void *tb, unsigned int len)
{
	unsigned char *tb_tmp = (unsigned char *)tb;
	unsigned int i,j;

#define via_chrome9_dump_func_head(fmt,arg...)    \
			printk(KERN_ERR "%s(): dump:" fmt,__FUNCTION__, ##arg)
#define via_chrome9_dump_func    printk

	via_chrome9_dump_func_head("kernel driver begin len = %d\n", len);
	for(i=0; i<len; ) {
		via_chrome9_dump_func("tb[%d]~tb[%d] ", i, i+15);
		for(j=0; j<16; j++) {
			via_chrome9_dump_func("0x%x, ",tb_tmp[i]);
			i++;
			if(i>=len) {
				break;
			}
		}
		via_chrome9_dump_func("\n");
	}
	via_chrome9_dump_func_head("end\n");
}

int via_chrome9_ioctl_pass_customize_timing(struct drm_device *dev, 
		void *data, struct drm_file *file_priv)
{
	struct drm_pass_customize_timing *args =
		(struct drm_pass_customize_timing *)data;
	/* customize timing package buffer contains header and timings, CBIOS need. */
	static u8 *cust_tm_buf_ptr = NULL;
	/* customize timing aux info contains dispDevs and ModeLineNums, driver need. */
	static u32 *cust_tm_aux_info_ptr = NULL;
	int ret = 0;

	if( NULL != cust_tm_buf_ptr ) {
		kfree(cust_tm_buf_ptr);
		cust_tm_buf_ptr = NULL;
	}
	if( NULL != cust_tm_aux_info_ptr ) {
		kfree(cust_tm_aux_info_ptr);
		cust_tm_aux_info_ptr = NULL;
	}

	KMS_DEBUG("CXZ:args: pkg_size=%d, disp_devs_and_mls_len=%d\n", 
			args->pkg_size, args->cust_tm_aux_info_len);

	cust_tm_buf_ptr = (u8 *)kmalloc(args->pkg_size,  GFP_KERNEL);
	cust_tm_aux_info_ptr =
		(u32 *)kmalloc(args->cust_tm_aux_info_len, GFP_KERNEL);

	copy_from_user(cust_tm_buf_ptr, args->ml_pkg, args->pkg_size);
	copy_from_user(cust_tm_aux_info_ptr, 
			args->cust_tm_aux_info_ptr, args->cust_tm_aux_info_len);

/*	via_chrome9_dump_mem(cust_tm_buf_ptr, args->pkg_size); */

	ret = CBiosLoadCustomizeTiming(pcbe, cust_tm_buf_ptr);
	/* record mode line info in kernel driver. */
	via_chrome9_parse_customize_timing_pkg(dev, cust_tm_buf_ptr, 
			cust_tm_aux_info_ptr, args->cust_tm_aux_info_len);

	return ret;
}

int via_chrome9_ioctl_helper_set_mode(struct drm_device *dev, void *data,
		struct drm_file *file_priv)
{
	int ret = 0;
	struct drm_mode_object *obj;
	struct drm_encoder *encoder = NULL;
    struct drm_connector *connector = NULL;
    struct drm_connector_helper_funcs *connector_func = NULL;
	struct drm_via_chrome9_mode_set_par *args =
		(struct drm_via_chrome9_mode_set_par *)data;

	obj = drm_mode_object_find(dev, args->connector_id,
				   DRM_MODE_OBJECT_CONNECTOR);
	if (!obj) {
		ret = -EINVAL;
		goto out;
	}
	connector = obj_to_connector(obj);
    connector_func =
		(struct drm_connector_helper_funcs *)connector->helper_private;
	encoder = connector_func->best_encoder(connector);
    if (encoder)
        via_chrome9_helper_set_mode(encoder);
    
out:
	return ret;
}

/**
 * via_chrome9_convert_umode porting from
 * drm_crtc_convert_to_umode - convert a modeinfo into a drm_display_mode
 * @out: drm_display_mode to return to the user
 * @in: drm_mode_modeinfo to use
 *
 * LOCKING:
 * None.
 *
 * Convert a drm_mode_modeinfo into a drm_display_mode structure to return to
 * the caller.
 */
void via_chrome9_convert_umode(struct drm_display_mode *out,
			    struct drm_mode_modeinfo *in)
{
	out->clock = in->clock;
	out->hdisplay = in->hdisplay;
	out->hsync_start = in->hsync_start;
	out->hsync_end = in->hsync_end;
	out->htotal = in->htotal;
	out->hskew = in->hskew;
	out->vdisplay = in->vdisplay;
	out->vsync_start = in->vsync_start;
	out->vsync_end = in->vsync_end;
	out->vtotal = in->vtotal;
	out->vscan = in->vscan;
	out->vrefresh = in->vrefresh;
	out->flags = in->flags;
	out->type = in->type;
	strncpy(out->name, in->name, DRM_DISPLAY_MODE_LEN);
	out->name[DRM_DISPLAY_MODE_LEN-1] = 0;
}

int via_chrome9_ioctl_output_mode_valid(struct drm_device *dev, void *data,
			struct drm_file *file_priv)
{
	int ret = 0;
	struct drm_mode_object *obj;
	struct drm_connector *connector;
	struct drm_display_mode mode;
	struct drm_connector_helper_funcs *connector_funcs = NULL;
	struct drm_via_chrome9_output_kmode *args = 
		(struct drm_via_chrome9_output_kmode *)data;
	/* KMS_DEBUG("\n"); */
	obj = drm_mode_object_find(dev, args->connector_id,
		DRM_MODE_OBJECT_CONNECTOR);
	if (!obj) {
		KMS_DEBUG("drm get connector error");
		ret = -EINVAL;
		goto out;
	}
	connector = obj_to_connector(obj);
	connector_funcs = connector->helper_private;
	memset(&mode, 0, sizeof(struct drm_display_mode));
	via_chrome9_convert_umode(&mode, args->output_kmode);
	args->mode_status = connector_funcs->mode_valid(connector, &mode);
out:
	return ret;
	
	return ret;
}

