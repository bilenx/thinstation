/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "via_chrome9_drv.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_object.h"
#include "via_chrome9_reloc.h"
#include "via_chrome9_fence.h"
#include "via_chrome9_3d_reg.h"
#include "via_chrome9_dma.h"
#include "via_chrome9_ttm.h"
#include <linux/version.h>
/**
 * modify the command buffer with reloc type
 */
static int via_chrome9_write_reloc(unsigned int *buffer_ptr,
		unsigned long offset,
		struct ttm_buffer_object *bo, uint32_t delta,
		enum drm_via_chrome9_reloc_type type)
{
	unsigned int *cmdbuf = buffer_ptr + offset;
	unsigned long target_bo_offset = bo->offset;
	unsigned int subaddr, value;

	switch (type) {
	case VIA_RELOC_2D:
		value = (target_bo_offset + delta) >> 3;
		writel(value, buffer_ptr + offset);
		break;
	case VIA_RELOC_3D:
		subaddr = (*cmdbuf) & 0xff000000;
		value = subaddr | ((target_bo_offset + delta) >> 8);
		writel(value, buffer_ptr + offset);
		break;
	case VIA_RELOC_HQV0:
	case VIA_RELOC_HQV1:
	case VIA_RELOC_VIDEO:
	case VIA_RELOC_VD:
		*cmdbuf = (target_bo_offset + delta) |
			((bo->mem.placement &
			VIA_CHROME9_GEM_DOMAIN_GTT) ? 0x1 : 0x0);
			/* local system dynamic buffer */
		break;
	case VIA_RELOC_VERTEX_STREAM_L:
		subaddr = (*cmdbuf)&0xfff00fff;
		*cmdbuf = (subaddr) |
			((((target_bo_offset + delta)&0x000003FF)>>2)<<12);
		break;
	case VIA_RELOC_VERTEX_STREAM_H:
		subaddr = (*cmdbuf)&0x000003FF;
		*cmdbuf = (subaddr) |  (((target_bo_offset + delta)>>10)<<10);
		break;
	default:
		DRM_INFO("undefine type for relocation\n");
		break;
	}

	return 0;
}
/* Try to parse Command type
 * Only handle 2d/3d command type
 * */
static inline void via_chrome9_parse_cmd_type(
		struct via_chrome9_fence_object *fence,
		enum drm_via_chrome9_reloc_type type)
{
	switch (type) {
	case VIA_RELOC_2D:
		fence->type |= VIA_CHROME9_CMD_2D;
		break;
	case VIA_RELOC_3D:
	case VIA_RELOC_VERTEX_STREAM_L:
	case VIA_RELOC_VERTEX_STREAM_H:
		fence->type |= VIA_CHROME9_CMD_3D;
		break;
	case VIA_RELOC_HQV0:
		fence->type |= VIA_CHROME9_CMD_HQV0;
		break;
	case VIA_RELOC_HQV1:
		fence->type |= VIA_CHROME9_CMD_HQV1;
		break;
	case VIA_RELOC_VIDEO:
		fence->type |= VIA_CHROME9_CMD_VIDEO;
		break;
	case VIA_RELOC_VD:
		fence->type |= VIA_CHROME9_CMD_VD;
		break;
	default:
		BUG();
	}
}
/**
 * valid the target bo
 */
int via_chrome9_reloc_valid(struct drm_via_chrome9_gem_flush_parse *parse,
		unsigned long *pcmddata, int i)
{
	struct drm_via_chrome9_gem_relocation_entry *entry;
	unsigned int *command_buffer_ptr;
	int ret;

	entry = (struct drm_via_chrome9_gem_relocation_entry *)
		&parse->relocs[i];
	command_buffer_ptr = (unsigned int *)pcmddata;

	ret = via_chrome9_write_reloc(command_buffer_ptr, entry->offset,
		&parse->reloc_buffer[i].vobj->bo,
		entry->delta, entry->type);

	return ret;
}

/**
 * parse the command buffer
 */
int via_chrome9_parse_init(struct drm_device *dev, struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse,
		struct drm_via_chrome9_gem_flush *data)
{
	INIT_LIST_HEAD(&parse->valid_list);

	parse->exec_objects =
		kzalloc(sizeof(struct drm_via_chrome9_gem_exec_object),
		GFP_KERNEL);
	if (parse->exec_objects == NULL) {
		DRM_ERROR("kzalloc the exec object error\n");
		return -ENOMEM;
	}

	if (DRM_COPY_FROM_USER(parse->exec_objects,
		(void __user *)(unsigned long)data->buffer_ptr,
		sizeof(struct drm_via_chrome9_gem_exec_object))) {
		return -EFAULT;
	}

	parse->use_branch_buffer =
		(data->flag & VIA_CHROME9_FLUSH_BRANCH_BUFFER) ? true : false;
	return 0;
}

static int via_chrome9_validate_init(struct drm_device *dev,
		struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse)
{
	int i, j, ret = 0;
	struct drm_via_chrome9_gem_relocation_entry *entry;

	if (NULL == parse->relocs || NULL == parse->fence)
		return -1;
retry:
	/* Traversing the reloc list and reserve BOs */
	for (i = 0; i < parse->exec_objects->relocation_count; i++) {
		entry =
			(struct drm_via_chrome9_gem_relocation_entry *)
			&parse->relocs[i];
		parse->reloc_buffer[i].reloc_count = i;
		parse->reloc_buffer[i].gobj =
			drm_gem_object_lookup(dev, file_priv,
			entry->target_handle);
		if (!parse->reloc_buffer[i].gobj)
			BUG();
		parse->reloc_buffer[i].vobj =
			parse->reloc_buffer[i].gobj->driver_private;
		/*If BO not been reserved, reserve it*/
		if (parse->reloc_buffer[i].vobj->reserved_by == NULL) {

			ret = ttm_bo_reserve(&parse->reloc_buffer[i].vobj->bo,
					true, false, false, 0);

			if (unlikely(ret != 0)) {
				DRM_ERROR("failed to reserve object.\n");
				return ret;
			}

			parse->reloc_buffer[i].vobj->reserved_by = file_priv;
			/* GPU may needs to wait CPU */
			if (atomic_read(
				&parse->reloc_buffer[i].vobj->bo.cpu_writers)
				> 0)
				goto unreserve;
		}
		if (!parse->use_branch_buffer)
			via_chrome9_parse_cmd_type(
				parse->fence, parse->relocs[i].type);
	}
	return ret;

unreserve:
	for (j = i; j >= 0; j--) {
		if (parse->reloc_buffer[j].vobj->reserved_by == file_priv) {
			ttm_bo_unreserve(&parse->reloc_buffer[j].vobj->bo);
			parse->reloc_buffer[j].vobj->reserved_by = NULL;
		}
		mutex_lock(&dev->struct_mutex);
		drm_gem_object_unreference(parse->reloc_buffer[j].gobj);
		mutex_unlock(&dev->struct_mutex);

	}

	via_chrome9_object_wait_cpu_access(parse->reloc_buffer[i].vobj,
		file_priv);
	goto retry;
}

static int via_chrome9_validate_bo(struct drm_device *dev,
		struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse)
{
	int i, ret = 0;
	struct via_chrome9_fence_object *old_fence = NULL;
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	struct via_chrome9_fence_ops *fence_ops =
		&dev_priv->engine_ops.fence_ops;
	struct drm_via_chrome9_gem_relocation_entry *entry;

	for (i = 0; i < parse->exec_objects->relocation_count; i++) {
		entry =
			(struct drm_via_chrome9_gem_relocation_entry *)
			&parse->relocs[i];

		/* only hanlde setting to GPU read/write domain */
		BUG_ON((entry->write_domain | entry->read_domains) &
			VIA_CHROME9_OBJ_DOMAIN_CPU);

		/* add read/write domain */
		parse->reloc_buffer[i].vobj->pending_write_domain =
			entry->write_domain;
		parse->reloc_buffer[i].vobj->pending_read_domain =
			entry->read_domains;

		/* check if need engines sync
		 * TODO: this can be optimized to reduce wait times
		 */
#if VIA_CHROME9_MULTILEVEL_BRANCH_BUFFER_ENABLE
		if (parse->reloc_buffer[i].vobj->access_engine_type &&
		    entry->access_engine_type !=
		    parse->reloc_buffer[i].vobj->access_engine_type) {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
			spin_lock(
				&parse->reloc_buffer[i].vobj->bo.bdev->fence_lock);
#else
			spin_lock(&parse->reloc_buffer[i].vobj->bo.lock);
#endif
			if (ttm_bo_wait(
				&(parse->reloc_buffer[i].vobj->bo),
				true, false, 1))
				parse->wait_engines |=
					(parse->reloc_buffer[i].vobj
					->access_engine_type)
					& (~((entry->access_engine_type)
					& (parse->reloc_buffer[i].vobj
					->access_engine_type)));
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
				spin_unlock(
					&parse->reloc_buffer[i].vobj
					->bo.bdev->fence_lock);
#else
				spin_unlock(&parse->reloc_buffer[i].vobj->bo.lock);
#endif
		}

		parse->reloc_buffer[i].vobj->access_engine_type =
			entry->access_engine_type;
#endif

		/* If domain not match, needs reloc & do cache coherence */
		if (!((parse->reloc_buffer[i].vobj->bo.mem.placement &
			entry->location_mask) &
			TTM_PL_MASK_MEM)){

			via_ttm_placement_from_domain(
				parse->reloc_buffer[i].vobj,
				entry->location_mask);
retry:
			/* validate the ttm buffer with proposed placement */
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
			ret = ttm_bo_validate(&parse->reloc_buffer[i].vobj->bo,
				&parse->reloc_buffer[i].vobj->placement,
				true, false, false);
#else
			ret = ttm_bo_validate(&parse->reloc_buffer[i].vobj->bo,
				&parse->reloc_buffer[i].vobj->placement,
				true, false);
#endif			
			if (unlikely(ret)) {
				if (ret !=  -ERESTARTSYS) {
					DRM_ERROR(
						"Failed to Move BO to location=%x in command flush,"
						"memory may not enough, pid=%d\n",
						entry->location_mask,
						current->pid);
					return ret;
				} else {
					goto retry;
				}
			}
		} else {
			/** may needs to do cache coherence
			 */
			if (parse->fence &&
				(parse->reloc_buffer[i].vobj->bo.sync_obj !=
				parse->fence))
				via_chrome9_set_gpu_domain(
					&parse->reloc_buffer[i].vobj->bo);
		}

		/* add the fence to this bo */
		if (parse->fence &&
			(parse->reloc_buffer[i].vobj->bo.sync_obj !=
			parse->fence)) {
			old_fence = (struct via_chrome9_fence_object *)
				parse->reloc_buffer[i].vobj->bo.sync_obj;
			parse->reloc_buffer[i].vobj->bo.sync_obj =
				via_chrome9_fence_ref(parse->fence);
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
			parse->reloc_buffer[i].vobj->bo.sync_obj_arg = NULL;
#endif
		}
		/*GPU fetch command in serial sequence,
		so GPU no need to wait GPU idle*/
		/*BUT should wait BO Moving if using DMA */
		/* TODO in 3-level branch buffer */
		if (old_fence) {
			if (test_bit(TTM_BO_PRIV_FLAG_MOVING,
				&parse->reloc_buffer[i].vobj->bo.priv_flags))
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
				if (!fence_ops->fence_wait(old_fence, NULL,
					false, false))
#else
				if (!fence_ops->fence_wait(old_fence,
					false, false))					
#endif
					clear_bit(TTM_BO_PRIV_FLAG_MOVING,
						&parse->reloc_buffer[i].vobj
						->bo.priv_flags);
			via_chrome9_fence_unref(&old_fence);
		}

		/* compare the bo offset and add it to valid list if mismatch*/
		if (parse->reloc_buffer[i].vobj->bo.offset !=
			entry->presumed_offset) {
			parse->need_correct = true;
			entry->presumed_offset =
				parse->reloc_buffer[i].vobj->bo.offset;
			INIT_LIST_HEAD(&parse->reloc_buffer[i].list);
			list_add_tail(
				&parse->reloc_buffer[i].list,
				&parse->valid_list);
		}
	}
	return ret;
}

static void via_chrome9_validate_fini(struct drm_device *dev,
		struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse)
{
	int i;
	if (!parse->reloc_buffer)
		return;

	for (i = 0; i < parse->exec_objects->relocation_count; i++) {
		if (parse->reloc_buffer[i].vobj &&
			parse->reloc_buffer[i].vobj->reserved_by == file_priv) {
			ttm_bo_unreserve(&parse->reloc_buffer[i].vobj->bo);
			parse->reloc_buffer[i].vobj->reserved_by = NULL;
		}
	}
}
/**
 * parse the reloc list and add the bo to valid list
 */
int via_chrome9_parse_reloc(struct drm_device *dev, struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int  ret;
	unsigned long size;

	parse->need_correct = false;

	ret = via_chrome9_fence_object_create(dev_priv, &parse->fence, false);
	if (ret) {
		DRM_ERROR(" can not allocate fence object for flush\n");
		return -ENOMEM;
	}

	if (!parse->exec_objects->relocation_count)
		return 0;

	size = parse->exec_objects->relocation_count *
		sizeof(struct drm_via_chrome9_gem_relocation_entry);
	/* kzalloc is a fast memory allocation routine, so try it first as much
	** as possible, but it is likely be failed when allocating much memory
	*/
	if (size < 0x20000) {
		parse->relocs = kzalloc(size, GFP_KERNEL);
		parse->mem_alloc_style[0] = mem_kzalloc_type;
	}

	if (parse->relocs == NULL) {
		parse->relocs = vmalloc(size);
		parse->mem_alloc_style[0] = mem_vmalloc_type;
	}

	if (parse->relocs == NULL) {
		DRM_ERROR("kzalloc the relocs error\n");
		return -ENOMEM;
	}

	size = parse->exec_objects->relocation_count *
		sizeof(struct via_chrome9_flush_buffer);

	if (size < 0x20000) {
		parse->reloc_buffer = kzalloc(size, GFP_KERNEL);
		parse->mem_alloc_style[1] = mem_kzalloc_type;
	}

	if (parse->reloc_buffer == NULL) {
		parse->reloc_buffer = vmalloc(size);
		parse->mem_alloc_style[1] = mem_vmalloc_type;
	}

	if (parse->reloc_buffer == NULL) {
		DRM_ERROR("kzalloc the reloc_buffer error\n");
		return -ENOMEM;
	}

	if (DRM_COPY_FROM_USER(parse->relocs,
			(void __user *)
			(unsigned long)parse->exec_objects->relocs_ptr,
			parse->exec_objects->relocation_count *
			sizeof(struct drm_via_chrome9_gem_relocation_entry))) {
		DRM_ERROR("DRM_COPY_FROM_USER relocs error\n");
		return -EFAULT;
	}

	/*validate BOs */
	ret = via_chrome9_validate_init(dev, file_priv, parse);
	if (ret) {
		via_chrome9_validate_fini(dev, file_priv, parse);
		return ret;
	}
	ret = via_chrome9_validate_bo(dev, file_priv, parse);
	if (ret) {
		via_chrome9_validate_fini(dev, file_priv, parse);
		send_sig(SIGTERM, current, 1);
		return ret;
	}

	/* update the buffer object offset to user space */
	if (parse->need_correct) {
		if (DRM_COPY_TO_USER(
			(void __user *)(unsigned long)
			parse->exec_objects->relocs_ptr,
			parse->relocs,
			parse->exec_objects->relocation_count *
			sizeof(struct drm_via_chrome9_gem_relocation_entry))) {

			DRM_ERROR("DRM_COPY_TO_USER relocs error\n");
			return -EFAULT;
		}
	}

	return 0;
}

/**
 * the fini for this exec
 */
void via_chrome9_parse_fini(struct drm_device *dev, struct drm_file *file_priv,
		struct drm_via_chrome9_gem_flush_parse *parse,
		int error)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *) dev->dev_private;
	struct via_chrome9_fence_ops *fence_ops =
		&dev_priv->engine_ops.fence_ops;
	struct via_chrome9_fence_object *old_fence = NULL;
	int i, ret;

	if (parse->fence) {
		if (!error) {
			ret = fence_ops->fence_emit(dev_priv, parse->fence);
			if (ret)
				DRM_ERROR(" can not emit fence object\n");
		}
		/* unreference this fence for future destroy */
		via_chrome9_fence_unref(&parse->fence);
	}
	via_chrome9_validate_fini(dev, file_priv, parse);

	if (parse->reloc_buffer && parse->exec_objects) {
		for (i = 0; i < parse->exec_objects->relocation_count; i++) {
			if (parse->reloc_buffer[i].gobj) {
				if (error) {
					old_fence =
					(struct via_chrome9_fence_object *)
						parse->reloc_buffer[i].vobj
						->bo.sync_obj;
					parse->reloc_buffer[i].vobj
						->bo.sync_obj = NULL;

					if (old_fence)
						via_chrome9_fence_unref(
							&old_fence);
				}
				mutex_lock(&dev->struct_mutex);
				drm_gem_object_unreference(
					parse->reloc_buffer[i].gobj);
				mutex_unlock(&dev->struct_mutex);
			}
		}
	}

	kfree(parse->exec_objects);

	if (parse->relocs) {
		if (parse->mem_alloc_style[0] == mem_kzalloc_type)
			kfree(parse->relocs);
		else if (parse->mem_alloc_style[0] == mem_vmalloc_type)
			vfree(parse->relocs);
	}

	if (parse->reloc_buffer) {
		if (parse->mem_alloc_style[1] == mem_kzalloc_type)
			kfree(parse->reloc_buffer);
		else if (parse->mem_alloc_style[1] == mem_vmalloc_type)
			vfree(parse->reloc_buffer);
	}

	parse->exec_objects = NULL;
	parse->relocs = NULL;
	parse->reloc_buffer = NULL;

}
