/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _VIA_CHROME9_FENCE_H_
#define _VIA_CHROME9_FENCE_H_

#include <asm/atomic.h>
#include <linux/wait.h>
#include <linux/list.h>
#include <linux/kref.h>
#include <ttm/ttm_bo_api.h>
#include "via_chrome9_drv.h"

#define VIA_CHROME9_FENCE_SYNC_BO_SIZE PAGE_SIZE
/*min DMA move size is 16 , and must be 16 align*/
#define VIA_CHROME9_DMA_FENCE_SIZE 31
#define VIA_CHROME9_FENCE_SIZE 0x20

struct via_chrome9_fence_object {
	/* point to via_chrome9 private data structure */
	struct drm_via_chrome9_private *p_priv;
	/* the reference information of this fence object */
	struct kref kref;
	/* indicate which list this fence object belongs to */
	struct list_head list;
	/* the sequence number that the fence object emit */
	uint32_t	sequence;
	/* the time to wait for the fence object signal */
	unsigned long timeout;
	/* whether this fence object emit or not */
	bool emited;
	/* whether this fence object has been signaled */
	bool signaled;
	/*If a DMA fence or not*/
	bool is_dma;
	/* Engine type this fence associated */
	uint32_t type;
	/* represents whether there is any process wait for this fence */
	bool waited;
};

enum drm_via_chrome9_fence_type {
	/* the reloc type for 2D command */
	VIA_FENCE_2D = 0,
	/* the reloc type for 3D command */
	VIA_FENCE_3D,
	/* the reloc type for video*/
	VIA_FENCE_VD,
	VIA_FENCE_HQV0,
	VIA_FENCE_HQV1,
	VIA_FENCE_VIDEO,
	VIA_FENCE_DMA,
	VIA_FENCE_NUM
};

struct via_chrome9_fence_pool {
	struct via_chrome9_object *fence_sync;
	uint32_t *fence_sync_virtual;
	uint64_t	fence_bus_addr;
	/* Fence command temp buffer */
	uint32_t *p_cmd_tmp;
	/* for access synchronization */
	spinlock_t fence_pool_lock;
	/* the fence sequence emitter */
	atomic_t	seq;
	atomic_t dma_seq;
	struct workqueue_struct *fence_wq;
	struct work_struct fence_work;
	/* for processes which wait for specified fence object to sleep */
	wait_queue_head_t	fence_wait_queue;
	/* the list hook all the initially created fence objects */
	struct list_head		created;
	/* the list hook all the emitted fence objects */
	struct list_head		emited[VIA_FENCE_NUM];
	/* the list hook all the signaled fence objects */
	struct list_head		signaled;
	/*For DMA fence*/
	struct list_head		dma_created;
	struct list_head		dma_emited;
	struct list_head		dma_signaled;
	uint64_t	eng_fence[VIA_FENCE_NUM];
};

extern int
via_chrome9_fence_object_create(struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object **pp_fence_object, bool is_dma);
extern int via_chrome9_fence_emit_h6(struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object *p_fence_object);
extern int via_chrome9_fence_emit_h5s2vp1(
		struct drm_via_chrome9_private *p_priv,
		struct via_chrome9_fence_object *p_fence_object);

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
extern bool via_chrome9_fence_signaled_h6(
	struct via_chrome9_fence_object *p_fence, void *sync_arg);
extern bool via_chrome9_fence_signaled_h5s2vp1(
	struct via_chrome9_fence_object *p_fence, void *sync_arg);

extern int via_chrome9_fence_wait_h6(
	struct via_chrome9_fence_object *p_fence,
	void *sync_arg, bool lazy, bool interruptible);

extern int via_chrome9_fence_wait_h5s2vp1(
	struct via_chrome9_fence_object *p_fence,
	void *sync_arg, bool lazy, bool interruptible);
extern int via_chrome9_fence_flush(
	struct via_chrome9_fence_object *p_fence, void *sync_arg);
#else
extern bool via_chrome9_fence_signaled_h6(
	struct via_chrome9_fence_object *p_fence);
extern bool via_chrome9_fence_signaled_h5s2vp1(
	struct via_chrome9_fence_object *p_fence);
extern int via_chrome9_fence_wait_h6(
	struct via_chrome9_fence_object *p_fence,
	bool lazy, bool interruptible);
extern int via_chrome9_fence_wait_h5s2vp1(
	struct via_chrome9_fence_object *p_fence,
	bool lazy, bool interruptible);
extern int via_chrome9_fence_flush(
	struct via_chrome9_fence_object *p_fence);
#endif
extern void via_chrome9_fence_unref(
	struct via_chrome9_fence_object **pp_fence);
extern void *via_chrome9_fence_ref(
	struct via_chrome9_fence_object *p_fence);
extern int via_chrome9_fence_mechanism_init(struct drm_device *dev);
extern void via_chrome9_fence_mechanism_fini(struct drm_device *dev);
#endif
