/*
 * Copyright 1998-2012 VIA Technologies, Inc. All Rights Reserved.
 * Copyright 2001-2012 S3 Graphics, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#include <linux/module.h>
#include "via_chrome9_drv.h"
#include "via_chrome9_object.h"
#include "via_chrome9_drm.h"
#include "via_chrome9_ttm.h"
#include "via_chrome9_dma.h"
#include <linux/version.h>

#include <linux/fs.h>

static struct vm_operations_struct via_chrome9_ttm_vm_ops;
static const struct vm_operations_struct *ttm_vm_ops = {NULL};
extern struct drm_device *drm_dev_v4l;

/**
 * initialize the gem buffer object
 */
int via_chrome9_gem_object_init(struct drm_gem_object *obj)
{
	return 0;
}

/**
 * free the gem buffer object
 */
void via_chrome9_gem_object_free(struct drm_gem_object *gobj)
{
	struct via_chrome9_object *vobj = gobj->driver_private;

	gobj->driver_private = NULL;
	if (vobj)
		via_chrome9_buffer_object_unref(&vobj);

	drm_gem_object_release(gobj);
	kfree(gobj);
}

/**
 * Unreference the ttm buffer object and do ttm_bo_release while this bo kref equal to zero
 */
void
via_chrome9_buffer_object_unref(struct via_chrome9_object **vobj)
{
	struct ttm_buffer_object *bo;

	if ((*vobj) == NULL)
		return;

	bo = &((*vobj)->bo);
	ttm_bo_unref(&bo);

	if (NULL == bo)
		*vobj = NULL;
}
EXPORT_SYMBOL(via_chrome9_buffer_object_unref);

/**
 * Add a reference to this buffer object
 */
void
via_chrome9_buffer_object_ref(struct ttm_buffer_object *bo)
{
	bo = ttm_bo_reference(bo);
}

/**
 * Unmap the ttm buffer object
 */
void
via_chrome9_buffer_object_kunmap(struct via_chrome9_object *vobj)
{
	spin_lock(&vobj->lock);
	if (vobj->ptr == NULL) {
		spin_unlock(&vobj->lock);
		return;
	}
	vobj->ptr = NULL;
	spin_unlock(&vobj->lock);
	ttm_bo_kunmap(&vobj->kmap);
}
EXPORT_SYMBOL(via_chrome9_buffer_object_kunmap);

/**
 * Register to the bo->destroy and destroy the via_chrome9_object while list_kref equal to zero
 */
static void
via_chrome9_buffer_object_destroy(struct ttm_buffer_object *bo)
{
	struct via_chrome9_object *vobj;

	vobj = container_of(bo, struct via_chrome9_object, bo);
	kfree(vobj);
	vobj = NULL;
}
/**
 * the buffer object domain
 */
void via_ttm_placement_from_domain(struct via_chrome9_object *vbo, u32 domain)
{
	u32 np = 0, nb = 0;
	int i;

	vbo->placement.fpfn = 0;
	vbo->placement.lpfn = 0;
	vbo->placement.placement = vbo->placements;
	vbo->placement.busy_placement = vbo->busy_placements;
	if (domain & VIA_CHROME9_GEM_DOMAIN_VRAM) {
		vbo->placements[np++] = TTM_PL_FLAG_WC | TTM_PL_FLAG_UNCACHED |
					TTM_PL_FLAG_VRAM;
		vbo->busy_placements[nb++] = TTM_PL_FLAG_WC | TTM_PL_FLAG_VRAM;
	}

	if (domain & VIA_CHROME9_GEM_DOMAIN_GTT) {
		vbo->placements[np++] = TTM_PL_MASK_CACHING | TTM_PL_FLAG_TT;
		vbo->busy_placements[nb++] = TTM_PL_FLAG_TT |
			TTM_PL_MASK_CACHING;
	}
	if (domain & VIA_CHROME9_GEM_DOMAIN_CPU)
		vbo->placements[np++] = TTM_PL_MASK_CACHING |
			TTM_PL_FLAG_SYSTEM;
	if (!np)
		vbo->placements[np++] = TTM_PL_MASK_CACHING |
			TTM_PL_FLAG_SYSTEM;
	vbo->placement.num_placement = np;
	vbo->placement.num_busy_placement = nb;

	/* add the no evict flag for buffer object */
	if (domain & TTM_PL_FLAG_NO_EVICT) {
		for (i = 0; i < vbo->placement.num_placement; i++)
			vbo->placements[i] |= TTM_PL_FLAG_NO_EVICT;
	}
}

/**
 * Creat a via_chrome9_buffer_object
 */
int
via_chrome9_buffer_object_create(struct ttm_bo_device *bdev,
			unsigned long size,
			enum ttm_bo_type type,
			uint32_t flags,
			uint32_t page_alignment,
			unsigned long buffer_start,
			bool interruptible,
			struct file *persistant_swap_storage,
			struct via_chrome9_object **p_bo)
{
	struct drm_via_chrome9_private *dev_priv;
	struct via_chrome9_object *vobj;
	int ret;
	size_t acc_size;
	
	dev_priv = container_of(bdev, struct drm_via_chrome9_private, bdev);
	if (unlikely(bdev->dev_mapping == NULL))
		bdev->dev_mapping = dev_priv->ddev->dev_mapping;

	vobj = kzalloc(sizeof(struct via_chrome9_object), GFP_KERNEL);
	if (unlikely(vobj == NULL))
		return -ENOMEM;

	spin_lock_init(&vobj->lock);
	via_ttm_placement_from_domain(vobj, flags);

	acc_size = ttm_bo_dma_acc_size(bdev, size,
				sizeof(struct via_chrome9_object));
		
#if (((LINUX_VERSION_CODE >= KERNEL_VERSION(3,5,5)) && (LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0))) || (KERNEL_VERSION(3,5,35) == (LINUX_VERSION_CODE + 28)))
	ret = ttm_bo_init(bdev, &vobj->bo, size, type, &vobj->placement,
				     page_alignment, buffer_start,
				     interruptible,
				     persistant_swap_storage, acc_size, NULL,
				     &via_chrome9_buffer_object_destroy);
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(3,8,0)
	ret = ttm_bo_init(bdev, &vobj->bo, size, type, &vobj->placement,
				     page_alignment, 
				     interruptible,
				     persistant_swap_storage, acc_size, NULL,
				     &via_chrome9_buffer_object_destroy);
#else
	ret = ttm_bo_init(bdev, &vobj->bo, size, type, &vobj->placement,
				     page_alignment, buffer_start,
				     interruptible,
				     persistant_swap_storage, acc_size,
				     &via_chrome9_buffer_object_destroy);
#endif
	if (unlikely(ret != 0)) {
		DRM_ERROR("Failed to allocate TTM object %ld\n", size);
		return ret;
	}
	/* Init read/write domain*/
	vobj->read_domain = VIA_CHROME9_OBJ_DOMAIN_CPU |
		VIA_CHROME9_OBJ_DOMAIN_GPU;
	vobj->write_domain = VIA_CHROME9_OBJ_DOMAIN_CPU |
		VIA_CHROME9_OBJ_DOMAIN_GPU;
	INIT_LIST_HEAD(&vobj->snoop_list);
	*p_bo = vobj;
	vobj->dev = dev_priv->ddev;

	return 0;
}
/*For v4l module*/
int
via_chrome9_buffer_object_create2(unsigned long size,
			enum ttm_bo_type type,
			uint32_t flags,
			uint32_t page_alignment,
			unsigned long buffer_start,
			bool interruptible,
			struct file *persistant_swap_storage,
			struct via_chrome9_object **p_bo)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)drm_dev_v4l->dev_private;

	return via_chrome9_buffer_object_create(&dev_priv->bdev, size, type,
			flags, page_alignment, buffer_start, interruptible,
			persistant_swap_storage, p_bo);
}
EXPORT_SYMBOL(via_chrome9_buffer_object_create2);

/**
 * wait this bo idle
 */
int via_chrome9_object_wait(struct via_chrome9_object *vobj, bool no_wait)
{
	int ret = 0;
/*
	struct drm_device *dev = vobj->dev;
       struct drm_via_chrome9_private *dev_priv =
			(struct drm_via_chrome9_private *)
			dev->dev_private;
	struct drm_via_chrome9_dma_manager *lpcmdmamanager =
			(struct drm_via_chrome9_dma_manager *)
			dev_priv->dma_manager;

	mutex_lock(&lpcmdmamanager->command_flush_lock);
*/
	ret = ttm_bo_reserve(&vobj->bo, true, false, false, 0);
	if (unlikely(ret != 0)) {
		DRM_ERROR("failed reserve the bo for object wait\n");
		goto error;
	}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
	spin_lock(&vobj->bo.bdev->fence_lock);
#else
	spin_lock(&vobj->bo.lock);
#endif
	if (vobj->bo.sync_obj)
		ret = ttm_bo_wait(&vobj->bo, true, false, no_wait);

	/* clear command flush flag */
	if (0 == ret)
		clear_bit(VIA_CHROME9_BO_FLAG_CMD_FLUSHING, &vobj->flags);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,38)
	spin_unlock(&vobj->bo.bdev->fence_lock);
#else
	spin_unlock(&vobj->bo.lock);
#endif
	ttm_bo_unreserve(&vobj->bo);
error:
/*	mutex_unlock(&lpcmdmamanager->command_flush_lock); */
	return ret;
}

/**
  * kmap this buffer object and return the virtual address
  */
int via_chrome9_buffer_object_kmap(struct via_chrome9_object *vobj, void **ptr)
{
	int ret;

	spin_lock(&vobj->lock);
	if (vobj->ptr) {
		if (ptr)
			*ptr = vobj->ptr;

		spin_unlock(&vobj->lock);
		return 0;
	}
	spin_unlock(&vobj->lock);

	ret = ttm_bo_reserve(&vobj->bo, false, false, false, 0);
	if (ret)
		return ret;

	ret = ttm_bo_kmap(&vobj->bo, 0, vobj->bo.num_pages, &vobj->kmap);
	if (ret) {
		DRM_ERROR(" kmap the buffer object error\n");
		ttm_bo_unreserve(&vobj->bo);
		return ret;
	}
	ttm_bo_unreserve(&vobj->bo);

	spin_lock(&vobj->lock);
	vobj->ptr = ttm_kmap_obj_virtual(&vobj->kmap, &vobj->iomem);
	spin_unlock(&vobj->lock);
	if (ptr)
		*ptr = vobj->ptr;

	return 0;
}
EXPORT_SYMBOL(via_chrome9_buffer_object_kmap);


/**
  * use mmap to map this buffer object
  */
int via_chrome9_object_mmap(struct drm_file *file_priv,
				struct via_chrome9_object *vobj,
				uint64_t size, uint64_t *offset, void **virtual)
{
	*offset = vobj->bo.addr_space_offset;
#if !(LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0))
	down_write(&current->mm->mmap_sem);
	*virtual = (void *)do_mmap_pgoff(file_priv->filp, 0, size,
		PROT_READ | PROT_WRITE, MAP_SHARED,
		vobj->bo.addr_space_offset >> PAGE_SHIFT);
	up_write(&current->mm->mmap_sem);
#endif

	if (*virtual == ((void *)-1))
		return  -ENOMEM;

	return 0;
}

static int via_chrome9_ttm_fault(struct vm_area_struct *vma,
	struct vm_fault *vmf)
{
	struct ttm_buffer_object *bo;
	int r;

	bo = (struct ttm_buffer_object *)vma->vm_private_data;
	if (bo == NULL)
		return VM_FAULT_NOPAGE;

	r = ttm_vm_ops->fault(vma, vmf);
	return r;
}

/**
  * file operation mmap
  */
int via_chrome9_mmap(struct file *filp, struct vm_area_struct *vma)
{
	struct drm_file *file_priv;
	struct drm_via_chrome9_private *dev_priv;
	int ret;

	if (unlikely(vma->vm_pgoff < DRM_FILE_PAGE_OFFSET))
		return drm_mmap(filp, vma);

	file_priv = (struct drm_file *)filp->private_data;
	dev_priv = file_priv->minor->dev->dev_private;
	if (dev_priv == NULL)
		return -EINVAL;

	ret = ttm_bo_mmap(filp, vma, &dev_priv->bdev);
	if (unlikely(ret != 0))
		return ret;

	if (unlikely(ttm_vm_ops == NULL)) {
		ttm_vm_ops = vma->vm_ops;
		via_chrome9_ttm_vm_ops = *ttm_vm_ops;
		via_chrome9_ttm_vm_ops.fault = &via_chrome9_ttm_fault;
	}
	vma->vm_ops = &via_chrome9_ttm_vm_ops;

	return 0;
}

/**
 * Allocate the bo for vq gart table and ring buffer
 */
int via_chrome9_allocate_basic_bo(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;
	int ret;

	/* allocate vq bo */
	ret = via_chrome9_buffer_object_create(&dev_priv->bdev, DEV_VQ_MEMORY,
				       ttm_bo_type_kernel,
				       TTM_PL_FLAG_VRAM |
				       TTM_PL_FLAG_NO_EVICT,
				       0, 0, false, NULL, &dev_priv->vq);
	if (unlikely(ret))
		return ret;

	/* allocate gart table bo */
	ret = via_chrome9_buffer_object_create(&dev_priv->bdev,
					(dev_priv->pcie_mem_size >> 10),
					ttm_bo_type_kernel,
					TTM_PL_FLAG_VRAM | TTM_PL_FLAG_NO_EVICT,
					0, 0, false, NULL, &dev_priv->agp_gart);
	if (unlikely(ret))
		goto out_err0;
	dev_priv->pcie_gart_start = dev_priv->agp_gart->bo.offset;

	/* kmap the gart table */
	ret = via_chrome9_buffer_object_kmap(dev_priv->agp_gart,
		(void **)&dev_priv->pcie_gart_map);
	if (ret) {
		DRM_ERROR("kmap the gart table error");
		goto out_err1;
	}

	/* allocate ring buffer here */
	dev_priv->ring_buffer_size = DEV_COMMAND_BUFFER_MEMORY;
	ret = via_chrome9_buffer_object_create(&dev_priv->bdev,
		dev_priv->ring_buffer_size,
		ttm_bo_type_kernel,
		TTM_PL_FLAG_TT |
		TTM_PL_FLAG_NO_EVICT,
		0, 0, false, NULL, &dev_priv->agp_ringbuffer);
	if (unlikely(ret)) {
		DRM_ERROR("allocate the ringbuffer error");
		goto out_err2;
	}

	/* change ringbuffer attribute to TTM_PL_FLAG_WC */
	ttm_tt_set_placement_caching(dev_priv->agp_ringbuffer->bo.ttm,
		TTM_PL_FLAG_WC);
	ttm_flag_masked(&dev_priv->agp_ringbuffer->bo.mem.placement,
		TTM_PL_FLAG_WC, TTM_PL_MASK_CACHING);

	/* kmap the ring buffer */
	ret = via_chrome9_buffer_object_kmap(dev_priv->agp_ringbuffer,
		(void **)&dev_priv->pcie_ringbuffer_map);
	if (unlikely(ret)) {
		DRM_ERROR("kmap the ringbuffer error");
		goto out_err3;
	}

	/*allocate shadow gart-table for apci store*/
	ret = via_chrome9_buffer_object_create(&dev_priv->bdev,
		(dev_priv->pcie_mem_size >> 10),
		ttm_bo_type_kernel,
		TTM_PL_FLAG_TT | TTM_PL_FLAG_NO_EVICT,
		0, 0, false, NULL, &dev_priv->pm_backup.agp_gart_shadow);
	if (unlikely(ret))
		goto out_err3;

	ret = via_chrome9_buffer_object_kmap(
		dev_priv->pm_backup.agp_gart_shadow, NULL);
	if (ret) {
		DRM_ERROR("kmap the gart table error");
		goto out_err4;
	}

	return 0;

out_err4:
	via_chrome9_buffer_object_unref(&dev_priv->pm_backup.agp_gart_shadow);
out_err3:
	via_chrome9_buffer_object_unref(&dev_priv->agp_ringbuffer);
out_err2:
	via_chrome9_buffer_object_kunmap(dev_priv->agp_gart);
	dev_priv->pcie_gart_map = NULL;
out_err1:
	via_chrome9_buffer_object_unref(&dev_priv->agp_gart);
out_err0:
	via_chrome9_buffer_object_unref(&dev_priv->vq);
	return ret;
}

/*evict vram BO (can be evicted) to system memory*/
int via_chrome9_evict_vram(struct drm_device *dev)
{
	struct drm_via_chrome9_private *dev_priv =
		(struct drm_via_chrome9_private *)dev->dev_private;

	return ttm_bo_evict_mm(&dev_priv->bdev, TTM_PL_VRAM);
}

/*Pin a BO to a memory type with NO_EVICT*/

int via_chrome9_bo_pin(struct via_chrome9_object *bo, u32 domain, u64 *gpu_addr)
{
	int r, i;

	r = ttm_bo_reserve(&bo->bo, true, false, false, 0);
	if (unlikely(r != 0))
		return r;

	via_ttm_placement_from_domain(bo, domain);
	for (i = 0; i < bo->placement.num_placement; i++)
		bo->placements[i] |= TTM_PL_FLAG_NO_EVICT;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
	r = ttm_bo_validate(&bo->bo, &bo->placement, false, false, false);
#else
	r = ttm_bo_validate(&bo->bo, &bo->placement, false, false);
#endif	
	if (likely(r == 0)) {
		if (gpu_addr != NULL)
			*gpu_addr = bo->bo.offset;
	}
	if (unlikely(r != 0))
		DRM_ERROR("via_chrome9 pin failed\n");

	ttm_bo_unreserve(&bo->bo);
	return r;
}
EXPORT_SYMBOL(via_chrome9_bo_pin);

/*Remove the NO_EVICT attribute of a BO*/

int via_chrome9_bo_unpin(struct via_chrome9_object *bo)
{
	int r, i;
	r = ttm_bo_reserve(&bo->bo, true, false, false, 0);
	if (unlikely(r != 0))
		return r;

	for (i = 0; i < bo->placement.num_placement; i++)
		bo->placements[i] &= ~TTM_PL_FLAG_NO_EVICT;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
	r = ttm_bo_validate(&bo->bo, &bo->placement, false, false, false);
#else
	r = ttm_bo_validate(&bo->bo, &bo->placement, false, false);
#endif	
	if (unlikely(r != 0))
		DRM_ERROR("via_chrome9 unpin failed\n");

	ttm_bo_unreserve(&bo->bo);
	return r;
}
EXPORT_SYMBOL(via_chrome9_bo_unpin);

/*
 * Handle BO domain changes between SYS & GTT
 * only set to cpu read/write domain
 */
int via_chrome9_object_set_domain(struct via_chrome9_object *bo,
		u32 domain)
{
	int r;

	/* only handle setting to CPU read/write domain
	 */
	BUG_ON((bo->pending_write_domain | bo->pending_read_domain) &
					VIA_CHROME9_OBJ_DOMAIN_GPU);

	/* Disable VRAM set cpu domain function, let CPU write/read WC VRAM
	** directly instead of moving BO into system RAM and read/write there.
	** Or sometimes, the move function will hangs.
	*/
	if (bo->bo.mem.placement & TTM_PL_FLAG_VRAM)
		return 0;

	r = ttm_bo_reserve(&bo->bo, true, false, false, 0);
	if (unlikely(r != 0))
		return r;

	via_ttm_placement_from_domain(bo, domain);

	/*
	 * handle bo move between SYS/GTT/VRAM
	 * and cache coherence when GTT is cached
	 * */
	if (!(domain & bo->bo.mem.placement & TTM_PL_MASK_MEM))
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
		r = ttm_bo_validate(&bo->bo, &bo->placement, false, false,
		false);
#else
		r = ttm_bo_validate(&bo->bo, &bo->placement, false,
		false);	
#endif
	else /* may need to flush GPU cache */
		via_chrome9_set_cpu_domain(&bo->bo, domain);

	if (unlikely(r != 0))
		DRM_ERROR("via_chrome9 set domain= %x failed\n", domain);
	ttm_bo_unreserve(&bo->bo);
	return r;
}

/*GPU wait CPU
 * Note: The caller must have reserved the bo
 */
int via_chrome9_object_wait_cpu_access(
	struct via_chrome9_object *bo, struct drm_file *file_priv)
{
	int ret = 0;
	if (likely((atomic_read(&bo->bo.cpu_writers) > 0))) {
		if (bo->owner_file) {
			BUG_ON(file_priv == bo->owner_file);
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,8,0)
			ret = ttm_bo_wait_cpu(&bo->bo, false);
#else
			ttm_bo_wait_unreserved(&bo->bo,false);
#endif			
			if (ret) {
				DRM_ERROR("via_chrome9: reserve bo is "
				"interrupted when GPU awaitting cpu\n");
			}
		}
	}
	return ret;
}

